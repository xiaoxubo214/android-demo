package a.a.a.a;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.Application;
import android.app.Application.ActivityLifecycleCallbacks;
import android.content.Context;
import android.os.Build.VERSION;
import android.os.Bundle;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class a
{
  private final Application a;
  private a b;

  public a(Context paramContext)
  {
    this.a = ((Application)paramContext.getApplicationContext());
    if (Build.VERSION.SDK_INT >= 14)
      this.b = new a(this.a);
  }

  public void a()
  {
    if (this.b != null)
      a.a(this.b);
  }

  public boolean a(b paramb)
  {
    return (this.b != null) && (a.a(this.b, paramb));
  }

  private static class a
  {
    private final Set<Application.ActivityLifecycleCallbacks> a = new HashSet();
    private final Application b;

    a(Application paramApplication)
    {
      this.b = paramApplication;
    }

    @TargetApi(14)
    private void a()
    {
      Iterator localIterator = this.a.iterator();
      while (localIterator.hasNext())
      {
        Application.ActivityLifecycleCallbacks localActivityLifecycleCallbacks = (Application.ActivityLifecycleCallbacks)localIterator.next();
        this.b.unregisterActivityLifecycleCallbacks(localActivityLifecycleCallbacks);
      }
    }

    @TargetApi(14)
    private boolean a(a.b paramb)
    {
      if (this.b != null)
      {
        b localb = new b(this, paramb);
        this.b.registerActivityLifecycleCallbacks(localb);
        this.a.add(localb);
        return true;
      }
      return false;
    }
  }

  public static abstract class b
  {
    public void a(Activity paramActivity)
    {
    }

    public void a(Activity paramActivity, Bundle paramBundle)
    {
    }

    public void b(Activity paramActivity)
    {
    }

    public void b(Activity paramActivity, Bundle paramBundle)
    {
    }

    public void c(Activity paramActivity)
    {
    }

    public void d(Activity paramActivity)
    {
    }

    public void e(Activity paramActivity)
    {
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a
 * JD-Core Version:    0.6.2
 */