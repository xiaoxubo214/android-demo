package a.a.a.a.a.a;

import android.content.Context;

public abstract class a<T>
  implements c<T>
{
  private final c<T> a;

  public a()
  {
    this(null);
  }

  public a(c<T> paramc)
  {
    this.a = paramc;
  }

  private void b(Context paramContext, T paramT)
  {
    if (paramT == null)
      throw new NullPointerException();
    a(paramContext, paramT);
  }

  public final T a(Context paramContext, d<T> paramd)
    throws Exception
  {
    try
    {
      Object localObject2 = c(paramContext);
      if (localObject2 == null)
        if (this.a == null)
          break label46;
      label46: Object localObject3;
      for (localObject2 = this.a.a(paramContext, paramd); ; localObject2 = localObject3)
      {
        b(paramContext, localObject2);
        return localObject2;
        localObject3 = paramd.b(paramContext);
      }
    }
    finally
    {
    }
  }

  public final void a(Context paramContext)
  {
    try
    {
      b(paramContext);
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  protected abstract void a(Context paramContext, T paramT);

  protected abstract void b(Context paramContext);

  protected abstract T c(Context paramContext);
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.a.a
 * JD-Core Version:    0.6.2
 */