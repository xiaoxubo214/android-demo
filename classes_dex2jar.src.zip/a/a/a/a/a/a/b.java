package a.a.a.a.a.a;

import android.content.Context;

public class b<T> extends a<T>
{
  private T a;

  public b()
  {
    this(null);
  }

  public b(c<T> paramc)
  {
    super(paramc);
  }

  protected void a(Context paramContext, T paramT)
  {
    this.a = paramT;
  }

  protected void b(Context paramContext)
  {
    this.a = null;
  }

  protected T c(Context paramContext)
  {
    return this.a;
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.a.b
 * JD-Core Version:    0.6.2
 */