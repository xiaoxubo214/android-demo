package a.a.a.a.a.a;

import android.content.Context;

public abstract interface c<T>
{
  public abstract T a(Context paramContext, d<T> paramd)
    throws Exception;

  public abstract void a(Context paramContext);
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.a.c
 * JD-Core Version:    0.6.2
 */