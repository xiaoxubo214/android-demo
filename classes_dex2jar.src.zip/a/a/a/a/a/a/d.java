package a.a.a.a.a.a;

import android.content.Context;

public abstract interface d<T>
{
  public abstract T b(Context paramContext)
    throws Exception;
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.a.d
 * JD-Core Version:    0.6.2
 */