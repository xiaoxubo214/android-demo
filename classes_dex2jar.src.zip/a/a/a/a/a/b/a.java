package a.a.a.a.a.b;

import a.a.a.a.a.e.d;
import a.a.a.a.a.e.e;
import a.a.a.a.a.e.o;
import a.a.a.a.n;
import java.util.Collections;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public abstract class a
{
  private static final Pattern a = Pattern.compile("http(s?)://[^\\/]+", 2);
  public static final String h = "X-CRASHLYTICS-API-KEY";
  public static final String i = "X-CRASHLYTICS-DEVELOPER-TOKEN";
  public static final String j = "X-CRASHLYTICS-API-CLIENT-TYPE";
  public static final String k = "X-CRASHLYTICS-API-CLIENT-VERSION";
  public static final String l = "X-REQUEST-ID";
  public static final String m = "User-Agent";
  public static final String n = "Accept";
  public static final String o = "Crashlytics Android SDK/";
  public static final String p = "application/json";
  public static final String q = "470fa2b4ae81cd56ecbcda9735803434cec591fa";
  public static final int r = 10000;
  public static final String s = "android";
  private final String b;
  private final o c;
  private final d d;
  private final String e;
  protected final n t;

  public a(n paramn, String paramString1, String paramString2, o paramo, d paramd)
  {
    if (paramString2 == null)
      throw new IllegalArgumentException("url must not be null.");
    if (paramo == null)
      throw new IllegalArgumentException("requestFactory must not be null.");
    this.t = paramn;
    this.e = paramString1;
    this.b = a(paramString2);
    this.c = paramo;
    this.d = paramd;
  }

  private String a(String paramString)
  {
    if (!k.e(this.e))
      paramString = a.matcher(paramString).replaceFirst(this.e);
    return paramString;
  }

  protected e a(Map<String, String> paramMap)
  {
    return this.c.a(this.d, a(), paramMap).d(false).e(10000).a("User-Agent", "Crashlytics Android SDK/" + this.t.a()).a("X-CRASHLYTICS-DEVELOPER-TOKEN", "470fa2b4ae81cd56ecbcda9735803434cec591fa");
  }

  protected String a()
  {
    return this.b;
  }

  protected e b()
  {
    return a(Collections.emptyMap());
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.b.a
 * JD-Core Version:    0.6.2
 */