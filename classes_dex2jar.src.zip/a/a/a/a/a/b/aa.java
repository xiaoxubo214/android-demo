package a.a.a.a.a.b;

public class aa
{
  public static final int a = 0;
  public static final int b = 1;

  public static int a(int paramInt)
  {
    if ((paramInt >= 200) && (paramInt <= 299));
    do
    {
      return 0;
      if ((paramInt >= 300) && (paramInt <= 399))
        return 1;
    }
    while ((paramInt >= 400) && (paramInt <= 499));
    if (paramInt >= 500)
      return 1;
    return 1;
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.b.aa
 * JD-Core Version:    0.6.2
 */