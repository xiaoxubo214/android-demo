package a.a.a.a.a.b;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.Resources.NotFoundException;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

public class ab extends Toast
{
  public ab(Context paramContext)
  {
    super(paramContext);
  }

  public static Toast a(Context paramContext, int paramInt1, int paramInt2)
    throws Resources.NotFoundException
  {
    return a(paramContext, paramContext.getResources().getText(paramInt1), paramInt2);
  }

  public static Toast a(Context paramContext, CharSequence paramCharSequence, int paramInt)
  {
    Toast localToast = Toast.makeText(paramContext, paramCharSequence, paramInt);
    ab localab = new ab(paramContext);
    localab.setView(localToast.getView());
    localab.setDuration(localToast.getDuration());
    return localab;
  }

  public void show()
  {
    if (Looper.myLooper() == Looper.getMainLooper())
    {
      super.show();
      return;
    }
    new Handler(Looper.getMainLooper()).post(new ac(this));
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.b.ab
 * JD-Core Version:    0.6.2
 */