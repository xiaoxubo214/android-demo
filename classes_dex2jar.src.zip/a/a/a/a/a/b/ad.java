package a.a.a.a.a.b;

public class ad
  implements n
{
  public long a()
  {
    return System.currentTimeMillis();
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.b.ad
 * JD-Core Version:    0.6.2
 */