package a.a.a.a.a.b;

import android.os.SystemClock;
import android.util.Log;

public class ae
{
  private final String a;
  private final String b;
  private final boolean c;
  private long d;
  private long e;

  public ae(String paramString1, String paramString2)
  {
    this.a = paramString1;
    this.b = paramString2;
    if (!Log.isLoggable(paramString2, 2));
    for (boolean bool = true; ; bool = false)
    {
      this.c = bool;
      return;
    }
  }

  private void d()
  {
    Log.v(this.b, this.a + ": " + this.e + "ms");
  }

  public void a()
  {
    try
    {
      boolean bool = this.c;
      if (bool);
      while (true)
      {
        return;
        this.d = SystemClock.elapsedRealtime();
        this.e = 0L;
      }
    }
    finally
    {
    }
  }

  public void b()
  {
    try
    {
      boolean bool = this.c;
      if (bool);
      while (true)
      {
        return;
        if (this.e == 0L)
        {
          this.e = (SystemClock.elapsedRealtime() - this.d);
          d();
        }
      }
    }
    finally
    {
    }
  }

  public long c()
  {
    return this.e;
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.b.ae
 * JD-Core Version:    0.6.2
 */