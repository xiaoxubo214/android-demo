package a.a.a.a.a.b;

class b
{
  public final String a;
  public final boolean b;

  b(String paramString, boolean paramBoolean)
  {
    this.a = paramString;
    this.b = paramBoolean;
  }

  public boolean equals(Object paramObject)
  {
    if (this == paramObject);
    b localb;
    do
    {
      return true;
      if ((paramObject == null) || (getClass() != paramObject.getClass()))
        return false;
      localb = (b)paramObject;
      if (this.b != localb.b)
        return false;
      if (this.a == null)
        break;
    }
    while (this.a.equals(localb.a));
    while (true)
    {
      return false;
      if (localb.a == null)
        break;
    }
  }

  public int hashCode()
  {
    if (this.a != null);
    for (int i = this.a.hashCode(); ; i = 0)
    {
      int j = i * 31;
      boolean bool = this.b;
      int k = 0;
      if (bool)
        k = 1;
      return j + k;
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.b.b
 * JD-Core Version:    0.6.2
 */