package a.a.a.a.a.b;

import a.a.a.a.q;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.text.TextUtils;

class c
{
  private static final String a = "TwitterAdvertisingInfoPreferences";
  private static final String b = "limit_ad_tracking_enabled";
  private static final String c = "advertising_id";
  private final Context d;
  private final a.a.a.a.a.f.d e;

  public c(Context paramContext)
  {
    this.d = paramContext.getApplicationContext();
    this.e = new a.a.a.a.a.f.e(paramContext, "TwitterAdvertisingInfoPreferences");
  }

  private void a(b paramb)
  {
    new Thread(new d(this, paramb)).start();
  }

  @SuppressLint({"CommitPrefEdits"})
  private void b(b paramb)
  {
    if (c(paramb))
    {
      this.e.a(this.e.b().putString("advertising_id", paramb.a).putBoolean("limit_ad_tracking_enabled", paramb.b));
      return;
    }
    this.e.a(this.e.b().remove("advertising_id").remove("limit_ad_tracking_enabled"));
  }

  private boolean c(b paramb)
  {
    return (paramb != null) && (!TextUtils.isEmpty(paramb.a));
  }

  private b e()
  {
    b localb1 = c().a();
    if (!c(localb1))
    {
      b localb2 = d().a();
      if (!c(localb2))
      {
        a.a.a.a.e.i().a("Fabric", "AdvertisingInfo not present");
        return localb2;
      }
      a.a.a.a.e.i().a("Fabric", "Using AdvertisingInfo from Service Provider");
      return localb2;
    }
    a.a.a.a.e.i().a("Fabric", "Using AdvertisingInfo from Reflection Provider");
    return localb1;
  }

  public b a()
  {
    b localb1 = b();
    if (c(localb1))
    {
      a.a.a.a.e.i().a("Fabric", "Using AdvertisingInfo from Preference Store");
      a(localb1);
      return localb1;
    }
    b localb2 = e();
    b(localb2);
    return localb2;
  }

  protected b b()
  {
    return new b(this.e.a().getString("advertising_id", ""), this.e.a().getBoolean("limit_ad_tracking_enabled", false));
  }

  public h c()
  {
    return new e(this.d);
  }

  public h d()
  {
    return new f(this.d);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.b.c
 * JD-Core Version:    0.6.2
 */