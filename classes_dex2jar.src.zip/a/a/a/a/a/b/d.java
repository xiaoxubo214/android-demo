package a.a.a.a.a.b;

import a.a.a.a.e;
import a.a.a.a.q;

class d extends j
{
  d(c paramc, b paramb)
  {
  }

  public void a()
  {
    b localb = c.a(this.b);
    if (!this.a.equals(localb))
    {
      e.i().a("Fabric", "Asychronously getting Advertising Info and storing it to preferences");
      c.a(this.b, localb);
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.b.d
 * JD-Core Version:    0.6.2
 */