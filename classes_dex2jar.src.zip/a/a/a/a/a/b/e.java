package a.a.a.a.a.b;

import a.a.a.a.q;
import android.content.Context;
import java.lang.reflect.Method;

class e
  implements h
{
  private static final int a = 0;
  private static final String b = "com.google.android.gms.common.GooglePlayServicesUtil";
  private static final String c = "isGooglePlayServicesAvailable";
  private static final String d = "com.google.android.gms.ads.identifier.AdvertisingIdClient";
  private static final String e = "com.google.android.gms.ads.identifier.AdvertisingIdClient$Info";
  private static final String f = "getAdvertisingIdInfo";
  private static final String g = "getId";
  private static final String h = "isLimitAdTrackingEnabled";
  private final Context i;

  public e(Context paramContext)
  {
    this.i = paramContext.getApplicationContext();
  }

  private String b()
  {
    try
    {
      String str = (String)Class.forName("com.google.android.gms.ads.identifier.AdvertisingIdClient$Info").getMethod("getId", new Class[0]).invoke(d(), new Object[0]);
      return str;
    }
    catch (Exception localException)
    {
      a.a.a.a.e.i().d("Fabric", "Could not call getId on com.google.android.gms.ads.identifier.AdvertisingIdClient$Info");
    }
    return null;
  }

  private boolean c()
  {
    try
    {
      boolean bool = ((Boolean)Class.forName("com.google.android.gms.ads.identifier.AdvertisingIdClient$Info").getMethod("isLimitAdTrackingEnabled", new Class[0]).invoke(d(), new Object[0])).booleanValue();
      return bool;
    }
    catch (Exception localException)
    {
      a.a.a.a.e.i().d("Fabric", "Could not call isLimitAdTrackingEnabled on com.google.android.gms.ads.identifier.AdvertisingIdClient$Info");
    }
    return false;
  }

  private Object d()
  {
    try
    {
      Method localMethod = Class.forName("com.google.android.gms.ads.identifier.AdvertisingIdClient").getMethod("getAdvertisingIdInfo", new Class[] { Context.class });
      Object[] arrayOfObject = new Object[1];
      arrayOfObject[0] = this.i;
      Object localObject = localMethod.invoke(null, arrayOfObject);
      return localObject;
    }
    catch (Exception localException)
    {
      a.a.a.a.e.i().d("Fabric", "Could not call getAdvertisingIdInfo on com.google.android.gms.ads.identifier.AdvertisingIdClient");
    }
    return null;
  }

  public b a()
  {
    if (a(this.i))
      return new b(b(), c());
    return null;
  }

  boolean a(Context paramContext)
  {
    try
    {
      int j = ((Integer)Class.forName("com.google.android.gms.common.GooglePlayServicesUtil").getMethod("isGooglePlayServicesAvailable", new Class[] { Context.class }).invoke(null, new Object[] { paramContext })).intValue();
      return j == 0;
    }
    catch (Exception localException)
    {
    }
    return false;
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.b.e
 * JD-Core Version:    0.6.2
 */