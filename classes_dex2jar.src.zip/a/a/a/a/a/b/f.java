package a.a.a.a.a.b;

import a.a.a.a.e;
import a.a.a.a.q;
import android.content.ComponentName;
import android.content.Context;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

class f
  implements h
{
  public static final String a = "com.google.android.gms.ads.identifier.service.START";
  public static final String b = "com.google.android.gms";
  private static final String c = "com.android.vending";
  private final Context d;

  public f(Context paramContext)
  {
    this.d = paramContext.getApplicationContext();
  }

  // ERROR //
  public b a()
  {
    // Byte code:
    //   0: invokestatic 44	android/os/Looper:myLooper	()Landroid/os/Looper;
    //   3: invokestatic 47	android/os/Looper:getMainLooper	()Landroid/os/Looper;
    //   6: if_acmpne +17 -> 23
    //   9: invokestatic 53	a/a/a/a/e:i	()La/a/a/a/q;
    //   12: ldc 55
    //   14: ldc 57
    //   16: invokeinterface 62 3 0
    //   21: aconst_null
    //   22: areturn
    //   23: aload_0
    //   24: getfield 31	a/a/a/a/a/b/f:d	Landroid/content/Context;
    //   27: invokevirtual 66	android/content/Context:getPackageManager	()Landroid/content/pm/PackageManager;
    //   30: ldc 16
    //   32: iconst_0
    //   33: invokevirtual 72	android/content/pm/PackageManager:getPackageInfo	(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;
    //   36: pop
    //   37: new 74	a/a/a/a/a/b/f$a
    //   40: dup
    //   41: aconst_null
    //   42: invokespecial 77	a/a/a/a/a/b/f$a:<init>	(La/a/a/a/a/b/g;)V
    //   45: astore 4
    //   47: new 79	android/content/Intent
    //   50: dup
    //   51: ldc 10
    //   53: invokespecial 82	android/content/Intent:<init>	(Ljava/lang/String;)V
    //   56: astore 5
    //   58: aload 5
    //   60: ldc 13
    //   62: invokevirtual 86	android/content/Intent:setPackage	(Ljava/lang/String;)Landroid/content/Intent;
    //   65: pop
    //   66: aload_0
    //   67: getfield 31	a/a/a/a/a/b/f:d	Landroid/content/Context;
    //   70: aload 5
    //   72: aload 4
    //   74: iconst_1
    //   75: invokevirtual 90	android/content/Context:bindService	(Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z
    //   78: istore 8
    //   80: iload 8
    //   82: ifeq +138 -> 220
    //   85: new 92	a/a/a/a/a/b/f$b
    //   88: dup
    //   89: aload 4
    //   91: invokevirtual 95	a/a/a/a/a/b/f$a:a	()Landroid/os/IBinder;
    //   94: invokespecial 98	a/a/a/a/a/b/f$b:<init>	(Landroid/os/IBinder;)V
    //   97: astore 9
    //   99: new 100	a/a/a/a/a/b/b
    //   102: dup
    //   103: aload 9
    //   105: invokevirtual 103	a/a/a/a/a/b/f$b:a	()Ljava/lang/String;
    //   108: aload 9
    //   110: invokevirtual 106	a/a/a/a/a/b/f$b:b	()Z
    //   113: invokespecial 109	a/a/a/a/a/b/b:<init>	(Ljava/lang/String;Z)V
    //   116: astore 10
    //   118: aload_0
    //   119: getfield 31	a/a/a/a/a/b/f:d	Landroid/content/Context;
    //   122: aload 4
    //   124: invokevirtual 113	android/content/Context:unbindService	(Landroid/content/ServiceConnection;)V
    //   127: aload 10
    //   129: areturn
    //   130: astore_2
    //   131: invokestatic 53	a/a/a/a/e:i	()La/a/a/a/q;
    //   134: ldc 55
    //   136: ldc 115
    //   138: invokeinterface 62 3 0
    //   143: aconst_null
    //   144: areturn
    //   145: astore_1
    //   146: invokestatic 53	a/a/a/a/e:i	()La/a/a/a/q;
    //   149: ldc 55
    //   151: ldc 117
    //   153: aload_1
    //   154: invokeinterface 120 4 0
    //   159: aconst_null
    //   160: areturn
    //   161: astore 12
    //   163: invokestatic 53	a/a/a/a/e:i	()La/a/a/a/q;
    //   166: ldc 55
    //   168: ldc 122
    //   170: aload 12
    //   172: invokeinterface 124 4 0
    //   177: aload_0
    //   178: getfield 31	a/a/a/a/a/b/f:d	Landroid/content/Context;
    //   181: aload 4
    //   183: invokevirtual 113	android/content/Context:unbindService	(Landroid/content/ServiceConnection;)V
    //   186: aconst_null
    //   187: areturn
    //   188: astore 7
    //   190: invokestatic 53	a/a/a/a/e:i	()La/a/a/a/q;
    //   193: ldc 55
    //   195: ldc 126
    //   197: aload 7
    //   199: invokeinterface 120 4 0
    //   204: aconst_null
    //   205: areturn
    //   206: astore 11
    //   208: aload_0
    //   209: getfield 31	a/a/a/a/a/b/f:d	Landroid/content/Context;
    //   212: aload 4
    //   214: invokevirtual 113	android/content/Context:unbindService	(Landroid/content/ServiceConnection;)V
    //   217: aload 11
    //   219: athrow
    //   220: invokestatic 53	a/a/a/a/e:i	()La/a/a/a/q;
    //   223: ldc 55
    //   225: ldc 126
    //   227: invokeinterface 62 3 0
    //   232: aconst_null
    //   233: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   23	37	130	android/content/pm/PackageManager$NameNotFoundException
    //   23	37	145	java/lang/Exception
    //   85	118	161	java/lang/Exception
    //   66	80	188	java/lang/Throwable
    //   118	127	188	java/lang/Throwable
    //   177	186	188	java/lang/Throwable
    //   208	220	188	java/lang/Throwable
    //   220	232	188	java/lang/Throwable
    //   85	118	206	finally
    //   163	177	206	finally
  }

  private static final class a
    implements ServiceConnection
  {
    private static final int a = 200;
    private boolean b = false;
    private final LinkedBlockingQueue<IBinder> c = new LinkedBlockingQueue(1);

    public IBinder a()
    {
      if (this.b)
        e.i().e("Fabric", "getBinder already called");
      this.b = true;
      try
      {
        IBinder localIBinder = (IBinder)this.c.poll(200L, TimeUnit.MILLISECONDS);
        return localIBinder;
      }
      catch (InterruptedException localInterruptedException)
      {
      }
      return null;
    }

    public void onServiceConnected(ComponentName paramComponentName, IBinder paramIBinder)
    {
      try
      {
        this.c.put(paramIBinder);
        return;
      }
      catch (InterruptedException localInterruptedException)
      {
      }
    }

    public void onServiceDisconnected(ComponentName paramComponentName)
    {
      this.c.clear();
    }
  }

  private static final class b
    implements IInterface
  {
    public static final String a = "com.google.android.gms.ads.identifier.internal.IAdvertisingIdService";
    private static final int b = 0;
    private static final int c = 1;
    private static final int d = 2;
    private final IBinder e;

    public b(IBinder paramIBinder)
    {
      this.e = paramIBinder;
    }

    public String a()
      throws RemoteException
    {
      Parcel localParcel1 = Parcel.obtain();
      Parcel localParcel2 = Parcel.obtain();
      try
      {
        localParcel1.writeInterfaceToken("com.google.android.gms.ads.identifier.internal.IAdvertisingIdService");
        this.e.transact(1, localParcel1, localParcel2, 0);
        localParcel2.readException();
        String str = localParcel2.readString();
        return str;
      }
      catch (Exception localException)
      {
        e.i().a("Fabric", "Could not get parcel from Google Play Service to capture AdvertisingId");
        return null;
      }
      finally
      {
        localParcel2.recycle();
        localParcel1.recycle();
      }
    }

    public IBinder asBinder()
    {
      return this.e;
    }

    public boolean b()
      throws RemoteException
    {
      boolean bool = true;
      Parcel localParcel1 = Parcel.obtain();
      Parcel localParcel2 = Parcel.obtain();
      try
      {
        localParcel1.writeInterfaceToken("com.google.android.gms.ads.identifier.internal.IAdvertisingIdService");
        localParcel1.writeInt(1);
        this.e.transact(2, localParcel1, localParcel2, 0);
        localParcel2.readException();
        int i = localParcel2.readInt();
        if (i != 0);
        while (true)
        {
          return bool;
          bool = false;
        }
      }
      catch (Exception localException)
      {
        e.i().a("Fabric", "Could not get parcel from Google Play Service to capture Advertising limitAdTracking");
        return false;
      }
      finally
      {
        localParcel2.recycle();
        localParcel1.recycle();
      }
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.b.f
 * JD-Core Version:    0.6.2
 */