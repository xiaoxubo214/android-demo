package a.a.a.a.a.b;

import a.a.a.a.e;
import a.a.a.a.q;
import android.content.Context;
import android.content.res.Resources;
import android.text.TextUtils;

public class i
{
  static final String a = "io.fabric.ApiKey";
  static final String b = "com.crashlytics.ApiKey";
  static final String c = "@string/twitter_consumer_secret";

  @Deprecated
  public static String a(Context paramContext)
  {
    e.i().d("Fabric", "getApiKey(context) is deprecated, please upgrade kit(s) to the latest version.");
    return new i().b(paramContext);
  }

  @Deprecated
  public static String a(Context paramContext, boolean paramBoolean)
  {
    e.i().d("Fabric", "getApiKey(context, debug) is deprecated, please upgrade kit(s) to the latest version.");
    return new i().b(paramContext);
  }

  protected String a()
  {
    return "Fabric could not be initialized, API key missing from AndroidManifest.xml. Add the following tag to your Application element \n\t<meta-data android:name=\"io.fabric.ApiKey\" android:value=\"YOUR_API_KEY\"/>";
  }

  public String b(Context paramContext)
  {
    String str = d(paramContext);
    if (TextUtils.isEmpty(str))
      str = e(paramContext);
    if (TextUtils.isEmpty(str))
      str = c(paramContext);
    if (TextUtils.isEmpty(str))
      f(paramContext);
    return str;
  }

  protected String c(Context paramContext)
  {
    return new u().a(paramContext);
  }

  // ERROR //
  protected String d(Context paramContext)
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore_2
    //   2: aload_1
    //   3: invokevirtual 74	android/content/Context:getPackageName	()Ljava/lang/String;
    //   6: astore 4
    //   8: aload_1
    //   9: invokevirtual 78	android/content/Context:getPackageManager	()Landroid/content/pm/PackageManager;
    //   12: aload 4
    //   14: sipush 128
    //   17: invokevirtual 84	android/content/pm/PackageManager:getApplicationInfo	(Ljava/lang/String;I)Landroid/content/pm/ApplicationInfo;
    //   20: getfield 90	android/content/pm/ApplicationInfo:metaData	Landroid/os/Bundle;
    //   23: astore 5
    //   25: aconst_null
    //   26: astore_2
    //   27: aload 5
    //   29: ifnull +62 -> 91
    //   32: aload 5
    //   34: ldc 8
    //   36: invokevirtual 96	android/os/Bundle:getString	(Ljava/lang/String;)Ljava/lang/String;
    //   39: astore 6
    //   41: ldc 14
    //   43: aload 6
    //   45: invokevirtual 102	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   48: ifeq +88 -> 136
    //   51: invokestatic 26	a/a/a/a/e:i	()La/a/a/a/q;
    //   54: ldc 28
    //   56: ldc 104
    //   58: invokeinterface 106 3 0
    //   63: aload_2
    //   64: ifnonnull +27 -> 91
    //   67: invokestatic 26	a/a/a/a/e:i	()La/a/a/a/q;
    //   70: ldc 28
    //   72: ldc 108
    //   74: invokeinterface 106 3 0
    //   79: aload 5
    //   81: ldc 11
    //   83: invokevirtual 96	android/os/Bundle:getString	(Ljava/lang/String;)Ljava/lang/String;
    //   86: astore 8
    //   88: aload 8
    //   90: astore_2
    //   91: aload_2
    //   92: areturn
    //   93: astore_3
    //   94: invokestatic 26	a/a/a/a/e:i	()La/a/a/a/q;
    //   97: ldc 28
    //   99: new 110	java/lang/StringBuilder
    //   102: dup
    //   103: invokespecial 111	java/lang/StringBuilder:<init>	()V
    //   106: ldc 113
    //   108: invokevirtual 117	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   111: aload_3
    //   112: invokevirtual 120	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   115: invokevirtual 123	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   118: invokeinterface 106 3 0
    //   123: aload_2
    //   124: areturn
    //   125: astore 7
    //   127: aload 6
    //   129: astore_2
    //   130: aload 7
    //   132: astore_3
    //   133: goto -39 -> 94
    //   136: aload 6
    //   138: astore_2
    //   139: goto -76 -> 63
    //
    // Exception table:
    //   from	to	target	type
    //   2	25	93	java/lang/Exception
    //   32	41	93	java/lang/Exception
    //   67	88	93	java/lang/Exception
    //   41	63	125	java/lang/Exception
  }

  protected String e(Context paramContext)
  {
    int i = k.a(paramContext, "io.fabric.ApiKey", "string");
    if (i == 0)
    {
      e.i().a("Fabric", "Falling back to Crashlytics key lookup from Strings");
      i = k.a(paramContext, "com.crashlytics.ApiKey", "string");
    }
    String str = null;
    if (i != 0)
      str = paramContext.getResources().getString(i);
    return str;
  }

  protected void f(Context paramContext)
  {
    if ((e.j()) || (k.j(paramContext)))
      throw new IllegalArgumentException(a());
    e.i().e("Fabric", a());
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.b.i
 * JD-Core Version:    0.6.2
 */