package a.a.a.a.a.b;

import android.os.Process;

public abstract class j
  implements Runnable
{
  protected abstract void a();

  public final void run()
  {
    Process.setThreadPriority(10);
    a();
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.b.j
 * JD-Core Version:    0.6.2
 */