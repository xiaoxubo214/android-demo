package a.a.a.a.a.b;

public enum o
{
  public static final String e = "io.crash.air";
  private final int f;

  static
  {
    o[] arrayOfo = new o[4];
    arrayOfo[0] = a;
    arrayOfo[1] = b;
    arrayOfo[2] = c;
    arrayOfo[3] = d;
  }

  private o(int paramInt)
  {
    this.f = paramInt;
  }

  public static o a(String paramString)
  {
    if ("io.crash.air".equals(paramString))
      return c;
    if (paramString != null)
      return d;
    return a;
  }

  public int a()
  {
    return this.f;
  }

  public String toString()
  {
    return Integer.toString(this.f);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.b.o
 * JD-Core Version:    0.6.2
 */