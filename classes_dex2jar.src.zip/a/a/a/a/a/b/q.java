package a.a.a.a.a.b;

import a.a.a.a.a.c.a.b;
import a.a.a.a.a.c.a.f;
import a.a.a.a.a.c.a.h;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

public final class q
{
  private static final long a = 2L;

  public static h a(String paramString, int paramInt, f paramf, b paramb)
  {
    h localh = new h(paramInt, c(paramString), paramf, paramb);
    a(paramString, localh);
    return localh;
  }

  public static ExecutorService a(String paramString)
  {
    ExecutorService localExecutorService = Executors.newSingleThreadExecutor(c(paramString));
    a(paramString, localExecutorService);
    return localExecutorService;
  }

  private static final void a(String paramString, ExecutorService paramExecutorService)
  {
    a(paramString, paramExecutorService, 2L, TimeUnit.SECONDS);
  }

  public static final void a(String paramString, ExecutorService paramExecutorService, long paramLong, TimeUnit paramTimeUnit)
  {
    Runtime.getRuntime().addShutdownHook(new Thread(new t(paramString, paramExecutorService, paramLong, paramTimeUnit), "Crashlytics Shutdown Hook for " + paramString));
  }

  public static ScheduledExecutorService b(String paramString)
  {
    ScheduledExecutorService localScheduledExecutorService = Executors.newSingleThreadScheduledExecutor(c(paramString));
    a(paramString, localScheduledExecutorService);
    return localScheduledExecutorService;
  }

  public static final ThreadFactory c(String paramString)
  {
    return new r(paramString, new AtomicLong(1L));
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.b.q
 * JD-Core Version:    0.6.2
 */