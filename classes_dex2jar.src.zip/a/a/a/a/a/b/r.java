package a.a.a.a.a.b;

import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicLong;

final class r
  implements ThreadFactory
{
  r(String paramString, AtomicLong paramAtomicLong)
  {
  }

  public Thread newThread(Runnable paramRunnable)
  {
    Thread localThread = Executors.defaultThreadFactory().newThread(new s(this, paramRunnable));
    localThread.setName(this.a + this.b.getAndIncrement());
    return localThread;
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.b.r
 * JD-Core Version:    0.6.2
 */