package a.a.a.a.a.b;

class s extends j
{
  s(r paramr, Runnable paramRunnable)
  {
  }

  public void a()
  {
    this.a.run();
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.b.s
 * JD-Core Version:    0.6.2
 */