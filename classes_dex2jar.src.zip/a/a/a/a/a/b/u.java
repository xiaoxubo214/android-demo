package a.a.a.a.a.b;

import a.a.a.a.e;
import a.a.a.a.q;
import android.content.Context;
import android.content.res.Resources;
import android.text.TextUtils;

public class u
{
  static final String a = "google_app_id";
  static final String b = "com.crashlytics.useFirebaseAppId";

  protected String a(Context paramContext)
  {
    int i = k.a(paramContext, "google_app_id", "string");
    if (i != 0)
    {
      e.i().a("Fabric", "Generating Crashlytics ApiKey from google_app_id in Strings");
      return a(paramContext.getResources().getString(i));
    }
    return null;
  }

  protected String a(String paramString)
  {
    return k.b(paramString).substring(0, 40);
  }

  public boolean b(Context paramContext)
  {
    if (k.a(paramContext, "com.crashlytics.useFirebaseAppId", false));
    label76: label79: 
    while (true)
    {
      return true;
      int i;
      if (k.a(paramContext, "google_app_id", "string") != 0)
      {
        i = 1;
        if ((TextUtils.isEmpty(new i().d(paramContext))) && (TextUtils.isEmpty(new i().e(paramContext))))
          break label76;
      }
      for (int j = 1; ; j = 0)
      {
        if ((i != 0) && (j == 0))
          break label79;
        return false;
        i = 0;
        break;
      }
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.b.u
 * JD-Core Version:    0.6.2
 */