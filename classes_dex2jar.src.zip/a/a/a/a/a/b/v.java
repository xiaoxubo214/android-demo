package a.a.a.a.a.b;

import a.a.a.a.e;
import a.a.a.a.n;
import a.a.a.a.q;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Build;
import android.os.Build.VERSION;
import android.provider.Settings.Secure;
import android.text.TextUtils;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.locks.ReentrantLock;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class v
{
  public static final String a = "com.crashlytics.CollectDeviceIdentifiers";
  public static final String b = "com.crashlytics.CollectUserIdentifiers";
  public static final String c = "0.0";
  static final String d = "crashlytics.advertising.id";
  private static final String i = "crashlytics.installation.id";
  private static final Pattern j = Pattern.compile("[^\\p{Alnum}]");
  private static final String k = "9774d56d682e549c";
  private static final String l = Pattern.quote("/");
  c e;
  b f;
  boolean g;
  u h;
  private final ReentrantLock m = new ReentrantLock();
  private final w n;
  private final boolean o;
  private final boolean p;
  private final Context q;
  private final String r;
  private final String s;
  private final Collection<n> t;

  public v(Context paramContext, String paramString1, String paramString2, Collection<n> paramCollection)
  {
    if (paramContext == null)
      throw new IllegalArgumentException("appContext must not be null");
    if (paramString1 == null)
      throw new IllegalArgumentException("appIdentifier must not be null");
    if (paramCollection == null)
      throw new IllegalArgumentException("kits must not be null");
    this.q = paramContext;
    this.r = paramString1;
    this.s = paramString2;
    this.t = paramCollection;
    this.n = new w();
    this.e = new c(paramContext);
    this.h = new u();
    this.o = k.a(paramContext, "com.crashlytics.CollectDeviceIdentifiers", true);
    if (!this.o)
      e.i().a("Fabric", "Device ID collection disabled for " + paramContext.getPackageName());
    this.p = k.a(paramContext, "com.crashlytics.CollectUserIdentifiers", true);
    if (!this.p)
      e.i().a("Fabric", "User information collection disabled for " + paramContext.getPackageName());
  }

  @SuppressLint({"CommitPrefEdits"})
  private String a(SharedPreferences paramSharedPreferences)
  {
    this.m.lock();
    try
    {
      String str = paramSharedPreferences.getString("crashlytics.installation.id", null);
      if (str == null)
      {
        str = a(UUID.randomUUID().toString());
        paramSharedPreferences.edit().putString("crashlytics.installation.id", str).commit();
      }
      return str;
    }
    finally
    {
      this.m.unlock();
    }
  }

  private String a(String paramString)
  {
    if (paramString == null)
      return null;
    return j.matcher(paramString).replaceAll("").toLowerCase(Locale.US);
  }

  @SuppressLint({"CommitPrefEdits"})
  private void a(SharedPreferences paramSharedPreferences, String paramString)
  {
    this.m.lock();
    try
    {
      boolean bool = TextUtils.isEmpty(paramString);
      if (bool)
        return;
      String str = paramSharedPreferences.getString("crashlytics.advertising.id", null);
      if (TextUtils.isEmpty(str))
        paramSharedPreferences.edit().putString("crashlytics.advertising.id", paramString).commit();
      while (true)
      {
        return;
        if (!str.equals(paramString))
          paramSharedPreferences.edit().remove("crashlytics.installation.id").putString("crashlytics.advertising.id", paramString).commit();
      }
    }
    finally
    {
      this.m.unlock();
    }
  }

  private void a(Map<a, String> paramMap, a parama, String paramString)
  {
    if (paramString != null)
      paramMap.put(parama, paramString);
  }

  private String b(String paramString)
  {
    return paramString.replaceAll(l, "");
  }

  private void b(SharedPreferences paramSharedPreferences)
  {
    b localb = r();
    if (localb != null)
      a(paramSharedPreferences, localb.a);
  }

  private Boolean s()
  {
    b localb = r();
    if (localb != null)
      return Boolean.valueOf(localb.b);
    return null;
  }

  @Deprecated
  public String a(String paramString1, String paramString2)
  {
    return "";
  }

  public boolean a()
  {
    return this.p;
  }

  public String b()
  {
    String str = this.s;
    if (str == null)
    {
      SharedPreferences localSharedPreferences = k.a(this.q);
      b(localSharedPreferences);
      str = localSharedPreferences.getString("crashlytics.installation.id", null);
      if (str == null)
        str = a(localSharedPreferences);
    }
    return str;
  }

  public String c()
  {
    return this.r;
  }

  public String d()
  {
    return e() + "/" + f();
  }

  public String e()
  {
    return b(Build.VERSION.RELEASE);
  }

  public String f()
  {
    return b(Build.VERSION.INCREMENTAL);
  }

  public String g()
  {
    Locale localLocale = Locale.US;
    Object[] arrayOfObject = new Object[2];
    arrayOfObject[0] = b(Build.MANUFACTURER);
    arrayOfObject[1] = b(Build.MODEL);
    return String.format(localLocale, "%s/%s", arrayOfObject);
  }

  public Map<a, String> h()
  {
    HashMap localHashMap = new HashMap();
    Iterator localIterator1 = this.t.iterator();
    while (localIterator1.hasNext())
    {
      n localn = (n)localIterator1.next();
      if ((localn instanceof p))
      {
        Iterator localIterator2 = ((p)localn).f().entrySet().iterator();
        while (localIterator2.hasNext())
        {
          Map.Entry localEntry = (Map.Entry)localIterator2.next();
          a(localHashMap, (a)localEntry.getKey(), (String)localEntry.getValue());
        }
      }
    }
    String str = k();
    if (TextUtils.isEmpty(str))
      a(localHashMap, a.d, l());
    while (true)
    {
      return Collections.unmodifiableMap(localHashMap);
      a(localHashMap, a.g, str);
    }
  }

  public String i()
  {
    return this.n.a(this.q);
  }

  public Boolean j()
  {
    boolean bool = q();
    Boolean localBoolean = null;
    if (bool)
      localBoolean = s();
    return localBoolean;
  }

  public String k()
  {
    boolean bool1 = q();
    String str = null;
    if (bool1)
    {
      b localb = r();
      str = null;
      if (localb != null)
      {
        boolean bool2 = localb.b;
        str = null;
        if (!bool2)
          str = localb.a;
      }
    }
    return str;
  }

  public String l()
  {
    boolean bool1 = Boolean.TRUE.equals(s());
    boolean bool2 = q();
    String str1 = null;
    if (bool2)
    {
      str1 = null;
      if (!bool1)
      {
        String str2 = Settings.Secure.getString(this.q.getContentResolver(), "android_id");
        boolean bool3 = "9774d56d682e549c".equals(str2);
        str1 = null;
        if (!bool3)
          str1 = a(str2);
      }
    }
    return str1;
  }

  @Deprecated
  public String m()
  {
    return null;
  }

  @Deprecated
  public String n()
  {
    return null;
  }

  @Deprecated
  public String o()
  {
    return null;
  }

  @Deprecated
  public String p()
  {
    return null;
  }

  protected boolean q()
  {
    return (this.o) && (!this.h.b(this.q));
  }

  b r()
  {
    try
    {
      if (!this.g)
      {
        this.f = this.e.a();
        this.g = true;
      }
      b localb = this.f;
      return localb;
    }
    finally
    {
    }
  }

  public static enum a
  {
    public final int h;

    static
    {
      a[] arrayOfa = new a[7];
      arrayOfa[0] = a;
      arrayOfa[1] = b;
      arrayOfa[2] = c;
      arrayOfa[3] = d;
      arrayOfa[4] = e;
      arrayOfa[5] = f;
      arrayOfa[6] = g;
    }

    private a(int paramInt)
    {
      this.h = paramInt;
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.b.v
 * JD-Core Version:    0.6.2
 */