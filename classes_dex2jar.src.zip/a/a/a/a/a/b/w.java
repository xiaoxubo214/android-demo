package a.a.a.a.a.b;

import a.a.a.a.a.a.b;
import a.a.a.a.a.a.d;
import a.a.a.a.e;
import a.a.a.a.q;
import android.content.Context;

public class w
{
  private static final String a = "";
  private final d<String> b = new x(this);
  private final b<String> c = new b();

  public String a(Context paramContext)
  {
    try
    {
      String str = (String)this.c.a(paramContext, this.b);
      boolean bool = "".equals(str);
      if (bool)
        str = null;
      return str;
    }
    catch (Exception localException)
    {
      e.i().e("Fabric", "Failed to determine installer package name", localException);
    }
    return null;
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.b.w
 * JD-Core Version:    0.6.2
 */