package a.a.a.a.a.b;

import a.a.a.a.a.a.d;
import android.content.Context;
import android.content.pm.PackageManager;

class x
  implements d<String>
{
  x(w paramw)
  {
  }

  public String a(Context paramContext)
    throws Exception
  {
    String str = paramContext.getPackageManager().getInstallerPackageName(paramContext.getPackageName());
    if (str == null)
      str = "";
    return str;
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.b.x
 * JD-Core Version:    0.6.2
 */