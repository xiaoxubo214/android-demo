package a.a.a.a.a.b;

import java.io.Closeable;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.nio.channels.FileChannel;
import java.util.NoSuchElementException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class y
  implements Closeable
{
  static final int a = 16;
  private static final Logger c = Logger.getLogger(y.class.getName());
  private static final int d = 4096;
  int b;
  private final RandomAccessFile e;
  private int f;
  private a g;
  private a h;
  private final byte[] i = new byte[16];

  public y(File paramFile)
    throws IOException
  {
    if (!paramFile.exists())
      a(paramFile);
    this.e = b(paramFile);
    g();
  }

  y(RandomAccessFile paramRandomAccessFile)
    throws IOException
  {
    this.e = paramRandomAccessFile;
    g();
  }

  private static int a(byte[] paramArrayOfByte, int paramInt)
  {
    return ((0xFF & paramArrayOfByte[paramInt]) << 24) + ((0xFF & paramArrayOfByte[(paramInt + 1)]) << 16) + ((0xFF & paramArrayOfByte[(paramInt + 2)]) << 8) + (0xFF & paramArrayOfByte[(paramInt + 3)]);
  }

  private a a(int paramInt)
    throws IOException
  {
    if (paramInt == 0)
      return a.b;
    this.e.seek(paramInt);
    return new a(paramInt, this.e.readInt());
  }

  private void a(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    throws IOException
  {
    a(this.i, new int[] { paramInt1, paramInt2, paramInt3, paramInt4 });
    this.e.seek(0L);
    this.e.write(this.i);
  }

  private void a(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int paramInt3)
    throws IOException
  {
    int j = b(paramInt1);
    if (j + paramInt3 <= this.b)
    {
      this.e.seek(j);
      this.e.write(paramArrayOfByte, paramInt2, paramInt3);
      return;
    }
    int k = this.b - j;
    this.e.seek(j);
    this.e.write(paramArrayOfByte, paramInt2, k);
    this.e.seek(16L);
    this.e.write(paramArrayOfByte, paramInt2 + k, paramInt3 - k);
  }

  private static void a(File paramFile)
    throws IOException
  {
    File localFile = new File(paramFile.getPath() + ".tmp");
    RandomAccessFile localRandomAccessFile = b(localFile);
    try
    {
      localRandomAccessFile.setLength(4096L);
      localRandomAccessFile.seek(0L);
      byte[] arrayOfByte = new byte[16];
      a(arrayOfByte, new int[] { 4096, 0, 0, 0 });
      localRandomAccessFile.write(arrayOfByte);
      localRandomAccessFile.close();
      if (!localFile.renameTo(paramFile))
        throw new IOException("Rename failed!");
    }
    finally
    {
      localRandomAccessFile.close();
    }
  }

  private static void a(byte[] paramArrayOfByte, int[] paramArrayOfInt)
  {
    int j = 0;
    int k = paramArrayOfInt.length;
    int m = 0;
    while (j < k)
    {
      b(paramArrayOfByte, m, paramArrayOfInt[j]);
      m += 4;
      j++;
    }
  }

  private int b(int paramInt)
  {
    if (paramInt < this.b)
      return paramInt;
    return paramInt + 16 - this.b;
  }

  private static RandomAccessFile b(File paramFile)
    throws FileNotFoundException
  {
    return new RandomAccessFile(paramFile, "rwd");
  }

  private static <T> T b(T paramT, String paramString)
  {
    if (paramT == null)
      throw new NullPointerException(paramString);
    return paramT;
  }

  private void b(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int paramInt3)
    throws IOException
  {
    int j = b(paramInt1);
    if (j + paramInt3 <= this.b)
    {
      this.e.seek(j);
      this.e.readFully(paramArrayOfByte, paramInt2, paramInt3);
      return;
    }
    int k = this.b - j;
    this.e.seek(j);
    this.e.readFully(paramArrayOfByte, paramInt2, k);
    this.e.seek(16L);
    this.e.readFully(paramArrayOfByte, paramInt2 + k, paramInt3 - k);
  }

  private static void b(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    paramArrayOfByte[paramInt1] = ((byte)(paramInt2 >> 24));
    paramArrayOfByte[(paramInt1 + 1)] = ((byte)(paramInt2 >> 16));
    paramArrayOfByte[(paramInt1 + 2)] = ((byte)(paramInt2 >> 8));
    paramArrayOfByte[(paramInt1 + 3)] = ((byte)paramInt2);
  }

  private void c(int paramInt)
    throws IOException
  {
    int j = paramInt + 4;
    int k = h();
    if (k >= j)
      return;
    int m = this.b;
    do
    {
      k += m;
      m <<= 1;
    }
    while (k < j);
    d(m);
    int n = b(4 + this.h.c + this.h.d);
    if (n < this.g.c)
    {
      FileChannel localFileChannel = this.e.getChannel();
      localFileChannel.position(this.b);
      int i2 = n - 4;
      if (localFileChannel.transferTo(16L, i2, localFileChannel) != i2)
        throw new AssertionError("Copied insufficient number of bytes!");
    }
    if (this.h.c < this.g.c)
    {
      int i1 = -16 + (this.b + this.h.c);
      a(m, this.f, this.g.c, i1);
      this.h = new a(i1, this.h.d);
    }
    while (true)
    {
      this.b = m;
      return;
      a(m, this.f, this.g.c, this.h.c);
    }
  }

  private void d(int paramInt)
    throws IOException
  {
    this.e.setLength(paramInt);
    this.e.getChannel().force(true);
  }

  private void g()
    throws IOException
  {
    this.e.seek(0L);
    this.e.readFully(this.i);
    this.b = a(this.i, 0);
    if (this.b > this.e.length())
      throw new IOException("File is truncated. Expected length: " + this.b + ", Actual length: " + this.e.length());
    this.f = a(this.i, 4);
    int j = a(this.i, 8);
    int k = a(this.i, 12);
    this.g = a(j);
    this.h = a(k);
  }

  private int h()
  {
    return this.b - a();
  }

  public int a()
  {
    if (this.f == 0)
      return 16;
    if (this.h.c >= this.g.c)
      return 16 + (4 + (this.h.c - this.g.c) + this.h.d);
    return 4 + this.h.c + this.h.d + this.b - this.g.c;
  }

  public void a(c paramc)
    throws IOException
  {
    try
    {
      if (this.f > 0)
        paramc.a(new b(this.g, null), this.g.d);
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  public void a(byte[] paramArrayOfByte)
    throws IOException
  {
    a(paramArrayOfByte, 0, paramArrayOfByte.length);
  }

  public void a(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    try
    {
      b(paramArrayOfByte, "buffer");
      if (((paramInt1 | paramInt2) < 0) || (paramInt2 > paramArrayOfByte.length - paramInt1))
        throw new IndexOutOfBoundsException();
    }
    finally
    {
    }
    c(paramInt2);
    boolean bool = b();
    int j;
    a locala;
    if (bool)
    {
      j = 16;
      locala = new a(j, paramInt2);
      b(this.i, 0, paramInt2);
      a(locala.c, this.i, 0, 4);
      a(4 + locala.c, paramArrayOfByte, paramInt1, paramInt2);
      if (!bool)
        break label199;
    }
    label199: for (int k = locala.c; ; k = this.g.c)
    {
      a(this.b, 1 + this.f, k, locala.c);
      this.h = locala;
      this.f = (1 + this.f);
      if (bool)
        this.g = this.h;
      return;
      j = b(4 + this.h.c + this.h.d);
      break;
    }
  }

  public boolean a(int paramInt1, int paramInt2)
  {
    return paramInt1 + (4 + a()) <= paramInt2;
  }

  public void b(c paramc)
    throws IOException
  {
    try
    {
      int j = this.g.c;
      for (int k = 0; k < this.f; k++)
      {
        a locala = a(j);
        paramc.a(new b(locala, null), locala.d);
        int m = b(4 + locala.c + locala.d);
        j = m;
      }
      return;
    }
    finally
    {
    }
  }

  public boolean b()
  {
    try
    {
      int j = this.f;
      if (j == 0)
      {
        bool = true;
        return bool;
      }
      boolean bool = false;
    }
    finally
    {
    }
  }

  public byte[] c()
    throws IOException
  {
    try
    {
      boolean bool = b();
      byte[] arrayOfByte;
      if (bool)
        arrayOfByte = null;
      while (true)
      {
        return arrayOfByte;
        int j = this.g.d;
        arrayOfByte = new byte[j];
        b(4 + this.g.c, arrayOfByte, 0, j);
      }
    }
    finally
    {
    }
  }

  public void close()
    throws IOException
  {
    try
    {
      this.e.close();
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  public int d()
  {
    try
    {
      int j = this.f;
      return j;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  public void e()
    throws IOException
  {
    try
    {
      if (b())
        throw new NoSuchElementException();
    }
    finally
    {
    }
    if (this.f == 1)
      f();
    while (true)
    {
      return;
      int j = b(4 + this.g.c + this.g.d);
      b(j, this.i, 0, 4);
      int k = a(this.i, 0);
      a(this.b, -1 + this.f, j, this.h.c);
      this.f = (-1 + this.f);
      this.g = new a(j, k);
    }
  }

  public void f()
    throws IOException
  {
    try
    {
      a(4096, 0, 0, 0);
      this.f = 0;
      this.g = a.b;
      this.h = a.b;
      if (this.b > 4096)
        d(4096);
      this.b = 4096;
      return;
    }
    finally
    {
    }
  }

  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append(getClass().getSimpleName()).append('[');
    localStringBuilder.append("fileLength=").append(this.b);
    localStringBuilder.append(", size=").append(this.f);
    localStringBuilder.append(", first=").append(this.g);
    localStringBuilder.append(", last=").append(this.h);
    localStringBuilder.append(", element lengths=[");
    try
    {
      b(new z(this, localStringBuilder));
      localStringBuilder.append("]]");
      return localStringBuilder.toString();
    }
    catch (IOException localIOException)
    {
      while (true)
        c.log(Level.WARNING, "read error", localIOException);
    }
  }

  static class a
  {
    static final int a = 4;
    static final a b = new a(0, 0);
    final int c;
    final int d;

    a(int paramInt1, int paramInt2)
    {
      this.c = paramInt1;
      this.d = paramInt2;
    }

    public String toString()
    {
      return getClass().getSimpleName() + "[position = " + this.c + ", length = " + this.d + "]";
    }
  }

  private final class b extends InputStream
  {
    private int b;
    private int c;

    private b(y.a arg2)
    {
      Object localObject;
      this.b = y.a(y.this, 4 + localObject.c);
      this.c = localObject.d;
    }

    public int read()
      throws IOException
    {
      if (this.c == 0)
        return -1;
      y.a(y.this).seek(this.b);
      int i = y.a(y.this).read();
      this.b = y.a(y.this, 1 + this.b);
      this.c = (-1 + this.c);
      return i;
    }

    public int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
      throws IOException
    {
      y.a(paramArrayOfByte, "buffer");
      if (((paramInt1 | paramInt2) < 0) || (paramInt2 > paramArrayOfByte.length - paramInt1))
        throw new ArrayIndexOutOfBoundsException();
      if (this.c > 0)
      {
        if (paramInt2 > this.c)
          paramInt2 = this.c;
        y.a(y.this, this.b, paramArrayOfByte, paramInt1, paramInt2);
        this.b = y.a(y.this, paramInt2 + this.b);
        this.c -= paramInt2;
        return paramInt2;
      }
      return -1;
    }
  }

  public static abstract interface c
  {
    public abstract void a(InputStream paramInputStream, int paramInt)
      throws IOException;
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.b.y
 * JD-Core Version:    0.6.2
 */