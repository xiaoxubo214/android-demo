package a.a.a.a.a.b;

import java.io.IOException;
import java.io.InputStream;

class z
  implements y.c
{
  boolean a = true;

  z(y paramy, StringBuilder paramStringBuilder)
  {
  }

  public void a(InputStream paramInputStream, int paramInt)
    throws IOException
  {
    if (this.a)
      this.a = false;
    while (true)
    {
      this.b.append(paramInt);
      return;
      this.b.append(", ");
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.b.z
 * JD-Core Version:    0.6.2
 */