package a.a.a.a.a.c;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import java.util.LinkedList;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.FutureTask;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicBoolean;

public abstract class a<Params, Progress, Result>
{
  private static final String a = "AsyncTask";
  public static final Executor b = new ThreadPoolExecutor(e, f, 1L, TimeUnit.SECONDS, i, h);
  public static final Executor c = new c(null);
  private static final int d = 0;
  private static final int e = 0;
  private static final int f = 0;
  private static final int g = 1;
  private static final ThreadFactory h = new b();
  private static final BlockingQueue<Runnable> i = new LinkedBlockingQueue(128);
  private static final int j = 1;
  private static final int k = 2;
  private static final b l = new b();
  private static volatile Executor m = c;
  private final e<Params, Result> n = new c(this);
  private final FutureTask<Result> o = new d(this, this.n);
  private volatile d p = d.a;
  private final AtomicBoolean q = new AtomicBoolean();
  private final AtomicBoolean r = new AtomicBoolean();

  public static void a(Runnable paramRunnable)
  {
    m.execute(paramRunnable);
  }

  public static void a(Executor paramExecutor)
  {
    m = paramExecutor;
  }

  private void d(Result paramResult)
  {
    if (!this.r.get())
      e(paramResult);
  }

  private Result e(Result paramResult)
  {
    l.obtainMessage(1, new a(this, new Object[] { paramResult })).sendToTarget();
    return paramResult;
  }

  private void f(Result paramResult)
  {
    if (f())
      b(paramResult);
    while (true)
    {
      this.p = d.c;
      return;
      a(paramResult);
    }
  }

  public static void n_()
  {
    l.getLooper();
  }

  public final a<Params, Progress, Result> a(Executor paramExecutor, Params[] paramArrayOfParams)
  {
    if (this.p != d.a);
    switch (e.a[this.p.ordinal()])
    {
    default:
      this.p = d.b;
      a();
      this.n.b = paramArrayOfParams;
      paramExecutor.execute(this.o);
      return this;
    case 1:
      throw new IllegalStateException("Cannot execute task: the task is already running.");
    case 2:
    }
    throw new IllegalStateException("Cannot execute task: the task has already been executed (a task can be executed only once)");
  }

  public final Result a(long paramLong, TimeUnit paramTimeUnit)
    throws InterruptedException, ExecutionException, TimeoutException
  {
    return this.o.get(paramLong, paramTimeUnit);
  }

  protected abstract Result a(Params[] paramArrayOfParams);

  protected void a()
  {
  }

  protected void a(Result paramResult)
  {
  }

  public final boolean a(boolean paramBoolean)
  {
    this.q.set(true);
    return this.o.cancel(paramBoolean);
  }

  protected void b(Result paramResult)
  {
    p_();
  }

  protected void b(Progress[] paramArrayOfProgress)
  {
  }

  public final a<Params, Progress, Result> c(Params[] paramArrayOfParams)
  {
    return a(m, paramArrayOfParams);
  }

  protected final void d(Progress[] paramArrayOfProgress)
  {
    if (!f())
      l.obtainMessage(2, new a(this, paramArrayOfProgress)).sendToTarget();
  }

  public final boolean f()
  {
    return this.q.get();
  }

  public final Result g()
    throws InterruptedException, ExecutionException
  {
    return this.o.get();
  }

  public final d o_()
  {
    return this.p;
  }

  protected void p_()
  {
  }

  private static class a<Data>
  {
    final a a;
    final Data[] b;

    a(a parama, Data[] paramArrayOfData)
    {
      this.a = parama;
      this.b = paramArrayOfData;
    }
  }

  private static class b extends Handler
  {
    public b()
    {
      super();
    }

    public void handleMessage(Message paramMessage)
    {
      a.a locala = (a.a)paramMessage.obj;
      switch (paramMessage.what)
      {
      default:
        return;
      case 1:
        a.c(locala.a, locala.b[0]);
        return;
      case 2:
      }
      locala.a.b(locala.b);
    }
  }

  private static class c
    implements Executor
  {
    final LinkedList<Runnable> a = new LinkedList();
    Runnable b;

    protected void a()
    {
      try
      {
        Runnable localRunnable = (Runnable)this.a.poll();
        this.b = localRunnable;
        if (localRunnable != null)
          a.b.execute(this.b);
        return;
      }
      finally
      {
      }
    }

    public void execute(Runnable paramRunnable)
    {
      try
      {
        this.a.offer(new f(this, paramRunnable));
        if (this.b == null)
          a();
        return;
      }
      finally
      {
        localObject = finally;
        throw localObject;
      }
    }
  }

  public static enum d
  {
    static
    {
      d[] arrayOfd = new d[3];
      arrayOfd[0] = a;
      arrayOfd[1] = b;
      arrayOfd[2] = c;
    }
  }

  private static abstract class e<Params, Result>
    implements Callable<Result>
  {
    Params[] b;
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.c.a
 * JD-Core Version:    0.6.2
 */