package a.a.a.a.a.c.a;

import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.locks.AbstractQueuedSynchronizer;

public abstract class a<V>
  implements Future<V>
{
  private final a<V> a = new a();

  static final CancellationException a(String paramString, Throwable paramThrowable)
  {
    CancellationException localCancellationException = new CancellationException(paramString);
    localCancellationException.initCause(paramThrowable);
    return localCancellationException;
  }

  protected void a()
  {
  }

  protected boolean a(V paramV)
  {
    return this.a.a(paramV);
  }

  protected boolean a(Throwable paramThrowable)
  {
    if (paramThrowable == null)
      throw new NullPointerException();
    return this.a.a(paramThrowable);
  }

  protected final boolean b()
  {
    return this.a.d();
  }

  public boolean cancel(boolean paramBoolean)
  {
    if (!this.a.a(paramBoolean))
      return false;
    if (paramBoolean)
      a();
    return true;
  }

  public V get()
    throws InterruptedException, ExecutionException
  {
    return this.a.a();
  }

  public V get(long paramLong, TimeUnit paramTimeUnit)
    throws InterruptedException, TimeoutException, ExecutionException
  {
    return this.a.a(paramTimeUnit.toNanos(paramLong));
  }

  public boolean isCancelled()
  {
    return this.a.c();
  }

  public boolean isDone()
  {
    return this.a.b();
  }

  static final class a<V> extends AbstractQueuedSynchronizer
  {
    static final int a = 0;
    static final int b = 1;
    static final int c = 2;
    static final int d = 4;
    static final int e = 8;
    private static final long f;
    private V g;
    private Throwable h;

    private boolean a(V paramV, Throwable paramThrowable, int paramInt)
    {
      boolean bool = compareAndSetState(0, 1);
      if (bool)
      {
        this.g = paramV;
        if ((paramInt & 0xC) != 0)
          paramThrowable = new CancellationException("Future.cancel() was called.");
        this.h = paramThrowable;
        releaseShared(paramInt);
      }
      while (getState() != 1)
        return bool;
      acquireShared(-1);
      return bool;
    }

    private V e()
      throws CancellationException, ExecutionException
    {
      int i = getState();
      switch (i)
      {
      default:
        throw new IllegalStateException("Error, synchronizer in invalid state: " + i);
      case 2:
        if (this.h != null)
          throw new ExecutionException(this.h);
        return this.g;
      case 4:
      case 8:
      }
      throw a.a("Task was cancelled.", this.h);
    }

    V a()
      throws CancellationException, ExecutionException, InterruptedException
    {
      acquireSharedInterruptibly(-1);
      return e();
    }

    V a(long paramLong)
      throws TimeoutException, CancellationException, ExecutionException, InterruptedException
    {
      if (!tryAcquireSharedNanos(-1, paramLong))
        throw new TimeoutException("Timeout waiting for task.");
      return e();
    }

    boolean a(V paramV)
    {
      return a(paramV, null, 2);
    }

    boolean a(Throwable paramThrowable)
    {
      return a(null, paramThrowable, 2);
    }

    boolean a(boolean paramBoolean)
    {
      if (paramBoolean);
      for (int i = 8; ; i = 4)
        return a(null, null, i);
    }

    boolean b()
    {
      return (0xE & getState()) != 0;
    }

    boolean c()
    {
      return (0xC & getState()) != 0;
    }

    boolean d()
    {
      return getState() == 8;
    }

    protected int tryAcquireShared(int paramInt)
    {
      if (b())
        return 1;
      return -1;
    }

    protected boolean tryReleaseShared(int paramInt)
    {
      setState(paramInt);
      return true;
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.c.a.a
 * JD-Core Version:    0.6.2
 */