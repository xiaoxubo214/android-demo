package a.a.a.a.a.c.a;

public class c
  implements f
{
  private final int a;

  public c()
  {
    this(1);
  }

  public c(int paramInt)
  {
    this.a = paramInt;
  }

  public boolean a(int paramInt, Throwable paramThrowable)
  {
    return paramInt < this.a;
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.c.a.c
 * JD-Core Version:    0.6.2
 */