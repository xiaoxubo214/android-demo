package a.a.a.a.a.c.a;

public class d
  implements b
{
  private static final int a = 2;
  private final long b;
  private final int c;

  public d(long paramLong)
  {
    this(paramLong, 2);
  }

  public d(long paramLong, int paramInt)
  {
    this.b = paramLong;
    this.c = paramInt;
  }

  public long a(int paramInt)
  {
    return ()(this.b * Math.pow(this.c, paramInt));
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.c.a.d
 * JD-Core Version:    0.6.2
 */