package a.a.a.a.a.c.a;

import java.util.concurrent.Callable;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

class e<T> extends a<T>
  implements Runnable
{
  g a;
  private final h b;
  private final Callable<T> c;
  private final AtomicReference<Thread> d;

  e(Callable<T> paramCallable, g paramg, h paramh)
  {
    this.c = paramCallable;
    this.a = paramg;
    this.b = paramh;
    this.d = new AtomicReference();
  }

  private f c()
  {
    return this.a.d();
  }

  private b d()
  {
    return this.a.c();
  }

  private int e()
  {
    return this.a.a();
  }

  protected void a()
  {
    Thread localThread = (Thread)this.d.getAndSet(null);
    if (localThread != null)
      localThread.interrupt();
  }

  public void run()
  {
    if ((isDone()) || (!this.d.compareAndSet(null, Thread.currentThread())))
      return;
    try
    {
      a(this.c.call());
      return;
    }
    catch (Throwable localThrowable)
    {
      if (c().a(e(), localThrowable))
      {
        long l = d().a(e());
        this.a = this.a.e();
        this.b.schedule(this, l, TimeUnit.MILLISECONDS);
      }
      while (true)
      {
        return;
        a(localThrowable);
      }
    }
    finally
    {
      this.d.getAndSet(null);
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.c.a.e
 * JD-Core Version:    0.6.2
 */