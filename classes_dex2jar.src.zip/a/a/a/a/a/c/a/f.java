package a.a.a.a.a.c.a;

public abstract interface f
{
  public abstract boolean a(int paramInt, Throwable paramThrowable);
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.c.a.f
 * JD-Core Version:    0.6.2
 */