package a.a.a.a.a.c.a;

public class g
{
  private final int a;
  private final b b;
  private final f c;

  public g(int paramInt, b paramb, f paramf)
  {
    this.a = paramInt;
    this.b = paramb;
    this.c = paramf;
  }

  public g(b paramb, f paramf)
  {
    this(0, paramb, paramf);
  }

  public int a()
  {
    return this.a;
  }

  public long b()
  {
    return this.b.a(this.a);
  }

  public b c()
  {
    return this.b;
  }

  public f d()
  {
    return this.c;
  }

  public g e()
  {
    return new g(1 + this.a, this.b, this.c);
  }

  public g f()
  {
    return new g(this.b, this.c);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.c.a.g
 * JD-Core Version:    0.6.2
 */