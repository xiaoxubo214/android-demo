package a.a.a.a.a.c.a;

import java.util.concurrent.Callable;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.ThreadFactory;

public class h extends ScheduledThreadPoolExecutor
{
  private final f a;
  private final b b;

  public h(int paramInt, f paramf, b paramb)
  {
    this(paramInt, Executors.defaultThreadFactory(), paramf, paramb);
  }

  public h(int paramInt, ThreadFactory paramThreadFactory, f paramf, b paramb)
  {
    super(paramInt, paramThreadFactory);
    if (paramf == null)
      throw new NullPointerException("retry policy must not be null");
    if (paramb == null)
      throw new NullPointerException("backoff must not be null");
    this.a = paramf;
    this.b = paramb;
  }

  private <T> Future<T> b(Callable<T> paramCallable)
  {
    if (paramCallable == null)
      throw new NullPointerException();
    e locale = new e(paramCallable, new g(this.b, this.a), this);
    execute(locale);
    return locale;
  }

  public f a()
  {
    return this.a;
  }

  public Future<?> a(Runnable paramRunnable)
  {
    return b(Executors.callable(paramRunnable));
  }

  public <T> Future<T> a(Runnable paramRunnable, T paramT)
  {
    return b(Executors.callable(paramRunnable, paramT));
  }

  public <T> Future<T> a(Callable<T> paramCallable)
  {
    return b(paramCallable);
  }

  public b b()
  {
    return this.b;
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.c.a.h
 * JD-Core Version:    0.6.2
 */