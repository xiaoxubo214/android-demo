package a.a.a.a.a.c;

import android.os.Process;
import java.util.concurrent.atomic.AtomicBoolean;

class c extends a.e<Params, Result>
{
  c(a parama)
  {
    super(null);
  }

  public Result call()
    throws Exception
  {
    a.a(this.a).set(true);
    Process.setThreadPriority(10);
    return a.a(this.a, this.a.a(this.b));
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.c.c
 * JD-Core Version:    0.6.2
 */