package a.a.a.a.a.c;

import java.util.Collection;

public abstract interface h<T>
{
  public abstract void c(T paramT);

  public abstract Collection<T> d();

  public abstract boolean e();
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.c.h
 * JD-Core Version:    0.6.2
 */