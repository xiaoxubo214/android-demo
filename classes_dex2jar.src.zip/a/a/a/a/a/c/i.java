package a.a.a.a.a.c;

import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;

public class i<E extends h,  extends t,  extends p> extends PriorityBlockingQueue<E>
{
  static final int a = 0;
  static final int b = 1;
  static final int c = 2;
  static final int d = 3;
  final Queue<E> e = new LinkedList();
  private final ReentrantLock f = new ReentrantLock();

  public E a()
    throws InterruptedException
  {
    return b(0, null, null);
  }

  E a(int paramInt, Long paramLong, TimeUnit paramTimeUnit)
    throws InterruptedException
  {
    switch (paramInt)
    {
    default:
      return null;
    case 0:
      return (h)super.take();
    case 1:
      return (h)super.peek();
    case 2:
      return (h)super.poll();
    case 3:
    }
    return (h)super.poll(paramLong.longValue(), paramTimeUnit);
  }

  public E a(long paramLong, TimeUnit paramTimeUnit)
    throws InterruptedException
  {
    return b(3, Long.valueOf(paramLong), paramTimeUnit);
  }

  boolean a(int paramInt, E paramE)
  {
    try
    {
      this.f.lock();
      if (paramInt == 1)
        super.remove(paramE);
      boolean bool = this.e.offer(paramE);
      return bool;
    }
    finally
    {
      this.f.unlock();
    }
  }

  boolean a(E paramE)
  {
    return paramE.e();
  }

  <T> T[] a(T[] paramArrayOfT1, T[] paramArrayOfT2)
  {
    int i = paramArrayOfT1.length;
    int j = paramArrayOfT2.length;
    Object[] arrayOfObject = (Object[])Array.newInstance(paramArrayOfT1.getClass().getComponentType(), i + j);
    System.arraycopy(paramArrayOfT1, 0, arrayOfObject, 0, i);
    System.arraycopy(paramArrayOfT2, 0, arrayOfObject, i, j);
    return arrayOfObject;
  }

  public E b()
  {
    try
    {
      h localh = b(1, null, null);
      return localh;
    }
    catch (InterruptedException localInterruptedException)
    {
    }
    return null;
  }

  E b(int paramInt, Long paramLong, TimeUnit paramTimeUnit)
    throws InterruptedException
  {
    while (true)
    {
      h localh = a(paramInt, paramLong, paramTimeUnit);
      if ((localh == null) || (a(localh)))
        return localh;
      a(paramInt, localh);
    }
  }

  public E c()
  {
    try
    {
      h localh = b(2, null, null);
      return localh;
    }
    catch (InterruptedException localInterruptedException)
    {
    }
    return null;
  }

  public void clear()
  {
    try
    {
      this.f.lock();
      this.e.clear();
      super.clear();
      return;
    }
    finally
    {
      this.f.unlock();
    }
  }

  public boolean contains(Object paramObject)
  {
    try
    {
      this.f.lock();
      if (!super.contains(paramObject))
      {
        boolean bool2 = this.e.contains(paramObject);
        if (!bool2);
      }
      else
      {
        bool1 = true;
        return bool1;
      }
      boolean bool1 = false;
    }
    finally
    {
      this.f.unlock();
    }
  }

  public void d()
  {
    try
    {
      this.f.lock();
      Iterator localIterator = this.e.iterator();
      while (localIterator.hasNext())
      {
        h localh = (h)localIterator.next();
        if (a(localh))
        {
          super.offer(localh);
          localIterator.remove();
        }
      }
    }
    finally
    {
      this.f.unlock();
    }
    this.f.unlock();
  }

  public int drainTo(Collection<? super E> paramCollection)
  {
    int i;
    try
    {
      this.f.lock();
      i = super.drainTo(paramCollection) + this.e.size();
      while (!this.e.isEmpty())
        paramCollection.add(this.e.poll());
    }
    finally
    {
      this.f.unlock();
    }
    this.f.unlock();
    return i;
  }

  public int drainTo(Collection<? super E> paramCollection, int paramInt)
  {
    try
    {
      this.f.lock();
      for (int i = super.drainTo(paramCollection, paramInt); (!this.e.isEmpty()) && (i <= paramInt); i++)
        paramCollection.add(this.e.poll());
      return i;
    }
    finally
    {
      this.f.unlock();
    }
  }

  public boolean remove(Object paramObject)
  {
    try
    {
      this.f.lock();
      if (!super.remove(paramObject))
      {
        boolean bool2 = this.e.remove(paramObject);
        if (!bool2);
      }
      else
      {
        bool1 = true;
        return bool1;
      }
      boolean bool1 = false;
    }
    finally
    {
      this.f.unlock();
    }
  }

  public boolean removeAll(Collection<?> paramCollection)
  {
    try
    {
      this.f.lock();
      boolean bool1 = super.removeAll(paramCollection);
      boolean bool2 = this.e.removeAll(paramCollection);
      boolean bool3 = bool1 | bool2;
      return bool3;
    }
    finally
    {
      this.f.unlock();
    }
  }

  public int size()
  {
    try
    {
      this.f.lock();
      int i = this.e.size();
      int j = super.size();
      int k = i + j;
      return k;
    }
    finally
    {
      this.f.unlock();
    }
  }

  public Object[] toArray()
  {
    try
    {
      this.f.lock();
      Object[] arrayOfObject = a(super.toArray(), this.e.toArray());
      return arrayOfObject;
    }
    finally
    {
      this.f.unlock();
    }
  }

  public <T> T[] toArray(T[] paramArrayOfT)
  {
    try
    {
      this.f.lock();
      Object[] arrayOfObject = a(super.toArray(paramArrayOfT), this.e.toArray(paramArrayOfT));
      return arrayOfObject;
    }
    finally
    {
      this.f.unlock();
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.c.i
 * JD-Core Version:    0.6.2
 */