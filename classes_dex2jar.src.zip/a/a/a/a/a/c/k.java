package a.a.a.a.a.c;

public enum k
{
  static
  {
    k[] arrayOfk = new k[4];
    arrayOfk[0] = a;
    arrayOfk[1] = b;
    arrayOfk[2] = c;
    arrayOfk[3] = d;
  }

  static <Y> int a(p paramp, Y paramY)
  {
    if ((paramY instanceof p));
    for (k localk = ((p)paramY).b(); ; localk = b)
      return localk.ordinal() - paramp.b().ordinal();
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.c.k
 * JD-Core Version:    0.6.2
 */