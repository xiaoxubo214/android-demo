package a.a.a.a.a.c;

import java.util.Collection;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;

public abstract class l<Params, Progress, Result> extends a<Params, Progress, Result>
  implements g, h<t>, p, t
{
  private final r a = new r();

  public void a(t paramt)
  {
    if (o_() != a.d.a)
      throw new IllegalStateException("Must not add Dependency after task is running");
    ((h)c()).c(paramt);
  }

  public void a(Throwable paramThrowable)
  {
    ((t)c()).a(paramThrowable);
  }

  public final void a(ExecutorService paramExecutorService, Params[] paramArrayOfParams)
  {
    super.a(new a(paramExecutorService, this), paramArrayOfParams);
  }

  public k b()
  {
    return ((p)c()).b();
  }

  public void b(boolean paramBoolean)
  {
    ((t)c()).b(paramBoolean);
  }

  public <T extends h<t>,  extends p,  extends t> T c()
  {
    return this.a;
  }

  public int compareTo(Object paramObject)
  {
    return k.a(this, paramObject);
  }

  public Collection<t> d()
  {
    return ((h)c()).d();
  }

  public boolean e()
  {
    return ((h)c()).e();
  }

  public boolean h()
  {
    return ((t)c()).h();
  }

  public Throwable i()
  {
    return ((t)c()).i();
  }

  private static class a<Result>
    implements Executor
  {
    private final Executor a;
    private final l b;

    public a(Executor paramExecutor, l paraml)
    {
      this.a = paramExecutor;
      this.b = paraml;
    }

    public void execute(Runnable paramRunnable)
    {
      this.a.execute(new m(this, paramRunnable, null));
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.c.l
 * JD-Core Version:    0.6.2
 */