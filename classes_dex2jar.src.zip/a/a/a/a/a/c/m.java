package a.a.a.a.a.c;

class m extends o<Result>
{
  m(l.a parama, Runnable paramRunnable, Object paramObject)
  {
    super(paramRunnable, paramObject);
  }

  public <T extends h<t>,  extends p,  extends t> T c()
  {
    return l.a.a(this.a);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.c.m
 * JD-Core Version:    0.6.2
 */