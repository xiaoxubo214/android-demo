package a.a.a.a.a.c;

import java.util.concurrent.Callable;

public abstract class n<V> extends r
  implements Callable<V>
{
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.c.n
 * JD-Core Version:    0.6.2
 */