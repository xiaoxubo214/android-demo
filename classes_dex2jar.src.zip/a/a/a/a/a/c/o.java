package a.a.a.a.a.c;

import java.util.Collection;
import java.util.concurrent.Callable;
import java.util.concurrent.FutureTask;

public class o<V> extends FutureTask<V>
  implements g, h<t>, p, t
{
  final Object b = a(paramCallable);

  public o(Runnable paramRunnable, V paramV)
  {
    super(paramRunnable, paramV);
  }

  public o(Callable<V> paramCallable)
  {
    super(paramCallable);
  }

  protected <T extends h<t>,  extends p,  extends t> T a(Object paramObject)
  {
    if (r.a(paramObject))
      return (h)paramObject;
    return new r();
  }

  public void a(t paramt)
  {
    ((h)c()).c(paramt);
  }

  public void a(Throwable paramThrowable)
  {
    ((t)c()).a(paramThrowable);
  }

  public k b()
  {
    return ((p)c()).b();
  }

  public void b(boolean paramBoolean)
  {
    ((t)c()).b(paramBoolean);
  }

  public <T extends h<t>,  extends p,  extends t> T c()
  {
    return (h)this.b;
  }

  public int compareTo(Object paramObject)
  {
    return ((p)c()).compareTo(paramObject);
  }

  public Collection<t> d()
  {
    return ((h)c()).d();
  }

  public boolean e()
  {
    return ((h)c()).e();
  }

  public boolean h()
  {
    return ((t)c()).h();
  }

  public Throwable i()
  {
    return ((t)c()).i();
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.c.o
 * JD-Core Version:    0.6.2
 */