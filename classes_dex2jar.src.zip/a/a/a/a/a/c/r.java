package a.a.a.a.a.c;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

public class r
  implements h<t>, p, t
{
  private final List<t> a = new ArrayList();
  private final AtomicBoolean b = new AtomicBoolean(false);
  private final AtomicReference<Throwable> c = new AtomicReference(null);

  public static boolean a(Object paramObject)
  {
    try
    {
      h localh = (h)paramObject;
      t localt = (t)paramObject;
      p localp = (p)paramObject;
      return (localh != null) && (localt != null) && (localp != null);
    }
    catch (ClassCastException localClassCastException)
    {
    }
    return false;
  }

  public void a(t paramt)
  {
    try
    {
      this.a.add(paramt);
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  public void a(Throwable paramThrowable)
  {
    this.c.set(paramThrowable);
  }

  public k b()
  {
    return k.b;
  }

  public void b(boolean paramBoolean)
  {
    try
    {
      this.b.set(paramBoolean);
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  public int compareTo(Object paramObject)
  {
    return k.a(this, paramObject);
  }

  public Collection<t> d()
  {
    try
    {
      Collection localCollection = Collections.unmodifiableCollection(this.a);
      return localCollection;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  public boolean e()
  {
    Iterator localIterator = d().iterator();
    while (localIterator.hasNext())
      if (!((t)localIterator.next()).h())
        return false;
    return true;
  }

  public boolean h()
  {
    return this.b.get();
  }

  public Throwable i()
  {
    return (Throwable)this.c.get();
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.c.r
 * JD-Core Version:    0.6.2
 */