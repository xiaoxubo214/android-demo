package a.a.a.a.a.c;

import android.annotation.TargetApi;
import java.util.concurrent.Callable;
import java.util.concurrent.RunnableFuture;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class s extends ThreadPoolExecutor
{
  private static final int a = 0;
  private static final int b = 0;
  private static final int c = 0;
  private static final long d = 1L;

  <T extends Runnable,  extends h,  extends t,  extends p> s(int paramInt1, int paramInt2, long paramLong, TimeUnit paramTimeUnit, i<T> parami, ThreadFactory paramThreadFactory)
  {
    super(paramInt1, paramInt2, paramLong, paramTimeUnit, parami, paramThreadFactory);
    prestartAllCoreThreads();
  }

  public static s a()
  {
    return a(b, c);
  }

  public static s a(int paramInt)
  {
    return a(paramInt, paramInt);
  }

  public static <T extends Runnable,  extends h,  extends t,  extends p> s a(int paramInt1, int paramInt2)
  {
    return new s(paramInt1, paramInt2, 1L, TimeUnit.SECONDS, new i(), new a(10));
  }

  protected void afterExecute(Runnable paramRunnable, Throwable paramThrowable)
  {
    t localt = (t)paramRunnable;
    localt.b(true);
    localt.a(paramThrowable);
    b().d();
    super.afterExecute(paramRunnable, paramThrowable);
  }

  public i b()
  {
    return (i)super.getQueue();
  }

  @TargetApi(9)
  public void execute(Runnable paramRunnable)
  {
    if (r.a(paramRunnable))
    {
      super.execute(paramRunnable);
      return;
    }
    super.execute(newTaskFor(paramRunnable, null));
  }

  protected <T> RunnableFuture<T> newTaskFor(Runnable paramRunnable, T paramT)
  {
    return new o(paramRunnable, paramT);
  }

  protected <T> RunnableFuture<T> newTaskFor(Callable<T> paramCallable)
  {
    return new o(paramCallable);
  }

  protected static final class a
    implements ThreadFactory
  {
    private final int a;

    public a(int paramInt)
    {
      this.a = paramInt;
    }

    public Thread newThread(Runnable paramRunnable)
    {
      Thread localThread = new Thread(paramRunnable);
      localThread.setPriority(this.a);
      localThread.setName("Queue");
      return localThread;
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.c.s
 * JD-Core Version:    0.6.2
 */