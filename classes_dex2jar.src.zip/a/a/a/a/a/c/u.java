package a.a.a.a.a.c;

public class u extends RuntimeException
{
  public u()
  {
  }

  public u(String paramString)
  {
    super(paramString);
  }

  public u(String paramString, Throwable paramThrowable)
  {
    super(paramString, paramThrowable);
  }

  public u(Throwable paramThrowable)
  {
    super(paramThrowable);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.c.u
 * JD-Core Version:    0.6.2
 */