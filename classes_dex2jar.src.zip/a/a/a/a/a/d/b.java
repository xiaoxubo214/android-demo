package a.a.a.a.a.d;

import a.a.a.a.a.b.k;
import android.content.Context;
import java.io.IOException;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

public abstract class b<T>
  implements n<T>
{
  static final int a = -1;
  protected final Context b;
  protected final d<T> c;
  final ScheduledExecutorService d;
  final AtomicReference<ScheduledFuture<?>> e;
  volatile int f = -1;

  public b(Context paramContext, ScheduledExecutorService paramScheduledExecutorService, d<T> paramd)
  {
    this.b = paramContext;
    this.d = paramScheduledExecutorService;
    this.c = paramd;
    this.e = new AtomicReference();
  }

  public void a()
  {
    h();
  }

  protected void a(int paramInt)
  {
    this.f = paramInt;
    a(0L, this.f);
  }

  void a(long paramLong1, long paramLong2)
  {
    int i;
    if (this.e.get() == null)
      i = 1;
    while (true)
    {
      s locals;
      if (i != 0)
      {
        locals = new s(this.b, this);
        k.a(this.b, "Scheduling time based file roll over every " + paramLong2 + " seconds");
      }
      try
      {
        this.e.set(this.d.scheduleAtFixedRate(locals, paramLong1, paramLong2, TimeUnit.SECONDS));
        return;
        i = 0;
      }
      catch (RejectedExecutionException localRejectedExecutionException)
      {
        k.a(this.b, "Failed to schedule time based file roll over", localRejectedExecutionException);
      }
    }
  }

  public void a(T paramT)
  {
    k.a(this.b, paramT.toString());
    try
    {
      this.c.a(paramT);
      d();
      return;
    }
    catch (IOException localIOException)
    {
      while (true)
        k.a(this.b, "Failed to write event.", localIOException);
    }
  }

  public void b()
  {
    this.c.g();
  }

  public boolean c()
  {
    try
    {
      boolean bool = this.c.d();
      return bool;
    }
    catch (IOException localIOException)
    {
      k.a(this.b, "Failed to roll file over.", localIOException);
    }
    return false;
  }

  public void d()
  {
    if (this.f != -1);
    for (int i = 1; ; i = 0)
    {
      if (i != 0)
        a(this.f, this.f);
      return;
    }
  }

  public void e()
  {
    if (this.e.get() != null)
    {
      k.a(this.b, "Cancelling time-based rollover because no events are currently being generated.");
      ((ScheduledFuture)this.e.get()).cancel(false);
      this.e.set(null);
    }
  }

  public int g()
  {
    return this.f;
  }

  // ERROR //
  void h()
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 134	a/a/a/a/a/d/b:f	()La/a/a/a/a/d/p;
    //   4: astore_1
    //   5: aload_1
    //   6: ifnonnull +13 -> 19
    //   9: aload_0
    //   10: getfield 30	a/a/a/a/a/d/b:b	Landroid/content/Context;
    //   13: ldc 136
    //   15: invokestatic 80	a/a/a/a/a/b/k:a	(Landroid/content/Context;Ljava/lang/String;)V
    //   18: return
    //   19: aload_0
    //   20: getfield 30	a/a/a/a/a/d/b:b	Landroid/content/Context;
    //   23: ldc 138
    //   25: invokestatic 80	a/a/a/a/a/b/k:a	(Landroid/content/Context;Ljava/lang/String;)V
    //   28: aload_0
    //   29: getfield 34	a/a/a/a/a/d/b:c	La/a/a/a/a/d/d;
    //   32: invokevirtual 141	a/a/a/a/a/d/d:f	()Ljava/util/List;
    //   35: astore_2
    //   36: iconst_0
    //   37: istore_3
    //   38: aload_2
    //   39: invokeinterface 146 1 0
    //   44: ifle +91 -> 135
    //   47: aload_0
    //   48: getfield 30	a/a/a/a/a/d/b:b	Landroid/content/Context;
    //   51: astore 7
    //   53: getstatic 152	java/util/Locale:US	Ljava/util/Locale;
    //   56: astore 8
    //   58: iconst_1
    //   59: anewarray 5	java/lang/Object
    //   62: astore 9
    //   64: aload 9
    //   66: iconst_0
    //   67: aload_2
    //   68: invokeinterface 146 1 0
    //   73: invokestatic 158	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   76: aastore
    //   77: aload 7
    //   79: aload 8
    //   81: ldc 160
    //   83: aload 9
    //   85: invokestatic 166	java/lang/String:format	(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   88: invokestatic 80	a/a/a/a/a/b/k:a	(Landroid/content/Context;Ljava/lang/String;)V
    //   91: aload_1
    //   92: aload_2
    //   93: invokeinterface 171 2 0
    //   98: istore 10
    //   100: iload 10
    //   102: ifeq +28 -> 130
    //   105: aload_2
    //   106: invokeinterface 146 1 0
    //   111: istore 11
    //   113: iload 11
    //   115: iload_3
    //   116: iadd
    //   117: istore 5
    //   119: aload_0
    //   120: getfield 34	a/a/a/a/a/d/b:c	La/a/a/a/a/d/d;
    //   123: aload_2
    //   124: invokevirtual 174	a/a/a/a/a/d/d:a	(Ljava/util/List;)V
    //   127: iload 5
    //   129: istore_3
    //   130: iload 10
    //   132: ifne +15 -> 147
    //   135: iload_3
    //   136: ifne -118 -> 18
    //   139: aload_0
    //   140: getfield 34	a/a/a/a/a/d/b:c	La/a/a/a/a/d/d;
    //   143: invokevirtual 175	a/a/a/a/a/d/d:h	()V
    //   146: return
    //   147: aload_0
    //   148: getfield 34	a/a/a/a/a/d/b:c	La/a/a/a/a/d/d;
    //   151: invokevirtual 141	a/a/a/a/a/d/d:f	()Ljava/util/List;
    //   154: astore 12
    //   156: aload 12
    //   158: astore_2
    //   159: goto -121 -> 38
    //   162: astore 4
    //   164: iload_3
    //   165: istore 5
    //   167: aload 4
    //   169: astore 6
    //   171: aload_0
    //   172: getfield 30	a/a/a/a/a/d/b:b	Landroid/content/Context;
    //   175: new 59	java/lang/StringBuilder
    //   178: dup
    //   179: invokespecial 60	java/lang/StringBuilder:<init>	()V
    //   182: ldc 177
    //   184: invokevirtual 66	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   187: aload 6
    //   189: invokevirtual 180	java/lang/Exception:getMessage	()Ljava/lang/String;
    //   192: invokevirtual 66	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   195: invokevirtual 75	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   198: aload 6
    //   200: invokestatic 101	a/a/a/a/a/b/k:a	(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Throwable;)V
    //   203: iload 5
    //   205: istore_3
    //   206: goto -71 -> 135
    //   209: astore 6
    //   211: goto -40 -> 171
    //
    // Exception table:
    //   from	to	target	type
    //   38	100	162	java/lang/Exception
    //   105	113	162	java/lang/Exception
    //   147	156	162	java/lang/Exception
    //   119	127	209	java/lang/Exception
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.d.b
 * JD-Core Version:    0.6.2
 */