package a.a.a.a.a.d;

import a.a.a.a.a.b.k;
import a.a.a.a.a.b.n;
import android.content.Context;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.TreeSet;
import java.util.concurrent.CopyOnWriteArrayList;

public abstract class d<T>
{
  public static final String a = "_";
  public static final int b = 8000;
  public static final int c = 1;
  public static final int d = 100;
  protected final Context e;
  protected final c<T> f;
  protected final n g;
  protected final l h;
  protected volatile long i;
  protected final List<m> j = new CopyOnWriteArrayList();
  private final int k;

  public d(Context paramContext, c<T> paramc, n paramn, l paraml, int paramInt)
    throws IOException
  {
    this.e = paramContext.getApplicationContext();
    this.f = paramc;
    this.h = paraml;
    this.g = paramn;
    this.i = this.g.a();
    this.k = paramInt;
  }

  private void a(int paramInt)
    throws IOException
  {
    if (!this.h.a(paramInt, c()))
    {
      Locale localLocale = Locale.US;
      Object[] arrayOfObject = new Object[3];
      arrayOfObject[0] = Integer.valueOf(this.h.a());
      arrayOfObject[1] = Integer.valueOf(paramInt);
      arrayOfObject[2] = Integer.valueOf(c());
      String str = String.format(localLocale, "session analytics events file is %d bytes, new event is %d bytes, this is over flush limit of %d, rolling it over", arrayOfObject);
      k.a(this.e, 4, "Fabric", str);
      d();
    }
  }

  private void b(String paramString)
  {
    Iterator localIterator = this.j.iterator();
    while (localIterator.hasNext())
    {
      m localm = (m)localIterator.next();
      try
      {
        localm.a(paramString);
      }
      catch (Exception localException)
      {
        k.a(this.e, "One of the roll over listeners threw an exception", localException);
      }
    }
  }

  public long a(String paramString)
  {
    String[] arrayOfString = paramString.split("_");
    if (arrayOfString.length != 3)
      return 0L;
    try
    {
      long l = Long.valueOf(arrayOfString[2]).longValue();
      return l;
    }
    catch (NumberFormatException localNumberFormatException)
    {
    }
    return 0L;
  }

  protected abstract String a();

  public void a(m paramm)
  {
    if (paramm != null)
      this.j.add(paramm);
  }

  public void a(T paramT)
    throws IOException
  {
    byte[] arrayOfByte = this.f.a(paramT);
    a(arrayOfByte.length);
    this.h.a(arrayOfByte);
  }

  public void a(List<File> paramList)
  {
    this.h.a(paramList);
  }

  protected int b()
  {
    return this.k;
  }

  protected int c()
  {
    return 8000;
  }

  public boolean d()
    throws IOException
  {
    boolean bool = true;
    String str;
    if (!this.h.b())
    {
      str = a();
      this.h.a(str);
      Context localContext = this.e;
      Locale localLocale = Locale.US;
      Object[] arrayOfObject = new Object[bool];
      arrayOfObject[0] = str;
      k.a(localContext, 4, "Fabric", String.format(localLocale, "generated new file %s", arrayOfObject));
      this.i = this.g.a();
    }
    while (true)
    {
      b(str);
      return bool;
      str = null;
      bool = false;
    }
  }

  public long e()
  {
    return this.i;
  }

  public List<File> f()
  {
    return this.h.a(1);
  }

  public void g()
  {
    this.h.a(this.h.e());
    this.h.f();
  }

  public void h()
  {
    List localList = this.h.e();
    int m = b();
    if (localList.size() <= m)
      return;
    int n = localList.size() - m;
    Context localContext = this.e;
    Locale localLocale = Locale.US;
    Object[] arrayOfObject = new Object[3];
    arrayOfObject[0] = Integer.valueOf(localList.size());
    arrayOfObject[1] = Integer.valueOf(m);
    arrayOfObject[2] = Integer.valueOf(n);
    k.a(localContext, String.format(localLocale, "Found %d files in  roll over directory, this is greater than %d, deleting %d oldest files", arrayOfObject));
    TreeSet localTreeSet = new TreeSet(new e(this));
    Iterator localIterator1 = localList.iterator();
    while (localIterator1.hasNext())
    {
      File localFile = (File)localIterator1.next();
      localTreeSet.add(new a(localFile, a(localFile.getName())));
    }
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator2 = localTreeSet.iterator();
    do
    {
      if (!localIterator2.hasNext())
        break;
      localArrayList.add(((a)localIterator2.next()).a);
    }
    while (localArrayList.size() != n);
    this.h.a(localArrayList);
  }

  static class a
  {
    final File a;
    final long b;

    public a(File paramFile, long paramLong)
    {
      this.a = paramFile;
      this.b = paramLong;
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.d.d
 * JD-Core Version:    0.6.2
 */