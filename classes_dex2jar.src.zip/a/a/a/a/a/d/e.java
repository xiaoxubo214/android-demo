package a.a.a.a.a.d;

import java.util.Comparator;

class e
  implements Comparator<d.a>
{
  e(d paramd)
  {
  }

  public int a(d.a parama1, d.a parama2)
  {
    return (int)(parama1.b - parama2.b);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.d.e
 * JD-Core Version:    0.6.2
 */