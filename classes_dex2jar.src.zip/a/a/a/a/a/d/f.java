package a.a.a.a.a.d;

import a.a.a.a.a.b.k;
import android.content.Context;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;

public abstract class f<T>
  implements m
{
  protected final Context a;
  protected final ScheduledExecutorService b;
  protected n<T> c;

  public f(Context paramContext, n<T> paramn, d paramd, ScheduledExecutorService paramScheduledExecutorService)
  {
    this.a = paramContext.getApplicationContext();
    this.b = paramScheduledExecutorService;
    this.c = paramn;
    paramd.a(this);
  }

  public void a()
  {
    b(new j(this));
  }

  public void a(T paramT)
  {
    a(new h(this, paramT));
  }

  public void a(T paramT, boolean paramBoolean)
  {
    b(new g(this, paramT, paramBoolean));
  }

  protected void a(Runnable paramRunnable)
  {
    try
    {
      this.b.submit(paramRunnable).get();
      return;
    }
    catch (Exception localException)
    {
      k.a(this.a, "Failed to run events task", localException);
    }
  }

  public void a(String paramString)
  {
    b(new i(this));
  }

  protected abstract n<T> b();

  protected void b(Runnable paramRunnable)
  {
    try
    {
      this.b.submit(paramRunnable);
      return;
    }
    catch (Exception localException)
    {
      k.a(this.a, "Failed to submit events task", localException);
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.d.f
 * JD-Core Version:    0.6.2
 */