package a.a.a.a.a.d;

import a.a.a.a.a.b.k;

class g
  implements Runnable
{
  g(f paramf, Object paramObject, boolean paramBoolean)
  {
  }

  public void run()
  {
    try
    {
      this.c.c.a(this.a);
      if (this.b)
        this.c.c.c();
      return;
    }
    catch (Exception localException)
    {
      k.a(this.c.a, "Failed to record event.", localException);
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.d.g
 * JD-Core Version:    0.6.2
 */