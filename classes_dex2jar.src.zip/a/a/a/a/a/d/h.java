package a.a.a.a.a.d;

import a.a.a.a.a.b.k;

class h
  implements Runnable
{
  h(f paramf, Object paramObject)
  {
  }

  public void run()
  {
    try
    {
      this.b.c.a(this.a);
      return;
    }
    catch (Exception localException)
    {
      k.a(this.b.a, "Crashlytics failed to record event", localException);
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.d.h
 * JD-Core Version:    0.6.2
 */