package a.a.a.a.a.d;

import a.a.a.a.a.b.k;

class i
  implements Runnable
{
  i(f paramf)
  {
  }

  public void run()
  {
    try
    {
      this.a.c.a();
      return;
    }
    catch (Exception localException)
    {
      k.a(this.a.a, "Failed to send events files.", localException);
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.d.i
 * JD-Core Version:    0.6.2
 */