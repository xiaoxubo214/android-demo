package a.a.a.a.a.d;

import a.a.a.a.a.b.k;

class j
  implements Runnable
{
  j(f paramf)
  {
  }

  public void run()
  {
    try
    {
      n localn = this.a.c;
      this.a.c = this.a.b();
      localn.b();
      return;
    }
    catch (Exception localException)
    {
      k.a(this.a.a, "Failed to disable events.", localException);
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.d.j
 * JD-Core Version:    0.6.2
 */