package a.a.a.a.a.d;

public abstract interface k<T>
{
  public abstract void a();

  public abstract void a(T paramT);

  public abstract void b();
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.d.k
 * JD-Core Version:    0.6.2
 */