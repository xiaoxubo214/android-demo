package a.a.a.a.a.d;

import java.io.File;
import java.io.IOException;
import java.util.List;

public abstract interface l
{
  public abstract int a();

  public abstract List<File> a(int paramInt);

  public abstract void a(String paramString)
    throws IOException;

  public abstract void a(List<File> paramList);

  public abstract void a(byte[] paramArrayOfByte)
    throws IOException;

  public abstract boolean a(int paramInt1, int paramInt2);

  public abstract boolean b();

  public abstract File c();

  public abstract File d();

  public abstract List<File> e();

  public abstract void f();
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.d.l
 * JD-Core Version:    0.6.2
 */