package a.a.a.a.a.d;

import a.a.a.a.a.b.k;
import android.content.Context;

public class s
  implements Runnable
{
  private final Context a;
  private final o b;

  public s(Context paramContext, o paramo)
  {
    this.a = paramContext;
    this.b = paramo;
  }

  public void run()
  {
    try
    {
      k.a(this.a, "Performing time based file roll over.");
      if (!this.b.c())
        this.b.e();
      return;
    }
    catch (Exception localException)
    {
      k.a(this.a, "Failed to roll over file", localException);
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.d.s
 * JD-Core Version:    0.6.2
 */