package a.a.a.a.a.e;

import java.util.Collections;
import java.util.Locale;
import java.util.Map;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSocketFactory;

public class b
  implements o
{
  private static final String a = "https";
  private final a.a.a.a.q b;
  private q c;
  private SSLSocketFactory d;
  private boolean e;

  public b()
  {
    this(new a.a.a.a.d());
  }

  public b(a.a.a.a.q paramq)
  {
    this.b = paramq;
  }

  private boolean a(String paramString)
  {
    return (paramString != null) && (paramString.toLowerCase(Locale.US).startsWith("https"));
  }

  private void b()
  {
    try
    {
      this.e = false;
      this.d = null;
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  private SSLSocketFactory c()
  {
    try
    {
      if ((this.d == null) && (!this.e))
        this.d = d();
      SSLSocketFactory localSSLSocketFactory = this.d;
      return localSSLSocketFactory;
    }
    finally
    {
    }
  }

  private SSLSocketFactory d()
  {
    try
    {
      this.e = true;
      try
      {
        localSSLSocketFactory = p.a(this.c);
        this.b.a("Fabric", "Custom SSL pinning enabled");
        return localSSLSocketFactory;
      }
      catch (Exception localException)
      {
        while (true)
        {
          this.b.e("Fabric", "Exception while validating pinned certs", localException);
          SSLSocketFactory localSSLSocketFactory = null;
        }
      }
    }
    finally
    {
    }
  }

  public e a(d paramd, String paramString)
  {
    return a(paramd, paramString, Collections.emptyMap());
  }

  public e a(d paramd, String paramString, Map<String, String> paramMap)
  {
    e locale;
    switch (c.a[paramd.ordinal()])
    {
    default:
      throw new IllegalArgumentException("Unsupported HTTP method!");
    case 1:
      locale = e.a(paramString, paramMap, true);
    case 2:
    case 3:
    case 4:
    }
    while (true)
    {
      if ((a(paramString)) && (this.c != null))
      {
        SSLSocketFactory localSSLSocketFactory = c();
        if (localSSLSocketFactory != null)
          ((HttpsURLConnection)locale.a()).setSSLSocketFactory(localSSLSocketFactory);
      }
      return locale;
      locale = e.b(paramString, paramMap, true);
      continue;
      locale = e.d(paramString);
      continue;
      locale = e.e(paramString);
    }
  }

  public q a()
  {
    return this.c;
  }

  public void a(q paramq)
  {
    if (this.c != paramq)
    {
      this.c = paramq;
      b();
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.e.b
 * JD-Core Version:    0.6.2
 */