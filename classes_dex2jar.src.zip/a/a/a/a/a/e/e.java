package a.a.a.a.a.e;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.Flushable;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.Proxy;
import java.net.Proxy.Type;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;
import java.nio.charset.CharsetEncoder;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import java.util.zip.GZIPInputStream;

public class e
{
  public static final String A = "POST";
  public static final String B = "PUT";
  public static final String C = "TRACE";
  public static final String D = "charset";
  private static final String F = "00content0boundary00";
  private static final String G = "multipart/form-data; boundary=00content0boundary00";
  private static final String H = "\r\n";
  private static final String[] I = new String[0];
  private static c J = c.a;
  public static final String a = "UTF-8";
  public static final String b = "application/x-www-form-urlencoded";
  public static final String c = "application/json";
  public static final String d = "gzip";
  public static final String e = "Accept";
  public static final String f = "Accept-Charset";
  public static final String g = "Accept-Encoding";
  public static final String h = "Authorization";
  public static final String i = "Cache-Control";
  public static final String j = "Content-Encoding";
  public static final String k = "Content-Length";
  public static final String l = "Content-Type";
  public static final String m = "Date";
  public static final String n = "ETag";
  public static final String o = "Expires";
  public static final String p = "If-None-Match";
  public static final String q = "Last-Modified";
  public static final String r = "Location";
  public static final String s = "Proxy-Authorization";
  public static final String t = "Referer";
  public static final String u = "Server";
  public static final String v = "User-Agent";
  public static final String w = "DELETE";
  public static final String x = "GET";
  public static final String y = "HEAD";
  public static final String z = "OPTIONS";
  public final URL E;
  private HttpURLConnection K = null;
  private final String L;
  private g M;
  private boolean N;
  private boolean O;
  private boolean P = true;
  private boolean Q = false;
  private int R = 8192;
  private String S;
  private int T;

  public e(CharSequence paramCharSequence, String paramString)
    throws e.e
  {
    try
    {
      this.E = new URL(paramCharSequence.toString());
      this.L = paramString;
      return;
    }
    catch (MalformedURLException localMalformedURLException)
    {
      throw new e(localMalformedURLException);
    }
  }

  public e(URL paramURL, String paramString)
    throws e.e
  {
    this.E = paramURL;
    this.L = paramString;
  }

  private Proxy R()
  {
    return new Proxy(Proxy.Type.HTTP, new InetSocketAddress(this.S, this.T));
  }

  private HttpURLConnection S()
  {
    try
    {
      if (this.S != null);
      HttpURLConnection localHttpURLConnection;
      for (Object localObject = J.a(this.E, R()); ; localObject = localHttpURLConnection)
      {
        ((HttpURLConnection)localObject).setRequestMethod(this.L);
        return localObject;
        localHttpURLConnection = J.a(this.E);
      }
    }
    catch (IOException localIOException)
    {
      throw new e(localIOException);
    }
  }

  public static e a(CharSequence paramCharSequence, Map<?, ?> paramMap, boolean paramBoolean)
  {
    String str = a(paramCharSequence, paramMap);
    if (paramBoolean)
      str = a(str);
    return b(str);
  }

  public static e a(CharSequence paramCharSequence, boolean paramBoolean, Object[] paramArrayOfObject)
  {
    String str = a(paramCharSequence, paramArrayOfObject);
    if (paramBoolean)
      str = a(str);
    return b(str);
  }

  public static e a(URL paramURL)
    throws e.e
  {
    return new e(paramURL, "GET");
  }

  // ERROR //
  public static String a(CharSequence paramCharSequence)
    throws e.e
  {
    // Byte code:
    //   0: new 153	java/net/URL
    //   3: dup
    //   4: aload_0
    //   5: invokeinterface 159 1 0
    //   10: invokespecial 162	java/net/URL:<init>	(Ljava/lang/String;)V
    //   13: astore_1
    //   14: aload_1
    //   15: invokevirtual 230	java/net/URL:getHost	()Ljava/lang/String;
    //   18: astore_2
    //   19: aload_1
    //   20: invokevirtual 234	java/net/URL:getPort	()I
    //   23: istore_3
    //   24: iload_3
    //   25: iconst_m1
    //   26: if_icmpeq +30 -> 56
    //   29: new 236	java/lang/StringBuilder
    //   32: dup
    //   33: invokespecial 237	java/lang/StringBuilder:<init>	()V
    //   36: aload_2
    //   37: invokevirtual 241	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   40: bipush 58
    //   42: invokevirtual 244	java/lang/StringBuilder:append	(C)Ljava/lang/StringBuilder;
    //   45: iload_3
    //   46: invokestatic 249	java/lang/Integer:toString	(I)Ljava/lang/String;
    //   49: invokevirtual 241	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   52: invokevirtual 250	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   55: astore_2
    //   56: new 252	java/net/URI
    //   59: dup
    //   60: aload_1
    //   61: invokevirtual 255	java/net/URL:getProtocol	()Ljava/lang/String;
    //   64: aload_2
    //   65: aload_1
    //   66: invokevirtual 258	java/net/URL:getPath	()Ljava/lang/String;
    //   69: aload_1
    //   70: invokevirtual 261	java/net/URL:getQuery	()Ljava/lang/String;
    //   73: aconst_null
    //   74: invokespecial 264	java/net/URI:<init>	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    //   77: invokevirtual 267	java/net/URI:toASCIIString	()Ljava/lang/String;
    //   80: astore 7
    //   82: aload 7
    //   84: bipush 63
    //   86: invokevirtual 271	java/lang/String:indexOf	(I)I
    //   89: istore 8
    //   91: iload 8
    //   93: ifle +65 -> 158
    //   96: iload 8
    //   98: iconst_1
    //   99: iadd
    //   100: aload 7
    //   102: invokevirtual 274	java/lang/String:length	()I
    //   105: if_icmpge +53 -> 158
    //   108: new 236	java/lang/StringBuilder
    //   111: dup
    //   112: invokespecial 237	java/lang/StringBuilder:<init>	()V
    //   115: aload 7
    //   117: iconst_0
    //   118: iload 8
    //   120: iconst_1
    //   121: iadd
    //   122: invokevirtual 278	java/lang/String:substring	(II)Ljava/lang/String;
    //   125: invokevirtual 241	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   128: aload 7
    //   130: iload 8
    //   132: iconst_1
    //   133: iadd
    //   134: invokevirtual 280	java/lang/String:substring	(I)Ljava/lang/String;
    //   137: ldc_w 282
    //   140: ldc_w 284
    //   143: invokevirtual 288	java/lang/String:replace	(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   146: invokevirtual 241	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   149: invokevirtual 250	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   152: astore 9
    //   154: aload 9
    //   156: astore 7
    //   158: aload 7
    //   160: areturn
    //   161: astore 10
    //   163: new 139	a/a/a/a/a/e/e$e
    //   166: dup
    //   167: aload 10
    //   169: invokespecial 169	a/a/a/a/a/e/e$e:<init>	(Ljava/io/IOException;)V
    //   172: athrow
    //   173: astore 4
    //   175: new 194	java/io/IOException
    //   178: dup
    //   179: ldc_w 290
    //   182: invokespecial 291	java/io/IOException:<init>	(Ljava/lang/String;)V
    //   185: astore 5
    //   187: aload 5
    //   189: aload 4
    //   191: invokevirtual 295	java/io/IOException:initCause	(Ljava/lang/Throwable;)Ljava/lang/Throwable;
    //   194: pop
    //   195: new 139	a/a/a/a/a/e/e$e
    //   198: dup
    //   199: aload 5
    //   201: invokespecial 169	a/a/a/a/a/e/e$e:<init>	(Ljava/io/IOException;)V
    //   204: athrow
    //
    // Exception table:
    //   from	to	target	type
    //   0	14	161	java/io/IOException
    //   56	91	173	java/net/URISyntaxException
    //   96	154	173	java/net/URISyntaxException
  }

  public static String a(CharSequence paramCharSequence, Map<?, ?> paramMap)
  {
    String str = paramCharSequence.toString();
    if ((paramMap == null) || (paramMap.isEmpty()))
      return str;
    StringBuilder localStringBuilder = new StringBuilder(str);
    a(str, localStringBuilder);
    b(str, localStringBuilder);
    Iterator localIterator = paramMap.entrySet().iterator();
    Map.Entry localEntry1 = (Map.Entry)localIterator.next();
    localStringBuilder.append(localEntry1.getKey().toString());
    localStringBuilder.append('=');
    Object localObject1 = localEntry1.getValue();
    if (localObject1 != null)
      localStringBuilder.append(localObject1);
    while (localIterator.hasNext())
    {
      localStringBuilder.append('&');
      Map.Entry localEntry2 = (Map.Entry)localIterator.next();
      localStringBuilder.append(localEntry2.getKey().toString());
      localStringBuilder.append('=');
      Object localObject2 = localEntry2.getValue();
      if (localObject2 != null)
        localStringBuilder.append(localObject2);
    }
    return localStringBuilder.toString();
  }

  public static String a(CharSequence paramCharSequence, Object[] paramArrayOfObject)
  {
    String str = paramCharSequence.toString();
    if ((paramArrayOfObject == null) || (paramArrayOfObject.length == 0))
      return str;
    if (paramArrayOfObject.length % 2 != 0)
      throw new IllegalArgumentException("Must specify an even number of parameter names/values");
    StringBuilder localStringBuilder = new StringBuilder(str);
    a(str, localStringBuilder);
    b(str, localStringBuilder);
    localStringBuilder.append(paramArrayOfObject[0]);
    localStringBuilder.append('=');
    Object localObject1 = paramArrayOfObject[1];
    if (localObject1 != null)
      localStringBuilder.append(localObject1);
    for (int i1 = 2; i1 < paramArrayOfObject.length; i1 += 2)
    {
      localStringBuilder.append('&');
      localStringBuilder.append(paramArrayOfObject[i1]);
      localStringBuilder.append('=');
      Object localObject2 = paramArrayOfObject[(i1 + 1)];
      if (localObject2 != null)
        localStringBuilder.append(localObject2);
    }
    return localStringBuilder.toString();
  }

  private static StringBuilder a(String paramString, StringBuilder paramStringBuilder)
  {
    if (2 + paramString.indexOf(':') == paramString.lastIndexOf('/'))
      paramStringBuilder.append('/');
    return paramStringBuilder;
  }

  public static void a(int paramInt)
  {
    String str = Integer.toString(paramInt);
    j("http.proxyPort", str);
    j("https.proxyPort", str);
  }

  public static void a(c paramc)
  {
    if (paramc == null)
    {
      J = c.a;
      return;
    }
    J = paramc;
  }

  public static void a(String paramString)
  {
    j("http.proxyHost", paramString);
    j("https.proxyHost", paramString);
  }

  public static void a(boolean paramBoolean)
  {
    j("http.keepAlive", Boolean.toString(paramBoolean));
  }

  public static void a(String[] paramArrayOfString)
  {
    if ((paramArrayOfString != null) && (paramArrayOfString.length > 0))
    {
      StringBuilder localStringBuilder = new StringBuilder();
      int i1 = -1 + paramArrayOfString.length;
      for (int i2 = 0; i2 < i1; i2++)
        localStringBuilder.append(paramArrayOfString[i2]).append('|');
      localStringBuilder.append(paramArrayOfString[i1]);
      j("http.nonProxyHosts", localStringBuilder.toString());
      return;
    }
    j("http.nonProxyHosts", null);
  }

  public static e b(CharSequence paramCharSequence)
    throws e.e
  {
    return new e(paramCharSequence, "GET");
  }

  public static e b(CharSequence paramCharSequence, Map<?, ?> paramMap, boolean paramBoolean)
  {
    String str = a(paramCharSequence, paramMap);
    if (paramBoolean)
      str = a(str);
    return c(str);
  }

  public static e b(CharSequence paramCharSequence, boolean paramBoolean, Object[] paramArrayOfObject)
  {
    String str = a(paramCharSequence, paramArrayOfObject);
    if (paramBoolean)
      str = a(str);
    return c(str);
  }

  public static e b(URL paramURL)
    throws e.e
  {
    return new e(paramURL, "POST");
  }

  private static StringBuilder b(String paramString, StringBuilder paramStringBuilder)
  {
    int i1 = paramString.indexOf('?');
    int i2 = -1 + paramStringBuilder.length();
    if (i1 == -1)
      paramStringBuilder.append('?');
    while ((i1 >= i2) || (paramString.charAt(i2) == '&'))
      return paramStringBuilder;
    paramStringBuilder.append('&');
    return paramStringBuilder;
  }

  public static e c(CharSequence paramCharSequence)
    throws e.e
  {
    return new e(paramCharSequence, "POST");
  }

  public static e c(CharSequence paramCharSequence, Map<?, ?> paramMap, boolean paramBoolean)
  {
    String str = a(paramCharSequence, paramMap);
    if (paramBoolean)
      str = a(str);
    return d(str);
  }

  public static e c(CharSequence paramCharSequence, boolean paramBoolean, Object[] paramArrayOfObject)
  {
    String str = a(paramCharSequence, paramArrayOfObject);
    if (paramBoolean)
      str = a(str);
    return d(str);
  }

  public static e c(URL paramURL)
    throws e.e
  {
    return new e(paramURL, "PUT");
  }

  public static e d(CharSequence paramCharSequence)
    throws e.e
  {
    return new e(paramCharSequence, "PUT");
  }

  public static e d(CharSequence paramCharSequence, Map<?, ?> paramMap, boolean paramBoolean)
  {
    String str = a(paramCharSequence, paramMap);
    if (paramBoolean)
      str = a(str);
    return e(str);
  }

  public static e d(CharSequence paramCharSequence, boolean paramBoolean, Object[] paramArrayOfObject)
  {
    String str = a(paramCharSequence, paramArrayOfObject);
    if (paramBoolean)
      str = a(str);
    return e(str);
  }

  public static e d(URL paramURL)
    throws e.e
  {
    return new e(paramURL, "DELETE");
  }

  public static e e(CharSequence paramCharSequence)
    throws e.e
  {
    return new e(paramCharSequence, "DELETE");
  }

  public static e e(CharSequence paramCharSequence, Map<?, ?> paramMap, boolean paramBoolean)
  {
    String str = a(paramCharSequence, paramMap);
    if (paramBoolean)
      str = a(str);
    return f(str);
  }

  public static e e(CharSequence paramCharSequence, boolean paramBoolean, Object[] paramArrayOfObject)
  {
    String str = a(paramCharSequence, paramArrayOfObject);
    if (paramBoolean)
      str = a(str);
    return f(str);
  }

  public static e e(URL paramURL)
    throws e.e
  {
    return new e(paramURL, "HEAD");
  }

  public static e f(CharSequence paramCharSequence)
    throws e.e
  {
    return new e(paramCharSequence, "HEAD");
  }

  public static e f(URL paramURL)
    throws e.e
  {
    return new e(paramURL, "OPTIONS");
  }

  public static e g(CharSequence paramCharSequence)
    throws e.e
  {
    return new e(paramCharSequence, "OPTIONS");
  }

  public static e g(URL paramURL)
    throws e.e
  {
    return new e(paramURL, "TRACE");
  }

  public static e h(CharSequence paramCharSequence)
    throws e.e
  {
    return new e(paramCharSequence, "TRACE");
  }

  private static String j(String paramString1, String paramString2)
  {
    if (paramString2 != null);
    for (Object localObject = new f(paramString1, paramString2); ; localObject = new g(paramString1))
      return (String)AccessController.doPrivileged((PrivilegedAction)localObject);
  }

  private static String v(String paramString)
  {
    if ((paramString != null) && (paramString.length() > 0))
      return paramString;
    return "UTF-8";
  }

  public String A()
  {
    return e("Cache-Control");
  }

  public String B()
  {
    return e("ETag");
  }

  public long C()
  {
    return f("Expires");
  }

  public long D()
  {
    return f("Last-Modified");
  }

  public String E()
  {
    return e("Location");
  }

  public String F()
  {
    return e("Content-Type");
  }

  public int G()
  {
    return g("Content-Length");
  }

  public e H()
  {
    return t("application/json");
  }

  protected e I()
    throws IOException
  {
    if (this.M == null)
      return this;
    if (this.N)
      this.M.a("\r\n--00content0boundary00--\r\n");
    if (this.P);
    try
    {
      this.M.close();
      while (true)
      {
        label41: this.M = null;
        return this;
        this.M.close();
      }
    }
    catch (IOException localIOException)
    {
      break label41;
    }
  }

  protected e J()
    throws e.e
  {
    try
    {
      e locale = I();
      return locale;
    }
    catch (IOException localIOException)
    {
      throw new e(localIOException);
    }
  }

  protected e K()
    throws IOException
  {
    if (this.M != null)
      return this;
    a().setDoOutput(true);
    String str = c(a().getRequestProperty("Content-Type"), "charset");
    this.M = new g(a().getOutputStream(), str, this.R);
    return this;
  }

  protected e L()
    throws IOException
  {
    if (!this.N)
    {
      this.N = true;
      r("multipart/form-data; boundary=00content0boundary00").K();
      this.M.a("--00content0boundary00\r\n");
      return this;
    }
    this.M.a("\r\n--00content0boundary00\r\n");
    return this;
  }

  public OutputStreamWriter M()
    throws e.e
  {
    try
    {
      K();
      OutputStreamWriter localOutputStreamWriter = new OutputStreamWriter(this.M, g.a(this.M).charset());
      return localOutputStreamWriter;
    }
    catch (IOException localIOException)
    {
      throw new e(localIOException);
    }
  }

  public e N()
    throws e.e
  {
    return this;
  }

  public e O()
  {
    return this;
  }

  public URL P()
  {
    return a().getURL();
  }

  public String Q()
  {
    return a().getRequestMethod();
  }

  public int a(String paramString, int paramInt)
    throws e.e
  {
    J();
    return a().getHeaderFieldInt(paramString, paramInt);
  }

  public long a(String paramString, long paramLong)
    throws e.e
  {
    J();
    return a().getHeaderFieldDate(paramString, paramLong);
  }

  public e a(long paramLong)
  {
    a().setIfModifiedSince(paramLong);
    return this;
  }

  public e a(File paramFile)
    throws e.e
  {
    try
    {
      BufferedOutputStream localBufferedOutputStream = new BufferedOutputStream(new FileOutputStream(paramFile), this.R);
      return (e)new h(this, localBufferedOutputStream, this.P, localBufferedOutputStream).call();
    }
    catch (FileNotFoundException localFileNotFoundException)
    {
      throw new e(localFileNotFoundException);
    }
  }

  public e a(InputStream paramInputStream)
    throws e.e
  {
    try
    {
      K();
      a(paramInputStream, this.M);
      return this;
    }
    catch (IOException localIOException)
    {
      throw new e(localIOException);
    }
  }

  protected e a(InputStream paramInputStream, OutputStream paramOutputStream)
    throws IOException
  {
    return (e)new k(this, paramInputStream, this.P, paramInputStream, paramOutputStream).call();
  }

  public e a(OutputStream paramOutputStream)
    throws e.e
  {
    try
    {
      e locale = a(q(), paramOutputStream);
      return locale;
    }
    catch (IOException localIOException)
    {
      throw new e(localIOException);
    }
  }

  public e a(PrintStream paramPrintStream)
    throws e.e
  {
    return a(paramPrintStream);
  }

  public e a(Reader paramReader)
    throws e.e
  {
    try
    {
      K();
      OutputStreamWriter localOutputStreamWriter = new OutputStreamWriter(this.M, g.a(this.M).charset());
      return (e)new m(this, localOutputStreamWriter, paramReader, localOutputStreamWriter).call();
    }
    catch (IOException localIOException)
    {
      throw new e(localIOException);
    }
  }

  protected e a(Reader paramReader, Writer paramWriter)
    throws IOException
  {
    return (e)new l(this, paramReader, this.P, paramReader, paramWriter).call();
  }

  public e a(Writer paramWriter)
    throws e.e
  {
    BufferedReader localBufferedReader = t();
    return (e)new j(this, localBufferedReader, this.P, localBufferedReader, paramWriter).call();
  }

  public e a(Appendable paramAppendable)
    throws e.e
  {
    BufferedReader localBufferedReader = t();
    return (e)new i(this, localBufferedReader, this.P, localBufferedReader, paramAppendable).call();
  }

  public e a(Object paramObject1, Object paramObject2)
    throws e.e
  {
    return a(paramObject1, paramObject2, "UTF-8");
  }

  public e a(Object paramObject1, Object paramObject2, String paramString)
    throws e.e
  {
    int i1;
    if (!this.O)
      i1 = 1;
    while (true)
    {
      if (i1 != 0)
      {
        f("application/x-www-form-urlencoded", paramString);
        this.O = true;
      }
      String str = v(paramString);
      try
      {
        K();
        if (i1 == 0)
          this.M.write(38);
        this.M.a(URLEncoder.encode(paramObject1.toString(), str));
        this.M.write(61);
        if (paramObject2 != null)
          this.M.a(URLEncoder.encode(paramObject2.toString(), str));
        return this;
        i1 = 0;
      }
      catch (IOException localIOException)
      {
        throw new e(localIOException);
      }
    }
  }

  public e a(String paramString, File paramFile)
    throws e.e
  {
    return a(paramString, null, paramFile);
  }

  public e a(String paramString, InputStream paramInputStream)
    throws e.e
  {
    return a(paramString, null, null, paramInputStream);
  }

  public e a(String paramString, Number paramNumber)
  {
    if (paramNumber != null);
    for (String str = paramNumber.toString(); ; str = null)
      return a(paramString, str);
  }

  public e a(String paramString1, String paramString2)
  {
    a().setRequestProperty(paramString1, paramString2);
    return this;
  }

  public e a(String paramString1, String paramString2, File paramFile)
    throws e.e
  {
    return a(paramString1, paramString2, null, paramFile);
  }

  public e a(String paramString1, String paramString2, Number paramNumber)
    throws e.e
  {
    if (paramNumber != null);
    for (String str = paramNumber.toString(); ; str = null)
      return b(paramString1, paramString2, str);
  }

  protected e a(String paramString1, String paramString2, String paramString3)
    throws IOException
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("form-data; name=\"").append(paramString1);
    if (paramString2 != null)
      localStringBuilder.append("\"; filename=\"").append(paramString2);
    localStringBuilder.append('"');
    i("Content-Disposition", localStringBuilder.toString());
    if (paramString3 != null)
      i("Content-Type", paramString3);
    return i("\r\n");
  }

  // ERROR //
  public e a(String paramString1, String paramString2, String paramString3, File paramFile)
    throws e.e
  {
    // Byte code:
    //   0: new 611	java/io/BufferedInputStream
    //   3: dup
    //   4: new 613	java/io/FileInputStream
    //   7: dup
    //   8: aload 4
    //   10: invokespecial 614	java/io/FileInputStream:<init>	(Ljava/io/File;)V
    //   13: invokespecial 617	java/io/BufferedInputStream:<init>	(Ljava/io/InputStream;)V
    //   16: astore 5
    //   18: aload_0
    //   19: aload_1
    //   20: aload_2
    //   21: aload_3
    //   22: aload 5
    //   24: invokevirtual 586	a/a/a/a/a/e/e:a	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/io/InputStream;)La/a/a/a/a/e/e;
    //   27: astore 9
    //   29: aload 5
    //   31: ifnull +8 -> 39
    //   34: aload 5
    //   36: invokevirtual 620	java/io/InputStream:close	()V
    //   39: aload 9
    //   41: areturn
    //   42: astore 6
    //   44: aconst_null
    //   45: astore 5
    //   47: new 139	a/a/a/a/a/e/e$e
    //   50: dup
    //   51: aload 6
    //   53: invokespecial 169	a/a/a/a/a/e/e$e:<init>	(Ljava/io/IOException;)V
    //   56: athrow
    //   57: astore 7
    //   59: aload 5
    //   61: ifnull +8 -> 69
    //   64: aload 5
    //   66: invokevirtual 620	java/io/InputStream:close	()V
    //   69: aload 7
    //   71: athrow
    //   72: astore 10
    //   74: aload 9
    //   76: areturn
    //   77: astore 8
    //   79: goto -10 -> 69
    //   82: astore 7
    //   84: aconst_null
    //   85: astore 5
    //   87: goto -28 -> 59
    //   90: astore 6
    //   92: goto -45 -> 47
    //
    // Exception table:
    //   from	to	target	type
    //   0	18	42	java/io/IOException
    //   18	29	57	finally
    //   47	57	57	finally
    //   34	39	72	java/io/IOException
    //   64	69	77	java/io/IOException
    //   0	18	82	finally
    //   18	29	90	java/io/IOException
  }

  public e a(String paramString1, String paramString2, String paramString3, InputStream paramInputStream)
    throws e.e
  {
    try
    {
      L();
      a(paramString1, paramString2, paramString3);
      a(paramInputStream, this.M);
      return this;
    }
    catch (IOException localIOException)
    {
      throw new e(localIOException);
    }
  }

  public e a(String paramString1, String paramString2, String paramString3, String paramString4)
    throws e.e
  {
    try
    {
      L();
      a(paramString1, paramString2, paramString3);
      this.M.a(paramString4);
      return this;
    }
    catch (IOException localIOException)
    {
      throw new e(localIOException);
    }
  }

  public e a(Map.Entry<String, String> paramEntry)
  {
    return a((String)paramEntry.getKey(), (String)paramEntry.getValue());
  }

  public e a(Map.Entry<?, ?> paramEntry, String paramString)
    throws e.e
  {
    return a(paramEntry.getKey(), paramEntry.getValue(), paramString);
  }

  public e a(Map<String, String> paramMap)
  {
    if (!paramMap.isEmpty())
    {
      Iterator localIterator = paramMap.entrySet().iterator();
      while (localIterator.hasNext())
        a((Map.Entry)localIterator.next());
    }
    return this;
  }

  public e a(Map<?, ?> paramMap, String paramString)
    throws e.e
  {
    if (!paramMap.isEmpty())
    {
      Iterator localIterator = paramMap.entrySet().iterator();
      while (localIterator.hasNext())
        a((Map.Entry)localIterator.next(), paramString);
    }
    return this;
  }

  public e a(AtomicInteger paramAtomicInteger)
    throws e.e
  {
    paramAtomicInteger.set(c());
    return this;
  }

  public e a(AtomicReference<String> paramAtomicReference)
    throws e.e
  {
    paramAtomicReference.set(n());
    return this;
  }

  public e a(AtomicReference<String> paramAtomicReference, String paramString)
    throws e.e
  {
    paramAtomicReference.set(b(paramString));
    return this;
  }

  public e a(byte[] paramArrayOfByte)
    throws e.e
  {
    return a(new ByteArrayInputStream(paramArrayOfByte));
  }

  public HttpURLConnection a()
  {
    if (this.K == null)
      this.K = S();
    return this.K;
  }

  public e b(int paramInt)
  {
    a().setChunkedStreamingMode(paramInt);
    return this;
  }

  public e b(File paramFile)
    throws e.e
  {
    try
    {
      BufferedInputStream localBufferedInputStream = new BufferedInputStream(new FileInputStream(paramFile));
      return a(localBufferedInputStream);
    }
    catch (FileNotFoundException localFileNotFoundException)
    {
      throw new e(localFileNotFoundException);
    }
  }

  public e b(String paramString, int paramInt)
  {
    if (this.K != null)
      throw new IllegalStateException("The connection has already been created. This method must be called before reading or writing to the request.");
    this.S = paramString;
    this.T = paramInt;
    return this;
  }

  public e b(String paramString, Number paramNumber)
    throws e.e
  {
    return a(paramString, null, paramNumber);
  }

  public e b(String paramString1, String paramString2, String paramString3)
    throws e.e
  {
    return a(paramString1, paramString2, null, paramString3);
  }

  public e b(Map.Entry<?, ?> paramEntry)
    throws e.e
  {
    return a(paramEntry, "UTF-8");
  }

  public e b(Map<?, ?> paramMap)
    throws e.e
  {
    return a(paramMap, "UTF-8");
  }

  public e b(boolean paramBoolean)
  {
    this.P = paramBoolean;
    return this;
  }

  public String b(String paramString)
    throws e.e
  {
    ByteArrayOutputStream localByteArrayOutputStream = m();
    try
    {
      a(q(), localByteArrayOutputStream);
      String str = localByteArrayOutputStream.toString(v(paramString));
      return str;
    }
    catch (IOException localIOException)
    {
      throw new e(localIOException);
    }
  }

  public String b(String paramString1, String paramString2)
  {
    return c(e(paramString1), paramString2);
  }

  public boolean b()
  {
    return this.P;
  }

  public int c()
    throws e.e
  {
    try
    {
      I();
      int i1 = a().getResponseCode();
      return i1;
    }
    catch (IOException localIOException)
    {
      throw new e(localIOException);
    }
  }

  public e c(int paramInt)
  {
    if (paramInt < 1)
      throw new IllegalArgumentException("Size must be greater than zero");
    this.R = paramInt;
    return this;
  }

  public e c(boolean paramBoolean)
  {
    this.Q = paramBoolean;
    return this;
  }

  public InputStreamReader c(String paramString)
    throws e.e
  {
    try
    {
      InputStreamReader localInputStreamReader = new InputStreamReader(r(), v(paramString));
      return localInputStreamReader;
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException)
    {
      throw new e(localUnsupportedEncodingException);
    }
  }

  protected String c(String paramString1, String paramString2)
  {
    String str;
    if ((paramString1 == null) || (paramString1.length() == 0))
    {
      str = null;
      return str;
    }
    int i1 = paramString1.length();
    int i2 = 1 + paramString1.indexOf(';');
    if ((i2 == 0) || (i2 == i1))
      return null;
    int i3 = paramString1.indexOf(';', i2);
    int i4;
    int i5;
    if (i3 == -1)
    {
      i4 = i2;
      i5 = i1;
    }
    while (true)
    {
      if (i4 < i5)
      {
        int i6 = paramString1.indexOf('=', i4);
        if ((i6 != -1) && (i6 < i5) && (paramString2.equals(paramString1.substring(i4, i6).trim())))
        {
          str = paramString1.substring(i6 + 1, i5).trim();
          int i10 = str.length();
          if (i10 != 0)
          {
            if ((i10 <= 2) || ('"' != str.charAt(0)) || ('"' != str.charAt(i10 - 1)))
              break;
            return str.substring(1, i10 - 1);
          }
        }
        int i7 = i5 + 1;
        int i8 = paramString1.indexOf(';', i7);
        if (i8 == -1)
          i8 = i1;
        int i9 = i8;
        i4 = i7;
        i5 = i9;
        continue;
      }
      return null;
      i4 = i2;
      i5 = i3;
    }
  }

  public e d(int paramInt)
  {
    a().setReadTimeout(paramInt);
    return this;
  }

  public e d(String paramString1, String paramString2)
  {
    return o("Basic " + a.a(new StringBuilder().append(paramString1).append(':').append(paramString2).toString()));
  }

  public e d(boolean paramBoolean)
  {
    a().setUseCaches(paramBoolean);
    return this;
  }

  public BufferedReader d(String paramString)
    throws e.e
  {
    return new BufferedReader(c(paramString), this.R);
  }

  public boolean d()
    throws e.e
  {
    return 200 == c();
  }

  public e e(int paramInt)
  {
    a().setConnectTimeout(paramInt);
    return this;
  }

  public e e(String paramString1, String paramString2)
  {
    return p("Basic " + a.a(new StringBuilder().append(paramString1).append(':').append(paramString2).toString()));
  }

  public e e(boolean paramBoolean)
  {
    a().setInstanceFollowRedirects(paramBoolean);
    return this;
  }

  public String e(String paramString)
    throws e.e
  {
    J();
    return a().getHeaderField(paramString);
  }

  public boolean e()
    throws e.e
  {
    return 201 == c();
  }

  public long f(String paramString)
    throws e.e
  {
    return a(paramString, -1L);
  }

  public e f(int paramInt)
  {
    a().setFixedLengthStreamingMode(paramInt);
    return this;
  }

  public e f(String paramString1, String paramString2)
  {
    if ((paramString2 != null) && (paramString2.length() > 0))
      return a("Content-Type", paramString1 + "; charset=" + paramString2);
    return a("Content-Type", paramString1);
  }

  public boolean f()
    throws e.e
  {
    return 500 == c();
  }

  public int g(String paramString)
    throws e.e
  {
    return a(paramString, -1);
  }

  protected e g(String paramString1, String paramString2)
    throws IOException
  {
    return a(paramString1, paramString2, null);
  }

  public boolean g()
    throws e.e
  {
    return 400 == c();
  }

  public e h(String paramString1, String paramString2)
  {
    return b(paramString1, null, paramString2);
  }

  public boolean h()
    throws e.e
  {
    return 404 == c();
  }

  public String[] h(String paramString)
  {
    Map localMap = u();
    if ((localMap == null) || (localMap.isEmpty()))
      return I;
    List localList = (List)localMap.get(paramString);
    if ((localList != null) && (!localList.isEmpty()))
      return (String[])localList.toArray(new String[localList.size()]);
    return I;
  }

  public e i(CharSequence paramCharSequence)
    throws e.e
  {
    try
    {
      K();
      this.M.a(paramCharSequence.toString());
      return this;
    }
    catch (IOException localIOException)
    {
      throw new e(localIOException);
    }
  }

  public e i(String paramString1, String paramString2)
    throws e.e
  {
    return i(paramString1).i(": ").i(paramString2).i("\r\n");
  }

  public Map<String, String> i(String paramString)
  {
    return j(e(paramString));
  }

  public boolean i()
    throws e.e
  {
    return 304 == c();
  }

  public String j()
    throws e.e
  {
    try
    {
      I();
      String str = a().getResponseMessage();
      return str;
    }
    catch (IOException localIOException)
    {
      throw new e(localIOException);
    }
  }

  protected Map<String, String> j(String paramString)
  {
    if ((paramString == null) || (paramString.length() == 0))
      return Collections.emptyMap();
    int i1 = paramString.length();
    int i2 = 1 + paramString.indexOf(';');
    if ((i2 == 0) || (i2 == i1))
      return Collections.emptyMap();
    int i3 = paramString.indexOf(';', i2);
    if (i3 == -1)
      i3 = i1;
    LinkedHashMap localLinkedHashMap = new LinkedHashMap();
    if (i2 < i3)
    {
      int i4 = paramString.indexOf('=', i2);
      String str1;
      String str2;
      if ((i4 != -1) && (i4 < i3))
      {
        str1 = paramString.substring(i2, i4).trim();
        if (str1.length() > 0)
        {
          str2 = paramString.substring(i4 + 1, i3).trim();
          int i5 = str2.length();
          if (i5 != 0)
          {
            if ((i5 <= 2) || ('"' != str2.charAt(0)) || ('"' != str2.charAt(i5 - 1)))
              break label221;
            localLinkedHashMap.put(str1, str2.substring(1, i5 - 1));
          }
        }
      }
      while (true)
      {
        i2 = i3 + 1;
        i3 = paramString.indexOf(';', i2);
        if (i3 != -1)
          break;
        i3 = i1;
        break;
        label221: localLinkedHashMap.put(str1, str2);
      }
    }
    return localLinkedHashMap;
  }

  public e k()
  {
    a().disconnect();
    return this;
  }

  public e k(String paramString)
  {
    return a("User-Agent", paramString);
  }

  public int l()
  {
    return this.R;
  }

  public e l(String paramString)
  {
    return a("Referer", paramString);
  }

  public e m(String paramString)
  {
    return a("Accept-Encoding", paramString);
  }

  protected ByteArrayOutputStream m()
  {
    int i1 = G();
    if (i1 > 0)
      return new ByteArrayOutputStream(i1);
    return new ByteArrayOutputStream();
  }

  public e n(String paramString)
  {
    return a("Accept-Charset", paramString);
  }

  public String n()
    throws e.e
  {
    return b(v());
  }

  public e o(String paramString)
  {
    return a("Authorization", paramString);
  }

  public boolean o()
    throws e.e
  {
    return G() == 0;
  }

  public e p(String paramString)
  {
    return a("Proxy-Authorization", paramString);
  }

  public byte[] p()
    throws e.e
  {
    ByteArrayOutputStream localByteArrayOutputStream = m();
    try
    {
      a(q(), localByteArrayOutputStream);
      return localByteArrayOutputStream.toByteArray();
    }
    catch (IOException localIOException)
    {
      throw new e(localIOException);
    }
  }

  public e q(String paramString)
  {
    return a("If-None-Match", paramString);
  }

  public BufferedInputStream q()
    throws e.e
  {
    return new BufferedInputStream(r(), this.R);
  }

  public e r(String paramString)
  {
    return f(paramString, null);
  }

  public InputStream r()
    throws e.e
  {
    if (c() < 400);
    Object localObject;
    while (true)
    {
      try
      {
        InputStream localInputStream2 = a().getInputStream();
        localObject = localInputStream2;
        if ((this.Q) && ("gzip".equals(x())))
          break;
        return localObject;
      }
      catch (IOException localIOException3)
      {
        throw new e(localIOException3);
      }
      localObject = a().getErrorStream();
      if (localObject == null)
        try
        {
          InputStream localInputStream1 = a().getInputStream();
          localObject = localInputStream1;
        }
        catch (IOException localIOException1)
        {
          throw new e(localIOException1);
        }
    }
    try
    {
      GZIPInputStream localGZIPInputStream = new GZIPInputStream((InputStream)localObject);
      return localGZIPInputStream;
    }
    catch (IOException localIOException2)
    {
      throw new e(localIOException2);
    }
  }

  public e s(String paramString)
  {
    return f(Integer.parseInt(paramString));
  }

  public InputStreamReader s()
    throws e.e
  {
    return c(v());
  }

  public e t(String paramString)
  {
    return a("Accept", paramString);
  }

  public BufferedReader t()
    throws e.e
  {
    return d(v());
  }

  public String toString()
  {
    return Q() + ' ' + P();
  }

  public Map<String, List<String>> u()
    throws e.e
  {
    J();
    return a().getHeaderFields();
  }

  public String v()
  {
    return b("Content-Type", "charset");
  }

  public e w()
  {
    return m("gzip");
  }

  public String x()
  {
    return e("Content-Encoding");
  }

  public String y()
  {
    return e("Server");
  }

  public long z()
  {
    return f("Date");
  }

  public static class a
  {
    private static final byte a = 61;
    private static final String b = "US-ASCII";
    private static final byte[] c = { 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 43, 47 };

    public static String a(String paramString)
    {
      try
      {
        byte[] arrayOfByte2 = paramString.getBytes("US-ASCII");
        arrayOfByte1 = arrayOfByte2;
        return a(arrayOfByte1);
      }
      catch (UnsupportedEncodingException localUnsupportedEncodingException)
      {
        while (true)
          byte[] arrayOfByte1 = paramString.getBytes();
      }
    }

    public static String a(byte[] paramArrayOfByte)
    {
      return a(paramArrayOfByte, 0, paramArrayOfByte.length);
    }

    public static String a(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    {
      byte[] arrayOfByte = b(paramArrayOfByte, paramInt1, paramInt2);
      try
      {
        String str = new String(arrayOfByte, "US-ASCII");
        return str;
      }
      catch (UnsupportedEncodingException localUnsupportedEncodingException)
      {
      }
      return new String(arrayOfByte);
    }

    private static byte[] a(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3)
    {
      byte[] arrayOfByte = c;
      int i;
      if (paramInt2 > 0)
      {
        i = paramArrayOfByte1[paramInt1] << 24 >>> 8;
        label20: if (paramInt2 <= 1)
          break label108;
      }
      int n;
      label108: for (int j = paramArrayOfByte1[(paramInt1 + 1)] << 24 >>> 16; ; j = 0)
      {
        int k = j | i;
        int m = 0;
        if (paramInt2 > 2)
          m = paramArrayOfByte1[(paramInt1 + 2)] << 24 >>> 24;
        n = m | k;
        switch (paramInt2)
        {
        default:
          return paramArrayOfByte2;
          i = 0;
          break label20;
        case 3:
        case 2:
        case 1:
        }
      }
      paramArrayOfByte2[paramInt3] = arrayOfByte[(n >>> 18)];
      paramArrayOfByte2[(paramInt3 + 1)] = arrayOfByte[(0x3F & n >>> 12)];
      paramArrayOfByte2[(paramInt3 + 2)] = arrayOfByte[(0x3F & n >>> 6)];
      paramArrayOfByte2[(paramInt3 + 3)] = arrayOfByte[(n & 0x3F)];
      return paramArrayOfByte2;
      paramArrayOfByte2[paramInt3] = arrayOfByte[(n >>> 18)];
      paramArrayOfByte2[(paramInt3 + 1)] = arrayOfByte[(0x3F & n >>> 12)];
      paramArrayOfByte2[(paramInt3 + 2)] = arrayOfByte[(0x3F & n >>> 6)];
      paramArrayOfByte2[(paramInt3 + 3)] = 61;
      return paramArrayOfByte2;
      paramArrayOfByte2[paramInt3] = arrayOfByte[(n >>> 18)];
      paramArrayOfByte2[(paramInt3 + 1)] = arrayOfByte[(0x3F & n >>> 12)];
      paramArrayOfByte2[(paramInt3 + 2)] = 61;
      paramArrayOfByte2[(paramInt3 + 3)] = 61;
      return paramArrayOfByte2;
    }

    public static byte[] b(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    {
      if (paramArrayOfByte == null)
        throw new NullPointerException("Cannot serialize a null array.");
      if (paramInt1 < 0)
        throw new IllegalArgumentException("Cannot have negative offset: " + paramInt1);
      if (paramInt2 < 0)
        throw new IllegalArgumentException("Cannot have length offset: " + paramInt2);
      if (paramInt1 + paramInt2 > paramArrayOfByte.length)
      {
        Locale localLocale = Locale.ENGLISH;
        Object[] arrayOfObject = new Object[3];
        arrayOfObject[0] = Integer.valueOf(paramInt1);
        arrayOfObject[1] = Integer.valueOf(paramInt2);
        arrayOfObject[2] = Integer.valueOf(paramArrayOfByte.length);
        throw new IllegalArgumentException(String.format(localLocale, "Cannot have offset of %d and length of %d with array of length %d", arrayOfObject));
      }
      int i = 4 * (paramInt2 / 3);
      if (paramInt2 % 3 > 0);
      byte[] arrayOfByte1;
      int m;
      int n;
      for (int j = 4; ; j = 0)
      {
        arrayOfByte1 = new byte[j + i];
        int k = paramInt2 - 2;
        m = 0;
        n = 0;
        while (n < k)
        {
          a(paramArrayOfByte, n + paramInt1, 3, arrayOfByte1, m);
          n += 3;
          m += 4;
        }
      }
      if (n < paramInt2)
      {
        a(paramArrayOfByte, n + paramInt1, paramInt2 - n, arrayOfByte1, m);
        m += 4;
      }
      if (m <= -1 + arrayOfByte1.length)
      {
        byte[] arrayOfByte2 = new byte[m];
        System.arraycopy(arrayOfByte1, 0, arrayOfByte2, 0, m);
        return arrayOfByte2;
      }
      return arrayOfByte1;
    }
  }

  protected static abstract class b<V> extends e.f<V>
  {
    private final Closeable a;
    private final boolean b;

    protected b(Closeable paramCloseable, boolean paramBoolean)
    {
      this.a = paramCloseable;
      this.b = paramBoolean;
    }

    protected void c()
      throws IOException
    {
      if ((this.a instanceof Flushable))
        ((Flushable)this.a).flush();
      if (this.b);
      try
      {
        this.a.close();
        return;
        this.a.close();
        return;
      }
      catch (IOException localIOException)
      {
      }
    }
  }

  public static abstract interface c
  {
    public static final c a = new n();

    public abstract HttpURLConnection a(URL paramURL)
      throws IOException;

    public abstract HttpURLConnection a(URL paramURL, Proxy paramProxy)
      throws IOException;
  }

  protected static abstract class d<V> extends e.f<V>
  {
    private final Flushable a;

    protected d(Flushable paramFlushable)
    {
      this.a = paramFlushable;
    }

    protected void c()
      throws IOException
    {
      this.a.flush();
    }
  }

  public static class e extends RuntimeException
  {
    private static final long a = -1170466989781746231L;

    protected e(IOException paramIOException)
    {
      super();
    }

    public IOException a()
    {
      return (IOException)super.getCause();
    }
  }

  protected static abstract class f<V>
    implements Callable<V>
  {
    protected abstract V b()
      throws e.e, IOException;

    protected abstract void c()
      throws IOException;

    // ERROR //
    public V call()
      throws e.e
    {
      // Byte code:
      //   0: iconst_1
      //   1: istore_1
      //   2: aload_0
      //   3: invokevirtual 21	a/a/a/a/a/e/e$f:b	()Ljava/lang/Object;
      //   6: astore 6
      //   8: aload_0
      //   9: invokevirtual 23	a/a/a/a/a/e/e$f:c	()V
      //   12: aload 6
      //   14: areturn
      //   15: astore 7
      //   17: new 15	a/a/a/a/a/e/e$e
      //   20: dup
      //   21: aload 7
      //   23: invokespecial 26	a/a/a/a/a/e/e$e:<init>	(Ljava/io/IOException;)V
      //   26: athrow
      //   27: astore 5
      //   29: aload 5
      //   31: athrow
      //   32: astore_2
      //   33: aload_0
      //   34: invokevirtual 23	a/a/a/a/a/e/e$f:c	()V
      //   37: aload_2
      //   38: athrow
      //   39: astore 4
      //   41: new 15	a/a/a/a/a/e/e$e
      //   44: dup
      //   45: aload 4
      //   47: invokespecial 26	a/a/a/a/a/e/e$e:<init>	(Ljava/io/IOException;)V
      //   50: athrow
      //   51: astore_3
      //   52: iload_1
      //   53: ifne -16 -> 37
      //   56: new 15	a/a/a/a/a/e/e$e
      //   59: dup
      //   60: aload_3
      //   61: invokespecial 26	a/a/a/a/a/e/e$e:<init>	(Ljava/io/IOException;)V
      //   64: athrow
      //   65: astore_2
      //   66: iconst_0
      //   67: istore_1
      //   68: goto -35 -> 33
      //
      // Exception table:
      //   from	to	target	type
      //   8	12	15	java/io/IOException
      //   2	8	27	a/a/a/a/a/e/e$e
      //   29	32	32	finally
      //   41	51	32	finally
      //   2	8	39	java/io/IOException
      //   33	37	51	java/io/IOException
      //   2	8	65	finally
    }
  }

  public static class g extends BufferedOutputStream
  {
    private final CharsetEncoder a;

    public g(OutputStream paramOutputStream, String paramString, int paramInt)
    {
      super(paramInt);
      this.a = Charset.forName(e.u(paramString)).newEncoder();
    }

    public g a(String paramString)
      throws IOException
    {
      ByteBuffer localByteBuffer = this.a.encode(CharBuffer.wrap(paramString));
      super.write(localByteBuffer.array(), 0, localByteBuffer.limit());
      return this;
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.e.e
 * JD-Core Version:    0.6.2
 */