package a.a.a.a.a.e;

import java.security.PrivilegedAction;

final class f
  implements PrivilegedAction<String>
{
  f(String paramString1, String paramString2)
  {
  }

  public String a()
  {
    return System.setProperty(this.a, this.b);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.e.f
 * JD-Core Version:    0.6.2
 */