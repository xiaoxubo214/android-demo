package a.a.a.a.a.e;

import java.security.PrivilegedAction;

final class g
  implements PrivilegedAction<String>
{
  g(String paramString)
  {
  }

  public String a()
  {
    return System.clearProperty(this.a);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.e.g
 * JD-Core Version:    0.6.2
 */