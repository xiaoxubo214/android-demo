package a.a.a.a.a.e;

import java.io.Closeable;
import java.io.IOException;
import java.io.OutputStream;

class h extends e.b<e>
{
  h(e parame, Closeable paramCloseable, boolean paramBoolean, OutputStream paramOutputStream)
  {
    super(paramCloseable, paramBoolean);
  }

  protected e a()
    throws e.e, IOException
  {
    return this.b.a(this.a);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.e.h
 * JD-Core Version:    0.6.2
 */