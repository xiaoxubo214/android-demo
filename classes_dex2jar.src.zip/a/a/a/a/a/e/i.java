package a.a.a.a.a.e;

import java.io.BufferedReader;
import java.io.Closeable;
import java.io.IOException;
import java.nio.CharBuffer;

class i extends e.b<e>
{
  i(e parame, Closeable paramCloseable, boolean paramBoolean, BufferedReader paramBufferedReader, Appendable paramAppendable)
  {
    super(paramCloseable, paramBoolean);
  }

  public e a()
    throws IOException
  {
    CharBuffer localCharBuffer = CharBuffer.allocate(e.a(this.c));
    while (true)
    {
      int i = this.a.read(localCharBuffer);
      if (i == -1)
        break;
      localCharBuffer.rewind();
      this.b.append(localCharBuffer, 0, i);
      localCharBuffer.rewind();
    }
    return this.c;
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.e.i
 * JD-Core Version:    0.6.2
 */