package a.a.a.a.a.e;

import java.io.BufferedReader;
import java.io.Closeable;
import java.io.IOException;
import java.io.Writer;

class j extends e.b<e>
{
  j(e parame, Closeable paramCloseable, boolean paramBoolean, BufferedReader paramBufferedReader, Writer paramWriter)
  {
    super(paramCloseable, paramBoolean);
  }

  public e a()
    throws IOException
  {
    return this.c.a(this.a, this.b);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.e.j
 * JD-Core Version:    0.6.2
 */