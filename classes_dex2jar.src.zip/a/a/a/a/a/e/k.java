package a.a.a.a.a.e;

import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

class k extends e.b<e>
{
  k(e parame, Closeable paramCloseable, boolean paramBoolean, InputStream paramInputStream, OutputStream paramOutputStream)
  {
    super(paramCloseable, paramBoolean);
  }

  public e a()
    throws IOException
  {
    byte[] arrayOfByte = new byte[e.a(this.c)];
    while (true)
    {
      int i = this.a.read(arrayOfByte);
      if (i == -1)
        break;
      this.b.write(arrayOfByte, 0, i);
    }
    return this.c;
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.e.k
 * JD-Core Version:    0.6.2
 */