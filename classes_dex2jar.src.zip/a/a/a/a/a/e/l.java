package a.a.a.a.a.e;

import java.io.Closeable;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;

class l extends e.b<e>
{
  l(e parame, Closeable paramCloseable, boolean paramBoolean, Reader paramReader, Writer paramWriter)
  {
    super(paramCloseable, paramBoolean);
  }

  public e a()
    throws IOException
  {
    char[] arrayOfChar = new char[e.a(this.c)];
    while (true)
    {
      int i = this.a.read(arrayOfChar);
      if (i == -1)
        break;
      this.b.write(arrayOfChar, 0, i);
    }
    return this.c;
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.e.l
 * JD-Core Version:    0.6.2
 */