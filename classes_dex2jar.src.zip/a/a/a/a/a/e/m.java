package a.a.a.a.a.e;

import java.io.Flushable;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;

class m extends e.d<e>
{
  m(e parame, Flushable paramFlushable, Reader paramReader, Writer paramWriter)
  {
    super(paramFlushable);
  }

  protected e a()
    throws IOException
  {
    return this.c.a(this.a, this.b);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.e.m
 * JD-Core Version:    0.6.2
 */