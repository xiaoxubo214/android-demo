package a.a.a.a.a.e;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.Proxy;
import java.net.URL;

final class n
  implements e.c
{
  public HttpURLConnection a(URL paramURL)
    throws IOException
  {
    return (HttpURLConnection)paramURL.openConnection();
  }

  public HttpURLConnection a(URL paramURL, Proxy paramProxy)
    throws IOException
  {
    return (HttpURLConnection)paramURL.openConnection(paramProxy);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.e.n
 * JD-Core Version:    0.6.2
 */