package a.a.a.a.a.e;

import java.util.Map;

public abstract interface o
{
  public abstract e a(d paramd, String paramString);

  public abstract e a(d paramd, String paramString, Map<String, String> paramMap);

  public abstract q a();

  public abstract void a(q paramq);
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.e.o
 * JD-Core Version:    0.6.2
 */