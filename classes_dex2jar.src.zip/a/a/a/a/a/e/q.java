package a.a.a.a.a.e;

import java.io.InputStream;

public abstract interface q
{
  public static final long a = -1L;

  public abstract InputStream a();

  public abstract String b();

  public abstract String[] c();

  public abstract long d();
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.e.q
 * JD-Core Version:    0.6.2
 */