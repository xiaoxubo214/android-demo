package a.a.a.a.a.f;

import java.io.File;

public abstract interface a
{
  public abstract File a();

  public abstract File b();

  public abstract File c();

  public abstract File d();
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.f.a
 * JD-Core Version:    0.6.2
 */