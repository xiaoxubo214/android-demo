package a.a.a.a.a.f;

import a.a.a.a.e;
import a.a.a.a.n;
import a.a.a.a.q;
import android.annotation.TargetApi;
import android.content.Context;
import android.os.Build.VERSION;
import android.os.Environment;
import java.io.File;

public class b
  implements a
{
  private final Context a;
  private final String b;
  private final String c;

  public b(n paramn)
  {
    if (paramn.u() == null)
      throw new IllegalStateException("Cannot get directory before context has been set. Call Fabric.with() first");
    this.a = paramn.u();
    this.b = paramn.w();
    this.c = ("Android/" + this.a.getPackageName());
  }

  public File a()
  {
    return a(this.a.getCacheDir());
  }

  File a(File paramFile)
  {
    if (paramFile != null)
    {
      if ((paramFile.exists()) || (paramFile.mkdirs()))
        return paramFile;
      e.i().d("Fabric", "Couldn't create file");
    }
    while (true)
    {
      return null;
      e.i().a("Fabric", "Null File");
    }
  }

  public File b()
  {
    boolean bool = e();
    File localFile = null;
    if (bool)
      if (Build.VERSION.SDK_INT < 8)
        break label33;
    label33: for (localFile = this.a.getExternalCacheDir(); ; localFile = new File(Environment.getExternalStorageDirectory(), this.c + "/cache/" + this.b))
      return a(localFile);
  }

  public File c()
  {
    return a(this.a.getFilesDir());
  }

  @TargetApi(8)
  public File d()
  {
    boolean bool = e();
    File localFile = null;
    if (bool)
      if (Build.VERSION.SDK_INT < 8)
        break label34;
    label34: for (localFile = this.a.getExternalFilesDir(null); ; localFile = new File(Environment.getExternalStorageDirectory(), this.c + "/files/" + this.b))
      return a(localFile);
  }

  boolean e()
  {
    if (!"mounted".equals(Environment.getExternalStorageState()))
    {
      e.i().d("Fabric", "External Storage is not mounted and/or writable\nHave you declared android.permission.WRITE_EXTERNAL_STORAGE in the manifest?");
      return false;
    }
    return true;
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.f.b
 * JD-Core Version:    0.6.2
 */