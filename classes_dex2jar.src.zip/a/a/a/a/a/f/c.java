package a.a.a.a.a.f;

public abstract interface c<T>
{
  public abstract T a();

  public abstract void a(T paramT);

  public abstract void b();
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.f.c
 * JD-Core Version:    0.6.2
 */