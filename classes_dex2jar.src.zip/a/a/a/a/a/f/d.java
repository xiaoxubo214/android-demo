package a.a.a.a.a.f;

import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

public abstract interface d
{
  public abstract SharedPreferences a();

  public abstract boolean a(SharedPreferences.Editor paramEditor);

  public abstract SharedPreferences.Editor b();
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.f.d
 * JD-Core Version:    0.6.2
 */