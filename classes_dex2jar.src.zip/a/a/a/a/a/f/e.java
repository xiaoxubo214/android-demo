package a.a.a.a.a.f;

import a.a.a.a.n;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Build.VERSION;

public class e
  implements d
{
  private final SharedPreferences a;
  private final String b;
  private final Context c;

  @Deprecated
  public e(n paramn)
  {
    this(paramn.u(), paramn.getClass().getName());
  }

  public e(Context paramContext, String paramString)
  {
    if (paramContext == null)
      throw new IllegalStateException("Cannot get directory before context has been set. Call Fabric.with() first");
    this.c = paramContext;
    this.b = paramString;
    this.a = this.c.getSharedPreferences(this.b, 0);
  }

  public SharedPreferences a()
  {
    return this.a;
  }

  @TargetApi(9)
  public boolean a(SharedPreferences.Editor paramEditor)
  {
    if (Build.VERSION.SDK_INT >= 9)
    {
      paramEditor.apply();
      return true;
    }
    return paramEditor.commit();
  }

  public SharedPreferences.Editor b()
  {
    return this.a.edit();
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.f.e
 * JD-Core Version:    0.6.2
 */