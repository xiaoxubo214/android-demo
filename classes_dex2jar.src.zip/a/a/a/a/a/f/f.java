package a.a.a.a.a.f;

import android.annotation.SuppressLint;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

public class f<T>
  implements c<T>
{
  private final d a;
  private final g<T> b;
  private final String c;

  public f(d paramd, g<T> paramg, String paramString)
  {
    this.a = paramd;
    this.b = paramg;
    this.c = paramString;
  }

  public T a()
  {
    SharedPreferences localSharedPreferences = this.a.a();
    return this.b.a(localSharedPreferences.getString(this.c, null));
  }

  @SuppressLint({"CommitPrefEdits"})
  public void a(T paramT)
  {
    this.a.a(this.a.b().putString(this.c, this.b.a(paramT)));
  }

  @SuppressLint({"CommitPrefEdits"})
  public void b()
  {
    this.a.b().remove(this.c).commit();
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.f.f
 * JD-Core Version:    0.6.2
 */