package a.a.a.a.a.g;

import a.a.a.a.a.b.aa;
import a.a.a.a.a.b.k;
import a.a.a.a.n;
import a.a.a.a.p;
import a.a.a.a.q;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.Resources.NotFoundException;
import java.io.InputStream;
import java.util.Collection;
import java.util.Iterator;
import java.util.Locale;

abstract class a extends a.a.a.a.a.b.a
  implements f
{
  public static final String A = "app[build][libraries][%s]";
  public static final String B = "app[build][libraries][%s][version]";
  public static final String C = "app[build][libraries][%s][type]";
  static final String D = "icon.png";
  static final String E = "application/octet-stream";
  public static final String a = "app[identifier]";
  public static final String b = "app[name]";
  public static final String c = "app[instance_identifier]";
  public static final String d = "app[display_version]";
  public static final String e = "app[build_version]";
  public static final String f = "app[source]";
  public static final String g = "app[minimum_sdk_version]";
  public static final String u = "app[built_sdk_version]";
  public static final String v = "app[icon][hash]";
  public static final String w = "app[icon][data]";
  public static final String x = "app[icon][width]";
  public static final String y = "app[icon][height]";
  public static final String z = "app[icon][prerendered]";

  public a(n paramn, String paramString1, String paramString2, a.a.a.a.a.e.o paramo, a.a.a.a.a.e.d paramd)
  {
    super(paramn, paramString1, paramString2, paramo, paramd);
  }

  private a.a.a.a.a.e.e a(a.a.a.a.a.e.e parame, d paramd)
  {
    return parame.a("X-CRASHLYTICS-API-KEY", paramd.a).a("X-CRASHLYTICS-API-CLIENT-TYPE", "android").a("X-CRASHLYTICS-API-CLIENT-VERSION", this.t.a());
  }

  private a.a.a.a.a.e.e b(a.a.a.a.a.e.e parame, d paramd)
  {
    a.a.a.a.a.e.e locale = parame.h("app[identifier]", paramd.b).h("app[name]", paramd.f).h("app[display_version]", paramd.c).h("app[build_version]", paramd.d).b("app[source]", Integer.valueOf(paramd.g)).h("app[minimum_sdk_version]", paramd.h).h("app[built_sdk_version]", paramd.i);
    if (!k.e(paramd.e))
      locale.h("app[instance_identifier]", paramd.e);
    InputStream localInputStream;
    if (paramd.j != null)
      localInputStream = null;
    try
    {
      localInputStream = this.t.u().getResources().openRawResource(paramd.j.b);
      locale.h("app[icon][hash]", paramd.j.a).a("app[icon][data]", "icon.png", "application/octet-stream", localInputStream).b("app[icon][width]", Integer.valueOf(paramd.j.c)).b("app[icon][height]", Integer.valueOf(paramd.j.d));
      k.a(localInputStream, "Failed to close app icon InputStream.");
      if (paramd.k != null)
      {
        Iterator localIterator = paramd.k.iterator();
        while (localIterator.hasNext())
        {
          p localp = (p)localIterator.next();
          locale.h(a(localp), localp.b());
          locale.h(b(localp), localp.c());
        }
      }
    }
    catch (Resources.NotFoundException localNotFoundException)
    {
      while (true)
      {
        a.a.a.a.e.i().e("Fabric", "Failed to find app icon with resource ID: " + paramd.j.b, localNotFoundException);
        k.a(localInputStream, "Failed to close app icon InputStream.");
      }
    }
    finally
    {
      k.a(localInputStream, "Failed to close app icon InputStream.");
    }
    return locale;
  }

  String a(p paramp)
  {
    Locale localLocale = Locale.US;
    Object[] arrayOfObject = new Object[1];
    arrayOfObject[0] = paramp.a();
    return String.format(localLocale, "app[build][libraries][%s][version]", arrayOfObject);
  }

  public boolean a(d paramd)
  {
    a.a.a.a.a.e.e locale = b(a(b(), paramd), paramd);
    a.a.a.a.e.i().a("Fabric", "Sending app info to " + a());
    if (paramd.j != null)
    {
      a.a.a.a.e.i().a("Fabric", "App icon hash is " + paramd.j.a);
      a.a.a.a.e.i().a("Fabric", "App icon size is " + paramd.j.c + "x" + paramd.j.d);
    }
    int i = locale.c();
    if ("POST".equals(locale.Q()));
    for (String str = "Create"; ; str = "Update")
    {
      a.a.a.a.e.i().a("Fabric", str + " app request ID: " + locale.e("X-REQUEST-ID"));
      a.a.a.a.e.i().a("Fabric", "Result was " + i);
      if (aa.a(i) != 0)
        break;
      return true;
    }
    return false;
  }

  String b(p paramp)
  {
    Locale localLocale = Locale.US;
    Object[] arrayOfObject = new Object[1];
    arrayOfObject[0] = paramp.a();
    return String.format(localLocale, "app[build][libraries][%s][type]", arrayOfObject);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.g.a
 * JD-Core Version:    0.6.2
 */