package a.a.a.a.a.g;

import a.a.a.a.a.e.d;
import a.a.a.a.a.e.o;
import a.a.a.a.n;

public class aa extends a
{
  public aa(n paramn, String paramString1, String paramString2, o paramo)
  {
    super(paramn, paramString1, paramString2, paramo, d.c);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.g.aa
 * JD-Core Version:    0.6.2
 */