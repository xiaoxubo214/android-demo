package a.a.a.a.a.g;

public class b
{
  public static final int l = 1;
  public final String a;
  public final int b;
  public final int c;
  public final int d;
  public final int e;
  public final boolean f;
  public final boolean g;
  public final boolean h;
  public final boolean i;
  public final boolean j;
  public final int k;

  @Deprecated
  public b(String paramString, int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean)
  {
    this(paramString, paramInt1, paramInt2, paramInt3, paramInt4, false, false, paramBoolean, true, 1, true);
  }

  @Deprecated
  public b(String paramString, int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean, int paramInt5)
  {
    this(paramString, paramInt1, paramInt2, paramInt3, paramInt4, false, false, paramBoolean, true, paramInt5, true);
  }

  public b(String paramString, int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, int paramInt5, boolean paramBoolean5)
  {
    this.a = paramString;
    this.b = paramInt1;
    this.c = paramInt2;
    this.d = paramInt3;
    this.e = paramInt4;
    this.f = paramBoolean1;
    this.g = paramBoolean2;
    this.h = paramBoolean3;
    this.i = paramBoolean4;
    this.k = paramInt5;
    this.j = paramBoolean5;
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.g.b
 * JD-Core Version:    0.6.2
 */