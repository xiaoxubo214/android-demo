package a.a.a.a.a.g;

class c
{
  public final String a;
  public final int b;
  public final int c;

  public c(String paramString, int paramInt1, int paramInt2)
  {
    this.a = paramString;
    this.b = paramInt1;
    this.c = paramInt2;
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.g.c
 * JD-Core Version:    0.6.2
 */