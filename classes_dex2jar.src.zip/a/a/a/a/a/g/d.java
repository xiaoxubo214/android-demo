package a.a.a.a.a.g;

import a.a.a.a.p;
import java.util.Collection;

public class d
{
  public final String a;
  public final String b;
  public final String c;
  public final String d;
  public final String e;
  public final String f;
  public final int g;
  public final String h;
  public final String i;
  public final o j;
  public final Collection<p> k;

  public d(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, int paramInt, String paramString7, String paramString8, o paramo, Collection<p> paramCollection)
  {
    this.a = paramString1;
    this.b = paramString2;
    this.c = paramString3;
    this.d = paramString4;
    this.e = paramString5;
    this.f = paramString6;
    this.g = paramInt;
    this.h = paramString7;
    this.i = paramString8;
    this.j = paramo;
    this.k = paramCollection;
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.g.d
 * JD-Core Version:    0.6.2
 */