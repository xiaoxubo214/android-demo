package a.a.a.a.a.g;

public class e
{
  public static final String a = "new";
  public static final String b = "configured";
  public static final String c = "activated";
  public final String d;
  public final String e;
  public final String f;
  public final String g;
  public final String h;
  public final boolean i;
  public final c j;

  public e(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, boolean paramBoolean, c paramc)
  {
    this.d = paramString1;
    this.e = paramString2;
    this.f = paramString3;
    this.g = paramString4;
    this.h = paramString5;
    this.i = paramBoolean;
    this.j = paramc;
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.g.e
 * JD-Core Version:    0.6.2
 */