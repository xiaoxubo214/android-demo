package a.a.a.a.a.g;

public class g
{
  public final String a;
  public final int b;

  public g(String paramString, int paramInt)
  {
    this.a = paramString;
    this.b = paramInt;
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.g.g
 * JD-Core Version:    0.6.2
 */