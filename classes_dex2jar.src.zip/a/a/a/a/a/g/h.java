package a.a.a.a.a.g;

import org.json.JSONObject;

public abstract interface h
{
  public abstract JSONObject a();

  public abstract void a(long paramLong, JSONObject paramJSONObject);
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.g.h
 * JD-Core Version:    0.6.2
 */