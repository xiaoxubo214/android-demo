package a.a.a.a.a.g;

import a.a.a.a.a.f.d;
import a.a.a.a.q;
import android.annotation.SuppressLint;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import org.json.JSONException;
import org.json.JSONObject;

class k
  implements u
{
  private static final String a = "Unknown error while loading Crashlytics settings. Crashes will be cached until settings can be retrieved.";
  private static final String b = "existing_instance_identifier";
  private final y c;
  private final x d;
  private final a.a.a.a.a.b.n e;
  private final h f;
  private final z g;
  private final a.a.a.a.n h;
  private final d i;

  public k(a.a.a.a.n paramn, y paramy, a.a.a.a.a.b.n paramn1, x paramx, h paramh, z paramz)
  {
    this.h = paramn;
    this.c = paramy;
    this.e = paramn1;
    this.d = paramx;
    this.f = paramh;
    this.g = paramz;
    this.i = new a.a.a.a.a.f.e(this.h);
  }

  private void a(JSONObject paramJSONObject, String paramString)
    throws JSONException
  {
    a.a.a.a.e.i().a("Fabric", paramString + paramJSONObject.toString());
  }

  // ERROR //
  private v b(t paramt)
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore_2
    //   2: getstatic 88	a/a/a/a/a/g/t:b	La/a/a/a/a/g/t;
    //   5: aload_1
    //   6: invokevirtual 92	a/a/a/a/a/g/t:equals	(Ljava/lang/Object;)Z
    //   9: istore 4
    //   11: aconst_null
    //   12: astore_2
    //   13: iload 4
    //   15: ifne +99 -> 114
    //   18: aload_0
    //   19: getfield 42	a/a/a/a/a/g/k:f	La/a/a/a/a/g/h;
    //   22: invokeinterface 97 1 0
    //   27: astore 5
    //   29: aload 5
    //   31: ifnull +130 -> 161
    //   34: aload_0
    //   35: getfield 40	a/a/a/a/a/g/k:d	La/a/a/a/a/g/x;
    //   38: aload_0
    //   39: getfield 38	a/a/a/a/a/g/k:e	La/a/a/a/a/b/n;
    //   42: aload 5
    //   44: invokeinterface 102 3 0
    //   49: astore 6
    //   51: aload 6
    //   53: ifnull +93 -> 146
    //   56: aload_0
    //   57: aload 5
    //   59: ldc 104
    //   61: invokespecial 106	a/a/a/a/a/g/k:a	(Lorg/json/JSONObject;Ljava/lang/String;)V
    //   64: aload_0
    //   65: getfield 38	a/a/a/a/a/g/k:e	La/a/a/a/a/b/n;
    //   68: invokeinterface 111 1 0
    //   73: lstore 7
    //   75: getstatic 113	a/a/a/a/a/g/t:c	La/a/a/a/a/g/t;
    //   78: aload_1
    //   79: invokevirtual 92	a/a/a/a/a/g/t:equals	(Ljava/lang/Object;)Z
    //   82: ifne +17 -> 99
    //   85: aload 6
    //   87: lload 7
    //   89: invokevirtual 118	a/a/a/a/a/g/v:a	(J)Z
    //   92: istore 10
    //   94: iload 10
    //   96: ifne +20 -> 116
    //   99: invokestatic 59	a/a/a/a/e:i	()La/a/a/a/q;
    //   102: ldc 61
    //   104: ldc 120
    //   106: invokeinterface 80 3 0
    //   111: aload 6
    //   113: astore_2
    //   114: aload_2
    //   115: areturn
    //   116: invokestatic 59	a/a/a/a/e:i	()La/a/a/a/q;
    //   119: ldc 61
    //   121: ldc 122
    //   123: invokeinterface 80 3 0
    //   128: aconst_null
    //   129: areturn
    //   130: astore_3
    //   131: invokestatic 59	a/a/a/a/e:i	()La/a/a/a/q;
    //   134: ldc 61
    //   136: ldc 124
    //   138: aload_3
    //   139: invokeinterface 127 4 0
    //   144: aload_2
    //   145: areturn
    //   146: invokestatic 59	a/a/a/a/e:i	()La/a/a/a/q;
    //   149: ldc 61
    //   151: ldc 129
    //   153: aconst_null
    //   154: invokeinterface 127 4 0
    //   159: aconst_null
    //   160: areturn
    //   161: invokestatic 59	a/a/a/a/e:i	()La/a/a/a/q;
    //   164: ldc 61
    //   166: ldc 131
    //   168: invokeinterface 80 3 0
    //   173: aconst_null
    //   174: areturn
    //   175: astore 9
    //   177: aload 6
    //   179: astore_2
    //   180: aload 9
    //   182: astore_3
    //   183: goto -52 -> 131
    //
    // Exception table:
    //   from	to	target	type
    //   2	11	130	java/lang/Exception
    //   18	29	130	java/lang/Exception
    //   34	51	130	java/lang/Exception
    //   56	94	130	java/lang/Exception
    //   116	128	130	java/lang/Exception
    //   146	159	130	java/lang/Exception
    //   161	173	130	java/lang/Exception
    //   99	111	175	java/lang/Exception
  }

  public v a()
  {
    return a(t.a);
  }

  // ERROR //
  public v a(t paramt)
  {
    // Byte code:
    //   0: invokestatic 140	a/a/a/a/e:j	()Z
    //   3: istore 5
    //   5: aconst_null
    //   6: astore 6
    //   8: iload 5
    //   10: ifne +28 -> 38
    //   13: aload_0
    //   14: invokevirtual 142	a/a/a/a/a/g/k:d	()Z
    //   17: istore 7
    //   19: aconst_null
    //   20: astore 6
    //   22: iload 7
    //   24: ifne +14 -> 38
    //   27: aload_0
    //   28: aload_1
    //   29: invokespecial 144	a/a/a/a/a/g/k:b	(La/a/a/a/a/g/t;)La/a/a/a/a/g/v;
    //   32: astore 8
    //   34: aload 8
    //   36: astore 6
    //   38: aload 6
    //   40: ifnonnull +73 -> 113
    //   43: aload_0
    //   44: getfield 44	a/a/a/a/a/g/k:g	La/a/a/a/a/g/z;
    //   47: aload_0
    //   48: getfield 36	a/a/a/a/a/g/k:c	La/a/a/a/a/g/y;
    //   51: invokeinterface 149 2 0
    //   56: astore 11
    //   58: aload 11
    //   60: ifnull +53 -> 113
    //   63: aload_0
    //   64: getfield 40	a/a/a/a/a/g/k:d	La/a/a/a/a/g/x;
    //   67: aload_0
    //   68: getfield 38	a/a/a/a/a/g/k:e	La/a/a/a/a/b/n;
    //   71: aload 11
    //   73: invokeinterface 102 3 0
    //   78: astore 6
    //   80: aload_0
    //   81: getfield 42	a/a/a/a/a/g/k:f	La/a/a/a/a/g/h;
    //   84: aload 6
    //   86: getfield 152	a/a/a/a/a/g/v:g	J
    //   89: aload 11
    //   91: invokeinterface 155 4 0
    //   96: aload_0
    //   97: aload 11
    //   99: ldc 157
    //   101: invokespecial 106	a/a/a/a/a/g/k:a	(Lorg/json/JSONObject;Ljava/lang/String;)V
    //   104: aload_0
    //   105: aload_0
    //   106: invokevirtual 159	a/a/a/a/a/g/k:b	()Ljava/lang/String;
    //   109: invokevirtual 162	a/a/a/a/a/g/k:a	(Ljava/lang/String;)Z
    //   112: pop
    //   113: aload 6
    //   115: astore_3
    //   116: aload_3
    //   117: ifnonnull +15 -> 132
    //   120: aload_0
    //   121: getstatic 113	a/a/a/a/a/g/t:c	La/a/a/a/a/g/t;
    //   124: invokespecial 144	a/a/a/a/a/g/k:b	(La/a/a/a/a/g/t;)La/a/a/a/a/g/v;
    //   127: astore 9
    //   129: aload 9
    //   131: astore_3
    //   132: aload_3
    //   133: areturn
    //   134: astore_2
    //   135: aconst_null
    //   136: astore_3
    //   137: aload_2
    //   138: astore 4
    //   140: invokestatic 59	a/a/a/a/e:i	()La/a/a/a/q;
    //   143: ldc 61
    //   145: ldc 10
    //   147: aload 4
    //   149: invokeinterface 127 4 0
    //   154: aload_3
    //   155: areturn
    //   156: astore 10
    //   158: aload 6
    //   160: astore_3
    //   161: aload 10
    //   163: astore 4
    //   165: goto -25 -> 140
    //   168: astore 4
    //   170: goto -30 -> 140
    //
    // Exception table:
    //   from	to	target	type
    //   0	5	134	java/lang/Exception
    //   13	19	134	java/lang/Exception
    //   27	34	134	java/lang/Exception
    //   43	58	156	java/lang/Exception
    //   63	113	156	java/lang/Exception
    //   120	129	168	java/lang/Exception
  }

  @SuppressLint({"CommitPrefEdits"})
  boolean a(String paramString)
  {
    SharedPreferences.Editor localEditor = this.i.b();
    localEditor.putString("existing_instance_identifier", paramString);
    return this.i.a(localEditor);
  }

  String b()
  {
    String[] arrayOfString = new String[1];
    arrayOfString[0] = a.a.a.a.a.b.k.n(this.h.u());
    return a.a.a.a.a.b.k.a(arrayOfString);
  }

  String c()
  {
    return this.i.a().getString("existing_instance_identifier", "");
  }

  boolean d()
  {
    return !c().equals(b());
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.g.k
 * JD-Core Version:    0.6.2
 */