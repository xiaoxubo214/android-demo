package a.a.a.a.a.g;

import org.json.JSONException;
import org.json.JSONObject;

class l
  implements x
{
  private long a(a.a.a.a.a.b.n paramn, long paramLong, JSONObject paramJSONObject)
    throws JSONException
  {
    if (paramJSONObject.has("expires_at"))
      return paramJSONObject.getLong("expires_at");
    return paramn.a() + 1000L * paramLong;
  }

  private e a(JSONObject paramJSONObject)
    throws JSONException
  {
    String str1 = paramJSONObject.getString("identifier");
    String str2 = paramJSONObject.getString("status");
    String str3 = paramJSONObject.getString("url");
    String str4 = paramJSONObject.getString("reports_url");
    String str5 = paramJSONObject.getString("ndk_reports_url");
    boolean bool1 = paramJSONObject.optBoolean("update_required", false);
    boolean bool2 = paramJSONObject.has("icon");
    c localc = null;
    if (bool2)
    {
      boolean bool3 = paramJSONObject.getJSONObject("icon").has("hash");
      localc = null;
      if (bool3)
        localc = b(paramJSONObject.getJSONObject("icon"));
    }
    return new e(str1, str2, str3, str4, str5, bool1, localc);
  }

  private JSONObject a(b paramb)
    throws JSONException
  {
    return new JSONObject().put("url", paramb.a).put("flush_interval_secs", paramb.b).put("max_byte_size_per_file", paramb.c).put("max_file_count_per_send", paramb.d).put("max_pending_send_file_count", paramb.e);
  }

  private JSONObject a(c paramc)
    throws JSONException
  {
    return new JSONObject().put("hash", paramc.a).put("width", paramc.b).put("height", paramc.c);
  }

  private JSONObject a(e parame)
    throws JSONException
  {
    JSONObject localJSONObject = new JSONObject().put("identifier", parame.d).put("status", parame.e).put("url", parame.f).put("reports_url", parame.g).put("ndk_reports_url", parame.h).put("update_required", parame.i);
    if (parame.j != null)
      localJSONObject.put("icon", a(parame.j));
    return localJSONObject;
  }

  private JSONObject a(g paramg)
    throws JSONException
  {
    return new JSONObject().put("update_endpoint", paramg.a).put("update_suspend_duration", paramg.b);
  }

  private JSONObject a(n paramn)
    throws JSONException
  {
    return new JSONObject().put("collect_logged_exceptions", paramn.b).put("collect_reports", paramn.c).put("collect_analytics", paramn.d);
  }

  private JSONObject a(p paramp)
    throws JSONException
  {
    return new JSONObject().put("title", paramp.a).put("message", paramp.b).put("send_button_title", paramp.c).put("show_cancel_button", paramp.d).put("cancel_button_title", paramp.e).put("show_always_send_button", paramp.f).put("always_send_button_title", paramp.g);
  }

  private JSONObject a(q paramq)
    throws JSONException
  {
    return new JSONObject().put("log_buffer_size", paramq.a).put("max_chained_exception_depth", paramq.b).put("max_custom_exception_events", paramq.c).put("max_custom_key_value_pairs", paramq.d).put("identifier_mask", paramq.e).put("send_session_without_crash", paramq.f);
  }

  private c b(JSONObject paramJSONObject)
    throws JSONException
  {
    return new c(paramJSONObject.getString("hash"), paramJSONObject.getInt("width"), paramJSONObject.getInt("height"));
  }

  private n c(JSONObject paramJSONObject)
  {
    return new n(paramJSONObject.optBoolean("prompt_enabled", false), paramJSONObject.optBoolean("collect_logged_exceptions", true), paramJSONObject.optBoolean("collect_reports", true), paramJSONObject.optBoolean("collect_analytics", false));
  }

  private b d(JSONObject paramJSONObject)
  {
    return new b(paramJSONObject.optString("url", "https://e.crashlytics.com/spi/v2/events"), paramJSONObject.optInt("flush_interval_secs", 600), paramJSONObject.optInt("max_byte_size_per_file", 8000), paramJSONObject.optInt("max_file_count_per_send", 1), paramJSONObject.optInt("max_pending_send_file_count", 100), paramJSONObject.optBoolean("forward_to_google_analytics", false), paramJSONObject.optBoolean("include_purchase_events_in_forwarded_events", false), paramJSONObject.optBoolean("track_custom_events", true), paramJSONObject.optBoolean("track_predefined_events", true), paramJSONObject.optInt("sampling_rate", 1), paramJSONObject.optBoolean("flush_on_background", true));
  }

  private q e(JSONObject paramJSONObject)
    throws JSONException
  {
    return new q(paramJSONObject.optInt("log_buffer_size", 64000), paramJSONObject.optInt("max_chained_exception_depth", 8), paramJSONObject.optInt("max_custom_exception_events", 64), paramJSONObject.optInt("max_custom_key_value_pairs", 64), paramJSONObject.optInt("identifier_mask", 255), paramJSONObject.optBoolean("send_session_without_crash", false), paramJSONObject.optInt("max_complete_sessions_count", 4));
  }

  private p f(JSONObject paramJSONObject)
    throws JSONException
  {
    return new p(paramJSONObject.optString("title", "Send Crash Report?"), paramJSONObject.optString("message", "Looks like we crashed! Please help us fix the problem by sending a crash report."), paramJSONObject.optString("send_button_title", "Send"), paramJSONObject.optBoolean("show_cancel_button", true), paramJSONObject.optString("cancel_button_title", "Don't Send"), paramJSONObject.optBoolean("show_always_send_button", true), paramJSONObject.optString("always_send_button_title", "Always Send"));
  }

  private g g(JSONObject paramJSONObject)
    throws JSONException
  {
    return new g(paramJSONObject.optString("update_endpoint", w.I), paramJSONObject.optInt("update_suspend_duration", 3600));
  }

  public v a(a.a.a.a.a.b.n paramn, JSONObject paramJSONObject)
    throws JSONException
  {
    int i = paramJSONObject.optInt("settings_version", 0);
    int j = paramJSONObject.optInt("cache_duration", 3600);
    e locale = a(paramJSONObject.getJSONObject("app"));
    q localq = e(paramJSONObject.getJSONObject("session"));
    p localp = f(paramJSONObject.getJSONObject("prompt"));
    n localn = c(paramJSONObject.getJSONObject("features"));
    b localb = d(paramJSONObject.getJSONObject("analytics"));
    g localg = g(paramJSONObject.getJSONObject("beta"));
    return new v(a(paramn, j, paramJSONObject), locale, localq, localp, localn, localb, localg, i, j);
  }

  public JSONObject a(v paramv)
    throws JSONException
  {
    return new JSONObject().put("expires_at", paramv.g).put("cache_duration", paramv.i).put("settings_version", paramv.h).put("features", a(paramv.d)).put("analytics", a(paramv.e)).put("beta", a(paramv.f)).put("app", a(paramv.a)).put("session", a(paramv.b)).put("prompt", a(paramv.c));
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.g.l
 * JD-Core Version:    0.6.2
 */