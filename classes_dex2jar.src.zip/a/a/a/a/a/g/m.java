package a.a.a.a.a.g;

import a.a.a.a.a.b.a;
import a.a.a.a.a.b.k;
import a.a.a.a.a.e.d;
import a.a.a.a.a.e.o;
import a.a.a.a.n;
import a.a.a.a.q;
import android.text.TextUtils;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONObject;

class m extends a
  implements z
{
  static final String a = "build_version";
  static final String b = "display_version";
  static final String c = "instance";
  static final String d = "source";
  static final String e = "icon_hash";
  static final String f = "X-CRASHLYTICS-DEVICE-MODEL";
  static final String g = "X-CRASHLYTICS-OS-BUILD-VERSION";
  static final String u = "X-CRASHLYTICS-OS-DISPLAY-VERSION";
  static final String v = "X-CRASHLYTICS-ADVERTISING-TOKEN";
  static final String w = "X-CRASHLYTICS-INSTALLATION-ID";
  static final String x = "X-CRASHLYTICS-ANDROID-ID";

  public m(n paramn, String paramString1, String paramString2, o paramo)
  {
    this(paramn, paramString1, paramString2, paramo, d.a);
  }

  m(n paramn, String paramString1, String paramString2, o paramo, d paramd)
  {
    super(paramn, paramString1, paramString2, paramo, paramd);
  }

  private a.a.a.a.a.e.e a(a.a.a.a.a.e.e parame, y paramy)
  {
    a(parame, "X-CRASHLYTICS-API-KEY", paramy.a);
    a(parame, "X-CRASHLYTICS-API-CLIENT-TYPE", "android");
    a(parame, "X-CRASHLYTICS-API-CLIENT-VERSION", this.t.a());
    a(parame, "Accept", "application/json");
    a(parame, "X-CRASHLYTICS-DEVICE-MODEL", paramy.b);
    a(parame, "X-CRASHLYTICS-OS-BUILD-VERSION", paramy.c);
    a(parame, "X-CRASHLYTICS-OS-DISPLAY-VERSION", paramy.d);
    a(parame, "X-CRASHLYTICS-INSTALLATION-ID", paramy.f);
    if (TextUtils.isEmpty(paramy.e))
    {
      a(parame, "X-CRASHLYTICS-ANDROID-ID", paramy.g);
      return parame;
    }
    a(parame, "X-CRASHLYTICS-ADVERTISING-TOKEN", paramy.e);
    return parame;
  }

  private JSONObject a(String paramString)
  {
    try
    {
      JSONObject localJSONObject = new JSONObject(paramString);
      return localJSONObject;
    }
    catch (Exception localException)
    {
      a.a.a.a.e.i().a("Fabric", "Failed to parse settings JSON from " + a(), localException);
      a.a.a.a.e.i().a("Fabric", "Settings response " + paramString);
    }
    return null;
  }

  private void a(a.a.a.a.a.e.e parame, String paramString1, String paramString2)
  {
    if (paramString2 != null)
      parame.a(paramString1, paramString2);
  }

  private Map<String, String> b(y paramy)
  {
    HashMap localHashMap = new HashMap();
    localHashMap.put("build_version", paramy.j);
    localHashMap.put("display_version", paramy.i);
    localHashMap.put("source", Integer.toString(paramy.k));
    if (paramy.l != null)
      localHashMap.put("icon_hash", paramy.l);
    String str = paramy.h;
    if (!k.e(str))
      localHashMap.put("instance", str);
    return localHashMap;
  }

  JSONObject a(a.a.a.a.a.e.e parame)
  {
    int i = parame.c();
    a.a.a.a.e.i().a("Fabric", "Settings result was: " + i);
    if (a(i))
      return a(parame.n());
    a.a.a.a.e.i().e("Fabric", "Failed to retrieve settings from " + a());
    return null;
  }

  // ERROR //
  public JSONObject a(y paramy)
  {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokespecial 205	a/a/a/a/a/g/m:b	(La/a/a/a/a/g/y;)Ljava/util/Map;
    //   5: astore 7
    //   7: aload_0
    //   8: aload 7
    //   10: invokevirtual 208	a/a/a/a/a/g/m:a	(Ljava/util/Map;)La/a/a/a/a/e/e;
    //   13: astore 8
    //   15: aload 8
    //   17: astore_3
    //   18: aload_0
    //   19: aload_3
    //   20: aload_1
    //   21: invokespecial 210	a/a/a/a/a/g/m:a	(La/a/a/a/a/e/e;La/a/a/a/a/g/y;)La/a/a/a/a/e/e;
    //   24: astore_3
    //   25: invokestatic 112	a/a/a/a/e:i	()La/a/a/a/q;
    //   28: ldc 114
    //   30: new 116	java/lang/StringBuilder
    //   33: dup
    //   34: invokespecial 119	java/lang/StringBuilder:<init>	()V
    //   37: ldc 212
    //   39: invokevirtual 125	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   42: aload_0
    //   43: invokevirtual 126	a/a/a/a/a/g/m:a	()Ljava/lang/String;
    //   46: invokevirtual 125	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   49: invokevirtual 129	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   52: invokeinterface 139 3 0
    //   57: invokestatic 112	a/a/a/a/e:i	()La/a/a/a/q;
    //   60: ldc 114
    //   62: new 116	java/lang/StringBuilder
    //   65: dup
    //   66: invokespecial 119	java/lang/StringBuilder:<init>	()V
    //   69: ldc 214
    //   71: invokevirtual 125	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   74: aload 7
    //   76: invokevirtual 217	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   79: invokevirtual 129	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   82: invokeinterface 139 3 0
    //   87: aload_0
    //   88: aload_3
    //   89: invokevirtual 219	a/a/a/a/a/g/m:a	(La/a/a/a/a/e/e;)Lorg/json/JSONObject;
    //   92: astore 9
    //   94: aload 9
    //   96: astore 6
    //   98: aload_3
    //   99: ifnull +37 -> 136
    //   102: invokestatic 112	a/a/a/a/e:i	()La/a/a/a/q;
    //   105: ldc 114
    //   107: new 116	java/lang/StringBuilder
    //   110: dup
    //   111: invokespecial 119	java/lang/StringBuilder:<init>	()V
    //   114: ldc 221
    //   116: invokevirtual 125	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   119: aload_3
    //   120: ldc 223
    //   122: invokevirtual 226	a/a/a/a/a/e/e:e	(Ljava/lang/String;)Ljava/lang/String;
    //   125: invokevirtual 125	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   128: invokevirtual 129	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   131: invokeinterface 139 3 0
    //   136: aload 6
    //   138: areturn
    //   139: astore 5
    //   141: aconst_null
    //   142: astore_3
    //   143: invokestatic 112	a/a/a/a/e:i	()La/a/a/a/q;
    //   146: ldc 114
    //   148: ldc 228
    //   150: aload 5
    //   152: invokeinterface 230 4 0
    //   157: aconst_null
    //   158: astore 6
    //   160: aload_3
    //   161: ifnull -25 -> 136
    //   164: invokestatic 112	a/a/a/a/e:i	()La/a/a/a/q;
    //   167: ldc 114
    //   169: new 116	java/lang/StringBuilder
    //   172: dup
    //   173: invokespecial 119	java/lang/StringBuilder:<init>	()V
    //   176: ldc 221
    //   178: invokevirtual 125	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   181: aload_3
    //   182: ldc 223
    //   184: invokevirtual 226	a/a/a/a/a/e/e:e	(Ljava/lang/String;)Ljava/lang/String;
    //   187: invokevirtual 125	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   190: invokevirtual 129	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   193: invokeinterface 139 3 0
    //   198: aconst_null
    //   199: areturn
    //   200: astore_2
    //   201: aconst_null
    //   202: astore_3
    //   203: aload_2
    //   204: astore 4
    //   206: aload_3
    //   207: ifnull +37 -> 244
    //   210: invokestatic 112	a/a/a/a/e:i	()La/a/a/a/q;
    //   213: ldc 114
    //   215: new 116	java/lang/StringBuilder
    //   218: dup
    //   219: invokespecial 119	java/lang/StringBuilder:<init>	()V
    //   222: ldc 221
    //   224: invokevirtual 125	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   227: aload_3
    //   228: ldc 223
    //   230: invokevirtual 226	a/a/a/a/a/e/e:e	(Ljava/lang/String;)Ljava/lang/String;
    //   233: invokevirtual 125	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   236: invokevirtual 129	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   239: invokeinterface 139 3 0
    //   244: aload 4
    //   246: athrow
    //   247: astore 4
    //   249: goto -43 -> 206
    //   252: astore 5
    //   254: goto -111 -> 143
    //
    // Exception table:
    //   from	to	target	type
    //   0	15	139	a/a/a/a/a/e/e$e
    //   0	15	200	finally
    //   18	94	247	finally
    //   143	157	247	finally
    //   18	94	252	a/a/a/a/a/e/e$e
  }

  boolean a(int paramInt)
  {
    return (paramInt == 200) || (paramInt == 201) || (paramInt == 202) || (paramInt == 203);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.g.m
 * JD-Core Version:    0.6.2
 */