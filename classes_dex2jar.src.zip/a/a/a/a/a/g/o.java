package a.a.a.a.a.g;

import a.a.a.a.a.b.k;
import a.a.a.a.e;
import a.a.a.a.q;
import android.content.Context;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;

public class o
{
  public final String a;
  public final int b;
  public final int c;
  public final int d;

  public o(String paramString, int paramInt1, int paramInt2, int paramInt3)
  {
    this.a = paramString;
    this.b = paramInt1;
    this.c = paramInt2;
    this.d = paramInt3;
  }

  public static o a(Context paramContext, String paramString)
  {
    if (paramString != null)
      try
      {
        int i = k.m(paramContext);
        e.i().a("Fabric", "App icon resource ID is " + i);
        BitmapFactory.Options localOptions = new BitmapFactory.Options();
        localOptions.inJustDecodeBounds = true;
        BitmapFactory.decodeResource(paramContext.getResources(), i, localOptions);
        o localo = new o(paramString, i, localOptions.outWidth, localOptions.outHeight);
        return localo;
      }
      catch (Exception localException)
      {
        e.i().e("Fabric", "Failed to load icon", localException);
      }
    return null;
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.g.o
 * JD-Core Version:    0.6.2
 */