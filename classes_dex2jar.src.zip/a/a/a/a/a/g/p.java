package a.a.a.a.a.g;

public class p
{
  public final String a;
  public final String b;
  public final String c;
  public final boolean d;
  public final String e;
  public final boolean f;
  public final String g;

  public p(String paramString1, String paramString2, String paramString3, boolean paramBoolean1, String paramString4, boolean paramBoolean2, String paramString5)
  {
    this.a = paramString1;
    this.b = paramString2;
    this.c = paramString3;
    this.d = paramBoolean1;
    this.e = paramString4;
    this.f = paramBoolean2;
    this.g = paramString5;
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.g.p
 * JD-Core Version:    0.6.2
 */