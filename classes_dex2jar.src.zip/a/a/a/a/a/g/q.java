package a.a.a.a.a.g;

public class q
{
  public final int a;
  public final int b;
  public final int c;
  public final int d;
  public final int e;
  public final boolean f;
  public final int g;

  public q(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, boolean paramBoolean, int paramInt6)
  {
    this.a = paramInt1;
    this.b = paramInt2;
    this.c = paramInt3;
    this.d = paramInt4;
    this.e = paramInt5;
    this.f = paramBoolean;
    this.g = paramInt6;
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.g.q
 * JD-Core Version:    0.6.2
 */