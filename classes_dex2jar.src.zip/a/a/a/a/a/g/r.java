package a.a.a.a.a.g;

import a.a.a.a.a.b.ad;
import a.a.a.a.a.b.i;
import a.a.a.a.e;
import a.a.a.a.n;
import a.a.a.a.q;
import android.content.Context;
import java.util.Locale;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicReference;

public class r
{
  public static final String a = "com.crashlytics.settings.json";
  private static final String b = "https://settings.crashlytics.com/spi/v2/platforms/android/apps/%s/settings";
  private final AtomicReference<v> c = new AtomicReference();
  private final CountDownLatch d = new CountDownLatch(1);
  private u e;
  private boolean f = false;

  public static r a()
  {
    return a.a();
  }

  private void a(v paramv)
  {
    this.c.set(paramv);
    this.d.countDown();
  }

  public r a(n paramn, a.a.a.a.a.b.v paramv, a.a.a.a.a.e.o paramo, String paramString1, String paramString2, String paramString3)
  {
    try
    {
      boolean bool = this.f;
      if (bool);
      for (r localr = this; ; localr = this)
      {
        return localr;
        if (this.e == null)
        {
          Context localContext = paramn.u();
          String str1 = paramv.c();
          String str2 = new i().b(localContext);
          String str3 = paramv.i();
          ad localad = new ad();
          l locall = new l();
          j localj = new j(paramn);
          String str4 = a.a.a.a.a.b.k.l(localContext);
          String str5 = String.format(Locale.US, "https://settings.crashlytics.com/spi/v2/platforms/android/apps/%s/settings", new Object[] { str1 });
          m localm = new m(paramn, paramString3, str5, paramo);
          String str6 = paramv.g();
          String str7 = paramv.f();
          String str8 = paramv.e();
          String str9 = paramv.k();
          String str10 = paramv.b();
          String str11 = paramv.l();
          String[] arrayOfString = new String[1];
          arrayOfString[0] = a.a.a.a.a.b.k.n(localContext);
          this.e = new k(paramn, new y(str2, str6, str7, str8, str9, str10, str11, a.a.a.a.a.b.k.a(arrayOfString), paramString2, paramString1, a.a.a.a.a.b.o.a(str3).a(), str4), localad, locall, localj, localm);
        }
        this.f = true;
      }
    }
    finally
    {
    }
  }

  public <T> T a(b<T> paramb, T paramT)
  {
    v localv = (v)this.c.get();
    if (localv == null)
      return paramT;
    return paramb.a(localv);
  }

  public void a(u paramu)
  {
    this.e = paramu;
  }

  public void b()
  {
    this.c.set(null);
  }

  public v c()
  {
    try
    {
      this.d.await();
      v localv = (v)this.c.get();
      return localv;
    }
    catch (InterruptedException localInterruptedException)
    {
      e.i().e("Fabric", "Interrupted while waiting for settings data.");
    }
    return null;
  }

  public boolean d()
  {
    try
    {
      v localv = this.e.a();
      a(localv);
      if (localv != null)
      {
        bool = true;
        return bool;
      }
      boolean bool = false;
    }
    finally
    {
    }
  }

  public boolean e()
  {
    try
    {
      v localv = this.e.a(t.b);
      a(localv);
      if (localv == null)
        e.i().e("Fabric", "Failed to force reload of settings from Crashlytics.", null);
      if (localv != null);
      for (boolean bool = true; ; bool = false)
        return bool;
    }
    finally
    {
    }
  }

  static class a
  {
    private static final r a = new r(null);
  }

  public static abstract interface b<T>
  {
    public abstract T a(v paramv);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.g.r
 * JD-Core Version:    0.6.2
 */