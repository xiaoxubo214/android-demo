package a.a.a.a.a.g;

public enum t
{
  static
  {
    t[] arrayOft = new t[3];
    arrayOft[0] = a;
    arrayOft[1] = b;
    arrayOft[2] = c;
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.g.t
 * JD-Core Version:    0.6.2
 */