package a.a.a.a.a.g;

public class v
{
  public final e a;
  public final q b;
  public final p c;
  public final n d;
  public final b e;
  public final g f;
  public final long g;
  public final int h;
  public final int i;

  public v(long paramLong, e parame, q paramq, p paramp, n paramn, b paramb, g paramg, int paramInt1, int paramInt2)
  {
    this.g = paramLong;
    this.a = parame;
    this.b = paramq;
    this.c = paramp;
    this.d = paramn;
    this.h = paramInt1;
    this.i = paramInt2;
    this.e = paramb;
    this.f = paramg;
  }

  public boolean a(long paramLong)
  {
    return this.g < paramLong;
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.g.v
 * JD-Core Version:    0.6.2
 */