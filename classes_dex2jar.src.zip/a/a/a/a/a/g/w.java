package a.a.a.a.a.g;

public class w
{
  public static final boolean A = false;
  public static final boolean B = false;
  public static final boolean C = true;
  public static final boolean D = true;
  public static final boolean E = true;
  public static final int F = 1;
  public static final String G = "update_endpoint";
  public static final String H = "update_suspend_duration";
  public static final String I = null;
  public static final int J = 3600;
  public static final String K = "prompt_enabled";
  public static final String L = "collect_reports";
  public static final String M = "collect_logged_exceptions";
  public static final String N = "collect_analytics";
  public static final boolean O = false;
  public static final boolean P = true;
  public static final boolean Q = true;
  public static final boolean R = false;
  public static final String S = "identifier";
  public static final String T = "status";
  public static final String U = "url";
  public static final String V = "reports_url";
  public static final String W = "ndk_reports_url";
  public static final String X = "update_required";
  public static final String Y = "icon";
  public static final boolean Z = false;
  public static final String a = "expires_at";
  public static final String aA = "Send Crash Report?";
  public static final String aB = "Looks like we crashed! Please help us fix the problem by sending a crash report.";
  public static final boolean aC = true;
  public static final boolean aD = true;
  public static final String aE = "Send";
  public static final String aF = "Always Send";
  public static final String aG = "Don't Send";
  public static final String aa = "hash";
  public static final String ab = "width";
  public static final String ac = "height";
  public static final String ad = "prerendered";
  public static final String ae = "log_buffer_size";
  public static final String af = "max_chained_exception_depth";
  public static final String ag = "max_custom_exception_events";
  public static final String ah = "max_custom_key_value_pairs";
  public static final String ai = "identifier_mask";
  public static final String aj = "send_session_without_crash";
  public static final String ak = "max_complete_sessions_count";
  public static final int al = 3600;
  public static final int am = 64000;
  public static final int an = 8;
  public static final int ao = 64;
  public static final int ap = 64;
  public static final int aq = 255;
  public static final boolean ar = false;
  public static final int as = 4;
  public static final String at = "title";
  public static final String au = "message";
  public static final String av = "send_button_title";
  public static final String aw = "show_cancel_button";
  public static final String ax = "cancel_button_title";
  public static final String ay = "show_always_send_button";
  public static final String az = "always_send_button_title";
  public static final String b = "app";
  public static final String c = "analytics";
  public static final String d = "beta";
  public static final String e = "session";
  public static final String f = "prompt";
  public static final String g = "settings_version";
  public static final String h = "features";
  public static final String i = "cache_duration";
  public static final int j = 0;
  public static final String k = "url";
  public static final String l = "flush_interval_secs";
  public static final String m = "max_byte_size_per_file";
  public static final String n = "max_file_count_per_send";
  public static final String o = "max_pending_send_file_count";
  public static final String p = "forward_to_google_analytics";
  public static final String q = "include_purchase_events_in_forwarded_events";
  public static final String r = "track_custom_events";
  public static final String s = "track_predefined_events";
  public static final String t = "sampling_rate";
  public static final String u = "flush_on_background";
  public static final String v = "https://e.crashlytics.com/spi/v2/events";
  public static final int w = 600;
  public static final int x = 8000;
  public static final int y = 1;
  public static final int z = 100;
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.g.w
 * JD-Core Version:    0.6.2
 */