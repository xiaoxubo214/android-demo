package a.a.a.a.a.g;

import a.a.a.a.a.b.n;
import org.json.JSONException;
import org.json.JSONObject;

public abstract interface x
{
  public abstract v a(n paramn, JSONObject paramJSONObject)
    throws JSONException;

  public abstract JSONObject a(v paramv)
    throws JSONException;
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.g.x
 * JD-Core Version:    0.6.2
 */