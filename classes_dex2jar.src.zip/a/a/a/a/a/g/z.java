package a.a.a.a.a.g;

import org.json.JSONObject;

public abstract interface z
{
  public abstract JSONObject a(y paramy);
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.g.z
 * JD-Core Version:    0.6.2
 */