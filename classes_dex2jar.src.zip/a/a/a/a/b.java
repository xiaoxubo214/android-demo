package a.a.a.a;

import android.app.Activity;
import android.app.Application.ActivityLifecycleCallbacks;
import android.os.Bundle;

class b
  implements Application.ActivityLifecycleCallbacks
{
  b(a.a parama, a.b paramb)
  {
  }

  public void onActivityCreated(Activity paramActivity, Bundle paramBundle)
  {
    this.a.a(paramActivity, paramBundle);
  }

  public void onActivityDestroyed(Activity paramActivity)
  {
    this.a.e(paramActivity);
  }

  public void onActivityPaused(Activity paramActivity)
  {
    this.a.c(paramActivity);
  }

  public void onActivityResumed(Activity paramActivity)
  {
    this.a.b(paramActivity);
  }

  public void onActivitySaveInstanceState(Activity paramActivity, Bundle paramBundle)
  {
    this.a.b(paramActivity, paramBundle);
  }

  public void onActivityStarted(Activity paramActivity)
  {
    this.a.a(paramActivity);
  }

  public void onActivityStopped(Activity paramActivity)
  {
    this.a.d(paramActivity);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.b
 * JD-Core Version:    0.6.2
 */