package a.a.a.a;

public final class c
{
  public static final boolean a = false;
  public static final String b = "io.fabric.sdk.android";
  public static final String c = "release";
  public static final String d = "";
  public static final int e = 1;
  public static final String f = "1.4.1";
  public static final String g = "fabric";
  public static final String h = "19";
  public static final String i = "470fa2b4ae81cd56ecbcda9735803434cec591fa";
  public static final String j = "io.fabric.sdk.android";
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.c
 * JD-Core Version:    0.6.2
 */