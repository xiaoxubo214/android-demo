package a.a.a.a;

import android.util.Log;

public class d
  implements q
{
  private int a;

  public d()
  {
    this.a = 4;
  }

  public d(int paramInt)
  {
    this.a = paramInt;
  }

  public int a()
  {
    return this.a;
  }

  public void a(int paramInt)
  {
    this.a = paramInt;
  }

  public void a(int paramInt, String paramString1, String paramString2)
  {
    a(paramInt, paramString1, paramString2, false);
  }

  public void a(int paramInt, String paramString1, String paramString2, boolean paramBoolean)
  {
    if ((paramBoolean) || (a(paramString1, paramInt)))
      Log.println(paramInt, paramString1, paramString2);
  }

  public void a(String paramString1, String paramString2)
  {
    a(paramString1, paramString2, null);
  }

  public void a(String paramString1, String paramString2, Throwable paramThrowable)
  {
    if (a(paramString1, 3))
      Log.d(paramString1, paramString2, paramThrowable);
  }

  public boolean a(String paramString, int paramInt)
  {
    return this.a <= paramInt;
  }

  public void b(String paramString1, String paramString2)
  {
    b(paramString1, paramString2, null);
  }

  public void b(String paramString1, String paramString2, Throwable paramThrowable)
  {
    if (a(paramString1, 2))
      Log.v(paramString1, paramString2, paramThrowable);
  }

  public void c(String paramString1, String paramString2)
  {
    c(paramString1, paramString2, null);
  }

  public void c(String paramString1, String paramString2, Throwable paramThrowable)
  {
    if (a(paramString1, 4))
      Log.i(paramString1, paramString2, paramThrowable);
  }

  public void d(String paramString1, String paramString2)
  {
    d(paramString1, paramString2, null);
  }

  public void d(String paramString1, String paramString2, Throwable paramThrowable)
  {
    if (a(paramString1, 5))
      Log.w(paramString1, paramString2, paramThrowable);
  }

  public void e(String paramString1, String paramString2)
  {
    e(paramString1, paramString2, null);
  }

  public void e(String paramString1, String paramString2, Throwable paramThrowable)
  {
    if (a(paramString1, 6))
      Log.e(paramString1, paramString2, paramThrowable);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.d
 * JD-Core Version:    0.6.2
 */