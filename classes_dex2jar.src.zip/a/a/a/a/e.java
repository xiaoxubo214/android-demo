package a.a.a.a;

import a.a.a.a.a.b.v;
import a.a.a.a.a.c.s;
import a.a.a.a.a.c.u;
import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicBoolean;

public class e
{
  public static final String a = "Fabric";
  static final String b = ".Fabric";
  static volatile e c;
  static final q d = new d();
  static final boolean e;
  final q f;
  final boolean g;
  private final Context h;
  private final Map<Class<? extends n>, n> i;
  private final ExecutorService j;
  private final Handler k;
  private final j<e> l;
  private final j<?> m;
  private final v n;
  private a o;
  private WeakReference<Activity> p;
  private AtomicBoolean q;

  e(Context paramContext, Map<Class<? extends n>, n> paramMap, s params, Handler paramHandler, q paramq, boolean paramBoolean, j paramj, v paramv, Activity paramActivity)
  {
    this.h = paramContext;
    this.i = paramMap;
    this.j = params;
    this.k = paramHandler;
    this.f = paramq;
    this.g = paramBoolean;
    this.l = paramj;
    this.q = new AtomicBoolean(false);
    this.m = a(paramMap.size());
    this.n = paramv;
    a(paramActivity);
  }

  static e a()
  {
    if (c == null)
      throw new IllegalStateException("Must Initialize Fabric before using singleton()");
    return c;
  }

  public static e a(e parame)
  {
    if (c == null);
    try
    {
      if (c == null)
        d(parame);
      return c;
    }
    finally
    {
    }
  }

  public static e a(Context paramContext, n[] paramArrayOfn)
  {
    if (c == null);
    try
    {
      if (c == null)
        d(new a(paramContext).a(paramArrayOfn).a());
      return c;
    }
    finally
    {
    }
  }

  public static <T extends n> T a(Class<T> paramClass)
  {
    return (n)a().i.get(paramClass);
  }

  private static void a(Map<Class<? extends n>, n> paramMap, Collection<? extends n> paramCollection)
  {
    Iterator localIterator = paramCollection.iterator();
    while (localIterator.hasNext())
    {
      n localn = (n)localIterator.next();
      paramMap.put(localn.getClass(), localn);
      if ((localn instanceof o))
        a(paramMap, ((o)localn).c());
    }
  }

  private static Map<Class<? extends n>, n> b(Collection<? extends n> paramCollection)
  {
    HashMap localHashMap = new HashMap(paramCollection.size());
    a(localHashMap, paramCollection);
    return localHashMap;
  }

  private static Activity d(Context paramContext)
  {
    if ((paramContext instanceof Activity))
      return (Activity)paramContext;
    return null;
  }

  private static void d(e parame)
  {
    c = parame;
    parame.n();
  }

  public static q i()
  {
    if (c == null)
      return d;
    return c.f;
  }

  public static boolean j()
  {
    if (c == null)
      return false;
    return c.g;
  }

  public static boolean k()
  {
    return (c != null) && (c.q.get());
  }

  private void n()
  {
    this.o = new a(this.h);
    this.o.a(new f(this));
    a(this.h);
  }

  public e a(Activity paramActivity)
  {
    this.p = new WeakReference(paramActivity);
    return this;
  }

  j<?> a(int paramInt)
  {
    return new g(this, paramInt);
  }

  void a(Context paramContext)
  {
    Future localFuture = b(paramContext);
    Collection localCollection = h();
    r localr = new r(localFuture, localCollection);
    ArrayList localArrayList = new ArrayList(localCollection);
    Collections.sort(localArrayList);
    localr.a(paramContext, this, j.d, this.n);
    Iterator localIterator1 = localArrayList.iterator();
    while (localIterator1.hasNext())
      ((n)localIterator1.next()).a(paramContext, this, this.m, this.n);
    localr.s();
    if (i().a("Fabric", 3));
    for (StringBuilder localStringBuilder = new StringBuilder("Initializing ").append(d()).append(" [Version: ").append(c()).append("], with the following kits:\n"); ; localStringBuilder = null)
    {
      Iterator localIterator2 = localArrayList.iterator();
      while (localIterator2.hasNext())
      {
        n localn = (n)localIterator2.next();
        localn.j.a(localr.j);
        a(this.i, localn);
        localn.s();
        if (localStringBuilder != null)
          localStringBuilder.append(localn.b()).append(" [Version: ").append(localn.a()).append("]\n");
      }
    }
    if (localStringBuilder != null)
      i().a("Fabric", localStringBuilder.toString());
  }

  void a(Map<Class<? extends n>, n> paramMap, n paramn)
  {
    a.a.a.a.a.c.j localj = paramn.n;
    if (localj != null)
      for (Class localClass : localj.a())
      {
        if (localClass.isInterface())
        {
          Iterator localIterator = paramMap.values().iterator();
          while (localIterator.hasNext())
          {
            n localn = (n)localIterator.next();
            if (localClass.isAssignableFrom(localn.getClass()))
              paramn.j.a(localn.j);
          }
        }
        if ((n)paramMap.get(localClass) == null)
          throw new u("Referenced Kit was null, does the kit exist?");
        paramn.j.a(((n)paramMap.get(localClass)).j);
      }
  }

  public Activity b()
  {
    if (this.p != null)
      return (Activity)this.p.get();
    return null;
  }

  Future<Map<String, p>> b(Context paramContext)
  {
    i locali = new i(paramContext.getPackageCodePath());
    return f().submit(locali);
  }

  public String c()
  {
    return "1.4.1.19";
  }

  public String d()
  {
    return "io.fabric.sdk.android:fabric";
  }

  public a e()
  {
    return this.o;
  }

  public ExecutorService f()
  {
    return this.j;
  }

  public Handler g()
  {
    return this.k;
  }

  public Collection<n> h()
  {
    return this.i.values();
  }

  public String l()
  {
    return this.n.c();
  }

  public String m()
  {
    return this.n.b();
  }

  public static class a
  {
    private final Context a;
    private n[] b;
    private s c;
    private Handler d;
    private q e;
    private boolean f;
    private String g;
    private String h;
    private j<e> i;

    public a(Context paramContext)
    {
      if (paramContext == null)
        throw new IllegalArgumentException("Context must not be null.");
      this.a = paramContext;
    }

    public a a(s params)
    {
      if (params == null)
        throw new IllegalArgumentException("PriorityThreadPoolExecutor must not be null.");
      if (this.c != null)
        throw new IllegalStateException("PriorityThreadPoolExecutor already set.");
      this.c = params;
      return this;
    }

    public a a(j<e> paramj)
    {
      if (paramj == null)
        throw new IllegalArgumentException("initializationCallback must not be null.");
      if (this.i != null)
        throw new IllegalStateException("initializationCallback already set.");
      this.i = paramj;
      return this;
    }

    public a a(q paramq)
    {
      if (paramq == null)
        throw new IllegalArgumentException("Logger must not be null.");
      if (this.e != null)
        throw new IllegalStateException("Logger already set.");
      this.e = paramq;
      return this;
    }

    @Deprecated
    public a a(Handler paramHandler)
    {
      return this;
    }

    public a a(String paramString)
    {
      if (paramString == null)
        throw new IllegalArgumentException("appIdentifier must not be null.");
      if (this.h != null)
        throw new IllegalStateException("appIdentifier already set.");
      this.h = paramString;
      return this;
    }

    @Deprecated
    public a a(ExecutorService paramExecutorService)
    {
      return this;
    }

    public a a(boolean paramBoolean)
    {
      this.f = paramBoolean;
      return this;
    }

    public a a(n[] paramArrayOfn)
    {
      if (this.b != null)
        throw new IllegalStateException("Kits already set.");
      this.b = paramArrayOfn;
      return this;
    }

    public e a()
    {
      if (this.c == null)
        this.c = s.a();
      if (this.d == null)
        this.d = new Handler(Looper.getMainLooper());
      if (this.e == null)
      {
        if (this.f)
          this.e = new d(3);
      }
      else
      {
        if (this.h == null)
          this.h = this.a.getPackageName();
        if (this.i == null)
          this.i = j.d;
        if (this.b != null)
          break label191;
      }
      label191: for (Object localObject = new HashMap(); ; localObject = e.a(Arrays.asList(this.b)))
      {
        Context localContext = this.a.getApplicationContext();
        v localv = new v(localContext, this.h, this.g, ((Map)localObject).values());
        return new e(localContext, (Map)localObject, this.c, this.d, this.e, this.f, this.i, localv, e.c(this.a));
        this.e = new d();
        break;
      }
    }

    public a b(String paramString)
    {
      if (paramString == null)
        throw new IllegalArgumentException("appInstallIdentifier must not be null.");
      if (this.g != null)
        throw new IllegalStateException("appInstallIdentifier already set.");
      this.g = paramString;
      return this;
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.e
 * JD-Core Version:    0.6.2
 */