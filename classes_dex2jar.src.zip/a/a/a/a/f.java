package a.a.a.a;

import android.app.Activity;
import android.os.Bundle;

class f extends a.b
{
  f(e parame)
  {
  }

  public void a(Activity paramActivity)
  {
    this.a.a(paramActivity);
  }

  public void a(Activity paramActivity, Bundle paramBundle)
  {
    this.a.a(paramActivity);
  }

  public void b(Activity paramActivity)
  {
    this.a.a(paramActivity);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.f
 * JD-Core Version:    0.6.2
 */