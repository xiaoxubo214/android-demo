package a.a.a.a;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicBoolean;

class g
  implements j
{
  final CountDownLatch a = new CountDownLatch(this.b);

  g(e parame, int paramInt)
  {
  }

  public void a(Exception paramException)
  {
    e.c(this.c).a(paramException);
  }

  public void a(Object paramObject)
  {
    this.a.countDown();
    if (this.a.getCount() == 0L)
    {
      e.b(this.c).set(true);
      e.c(this.c).a(this.c);
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.g
 * JD-Core Version:    0.6.2
 */