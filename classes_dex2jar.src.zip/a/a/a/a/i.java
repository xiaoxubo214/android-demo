package a.a.a.a;

import android.os.SystemClock;
import java.io.IOException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

class i
  implements Callable<Map<String, p>>
{
  static final String a = "fabric/";
  private static final String c = "fabric-identifier";
  private static final String d = "fabric-version";
  private static final String e = "fabric-build-type";
  final String b;

  i(String paramString)
  {
    this.b = paramString;
  }

  // ERROR //
  private p a(ZipEntry paramZipEntry, ZipFile paramZipFile)
  {
    // Byte code:
    //   0: aload_2
    //   1: aload_1
    //   2: invokevirtual 37	java/util/zip/ZipFile:getInputStream	(Ljava/util/zip/ZipEntry;)Ljava/io/InputStream;
    //   5: astore 6
    //   7: aload 6
    //   9: astore 4
    //   11: new 39	java/util/Properties
    //   14: dup
    //   15: invokespecial 40	java/util/Properties:<init>	()V
    //   18: astore 7
    //   20: aload 7
    //   22: aload 4
    //   24: invokevirtual 44	java/util/Properties:load	(Ljava/io/InputStream;)V
    //   27: aload 7
    //   29: ldc 14
    //   31: invokevirtual 48	java/util/Properties:getProperty	(Ljava/lang/String;)Ljava/lang/String;
    //   34: astore 8
    //   36: aload 7
    //   38: ldc 17
    //   40: invokevirtual 48	java/util/Properties:getProperty	(Ljava/lang/String;)Ljava/lang/String;
    //   43: astore 9
    //   45: aload 7
    //   47: ldc 20
    //   49: invokevirtual 48	java/util/Properties:getProperty	(Ljava/lang/String;)Ljava/lang/String;
    //   52: astore 10
    //   54: aload 8
    //   56: invokestatic 54	android/text/TextUtils:isEmpty	(Ljava/lang/CharSequence;)Z
    //   59: ifne +11 -> 70
    //   62: aload 9
    //   64: invokestatic 54	android/text/TextUtils:isEmpty	(Ljava/lang/CharSequence;)Z
    //   67: ifeq +74 -> 141
    //   70: new 56	java/lang/IllegalStateException
    //   73: dup
    //   74: new 58	java/lang/StringBuilder
    //   77: dup
    //   78: invokespecial 59	java/lang/StringBuilder:<init>	()V
    //   81: ldc 61
    //   83: invokevirtual 65	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   86: aload_1
    //   87: invokevirtual 71	java/util/zip/ZipEntry:getName	()Ljava/lang/String;
    //   90: invokevirtual 65	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   93: invokevirtual 74	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   96: invokespecial 76	java/lang/IllegalStateException:<init>	(Ljava/lang/String;)V
    //   99: athrow
    //   100: astore_3
    //   101: invokestatic 82	a/a/a/a/e:i	()La/a/a/a/q;
    //   104: ldc 84
    //   106: new 58	java/lang/StringBuilder
    //   109: dup
    //   110: invokespecial 59	java/lang/StringBuilder:<init>	()V
    //   113: ldc 86
    //   115: invokevirtual 65	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   118: aload_1
    //   119: invokevirtual 71	java/util/zip/ZipEntry:getName	()Ljava/lang/String;
    //   122: invokevirtual 65	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   125: invokevirtual 74	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   128: aload_3
    //   129: invokeinterface 91 4 0
    //   134: aload 4
    //   136: invokestatic 96	a/a/a/a/a/b/k:a	(Ljava/io/Closeable;)V
    //   139: aconst_null
    //   140: areturn
    //   141: new 98	a/a/a/a/p
    //   144: dup
    //   145: aload 8
    //   147: aload 9
    //   149: aload 10
    //   151: invokespecial 101	a/a/a/a/p:<init>	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    //   154: astore 11
    //   156: aload 4
    //   158: invokestatic 96	a/a/a/a/a/b/k:a	(Ljava/io/Closeable;)V
    //   161: aload 11
    //   163: areturn
    //   164: astore 5
    //   166: aconst_null
    //   167: astore 4
    //   169: aload 4
    //   171: invokestatic 96	a/a/a/a/a/b/k:a	(Ljava/io/Closeable;)V
    //   174: aload 5
    //   176: athrow
    //   177: astore 5
    //   179: goto -10 -> 169
    //   182: astore_3
    //   183: aconst_null
    //   184: astore 4
    //   186: goto -85 -> 101
    //
    // Exception table:
    //   from	to	target	type
    //   11	70	100	java/io/IOException
    //   70	100	100	java/io/IOException
    //   141	156	100	java/io/IOException
    //   0	7	164	finally
    //   11	70	177	finally
    //   70	100	177	finally
    //   101	134	177	finally
    //   141	156	177	finally
    //   0	7	182	java/io/IOException
  }

  private Map<String, p> c()
  {
    HashMap localHashMap = new HashMap();
    try
    {
      Class.forName("com.google.android.gms.ads.AdView");
      p localp = new p("com.google.firebase.firebase-ads", "0.0.0", "binary");
      localHashMap.put(localp.a(), localp);
      e.i().b("Fabric", "Found kit: com.google.firebase.firebase-ads");
      return localHashMap;
    }
    catch (Exception localException)
    {
    }
    return localHashMap;
  }

  private Map<String, p> d()
    throws Exception
  {
    HashMap localHashMap = new HashMap();
    ZipFile localZipFile = b();
    Enumeration localEnumeration = localZipFile.entries();
    while (localEnumeration.hasMoreElements())
    {
      ZipEntry localZipEntry = (ZipEntry)localEnumeration.nextElement();
      if ((localZipEntry.getName().startsWith("fabric/")) && (localZipEntry.getName().length() > "fabric/".length()))
      {
        p localp = a(localZipEntry, localZipFile);
        if (localp != null)
        {
          localHashMap.put(localp.a(), localp);
          q localq = e.i();
          Object[] arrayOfObject = new Object[2];
          arrayOfObject[0] = localp.a();
          arrayOfObject[1] = localp.b();
          localq.b("Fabric", String.format("Found kit:[%s] version:[%s]", arrayOfObject));
        }
      }
    }
    if (localZipFile != null);
    try
    {
      localZipFile.close();
      return localHashMap;
    }
    catch (IOException localIOException)
    {
    }
    return localHashMap;
  }

  public Map<String, p> a()
    throws Exception
  {
    HashMap localHashMap = new HashMap();
    long l = SystemClock.elapsedRealtime();
    localHashMap.putAll(c());
    localHashMap.putAll(d());
    e.i().b("Fabric", "finish scanning in " + (SystemClock.elapsedRealtime() - l));
    return localHashMap;
  }

  protected ZipFile b()
    throws IOException
  {
    return new ZipFile(this.b);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.i
 * JD-Core Version:    0.6.2
 */