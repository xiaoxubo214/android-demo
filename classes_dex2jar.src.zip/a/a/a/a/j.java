package a.a.a.a;

public abstract interface j<T>
{
  public static final j d = new a(null);

  public abstract void a(Exception paramException);

  public abstract void a(T paramT);

  public static class a
    implements j<Object>
  {
    public void a(Exception paramException)
    {
    }

    public void a(Object paramObject)
    {
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.j
 * JD-Core Version:    0.6.2
 */