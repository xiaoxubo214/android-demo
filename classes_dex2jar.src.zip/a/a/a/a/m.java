package a.a.a.a;

import a.a.a.a.a.b.ae;
import a.a.a.a.a.c.k;

class m<Result> extends a.a.a.a.a.c.l<Void, Void, Result>
{
  private static final String d = "KitInitialization";
  final n<Result> a;

  public m(n<Result> paramn)
  {
    this.a = paramn;
  }

  private ae a(String paramString)
  {
    ae localae = new ae(this.a.b() + "." + paramString, "KitInitialization");
    localae.a();
    return localae;
  }

  protected Result a(Void[] paramArrayOfVoid)
  {
    ae localae = a("doInBackground");
    boolean bool = f();
    Object localObject = null;
    if (!bool)
      localObject = this.a.i();
    localae.b();
    return localObject;
  }

  // ERROR //
  protected void a()
  {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial 70	a/a/a/a/a/c/l:a	()V
    //   4: aload_0
    //   5: ldc 72
    //   7: invokespecial 55	a/a/a/a/m:a	(Ljava/lang/String;)La/a/a/a/a/b/ae;
    //   10: astore_1
    //   11: aload_0
    //   12: getfield 19	a/a/a/a/m:a	La/a/a/a/n;
    //   15: invokevirtual 75	a/a/a/a/n:d_	()Z
    //   18: istore 7
    //   20: aload_1
    //   21: invokevirtual 65	a/a/a/a/a/b/ae:b	()V
    //   24: iload 7
    //   26: ifne +9 -> 35
    //   29: aload_0
    //   30: iconst_1
    //   31: invokevirtual 78	a/a/a/a/m:a	(Z)Z
    //   34: pop
    //   35: return
    //   36: astore 6
    //   38: aload 6
    //   40: athrow
    //   41: astore 4
    //   43: aload_1
    //   44: invokevirtual 65	a/a/a/a/a/b/ae:b	()V
    //   47: aload_0
    //   48: iconst_1
    //   49: invokevirtual 78	a/a/a/a/m:a	(Z)Z
    //   52: pop
    //   53: aload 4
    //   55: athrow
    //   56: astore_2
    //   57: invokestatic 83	a/a/a/a/e:i	()La/a/a/a/q;
    //   60: ldc 85
    //   62: ldc 87
    //   64: aload_2
    //   65: invokeinterface 93 4 0
    //   70: aload_1
    //   71: invokevirtual 65	a/a/a/a/a/b/ae:b	()V
    //   74: aload_0
    //   75: iconst_1
    //   76: invokevirtual 78	a/a/a/a/m:a	(Z)Z
    //   79: pop
    //   80: return
    //
    // Exception table:
    //   from	to	target	type
    //   11	20	36	a/a/a/a/a/c/u
    //   11	20	41	finally
    //   38	41	41	finally
    //   57	70	41	finally
    //   11	20	56	java/lang/Exception
  }

  protected void a(Result paramResult)
  {
    this.a.a(paramResult);
    this.a.l.a(paramResult);
  }

  public k b()
  {
    return k.c;
  }

  protected void b(Result paramResult)
  {
    this.a.b(paramResult);
    l locall = new l(this.a.b() + " Initialization was cancelled");
    this.a.l.a(locall);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.m
 * JD-Core Version:    0.6.2
 */