package a.a.a.a;

import a.a.a.a.a.b.v;
import a.a.a.a.a.c.t;
import android.content.Context;
import java.io.File;
import java.util.Collection;
import java.util.concurrent.ExecutorService;

public abstract class n<Result>
  implements Comparable<n>
{
  e i;
  m<Result> j = new m(this);
  Context k;
  j<Result> l;
  v m;
  final a.a.a.a.a.c.j n = (a.a.a.a.a.c.j)getClass().getAnnotation(a.a.a.a.a.c.j.class);

  public int a(n paramn)
  {
    if (b(paramn));
    do
    {
      return 1;
      if (paramn.b(this))
        return -1;
    }
    while ((x()) && (!paramn.x()));
    if ((!x()) && (paramn.x()))
      return -1;
    return 0;
  }

  public abstract String a();

  void a(Context paramContext, e parame, j<Result> paramj, v paramv)
  {
    this.i = parame;
    this.k = new h(paramContext, b(), w());
    this.l = paramj;
    this.m = paramv;
  }

  protected void a(Result paramResult)
  {
  }

  public abstract String b();

  protected void b(Result paramResult)
  {
  }

  boolean b(n paramn)
  {
    boolean bool1 = x();
    boolean bool2 = false;
    Class[] arrayOfClass;
    int i1;
    if (bool1)
    {
      arrayOfClass = this.n.a();
      i1 = arrayOfClass.length;
    }
    for (int i2 = 0; ; i2++)
    {
      bool2 = false;
      if (i2 < i1)
      {
        if (arrayOfClass[i2].isAssignableFrom(paramn.getClass()))
          bool2 = true;
      }
      else
        return bool2;
    }
  }

  protected boolean d_()
  {
    return true;
  }

  protected abstract Result i();

  final void s()
  {
    m localm = this.j;
    ExecutorService localExecutorService = this.i.f();
    Void[] arrayOfVoid = new Void[1];
    arrayOfVoid[0] = ((Void)null);
    localm.a(localExecutorService, arrayOfVoid);
  }

  protected v t()
  {
    return this.m;
  }

  public Context u()
  {
    return this.k;
  }

  public e v()
  {
    return this.i;
  }

  public String w()
  {
    return ".Fabric" + File.separator + b();
  }

  boolean x()
  {
    return this.n != null;
  }

  protected Collection<t> y()
  {
    return this.j.d();
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.n
 * JD-Core Version:    0.6.2
 */