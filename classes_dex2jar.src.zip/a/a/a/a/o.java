package a.a.a.a;

import java.util.Collection;

public abstract interface o
{
  public abstract Collection<? extends n> c();
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.o
 * JD-Core Version:    0.6.2
 */