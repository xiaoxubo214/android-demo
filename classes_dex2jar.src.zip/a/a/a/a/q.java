package a.a.a.a;

public abstract interface q
{
  public abstract int a();

  public abstract void a(int paramInt);

  public abstract void a(int paramInt, String paramString1, String paramString2);

  public abstract void a(int paramInt, String paramString1, String paramString2, boolean paramBoolean);

  public abstract void a(String paramString1, String paramString2);

  public abstract void a(String paramString1, String paramString2, Throwable paramThrowable);

  public abstract boolean a(String paramString, int paramInt);

  public abstract void b(String paramString1, String paramString2);

  public abstract void b(String paramString1, String paramString2, Throwable paramThrowable);

  public abstract void c(String paramString1, String paramString2);

  public abstract void c(String paramString1, String paramString2, Throwable paramThrowable);

  public abstract void d(String paramString1, String paramString2);

  public abstract void d(String paramString1, String paramString2, Throwable paramThrowable);

  public abstract void e(String paramString1, String paramString2);

  public abstract void e(String paramString1, String paramString2, Throwable paramThrowable);
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.q
 * JD-Core Version:    0.6.2
 */