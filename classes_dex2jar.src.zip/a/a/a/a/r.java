package a.a.a.a;

import a.a.a.a.a.b.k;
import a.a.a.a.a.e.b;
import a.a.a.a.a.g.aa;
import a.a.a.a.a.g.d;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.Future;

class r extends n<Boolean>
{
  static final String a = "com.crashlytics.ApiEndpoint";
  private static final String b = "binary";
  private final a.a.a.a.a.e.o c = new b();
  private PackageManager d;
  private String e;
  private PackageInfo f;
  private String g;
  private String h;
  private String o;
  private String p;
  private String q;
  private final Future<Map<String, p>> r;
  private final Collection<n> s;

  public r(Future<Map<String, p>> paramFuture, Collection<n> paramCollection)
  {
    this.r = paramFuture;
    this.s = paramCollection;
  }

  private d a(a.a.a.a.a.g.o paramo, Collection<p> paramCollection)
  {
    Context localContext = u();
    String str1 = new a.a.a.a.a.b.i().b(localContext);
    String str2 = k.a(new String[] { k.n(localContext) });
    int i = a.a.a.a.a.b.o.a(this.o).a();
    return new d(str1, t().c(), this.h, this.g, str2, this.p, i, this.q, "0", paramo, paramCollection);
  }

  private boolean a(a.a.a.a.a.g.e parame, a.a.a.a.a.g.o paramo, Collection<p> paramCollection)
  {
    d locald = a(paramo, paramCollection);
    return new aa(this, e(), parame.f, this.c).a(locald);
  }

  private boolean a(String paramString, a.a.a.a.a.g.e parame, Collection<p> paramCollection)
  {
    boolean bool = true;
    if ("new".equals(parame.e))
      if (b(paramString, parame, paramCollection))
        bool = a.a.a.a.a.g.r.a().e();
    do
    {
      return bool;
      e.i().e("Fabric", "Failed to create app with Crashlytics service.", null);
      return false;
      if ("configured".equals(parame.e))
        return a.a.a.a.a.g.r.a().e();
    }
    while (!parame.i);
    e.i().a("Fabric", "Server says an update is required - forcing a full App update.");
    c(paramString, parame, paramCollection);
    return bool;
  }

  private boolean b(String paramString, a.a.a.a.a.g.e parame, Collection<p> paramCollection)
  {
    d locald = a(a.a.a.a.a.g.o.a(u(), paramString), paramCollection);
    return new a.a.a.a.a.g.i(this, e(), parame.f, this.c).a(locald);
  }

  private boolean c(String paramString, a.a.a.a.a.g.e parame, Collection<p> paramCollection)
  {
    return a(parame, a.a.a.a.a.g.o.a(u(), paramString), paramCollection);
  }

  private a.a.a.a.a.g.v f()
  {
    try
    {
      a.a.a.a.a.g.r.a().a(this, this.m, this.c, this.g, this.h, e()).d();
      a.a.a.a.a.g.v localv = a.a.a.a.a.g.r.a().c();
      return localv;
    }
    catch (Exception localException)
    {
      e.i().e("Fabric", "Error dealing with settings", localException);
    }
    return null;
  }

  public String a()
  {
    return "1.4.1.19";
  }

  Map<String, p> a(Map<String, p> paramMap, Collection<n> paramCollection)
  {
    Iterator localIterator = paramCollection.iterator();
    while (localIterator.hasNext())
    {
      n localn = (n)localIterator.next();
      if (!paramMap.containsKey(localn.b()))
        paramMap.put(localn.b(), new p(localn.b(), localn.a(), "binary"));
    }
    return paramMap;
  }

  public String b()
  {
    return "io.fabric.sdk.android:fabric";
  }

  protected Boolean c()
  {
    String str = k.l(u());
    a.a.a.a.a.g.v localv = f();
    if (localv != null);
    while (true)
    {
      try
      {
        if (this.r != null)
        {
          localObject = (Map)this.r.get();
          Map localMap = a((Map)localObject, this.s);
          boolean bool2 = a(str, localv.a, localMap.values());
          bool1 = bool2;
          return Boolean.valueOf(bool1);
        }
        Object localObject = new HashMap();
        continue;
      }
      catch (Exception localException)
      {
        e.i().e("Fabric", "Error performing auto configuration.", localException);
      }
      boolean bool1 = false;
    }
  }

  protected boolean d_()
  {
    try
    {
      this.o = t().i();
      this.d = u().getPackageManager();
      this.e = u().getPackageName();
      this.f = this.d.getPackageInfo(this.e, 0);
      this.g = Integer.toString(this.f.versionCode);
      if (this.f.versionName == null);
      for (String str = "0.0"; ; str = this.f.versionName)
      {
        this.h = str;
        this.p = this.d.getApplicationLabel(u().getApplicationInfo()).toString();
        this.q = Integer.toString(u().getApplicationInfo().targetSdkVersion);
        return true;
      }
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException)
    {
      e.i().e("Fabric", "Failed init", localNameNotFoundException);
    }
    return false;
  }

  String e()
  {
    return k.b(u(), "com.crashlytics.ApiEndpoint");
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.r
 * JD-Core Version:    0.6.2
 */