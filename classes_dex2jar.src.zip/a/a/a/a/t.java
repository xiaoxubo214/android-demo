package a.a.a.a;

public class t
  implements q
{
  private int a = 7;

  public int a()
  {
    return this.a;
  }

  public void a(int paramInt)
  {
  }

  public void a(int paramInt, String paramString1, String paramString2)
  {
  }

  public void a(int paramInt, String paramString1, String paramString2, boolean paramBoolean)
  {
  }

  public void a(String paramString1, String paramString2)
  {
  }

  public void a(String paramString1, String paramString2, Throwable paramThrowable)
  {
  }

  public boolean a(String paramString, int paramInt)
  {
    return false;
  }

  public void b(String paramString1, String paramString2)
  {
  }

  public void b(String paramString1, String paramString2, Throwable paramThrowable)
  {
  }

  public void c(String paramString1, String paramString2)
  {
  }

  public void c(String paramString1, String paramString2, Throwable paramThrowable)
  {
  }

  public void d(String paramString1, String paramString2)
  {
  }

  public void d(String paramString1, String paramString2, Throwable paramThrowable)
  {
  }

  public void e(String paramString1, String paramString2)
  {
  }

  public void e(String paramString1, String paramString2, Throwable paramThrowable)
  {
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.t
 * JD-Core Version:    0.6.2
 */