package android.support.a.a;

class a
{
  static final int A = 8;
  static final int B = 9;
  static final int C = 10;
  static final int D = 4;
  static final int E = 6;
  static final int F = 7;
  static final int G = 5;
  static final int[] H = { 16842755, 16843781 };
  static final int I = 0;
  static final int J = 1;
  static final int[] K = { 16843161 };
  static final int L = 0;
  static final int[] M = { 16842755, 16843213 };
  static final int N = 1;
  static final int O = 0;
  static final int[] a = { 16842755, 16843041, 16843093, 16843097, 16843551, 16843754, 16843134, 16843778, 16843779 };
  static final int b = 4;
  static final int c = 5;
  static final int d = 2;
  static final int e = 0;
  static final int f = 1;
  static final int g = 6;
  static final int h = 8;
  static final int i = 7;
  static final int j = 3;
  static final int[] k = { 16842755, 16843189, 16843190, 16843556, 16843557, 16843558, 16843866, 16843867 };
  static final int l = 0;
  static final int m = 1;
  static final int n = 2;
  static final int o = 5;
  static final int p = 3;
  static final int q = 4;
  static final int r = 6;
  static final int s = 7;
  static final int[] t = { 16842755, 16843780, 16843781, 16843782, 16843783, 16843784, 16843785, 16843786, 16843787, 16843788, 16843789, 16843979, 16843980 };
  static final int u = 12;
  static final int v = 1;
  static final int w = 0;
  static final int x = 2;
  static final int y = 11;
  static final int z = 3;
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.a.a.a
 * JD-Core Version:    0.6.2
 */