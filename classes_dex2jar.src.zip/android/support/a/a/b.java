package android.support.a.a;

import android.animation.Animator;
import android.animation.AnimatorInflater;
import android.animation.AnimatorSet;
import android.animation.ArgbEvaluator;
import android.animation.ObjectAnimator;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.Resources.Theme;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff.Mode;
import android.graphics.Rect;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.AnimatedVectorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Drawable.Callback;
import android.graphics.drawable.Drawable.ConstantState;
import android.os.Build.VERSION;
import android.support.annotation.m;
import android.support.annotation.x;
import android.support.annotation.y;
import android.util.AttributeSet;
import android.util.Log;
import android.util.Xml;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

@TargetApi(21)
public class b extends h
  implements Animatable
{
  private static final String c = "AnimatedVDCompat";
  private static final String d = "animated-vector";
  private static final String e = "target";
  private static final boolean f;
  b a;
  private a g;
  private Context h;
  private ArgbEvaluator i = null;
  private final Drawable.Callback j = new c(this);

  private b()
  {
    this(null, null, null);
  }

  private b(@y Context paramContext)
  {
    this(paramContext, null, null);
  }

  private b(@y Context paramContext, @y a parama, @y Resources paramResources)
  {
    this.h = paramContext;
    if (parama != null)
    {
      this.g = parama;
      return;
    }
    this.g = new a(paramContext, parama, this.j, paramResources);
  }

  static TypedArray a(Resources paramResources, Resources.Theme paramTheme, AttributeSet paramAttributeSet, int[] paramArrayOfInt)
  {
    if (paramTheme == null)
      return paramResources.obtainAttributes(paramAttributeSet, paramArrayOfInt);
    return paramTheme.obtainStyledAttributes(paramAttributeSet, paramArrayOfInt, 0, 0);
  }

  @y
  public static b a(@x Context paramContext, @m int paramInt)
  {
    if (Build.VERSION.SDK_INT >= 21)
    {
      b localb1 = new b(paramContext);
      localb1.b = android.support.v4.c.b.a.a(paramContext.getResources(), paramInt, paramContext.getTheme());
      localb1.b.setCallback(localb1.j);
      localb1.a = new b(localb1.b.getConstantState());
      return localb1;
    }
    Resources localResources = paramContext.getResources();
    try
    {
      localXmlResourceParser = localResources.getXml(paramInt);
      localAttributeSet = Xml.asAttributeSet(localXmlResourceParser);
      int k;
      do
        k = localXmlResourceParser.next();
      while ((k != 2) && (k != 1));
      if (k != 2)
        throw new XmlPullParserException("No start tag found");
    }
    catch (XmlPullParserException localXmlPullParserException)
    {
      XmlResourceParser localXmlResourceParser;
      AttributeSet localAttributeSet;
      Log.e("AnimatedVDCompat", "parser error", localXmlPullParserException);
      return null;
      b localb2 = a(paramContext, paramContext.getResources(), localXmlResourceParser, localAttributeSet, paramContext.getTheme());
      return localb2;
    }
    catch (IOException localIOException)
    {
      while (true)
        Log.e("AnimatedVDCompat", "parser error", localIOException);
    }
  }

  public static b a(Context paramContext, Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme)
    throws XmlPullParserException, IOException
  {
    b localb = new b(paramContext);
    localb.inflate(paramResources, paramXmlPullParser, paramAttributeSet, paramTheme);
    return localb;
  }

  private void a(Animator paramAnimator)
  {
    if ((paramAnimator instanceof AnimatorSet))
    {
      ArrayList localArrayList = ((AnimatorSet)paramAnimator).getChildAnimations();
      if (localArrayList != null)
        for (int k = 0; k < localArrayList.size(); k++)
          a((Animator)localArrayList.get(k));
    }
    if ((paramAnimator instanceof ObjectAnimator))
    {
      ObjectAnimator localObjectAnimator = (ObjectAnimator)paramAnimator;
      String str = localObjectAnimator.getPropertyName();
      if (("fillColor".equals(str)) || ("strokeColor".equals(str)))
      {
        if (this.i == null)
          this.i = new ArgbEvaluator();
        localObjectAnimator.setEvaluator(this.i);
      }
    }
  }

  private void a(String paramString, Animator paramAnimator)
  {
    paramAnimator.setTarget(this.g.b.a(paramString));
    if (Build.VERSION.SDK_INT < 21)
      a(paramAnimator);
    if (this.g.c == null)
    {
      this.g.c = new ArrayList();
      this.g.d = new android.support.v4.m.a();
    }
    this.g.c.add(paramAnimator);
    this.g.d.put(paramAnimator, paramString);
  }

  private boolean a()
  {
    ArrayList localArrayList = this.g.c;
    if (localArrayList == null)
      return false;
    int k = localArrayList.size();
    for (int m = 0; m < k; m++)
      if (((Animator)localArrayList.get(m)).isRunning())
        return true;
    return false;
  }

  public void applyTheme(Resources.Theme paramTheme)
  {
    if (this.b != null)
      android.support.v4.e.a.a.a(this.b, paramTheme);
  }

  public boolean canApplyTheme()
  {
    if (this.b != null)
      return android.support.v4.e.a.a.d(this.b);
    return false;
  }

  public void draw(Canvas paramCanvas)
  {
    if (this.b != null)
      this.b.draw(paramCanvas);
    do
    {
      return;
      this.g.b.draw(paramCanvas);
    }
    while (!a());
    invalidateSelf();
  }

  public int getAlpha()
  {
    if (this.b != null)
      return android.support.v4.e.a.a.c(this.b);
    return this.g.b.getAlpha();
  }

  public int getChangingConfigurations()
  {
    if (this.b != null)
      return this.b.getChangingConfigurations();
    return super.getChangingConfigurations() | this.g.a;
  }

  public Drawable.ConstantState getConstantState()
  {
    if (this.b != null)
      return new b(this.b.getConstantState());
    return null;
  }

  public int getIntrinsicHeight()
  {
    if (this.b != null)
      return this.b.getIntrinsicHeight();
    return this.g.b.getIntrinsicHeight();
  }

  public int getIntrinsicWidth()
  {
    if (this.b != null)
      return this.b.getIntrinsicWidth();
    return this.g.b.getIntrinsicWidth();
  }

  public int getOpacity()
  {
    if (this.b != null)
      return this.b.getOpacity();
    return this.g.b.getOpacity();
  }

  public void inflate(Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet)
    throws XmlPullParserException, IOException
  {
    inflate(paramResources, paramXmlPullParser, paramAttributeSet, null);
  }

  public void inflate(Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme)
    throws XmlPullParserException, IOException
  {
    if (this.b != null)
    {
      android.support.v4.e.a.a.a(this.b, paramResources, paramXmlPullParser, paramAttributeSet, paramTheme);
      return;
    }
    int k = paramXmlPullParser.getEventType();
    label28: String str1;
    if (k != 1)
      if (k == 2)
      {
        str1 = paramXmlPullParser.getName();
        if (!"animated-vector".equals(str1))
          break label155;
        TypedArray localTypedArray2 = a(paramResources, paramTheme, paramAttributeSet, a.K);
        int n = localTypedArray2.getResourceId(0, 0);
        if (n != 0)
        {
          i locali = i.a(paramResources, n, paramTheme);
          locali.a(false);
          locali.setCallback(this.j);
          if (this.g.b != null)
            this.g.b.setCallback(null);
          this.g.b = locali;
        }
        localTypedArray2.recycle();
      }
    while (true)
    {
      k = paramXmlPullParser.next();
      break label28;
      break;
      label155: if ("target".equals(str1))
      {
        TypedArray localTypedArray1 = paramResources.obtainAttributes(paramAttributeSet, a.M);
        String str2 = localTypedArray1.getString(0);
        int m = localTypedArray1.getResourceId(1, 0);
        if (m != 0)
        {
          if (this.h == null)
            break label227;
          a(str2, AnimatorInflater.loadAnimator(this.h, m));
        }
        localTypedArray1.recycle();
      }
    }
    label227: throw new IllegalStateException("Context can't be null when inflating animators");
  }

  public boolean isRunning()
  {
    if (this.b != null)
      return ((AnimatedVectorDrawable)this.b).isRunning();
    ArrayList localArrayList = this.g.c;
    int k = localArrayList.size();
    for (int m = 0; m < k; m++)
      if (((Animator)localArrayList.get(m)).isRunning())
        return true;
    return false;
  }

  public boolean isStateful()
  {
    if (this.b != null)
      return this.b.isStateful();
    return this.g.b.isStateful();
  }

  public Drawable mutate()
  {
    if (this.b != null)
    {
      this.b.mutate();
      return this;
    }
    throw new IllegalStateException("Mutate() is not supported for older platform");
  }

  protected void onBoundsChange(Rect paramRect)
  {
    if (this.b != null)
    {
      this.b.setBounds(paramRect);
      return;
    }
    this.g.b.setBounds(paramRect);
  }

  protected boolean onLevelChange(int paramInt)
  {
    if (this.b != null)
      return this.b.setLevel(paramInt);
    return this.g.b.setLevel(paramInt);
  }

  protected boolean onStateChange(int[] paramArrayOfInt)
  {
    if (this.b != null)
      return this.b.setState(paramArrayOfInt);
    return this.g.b.setState(paramArrayOfInt);
  }

  public void setAlpha(int paramInt)
  {
    if (this.b != null)
    {
      this.b.setAlpha(paramInt);
      return;
    }
    this.g.b.setAlpha(paramInt);
  }

  public void setColorFilter(ColorFilter paramColorFilter)
  {
    if (this.b != null)
    {
      this.b.setColorFilter(paramColorFilter);
      return;
    }
    this.g.b.setColorFilter(paramColorFilter);
  }

  public void setTint(int paramInt)
  {
    if (this.b != null)
    {
      android.support.v4.e.a.a.a(this.b, paramInt);
      return;
    }
    this.g.b.setTint(paramInt);
  }

  public void setTintList(ColorStateList paramColorStateList)
  {
    if (this.b != null)
    {
      android.support.v4.e.a.a.a(this.b, paramColorStateList);
      return;
    }
    this.g.b.setTintList(paramColorStateList);
  }

  public void setTintMode(PorterDuff.Mode paramMode)
  {
    if (this.b != null)
    {
      android.support.v4.e.a.a.a(this.b, paramMode);
      return;
    }
    this.g.b.setTintMode(paramMode);
  }

  public boolean setVisible(boolean paramBoolean1, boolean paramBoolean2)
  {
    if (this.b != null)
      return this.b.setVisible(paramBoolean1, paramBoolean2);
    this.g.b.setVisible(paramBoolean1, paramBoolean2);
    return super.setVisible(paramBoolean1, paramBoolean2);
  }

  public void start()
  {
    if (this.b != null)
      ((AnimatedVectorDrawable)this.b).start();
    while (a())
      return;
    ArrayList localArrayList = this.g.c;
    int k = localArrayList.size();
    for (int m = 0; m < k; m++)
      ((Animator)localArrayList.get(m)).start();
    invalidateSelf();
  }

  public void stop()
  {
    if (this.b != null)
      ((AnimatedVectorDrawable)this.b).stop();
    while (true)
    {
      return;
      ArrayList localArrayList = this.g.c;
      int k = localArrayList.size();
      for (int m = 0; m < k; m++)
        ((Animator)localArrayList.get(m)).end();
    }
  }

  private static class a extends Drawable.ConstantState
  {
    int a;
    i b;
    ArrayList<Animator> c;
    android.support.v4.m.a<Animator, String> d;

    public a(Context paramContext, a parama, Drawable.Callback paramCallback, Resources paramResources)
    {
      if (parama != null)
      {
        this.a = parama.a;
        Drawable.ConstantState localConstantState;
        if (parama.b != null)
        {
          localConstantState = parama.b.getConstantState();
          if (paramResources == null)
            break label224;
        }
        label224: for (this.b = ((i)localConstantState.newDrawable(paramResources)); ; this.b = ((i)localConstantState.newDrawable()))
        {
          this.b = ((i)this.b.mutate());
          this.b.setCallback(paramCallback);
          this.b.setBounds(parama.b.getBounds());
          this.b.a(false);
          if (parama.c == null)
            break;
          int j = parama.c.size();
          this.c = new ArrayList(j);
          this.d = new android.support.v4.m.a(j);
          while (i < j)
          {
            Animator localAnimator1 = (Animator)parama.c.get(i);
            Animator localAnimator2 = localAnimator1.clone();
            String str = (String)parama.d.get(localAnimator1);
            localAnimator2.setTarget(this.b.a(str));
            this.c.add(localAnimator2);
            this.d.put(localAnimator2, str);
            i++;
          }
        }
      }
    }

    public int getChangingConfigurations()
    {
      return this.a;
    }

    public Drawable newDrawable()
    {
      throw new IllegalStateException("No constant state support for SDK < 21.");
    }

    public Drawable newDrawable(Resources paramResources)
    {
      throw new IllegalStateException("No constant state support for SDK < 21.");
    }
  }

  private static class b extends Drawable.ConstantState
  {
    private final Drawable.ConstantState a;

    public b(Drawable.ConstantState paramConstantState)
    {
      this.a = paramConstantState;
    }

    public boolean canApplyTheme()
    {
      return this.a.canApplyTheme();
    }

    public int getChangingConfigurations()
    {
      return this.a.getChangingConfigurations();
    }

    public Drawable newDrawable()
    {
      b localb = new b(null);
      localb.b = this.a.newDrawable();
      localb.b.setCallback(b.a(localb));
      return localb;
    }

    public Drawable newDrawable(Resources paramResources)
    {
      b localb = new b(null);
      localb.b = this.a.newDrawable(paramResources);
      localb.b.setCallback(b.a(localb));
      return localb;
    }

    public Drawable newDrawable(Resources paramResources, Resources.Theme paramTheme)
    {
      b localb = new b(null);
      localb.b = this.a.newDrawable(paramResources, paramTheme);
      localb.b.setCallback(b.a(localb));
      return localb;
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.a.a.b
 * JD-Core Version:    0.6.2
 */