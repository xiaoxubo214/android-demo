package android.support.v4.a;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.pm.ResolveInfo;
import android.os.Build.VERSION;

public final class a
{
  public static final int a = 1;
  public static final int b = 2;
  public static final int c = 4;
  public static final int d = 8;
  public static final int e = 32;
  public static final int f = -1;
  public static final int g = 1;
  public static final int h = 2;
  public static final int i = 4;
  public static final int j = 8;
  public static final int k = 16;
  public static final int l = 32;
  private static final d m = new c();

  static
  {
    if (Build.VERSION.SDK_INT >= 18)
    {
      m = new b();
      return;
    }
    if (Build.VERSION.SDK_INT >= 14)
    {
      m = new a();
      return;
    }
  }

  public static String a(int paramInt)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("[");
    while (paramInt > 0)
    {
      int n = 1 << Integer.numberOfTrailingZeros(paramInt);
      paramInt &= (n ^ 0xFFFFFFFF);
      if (localStringBuilder.length() > 1)
        localStringBuilder.append(", ");
      switch (n)
      {
      default:
        break;
      case 1:
        localStringBuilder.append("FEEDBACK_SPOKEN");
        break;
      case 4:
        localStringBuilder.append("FEEDBACK_AUDIBLE");
        break;
      case 2:
        localStringBuilder.append("FEEDBACK_HAPTIC");
        break;
      case 16:
        localStringBuilder.append("FEEDBACK_GENERIC");
        break;
      case 8:
        localStringBuilder.append("FEEDBACK_VISUAL");
      }
    }
    localStringBuilder.append("]");
    return localStringBuilder.toString();
  }

  public static String a(AccessibilityServiceInfo paramAccessibilityServiceInfo)
  {
    return m.c(paramAccessibilityServiceInfo);
  }

  public static ResolveInfo b(AccessibilityServiceInfo paramAccessibilityServiceInfo)
  {
    return m.d(paramAccessibilityServiceInfo);
  }

  public static String b(int paramInt)
  {
    switch (paramInt)
    {
    default:
      return null;
    case 1:
      return "DEFAULT";
    case 2:
      return "FLAG_INCLUDE_NOT_IMPORTANT_VIEWS";
    case 4:
      return "FLAG_REQUEST_TOUCH_EXPLORATION_MODE";
    case 8:
      return "FLAG_REQUEST_ENHANCED_WEB_ACCESSIBILITY";
    case 16:
      return "FLAG_REPORT_VIEW_IDS";
    case 32:
    }
    return "FLAG_REQUEST_FILTER_KEY_EVENTS";
  }

  public static String c(int paramInt)
  {
    switch (paramInt)
    {
    case 3:
    case 5:
    case 6:
    case 7:
    default:
      return "UNKNOWN";
    case 1:
      return "CAPABILITY_CAN_RETRIEVE_WINDOW_CONTENT";
    case 2:
      return "CAPABILITY_CAN_REQUEST_TOUCH_EXPLORATION";
    case 4:
      return "CAPABILITY_CAN_REQUEST_ENHANCED_WEB_ACCESSIBILITY";
    case 8:
    }
    return "CAPABILITY_CAN_FILTER_KEY_EVENTS";
  }

  public static String c(AccessibilityServiceInfo paramAccessibilityServiceInfo)
  {
    return m.e(paramAccessibilityServiceInfo);
  }

  public static boolean d(AccessibilityServiceInfo paramAccessibilityServiceInfo)
  {
    return m.a(paramAccessibilityServiceInfo);
  }

  public static String e(AccessibilityServiceInfo paramAccessibilityServiceInfo)
  {
    return m.b(paramAccessibilityServiceInfo);
  }

  public static int f(AccessibilityServiceInfo paramAccessibilityServiceInfo)
  {
    return m.f(paramAccessibilityServiceInfo);
  }

  static class a extends a.c
  {
    public boolean a(AccessibilityServiceInfo paramAccessibilityServiceInfo)
    {
      return b.a(paramAccessibilityServiceInfo);
    }

    public String b(AccessibilityServiceInfo paramAccessibilityServiceInfo)
    {
      return b.b(paramAccessibilityServiceInfo);
    }

    public String c(AccessibilityServiceInfo paramAccessibilityServiceInfo)
    {
      return b.c(paramAccessibilityServiceInfo);
    }

    public ResolveInfo d(AccessibilityServiceInfo paramAccessibilityServiceInfo)
    {
      return b.d(paramAccessibilityServiceInfo);
    }

    public String e(AccessibilityServiceInfo paramAccessibilityServiceInfo)
    {
      return b.e(paramAccessibilityServiceInfo);
    }

    public int f(AccessibilityServiceInfo paramAccessibilityServiceInfo)
    {
      if (a(paramAccessibilityServiceInfo))
        return 1;
      return 0;
    }
  }

  static class b extends a.a
  {
    public int f(AccessibilityServiceInfo paramAccessibilityServiceInfo)
    {
      return c.a(paramAccessibilityServiceInfo);
    }
  }

  static class c
    implements a.d
  {
    public boolean a(AccessibilityServiceInfo paramAccessibilityServiceInfo)
    {
      return false;
    }

    public String b(AccessibilityServiceInfo paramAccessibilityServiceInfo)
    {
      return null;
    }

    public String c(AccessibilityServiceInfo paramAccessibilityServiceInfo)
    {
      return null;
    }

    public ResolveInfo d(AccessibilityServiceInfo paramAccessibilityServiceInfo)
    {
      return null;
    }

    public String e(AccessibilityServiceInfo paramAccessibilityServiceInfo)
    {
      return null;
    }

    public int f(AccessibilityServiceInfo paramAccessibilityServiceInfo)
    {
      return 0;
    }
  }

  static abstract interface d
  {
    public abstract boolean a(AccessibilityServiceInfo paramAccessibilityServiceInfo);

    public abstract String b(AccessibilityServiceInfo paramAccessibilityServiceInfo);

    public abstract String c(AccessibilityServiceInfo paramAccessibilityServiceInfo);

    public abstract ResolveInfo d(AccessibilityServiceInfo paramAccessibilityServiceInfo);

    public abstract String e(AccessibilityServiceInfo paramAccessibilityServiceInfo);

    public abstract int f(AccessibilityServiceInfo paramAccessibilityServiceInfo);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.a.a
 * JD-Core Version:    0.6.2
 */