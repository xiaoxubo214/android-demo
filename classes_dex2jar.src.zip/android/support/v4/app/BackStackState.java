package android.support.v4.app;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.text.TextUtils;
import android.util.Log;
import java.util.ArrayList;

final class BackStackState
  implements Parcelable
{
  public static final Parcelable.Creator<BackStackState> CREATOR = new v();
  final int[] a;
  final int b;
  final int c;
  final String d;
  final int e;
  final int f;
  final CharSequence g;
  final int h;
  final CharSequence i;
  final ArrayList<String> j;
  final ArrayList<String> k;

  public BackStackState(Parcel paramParcel)
  {
    this.a = paramParcel.createIntArray();
    this.b = paramParcel.readInt();
    this.c = paramParcel.readInt();
    this.d = paramParcel.readString();
    this.e = paramParcel.readInt();
    this.f = paramParcel.readInt();
    this.g = ((CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(paramParcel));
    this.h = paramParcel.readInt();
    this.i = ((CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(paramParcel));
    this.j = paramParcel.createStringArrayList();
    this.k = paramParcel.createStringArrayList();
  }

  public BackStackState(r paramr)
  {
    r.a locala1 = paramr.l;
    int m = 0;
    while (locala1 != null)
    {
      if (locala1.i != null)
        m += locala1.i.size();
      locala1 = locala1.a;
    }
    this.a = new int[m + 7 * paramr.n];
    if (!paramr.u)
      throw new IllegalStateException("Not on back stack");
    r.a locala2 = paramr.l;
    int n = 0;
    if (locala2 != null)
    {
      int[] arrayOfInt1 = this.a;
      int i1 = n + 1;
      arrayOfInt1[n] = locala2.c;
      int[] arrayOfInt2 = this.a;
      int i2 = i1 + 1;
      if (locala2.d != null);
      int i7;
      int i9;
      for (int i3 = locala2.d.z; ; i3 = -1)
      {
        arrayOfInt2[i1] = i3;
        int[] arrayOfInt3 = this.a;
        int i4 = i2 + 1;
        arrayOfInt3[i2] = locala2.e;
        int[] arrayOfInt4 = this.a;
        int i5 = i4 + 1;
        arrayOfInt4[i4] = locala2.f;
        int[] arrayOfInt5 = this.a;
        int i6 = i5 + 1;
        arrayOfInt5[i5] = locala2.g;
        int[] arrayOfInt6 = this.a;
        i7 = i6 + 1;
        arrayOfInt6[i6] = locala2.h;
        if (locala2.i == null)
          break label343;
        int i8 = locala2.i.size();
        int[] arrayOfInt8 = this.a;
        i9 = i7 + 1;
        arrayOfInt8[i7] = i8;
        int i10 = 0;
        while (i10 < i8)
        {
          int[] arrayOfInt9 = this.a;
          int i11 = i9 + 1;
          arrayOfInt9[i9] = ((Fragment)locala2.i.get(i10)).z;
          i10++;
          i9 = i11;
        }
      }
      n = i9;
      while (true)
      {
        locala2 = locala2.a;
        break;
        label343: int[] arrayOfInt7 = this.a;
        n = i7 + 1;
        arrayOfInt7[i7] = 0;
      }
    }
    this.b = paramr.s;
    this.c = paramr.t;
    this.d = paramr.w;
    this.e = paramr.y;
    this.f = paramr.z;
    this.g = paramr.A;
    this.h = paramr.B;
    this.i = paramr.C;
    this.j = paramr.D;
    this.k = paramr.E;
  }

  public r a(al paramal)
  {
    r localr = new r(paramal);
    int m = 0;
    int i8;
    for (int n = 0; n < this.a.length; n = i8)
    {
      r.a locala = new r.a();
      int[] arrayOfInt1 = this.a;
      int i1 = n + 1;
      locala.c = arrayOfInt1[n];
      if (al.b)
        Log.v("FragmentManager", "Instantiate " + localr + " op #" + m + " base fragment #" + this.a[i1]);
      int[] arrayOfInt2 = this.a;
      int i2 = i1 + 1;
      int i3 = arrayOfInt2[i1];
      if (i3 >= 0);
      for (locala.d = ((Fragment)paramal.l.get(i3)); ; locala.d = null)
      {
        int[] arrayOfInt3 = this.a;
        int i4 = i2 + 1;
        locala.e = arrayOfInt3[i2];
        int[] arrayOfInt4 = this.a;
        int i5 = i4 + 1;
        locala.f = arrayOfInt4[i4];
        int[] arrayOfInt5 = this.a;
        int i6 = i5 + 1;
        locala.g = arrayOfInt5[i5];
        int[] arrayOfInt6 = this.a;
        int i7 = i6 + 1;
        locala.h = arrayOfInt6[i6];
        int[] arrayOfInt7 = this.a;
        i8 = i7 + 1;
        int i9 = arrayOfInt7[i7];
        if (i9 <= 0)
          break;
        locala.i = new ArrayList(i9);
        int i10 = 0;
        while (i10 < i9)
        {
          if (al.b)
            Log.v("FragmentManager", "Instantiate " + localr + " set remove fragment #" + this.a[i8]);
          ArrayList localArrayList = paramal.l;
          int[] arrayOfInt8 = this.a;
          int i11 = i8 + 1;
          Fragment localFragment = (Fragment)localArrayList.get(arrayOfInt8[i8]);
          locala.i.add(localFragment);
          i10++;
          i8 = i11;
        }
      }
      localr.a(locala);
      m++;
    }
    localr.s = this.b;
    localr.t = this.c;
    localr.w = this.d;
    localr.y = this.e;
    localr.u = true;
    localr.z = this.f;
    localr.A = this.g;
    localr.B = this.h;
    localr.C = this.i;
    localr.D = this.j;
    localr.E = this.k;
    localr.e(1);
    return localr;
  }

  public int describeContents()
  {
    return 0;
  }

  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    paramParcel.writeIntArray(this.a);
    paramParcel.writeInt(this.b);
    paramParcel.writeInt(this.c);
    paramParcel.writeString(this.d);
    paramParcel.writeInt(this.e);
    paramParcel.writeInt(this.f);
    TextUtils.writeToParcel(this.g, paramParcel, 0);
    paramParcel.writeInt(this.h);
    TextUtils.writeToParcel(this.i, paramParcel, 0);
    paramParcel.writeStringList(this.j);
    paramParcel.writeStringList(this.k);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.BackStackState
 * JD-Core Version:    0.6.2
 */