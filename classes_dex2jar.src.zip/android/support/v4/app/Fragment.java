package android.support.v4.app;

import android.app.Activity;
import android.content.ComponentCallbacks;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.annotation.x;
import android.support.annotation.y;
import android.support.v4.m.g;
import android.support.v4.m.n;
import android.support.v4.view.p;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnCreateContextMenuListener;
import android.view.ViewGroup;
import android.view.animation.Animation;
import java.io.FileDescriptor;
import java.io.PrintWriter;

public class Fragment
  implements ComponentCallbacks, View.OnCreateContextMenuListener
{
  private static final n<String, Class<?>> a = new n();
  static final Object n = new Object();
  static final int o = 0;
  static final int p = 1;
  static final int q = 2;
  static final int r = 3;
  static final int s = 4;
  static final int t = 5;
  String A;
  Bundle B;
  Fragment C;
  int D = -1;
  int E;
  boolean F;
  boolean G;
  boolean H;
  boolean I;
  boolean J;
  int K;
  al L;
  aj M;
  al N;
  Fragment O;
  int P;
  int Q;
  String R;
  boolean S;
  boolean T;
  boolean U;
  boolean V;
  boolean W;
  boolean X = true;
  boolean Y;
  int Z;
  ViewGroup aa;
  View ab;
  View ac;
  boolean ad;
  boolean ae = true;
  bj af;
  boolean ag;
  boolean ah;
  Object ai = null;
  Object aj = n;
  Object ak = null;
  Object al = n;
  Object am = null;
  Object an = n;
  Boolean ao;
  Boolean ap;
  co aq = null;
  co ar = null;
  int u = 0;
  View v;
  int w;
  Bundle x;
  SparseArray<Parcelable> y;
  int z = -1;

  public static Fragment a(Context paramContext, String paramString)
  {
    return a(paramContext, paramString, null);
  }

  public static Fragment a(Context paramContext, String paramString, @y Bundle paramBundle)
  {
    try
    {
      Class localClass = (Class)a.get(paramString);
      if (localClass == null)
      {
        localClass = paramContext.getClassLoader().loadClass(paramString);
        a.put(paramString, localClass);
      }
      Fragment localFragment = (Fragment)localClass.newInstance();
      if (paramBundle != null)
      {
        paramBundle.setClassLoader(localFragment.getClass().getClassLoader());
        localFragment.B = paramBundle;
      }
      return localFragment;
    }
    catch (ClassNotFoundException localClassNotFoundException)
    {
      throw new a("Unable to instantiate fragment " + paramString + ": make sure class name exists, is public, and has an" + " empty constructor that is public", localClassNotFoundException);
    }
    catch (InstantiationException localInstantiationException)
    {
      throw new a("Unable to instantiate fragment " + paramString + ": make sure class name exists, is public, and has an" + " empty constructor that is public", localInstantiationException);
    }
    catch (IllegalAccessException localIllegalAccessException)
    {
      throw new a("Unable to instantiate fragment " + paramString + ": make sure class name exists, is public, and has an" + " empty constructor that is public", localIllegalAccessException);
    }
  }

  static boolean b(Context paramContext, String paramString)
  {
    try
    {
      Class localClass = (Class)a.get(paramString);
      if (localClass == null)
      {
        localClass = paramContext.getClassLoader().loadClass(paramString);
        a.put(paramString, localClass);
      }
      boolean bool = Fragment.class.isAssignableFrom(localClass);
      return bool;
    }
    catch (ClassNotFoundException localClassNotFoundException)
    {
    }
    return false;
  }

  public final boolean A()
  {
    return this.I;
  }

  public final boolean B()
  {
    return this.u >= 5;
  }

  public final boolean C()
  {
    return (x()) && (!D()) && (this.ab != null) && (this.ab.getWindowToken() != null) && (this.ab.getVisibility() == 0);
  }

  public final boolean D()
  {
    return this.S;
  }

  public final boolean E()
  {
    return this.W;
  }

  public final boolean F()
  {
    return this.X;
  }

  public final boolean G()
  {
    return this.U;
  }

  public boolean H()
  {
    return this.ae;
  }

  public bi I()
  {
    if (this.af != null)
      return this.af;
    if (this.M == null)
      throw new IllegalStateException("Fragment " + this + " not attached to Activity");
    this.ah = true;
    this.af = this.M.a(this.A, this.ag, true);
    return this.af;
  }

  @y
  public View J()
  {
    return this.ab;
  }

  public void K()
  {
    this.Y = true;
  }

  public void L()
  {
    this.Y = true;
  }

  public void M()
  {
    this.Y = true;
    if (!this.ah)
    {
      this.ah = true;
      this.af = this.M.a(this.A, this.ag, false);
    }
    if (this.af != null)
      this.af.h();
  }

  void N()
  {
    this.z = -1;
    this.A = null;
    this.F = false;
    this.G = false;
    this.H = false;
    this.I = false;
    this.J = false;
    this.K = 0;
    this.L = null;
    this.N = null;
    this.M = null;
    this.P = 0;
    this.Q = 0;
    this.R = null;
    this.S = false;
    this.T = false;
    this.V = false;
    this.af = null;
    this.ag = false;
    this.ah = false;
  }

  public void O()
  {
  }

  public Object P()
  {
    return this.ai;
  }

  public Object Q()
  {
    if (this.aj == n)
      return P();
    return this.aj;
  }

  public Object R()
  {
    return this.ak;
  }

  public Object S()
  {
    if (this.al == n)
      return R();
    return this.al;
  }

  public Object T()
  {
    return this.am;
  }

  public Object U()
  {
    if (this.an == n)
      return T();
    return this.an;
  }

  public boolean V()
  {
    if (this.ap == null)
      return true;
    return this.ap.booleanValue();
  }

  public boolean W()
  {
    if (this.ao == null)
      return true;
    return this.ao.booleanValue();
  }

  void X()
  {
    this.N = new al();
    this.N.a(this.M, new ad(this), this);
  }

  void Y()
  {
    if (this.N != null)
    {
      this.N.n();
      this.N.j();
    }
    this.u = 4;
    this.Y = false;
    h();
    if (!this.Y)
      throw new cp("Fragment " + this + " did not call through to super.onStart()");
    if (this.N != null)
      this.N.q();
    if (this.af != null)
      this.af.g();
  }

  void Z()
  {
    if (this.N != null)
    {
      this.N.n();
      this.N.j();
    }
    this.u = 5;
    this.Y = false;
    K();
    if (!this.Y)
      throw new cp("Fragment " + this + " did not call through to super.onResume()");
    if (this.N != null)
    {
      this.N.r();
      this.N.j();
    }
  }

  @y
  public View a(LayoutInflater paramLayoutInflater, @y ViewGroup paramViewGroup, @y Bundle paramBundle)
  {
    return null;
  }

  public Animation a(int paramInt1, boolean paramBoolean, int paramInt2)
  {
    return null;
  }

  public final CharSequence a(@android.support.annotation.ae int paramInt)
  {
    return t().getText(paramInt);
  }

  public final String a(@android.support.annotation.ae int paramInt, Object[] paramArrayOfObject)
  {
    return t().getString(paramInt, paramArrayOfObject);
  }

  public void a(int paramInt1, int paramInt2, Intent paramIntent)
  {
  }

  final void a(int paramInt, Fragment paramFragment)
  {
    this.z = paramInt;
    if (paramFragment != null)
    {
      this.A = (paramFragment.A + ":" + this.z);
      return;
    }
    this.A = ("android:fragment:" + this.z);
  }

  public void a(int paramInt, @x String[] paramArrayOfString, @x int[] paramArrayOfInt)
  {
  }

  @Deprecated
  public void a(Activity paramActivity)
  {
    this.Y = true;
  }

  @Deprecated
  public void a(Activity paramActivity, AttributeSet paramAttributeSet, Bundle paramBundle)
  {
    this.Y = true;
  }

  public void a(Context paramContext)
  {
    this.Y = true;
    if (this.M == null);
    for (Activity localActivity = null; ; localActivity = this.M.h())
    {
      if (localActivity != null)
      {
        this.Y = false;
        a(localActivity);
      }
      return;
    }
  }

  public void a(Context paramContext, AttributeSet paramAttributeSet, Bundle paramBundle)
  {
    this.Y = true;
    if (this.M == null);
    for (Activity localActivity = null; ; localActivity = this.M.h())
    {
      if (localActivity != null)
      {
        this.Y = false;
        a(localActivity, paramAttributeSet, paramBundle);
      }
      return;
    }
  }

  public void a(Intent paramIntent)
  {
    a(paramIntent, null);
  }

  public void a(Intent paramIntent, int paramInt)
  {
    a(paramIntent, paramInt, null);
  }

  public void a(Intent paramIntent, int paramInt, @y Bundle paramBundle)
  {
    if (this.M == null)
      throw new IllegalStateException("Fragment " + this + " not attached to Activity");
    this.M.a(this, paramIntent, paramInt, paramBundle);
  }

  public void a(Intent paramIntent, @y Bundle paramBundle)
  {
    if (this.M == null)
      throw new IllegalStateException("Fragment " + this + " not attached to Activity");
    this.M.a(this, paramIntent, -1, paramBundle);
  }

  void a(Configuration paramConfiguration)
  {
    onConfigurationChanged(paramConfiguration);
    if (this.N != null)
      this.N.a(paramConfiguration);
  }

  public void a(@y Bundle paramBundle)
  {
    this.Y = true;
  }

  public void a(SavedState paramSavedState)
  {
    if (this.z >= 0)
      throw new IllegalStateException("Fragment already active");
    if ((paramSavedState != null) && (paramSavedState.a != null));
    for (Bundle localBundle = paramSavedState.a; ; localBundle = null)
    {
      this.x = localBundle;
      return;
    }
  }

  public void a(Fragment paramFragment, int paramInt)
  {
    this.C = paramFragment;
    this.E = paramInt;
  }

  public void a(co paramco)
  {
    this.aq = paramco;
  }

  public void a(Menu paramMenu)
  {
  }

  public void a(Menu paramMenu, MenuInflater paramMenuInflater)
  {
  }

  public void a(View paramView)
  {
    paramView.setOnCreateContextMenuListener(this);
  }

  public void a(View paramView, @y Bundle paramBundle)
  {
  }

  public void a(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString)
  {
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mFragmentId=#");
    paramPrintWriter.print(Integer.toHexString(this.P));
    paramPrintWriter.print(" mContainerId=#");
    paramPrintWriter.print(Integer.toHexString(this.Q));
    paramPrintWriter.print(" mTag=");
    paramPrintWriter.println(this.R);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mState=");
    paramPrintWriter.print(this.u);
    paramPrintWriter.print(" mIndex=");
    paramPrintWriter.print(this.z);
    paramPrintWriter.print(" mWho=");
    paramPrintWriter.print(this.A);
    paramPrintWriter.print(" mBackStackNesting=");
    paramPrintWriter.println(this.K);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mAdded=");
    paramPrintWriter.print(this.F);
    paramPrintWriter.print(" mRemoving=");
    paramPrintWriter.print(this.G);
    paramPrintWriter.print(" mFromLayout=");
    paramPrintWriter.print(this.H);
    paramPrintWriter.print(" mInLayout=");
    paramPrintWriter.println(this.I);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mHidden=");
    paramPrintWriter.print(this.S);
    paramPrintWriter.print(" mDetached=");
    paramPrintWriter.print(this.T);
    paramPrintWriter.print(" mMenuVisible=");
    paramPrintWriter.print(this.X);
    paramPrintWriter.print(" mHasMenu=");
    paramPrintWriter.println(this.W);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mRetainInstance=");
    paramPrintWriter.print(this.U);
    paramPrintWriter.print(" mRetaining=");
    paramPrintWriter.print(this.V);
    paramPrintWriter.print(" mUserVisibleHint=");
    paramPrintWriter.println(this.ae);
    if (this.L != null)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mFragmentManager=");
      paramPrintWriter.println(this.L);
    }
    if (this.M != null)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mHost=");
      paramPrintWriter.println(this.M);
    }
    if (this.O != null)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mParentFragment=");
      paramPrintWriter.println(this.O);
    }
    if (this.B != null)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mArguments=");
      paramPrintWriter.println(this.B);
    }
    if (this.x != null)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mSavedFragmentState=");
      paramPrintWriter.println(this.x);
    }
    if (this.y != null)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mSavedViewState=");
      paramPrintWriter.println(this.y);
    }
    if (this.C != null)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mTarget=");
      paramPrintWriter.print(this.C);
      paramPrintWriter.print(" mTargetRequestCode=");
      paramPrintWriter.println(this.E);
    }
    if (this.Z != 0)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mNextAnim=");
      paramPrintWriter.println(this.Z);
    }
    if (this.aa != null)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mContainer=");
      paramPrintWriter.println(this.aa);
    }
    if (this.ab != null)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mView=");
      paramPrintWriter.println(this.ab);
    }
    if (this.ac != null)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mInnerView=");
      paramPrintWriter.println(this.ab);
    }
    if (this.v != null)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mAnimatingAway=");
      paramPrintWriter.println(this.v);
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mStateAfterAnimating=");
      paramPrintWriter.println(this.w);
    }
    if (this.af != null)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.println("Loader Manager:");
      this.af.a(paramString + "  ", paramFileDescriptor, paramPrintWriter, paramArrayOfString);
    }
    if (this.N != null)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.println("Child " + this.N + ":");
      this.N.a(paramString + "  ", paramFileDescriptor, paramPrintWriter, paramArrayOfString);
    }
  }

  public final void a(@x String[] paramArrayOfString, int paramInt)
  {
    if (this.M == null)
      throw new IllegalStateException("Fragment " + this + " not attached to Activity");
    this.M.a(this, paramArrayOfString, paramInt);
  }

  public boolean a(MenuItem paramMenuItem)
  {
    return false;
  }

  public void a_(Object paramObject)
  {
    this.ai = paramObject;
  }

  public boolean a_(@x String paramString)
  {
    if (this.M != null)
      return this.M.a(paramString);
    return false;
  }

  void aa()
  {
    onLowMemory();
    if (this.N != null)
      this.N.x();
  }

  void ab()
  {
    if (this.N != null)
      this.N.s();
    this.u = 4;
    this.Y = false;
    L();
    if (!this.Y)
      throw new cp("Fragment " + this + " did not call through to super.onPause()");
  }

  void ac()
  {
    if (this.N != null)
      this.N.t();
    this.u = 3;
    this.Y = false;
    i();
    if (!this.Y)
      throw new cp("Fragment " + this + " did not call through to super.onStop()");
  }

  void ad()
  {
    if (this.N != null)
      this.N.u();
    this.u = 2;
    if (this.ag)
    {
      this.ag = false;
      if (!this.ah)
      {
        this.ah = true;
        this.af = this.M.a(this.A, this.ag, false);
      }
      if (this.af != null)
      {
        if (!this.M.m())
          break label88;
        this.af.d();
      }
    }
    return;
    label88: this.af.c();
  }

  void ae()
  {
    if (this.N != null)
      this.N.v();
    this.u = 1;
    this.Y = false;
    j();
    if (!this.Y)
      throw new cp("Fragment " + this + " did not call through to super.onDestroyView()");
    if (this.af != null)
      this.af.f();
  }

  void af()
  {
    if (this.N != null)
      this.N.w();
    this.u = 0;
    this.Y = false;
    M();
    if (!this.Y)
      throw new cp("Fragment " + this + " did not call through to super.onDestroy()");
  }

  Fragment b(String paramString)
  {
    if (paramString.equals(this.A))
      return this;
    if (this.N != null)
      return this.N.b(paramString);
    return null;
  }

  public LayoutInflater b(Bundle paramBundle)
  {
    LayoutInflater localLayoutInflater = this.M.b();
    v();
    p.a(localLayoutInflater, this.N.y());
    return localLayoutInflater;
  }

  View b(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup, Bundle paramBundle)
  {
    if (this.N != null)
      this.N.n();
    return a(paramLayoutInflater, paramViewGroup, paramBundle);
  }

  public final String b(@android.support.annotation.ae int paramInt)
  {
    return t().getString(paramInt);
  }

  public void b(co paramco)
  {
    this.ar = paramco;
  }

  public void b(Menu paramMenu)
  {
  }

  public void b(View paramView)
  {
    paramView.setOnCreateContextMenuListener(null);
  }

  public void b(Object paramObject)
  {
    this.aj = paramObject;
  }

  boolean b(Menu paramMenu, MenuInflater paramMenuInflater)
  {
    boolean bool1 = this.S;
    boolean bool2 = false;
    if (!bool1)
    {
      boolean bool3 = this.W;
      bool2 = false;
      if (bool3)
      {
        boolean bool4 = this.X;
        bool2 = false;
        if (bool4)
        {
          bool2 = true;
          a(paramMenu, paramMenuInflater);
        }
      }
      if (this.N != null)
        bool2 |= this.N.a(paramMenu, paramMenuInflater);
    }
    return bool2;
  }

  public boolean b(MenuItem paramMenuItem)
  {
    return false;
  }

  public void c(Object paramObject)
  {
    this.ak = paramObject;
  }

  boolean c(Menu paramMenu)
  {
    boolean bool1 = this.S;
    boolean bool2 = false;
    if (!bool1)
    {
      boolean bool3 = this.W;
      bool2 = false;
      if (bool3)
      {
        boolean bool4 = this.X;
        bool2 = false;
        if (bool4)
        {
          bool2 = true;
          a(paramMenu);
        }
      }
      if (this.N != null)
        bool2 |= this.N.a(paramMenu);
    }
    return bool2;
  }

  boolean c(MenuItem paramMenuItem)
  {
    if (!this.S)
    {
      if ((this.W) && (this.X) && (a(paramMenuItem)));
      while ((this.N != null) && (this.N.a(paramMenuItem)))
        return true;
    }
    return false;
  }

  public void d(@y Bundle paramBundle)
  {
    this.Y = true;
  }

  void d(Menu paramMenu)
  {
    if (!this.S)
    {
      if ((this.W) && (this.X))
        b(paramMenu);
      if (this.N != null)
        this.N.b(paramMenu);
    }
  }

  public void d(Object paramObject)
  {
    this.al = paramObject;
  }

  public void d(boolean paramBoolean)
  {
  }

  boolean d(MenuItem paramMenuItem)
  {
    if (!this.S)
    {
      if (b(paramMenuItem));
      while ((this.N != null) && (this.N.b(paramMenuItem)))
        return true;
    }
    return false;
  }

  public void e(Bundle paramBundle)
  {
  }

  public void e(Object paramObject)
  {
    this.am = paramObject;
  }

  public void e(boolean paramBoolean)
  {
    if (this.W != paramBoolean)
    {
      this.W = paramBoolean;
      if ((x()) && (!D()))
        this.M.d();
    }
  }

  public final boolean equals(Object paramObject)
  {
    return super.equals(paramObject);
  }

  final void f(Bundle paramBundle)
  {
    if (this.y != null)
    {
      this.ac.restoreHierarchyState(this.y);
      this.y = null;
    }
    this.Y = false;
    h(paramBundle);
    if (!this.Y)
      throw new cp("Fragment " + this + " did not call through to super.onViewStateRestored()");
  }

  public void f(Object paramObject)
  {
    this.an = paramObject;
  }

  public void f(boolean paramBoolean)
  {
    if (this.X != paramBoolean)
    {
      this.X = paramBoolean;
      if ((this.W) && (x()) && (!D()))
        this.M.d();
    }
  }

  public void g()
  {
    this.Y = true;
  }

  public void g(Bundle paramBundle)
  {
    if (this.z >= 0)
      throw new IllegalStateException("Fragment already active");
    this.B = paramBundle;
  }

  public void g(boolean paramBoolean)
  {
    if ((!this.ae) && (paramBoolean) && (this.u < 4))
      this.L.b(this);
    this.ae = paramBoolean;
    if (!paramBoolean);
    for (boolean bool = true; ; bool = false)
    {
      this.ad = bool;
      return;
    }
  }

  public final int g_()
  {
    return this.E;
  }

  public void h()
  {
    this.Y = true;
    if (!this.ag)
    {
      this.ag = true;
      if (!this.ah)
      {
        this.ah = true;
        this.af = this.M.a(this.A, this.ag, false);
      }
      if (this.af != null)
        this.af.b();
    }
  }

  public void h(@y Bundle paramBundle)
  {
    this.Y = true;
  }

  public void h(boolean paramBoolean)
  {
    this.ap = Boolean.valueOf(paramBoolean);
  }

  public final int hashCode()
  {
    return super.hashCode();
  }

  public void i()
  {
    this.Y = true;
  }

  void i(Bundle paramBundle)
  {
    if (this.N != null)
      this.N.n();
    this.u = 1;
    this.Y = false;
    a(paramBundle);
    if (!this.Y)
      throw new cp("Fragment " + this + " did not call through to super.onCreate()");
    if (paramBundle != null)
    {
      Parcelable localParcelable = paramBundle.getParcelable("android:support:fragments");
      if (localParcelable != null)
      {
        if (this.N == null)
          X();
        this.N.a(localParcelable, null);
        this.N.o();
      }
    }
  }

  public void i(boolean paramBoolean)
  {
    this.ao = Boolean.valueOf(paramBoolean);
  }

  public void j()
  {
    this.Y = true;
  }

  void j(Bundle paramBundle)
  {
    if (this.N != null)
      this.N.n();
    this.u = 2;
    this.Y = false;
    d(paramBundle);
    if (!this.Y)
      throw new cp("Fragment " + this + " did not call through to super.onActivityCreated()");
    if (this.N != null)
      this.N.p();
  }

  void k(Bundle paramBundle)
  {
    e(paramBundle);
    if (this.N != null)
    {
      Parcelable localParcelable = this.N.m();
      if (localParcelable != null)
        paramBundle.putParcelable("android:support:fragments", localParcelable);
    }
  }

  final boolean k()
  {
    return this.K > 0;
  }

  public final int l()
  {
    return this.P;
  }

  public final String m()
  {
    return this.R;
  }

  public final Bundle n()
  {
    return this.B;
  }

  public final Fragment o()
  {
    return this.C;
  }

  public void onConfigurationChanged(Configuration paramConfiguration)
  {
    this.Y = true;
  }

  public void onCreateContextMenu(ContextMenu paramContextMenu, View paramView, ContextMenu.ContextMenuInfo paramContextMenuInfo)
  {
    r().onCreateContextMenu(paramContextMenu, paramView, paramContextMenuInfo);
  }

  public void onLowMemory()
  {
    this.Y = true;
  }

  public Context q()
  {
    if (this.M == null)
      return null;
    return this.M.i();
  }

  public final af r()
  {
    if (this.M == null)
      return null;
    return (af)this.M.h();
  }

  public final Object s()
  {
    if (this.M == null)
      return null;
    return this.M.g();
  }

  public void setRetainInstance(boolean paramBoolean)
  {
    if ((paramBoolean) && (this.O != null))
      throw new IllegalStateException("Can't retain fragements that are nested in other fragments");
    this.U = paramBoolean;
  }

  public final Resources t()
  {
    if (this.M == null)
      throw new IllegalStateException("Fragment " + this + " not attached to Activity");
    return this.M.i().getResources();
  }

  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder(128);
    g.a(this, localStringBuilder);
    if (this.z >= 0)
    {
      localStringBuilder.append(" #");
      localStringBuilder.append(this.z);
    }
    if (this.P != 0)
    {
      localStringBuilder.append(" id=0x");
      localStringBuilder.append(Integer.toHexString(this.P));
    }
    if (this.R != null)
    {
      localStringBuilder.append(" ");
      localStringBuilder.append(this.R);
    }
    localStringBuilder.append('}');
    return localStringBuilder.toString();
  }

  public final ak u()
  {
    return this.L;
  }

  public final ak v()
  {
    if (this.N == null)
    {
      X();
      if (this.u < 5)
        break label31;
      this.N.r();
    }
    while (true)
    {
      return this.N;
      label31: if (this.u >= 4)
        this.N.q();
      else if (this.u >= 2)
        this.N.p();
      else if (this.u >= 1)
        this.N.o();
    }
  }

  public final Fragment w()
  {
    return this.O;
  }

  public final boolean x()
  {
    return (this.M != null) && (this.F);
  }

  public final boolean y()
  {
    return this.T;
  }

  public final boolean z()
  {
    return this.G;
  }

  public static class SavedState
    implements Parcelable
  {
    public static final Parcelable.Creator<SavedState> CREATOR = new ae();
    final Bundle a;

    SavedState(Bundle paramBundle)
    {
      this.a = paramBundle;
    }

    SavedState(Parcel paramParcel, ClassLoader paramClassLoader)
    {
      this.a = paramParcel.readBundle();
      if ((paramClassLoader != null) && (this.a != null))
        this.a.setClassLoader(paramClassLoader);
    }

    public int describeContents()
    {
      return 0;
    }

    public void writeToParcel(Parcel paramParcel, int paramInt)
    {
      paramParcel.writeBundle(this.a);
    }
  }

  public static class a extends RuntimeException
  {
    public a(String paramString, Exception paramException)
    {
      super(paramException);
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.Fragment
 * JD-Core Version:    0.6.2
 */