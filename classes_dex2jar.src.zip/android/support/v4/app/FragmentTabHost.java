package android.support.v4.app;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.BaseSavedState;
import android.widget.FrameLayout;
import android.widget.FrameLayout.LayoutParams;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TabHost;
import android.widget.TabHost.OnTabChangeListener;
import android.widget.TabHost.TabContentFactory;
import android.widget.TabHost.TabSpec;
import android.widget.TabWidget;
import java.util.ArrayList;

public class FragmentTabHost extends TabHost
  implements TabHost.OnTabChangeListener
{
  private final ArrayList<b> a = new ArrayList();
  private FrameLayout b;
  private Context c;
  private ak d;
  private int e;
  private TabHost.OnTabChangeListener f;
  private b g;
  private boolean h;

  public FragmentTabHost(Context paramContext)
  {
    super(paramContext, null);
    a(paramContext, null);
  }

  public FragmentTabHost(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    a(paramContext, paramAttributeSet);
  }

  private ay a(String paramString, ay paramay)
  {
    Object localObject1 = null;
    int i = 0;
    Object localObject2;
    if (i < this.a.size())
    {
      localObject2 = (b)this.a.get(i);
      if (!b.b((b)localObject2).equals(paramString))
        break label202;
    }
    while (true)
    {
      i++;
      localObject1 = localObject2;
      break;
      if (localObject1 == null)
        throw new IllegalStateException("No tab known for tag " + paramString);
      if (this.g != localObject1)
      {
        if (paramay == null)
          paramay = this.d.a();
        if ((this.g != null) && (b.a(this.g) != null))
          paramay.d(b.a(this.g));
        if (localObject1 != null)
        {
          if (b.a(localObject1) != null)
            break label190;
          b.a(localObject1, Fragment.a(this.c, b.c(localObject1).getName(), b.d(localObject1)));
          paramay.a(this.e, b.a(localObject1), b.b(localObject1));
        }
      }
      while (true)
      {
        this.g = localObject1;
        return paramay;
        label190: paramay.e(b.a(localObject1));
      }
      label202: localObject2 = localObject1;
    }
  }

  private void a()
  {
    if (this.b == null)
    {
      this.b = ((FrameLayout)findViewById(this.e));
      if (this.b == null)
        throw new IllegalStateException("No tab content FrameLayout found for id " + this.e);
    }
  }

  private void a(Context paramContext)
  {
    if (findViewById(16908307) == null)
    {
      LinearLayout localLinearLayout = new LinearLayout(paramContext);
      localLinearLayout.setOrientation(1);
      addView(localLinearLayout, new FrameLayout.LayoutParams(-1, -1));
      TabWidget localTabWidget = new TabWidget(paramContext);
      localTabWidget.setId(16908307);
      localTabWidget.setOrientation(0);
      localLinearLayout.addView(localTabWidget, new LinearLayout.LayoutParams(-1, -2, 0.0F));
      FrameLayout localFrameLayout1 = new FrameLayout(paramContext);
      localFrameLayout1.setId(16908305);
      localLinearLayout.addView(localFrameLayout1, new LinearLayout.LayoutParams(0, 0, 0.0F));
      FrameLayout localFrameLayout2 = new FrameLayout(paramContext);
      this.b = localFrameLayout2;
      this.b.setId(this.e);
      localLinearLayout.addView(localFrameLayout2, new LinearLayout.LayoutParams(-1, 0, 1.0F));
    }
  }

  private void a(Context paramContext, AttributeSet paramAttributeSet)
  {
    TypedArray localTypedArray = paramContext.obtainStyledAttributes(paramAttributeSet, new int[] { 16842995 }, 0, 0);
    this.e = localTypedArray.getResourceId(0, 0);
    localTypedArray.recycle();
    super.setOnTabChangedListener(this);
  }

  public void a(Context paramContext, ak paramak)
  {
    a(paramContext);
    super.setup();
    this.c = paramContext;
    this.d = paramak;
    a();
  }

  public void a(Context paramContext, ak paramak, int paramInt)
  {
    a(paramContext);
    super.setup();
    this.c = paramContext;
    this.d = paramak;
    this.e = paramInt;
    a();
    this.b.setId(paramInt);
    if (getId() == -1)
      setId(16908306);
  }

  public void a(TabHost.TabSpec paramTabSpec, Class<?> paramClass, Bundle paramBundle)
  {
    paramTabSpec.setContent(new a(this.c));
    String str = paramTabSpec.getTag();
    b localb = new b(str, paramClass, paramBundle);
    if (this.h)
    {
      b.a(localb, this.d.a(str));
      if ((b.a(localb) != null) && (!b.a(localb).y()))
      {
        ay localay = this.d.a();
        localay.d(b.a(localb));
        localay.h();
      }
    }
    this.a.add(localb);
    addTab(paramTabSpec);
  }

  protected void onAttachedToWindow()
  {
    super.onAttachedToWindow();
    String str = getCurrentTabTag();
    ay localay1 = null;
    int i = 0;
    if (i < this.a.size())
    {
      b localb = (b)this.a.get(i);
      b.a(localb, this.d.a(b.b(localb)));
      if ((b.a(localb) != null) && (!b.a(localb).y()))
      {
        if (!b.b(localb).equals(str))
          break label98;
        this.g = localb;
      }
      while (true)
      {
        i++;
        break;
        label98: if (localay1 == null)
          localay1 = this.d.a();
        localay1.d(b.a(localb));
      }
    }
    this.h = true;
    ay localay2 = a(str, localay1);
    if (localay2 != null)
    {
      localay2.h();
      this.d.c();
    }
  }

  protected void onDetachedFromWindow()
  {
    super.onDetachedFromWindow();
    this.h = false;
  }

  protected void onRestoreInstanceState(Parcelable paramParcelable)
  {
    SavedState localSavedState = (SavedState)paramParcelable;
    super.onRestoreInstanceState(localSavedState.getSuperState());
    setCurrentTabByTag(localSavedState.a);
  }

  protected Parcelable onSaveInstanceState()
  {
    SavedState localSavedState = new SavedState(super.onSaveInstanceState());
    localSavedState.a = getCurrentTabTag();
    return localSavedState;
  }

  public void onTabChanged(String paramString)
  {
    if (this.h)
    {
      ay localay = a(paramString, null);
      if (localay != null)
        localay.h();
    }
    if (this.f != null)
      this.f.onTabChanged(paramString);
  }

  public void setOnTabChangedListener(TabHost.OnTabChangeListener paramOnTabChangeListener)
  {
    this.f = paramOnTabChangeListener;
  }

  @Deprecated
  public void setup()
  {
    throw new IllegalStateException("Must call setup() that takes a Context and FragmentManager");
  }

  static class SavedState extends View.BaseSavedState
  {
    public static final Parcelable.Creator<SavedState> CREATOR = new ax();
    String a;

    private SavedState(Parcel paramParcel)
    {
      super();
      this.a = paramParcel.readString();
    }

    SavedState(Parcelable paramParcelable)
    {
      super();
    }

    public String toString()
    {
      return "FragmentTabHost.SavedState{" + Integer.toHexString(System.identityHashCode(this)) + " curTab=" + this.a + "}";
    }

    public void writeToParcel(Parcel paramParcel, int paramInt)
    {
      super.writeToParcel(paramParcel, paramInt);
      paramParcel.writeString(this.a);
    }
  }

  static class a
    implements TabHost.TabContentFactory
  {
    private final Context a;

    public a(Context paramContext)
    {
      this.a = paramContext;
    }

    public View createTabContent(String paramString)
    {
      View localView = new View(this.a);
      localView.setMinimumWidth(0);
      localView.setMinimumHeight(0);
      return localView;
    }
  }

  static final class b
  {
    private final String a;
    private final Class<?> b;
    private final Bundle c;
    private Fragment d;

    b(String paramString, Class<?> paramClass, Bundle paramBundle)
    {
      this.a = paramString;
      this.b = paramClass;
      this.c = paramBundle;
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.FragmentTabHost
 * JD-Core Version:    0.6.2
 */