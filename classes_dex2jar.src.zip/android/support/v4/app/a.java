package android.support.v4.app;

import android.app.Activity;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.res.Configuration;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Drawable.Callback;
import android.graphics.drawable.InsetDrawable;
import android.os.Build.VERSION;
import android.support.annotation.ae;
import android.support.annotation.m;
import android.support.annotation.y;
import android.support.v4.c.d;
import android.support.v4.view.aw;
import android.support.v4.widget.DrawerLayout;
import android.support.v4.widget.DrawerLayout.f;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;

@Deprecated
public class a
  implements DrawerLayout.f
{
  private static final a a = new b(null);
  private static final float b = 0.3333333F;
  private static final int c = 16908332;
  private final Activity d;
  private final e e;
  private final DrawerLayout f;
  private boolean g = true;
  private boolean h;
  private Drawable i;
  private Drawable j;
  private g k;
  private final int l;
  private final int m;
  private final int n;
  private Object o;

  static
  {
    int i1 = Build.VERSION.SDK_INT;
    if (i1 >= 18)
    {
      a = new d(null);
      return;
    }
    if (i1 >= 11)
    {
      a = new c(null);
      return;
    }
  }

  public a(Activity paramActivity, DrawerLayout paramDrawerLayout, @m int paramInt1, @ae int paramInt2, @ae int paramInt3)
  {
  }

  public a(Activity paramActivity, DrawerLayout paramDrawerLayout, boolean paramBoolean, @m int paramInt1, @ae int paramInt2, @ae int paramInt3)
  {
    this.d = paramActivity;
    g localg;
    if ((paramActivity instanceof f))
    {
      this.e = ((f)paramActivity).a();
      this.f = paramDrawerLayout;
      this.l = paramInt1;
      this.m = paramInt2;
      this.n = paramInt3;
      this.i = c();
      this.j = d.a(paramActivity, paramInt1);
      this.k = new g(this.j, null);
      localg = this.k;
      if (!paramBoolean)
        break label122;
    }
    label122: for (float f1 = 0.3333333F; ; f1 = 0.0F)
    {
      localg.b(f1);
      return;
      this.e = null;
      break;
    }
  }

  private static boolean a(Context paramContext)
  {
    return (paramContext.getApplicationInfo().targetSdkVersion >= 21) && (Build.VERSION.SDK_INT >= 21);
  }

  public void a()
  {
    g localg;
    if (this.f.g(8388611))
    {
      this.k.a(1.0F);
      if (this.g)
      {
        localg = this.k;
        if (!this.f.g(8388611))
          break label67;
      }
    }
    label67: for (int i1 = this.n; ; i1 = this.m)
    {
      a(localg, i1);
      return;
      this.k.a(0.0F);
      break;
    }
  }

  public void a(int paramInt)
  {
    Drawable localDrawable = null;
    if (paramInt != 0)
      localDrawable = d.a(this.d, paramInt);
    a(localDrawable);
  }

  public void a(Configuration paramConfiguration)
  {
    if (!this.h)
      this.i = c();
    this.j = d.a(this.d, this.l);
    a();
  }

  public void a(Drawable paramDrawable)
  {
    if (paramDrawable == null)
      this.i = c();
    for (this.h = false; ; this.h = true)
    {
      if (!this.g)
        a(this.i, 0);
      return;
      this.i = paramDrawable;
    }
  }

  void a(Drawable paramDrawable, int paramInt)
  {
    if (this.e != null)
    {
      this.e.a(paramDrawable, paramInt);
      return;
    }
    this.o = a.a(this.o, this.d, paramDrawable, paramInt);
  }

  public void a(View paramView)
  {
    this.k.a(1.0F);
    if (this.g)
      c(this.n);
  }

  public void a(View paramView, float paramFloat)
  {
    float f1 = this.k.a();
    if (paramFloat > 0.5F);
    for (float f2 = Math.max(f1, 2.0F * Math.max(0.0F, paramFloat - 0.5F)); ; f2 = Math.min(f1, paramFloat * 2.0F))
    {
      this.k.a(f2);
      return;
    }
  }

  public void a(boolean paramBoolean)
  {
    int i1;
    if (paramBoolean != this.g)
    {
      if (!paramBoolean)
        break label54;
      g localg = this.k;
      if (!this.f.g(8388611))
        break label46;
      i1 = this.n;
      a(localg, i1);
    }
    while (true)
    {
      this.g = paramBoolean;
      return;
      label46: i1 = this.m;
      break;
      label54: a(this.i, 0);
    }
  }

  public boolean a(MenuItem paramMenuItem)
  {
    if ((paramMenuItem != null) && (paramMenuItem.getItemId() == 16908332) && (this.g))
    {
      if (this.f.h(8388611))
        this.f.f(8388611);
      while (true)
      {
        return true;
        this.f.e(8388611);
      }
    }
    return false;
  }

  public void b(int paramInt)
  {
  }

  public void b(View paramView)
  {
    this.k.a(0.0F);
    if (this.g)
      c(this.m);
  }

  public boolean b()
  {
    return this.g;
  }

  Drawable c()
  {
    if (this.e != null)
      return this.e.a();
    return a.a(this.d);
  }

  void c(int paramInt)
  {
    if (this.e != null)
    {
      this.e.a(paramInt);
      return;
    }
    this.o = a.a(this.o, this.d, paramInt);
  }

  private static abstract interface a
  {
    public abstract Drawable a(Activity paramActivity);

    public abstract Object a(Object paramObject, Activity paramActivity, int paramInt);

    public abstract Object a(Object paramObject, Activity paramActivity, Drawable paramDrawable, int paramInt);
  }

  private static class b
    implements a.a
  {
    public Drawable a(Activity paramActivity)
    {
      return null;
    }

    public Object a(Object paramObject, Activity paramActivity, int paramInt)
    {
      return paramObject;
    }

    public Object a(Object paramObject, Activity paramActivity, Drawable paramDrawable, int paramInt)
    {
      return paramObject;
    }
  }

  private static class c
    implements a.a
  {
    public Drawable a(Activity paramActivity)
    {
      return b.a(paramActivity);
    }

    public Object a(Object paramObject, Activity paramActivity, int paramInt)
    {
      return b.a(paramObject, paramActivity, paramInt);
    }

    public Object a(Object paramObject, Activity paramActivity, Drawable paramDrawable, int paramInt)
    {
      return b.a(paramObject, paramActivity, paramDrawable, paramInt);
    }
  }

  private static class d
    implements a.a
  {
    public Drawable a(Activity paramActivity)
    {
      return c.a(paramActivity);
    }

    public Object a(Object paramObject, Activity paramActivity, int paramInt)
    {
      return c.a(paramObject, paramActivity, paramInt);
    }

    public Object a(Object paramObject, Activity paramActivity, Drawable paramDrawable, int paramInt)
    {
      return c.a(paramObject, paramActivity, paramDrawable, paramInt);
    }
  }

  public static abstract interface e
  {
    @y
    public abstract Drawable a();

    public abstract void a(@ae int paramInt);

    public abstract void a(Drawable paramDrawable, @ae int paramInt);
  }

  public static abstract interface f
  {
    @y
    public abstract a.e a();
  }

  private class g extends InsetDrawable
    implements Drawable.Callback
  {
    private final boolean b;
    private final Rect c;
    private float d;
    private float e;

    private g(Drawable arg2)
    {
      super(0);
      int i = Build.VERSION.SDK_INT;
      boolean bool = false;
      if (i > 18)
        bool = true;
      this.b = bool;
      this.c = new Rect();
    }

    public float a()
    {
      return this.d;
    }

    public void a(float paramFloat)
    {
      this.d = paramFloat;
      invalidateSelf();
    }

    public void b(float paramFloat)
    {
      this.e = paramFloat;
      invalidateSelf();
    }

    public void draw(Canvas paramCanvas)
    {
      int i = 1;
      copyBounds(this.c);
      paramCanvas.save();
      if (aw.j(a.a(a.this).getWindow().getDecorView()) == i);
      for (int j = i; ; j = 0)
      {
        if (j != 0)
          i = -1;
        int k = this.c.width();
        paramCanvas.translate(-this.e * k * this.d * i, 0.0F);
        if ((j != 0) && (!this.b))
        {
          paramCanvas.translate(k, 0.0F);
          paramCanvas.scale(-1.0F, 1.0F);
        }
        super.draw(paramCanvas);
        paramCanvas.restore();
        return;
      }
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.a
 * JD-Core Version:    0.6.2
 */