package android.support.v4.app;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnDismissListener;
import android.os.Bundle;
import android.support.annotation.af;
import android.support.annotation.x;
import android.support.annotation.y;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;

public class ac extends Fragment
  implements DialogInterface.OnCancelListener, DialogInterface.OnDismissListener
{
  public static final int a = 0;
  private static final String as = "android:savedDialogState";
  private static final String at = "android:style";
  private static final String au = "android:theme";
  private static final String av = "android:cancelable";
  private static final String aw = "android:showsDialog";
  private static final String ax = "android:backStackId";
  public static final int b = 1;
  public static final int c = 2;
  public static final int d = 3;
  int e = 0;
  int f = 0;
  boolean g = true;
  boolean h = true;
  int i = -1;
  Dialog j;
  boolean k;
  boolean l;
  boolean m;

  public int a(ay paramay, String paramString)
  {
    this.l = false;
    this.m = true;
    paramay.a(this, paramString);
    this.k = false;
    this.i = paramay.h();
    return this.i;
  }

  public void a()
  {
    a(false);
  }

  public void a(int paramInt1, @af int paramInt2)
  {
    this.e = paramInt1;
    if ((this.e == 2) || (this.e == 3))
      this.f = 16973913;
    if (paramInt2 != 0)
      this.f = paramInt2;
  }

  public void a(Activity paramActivity)
  {
    super.a(paramActivity);
    if (!this.m)
      this.l = false;
  }

  public void a(Dialog paramDialog, int paramInt)
  {
    switch (paramInt)
    {
    default:
      return;
    case 3:
      paramDialog.getWindow().addFlags(24);
    case 1:
    case 2:
    }
    paramDialog.requestWindowFeature(1);
  }

  public void a(@y Bundle paramBundle)
  {
    super.a(paramBundle);
    if (this.Q == 0);
    for (boolean bool = true; ; bool = false)
    {
      this.h = bool;
      if (paramBundle != null)
      {
        this.e = paramBundle.getInt("android:style", 0);
        this.f = paramBundle.getInt("android:theme", 0);
        this.g = paramBundle.getBoolean("android:cancelable", true);
        this.h = paramBundle.getBoolean("android:showsDialog", this.h);
        this.i = paramBundle.getInt("android:backStackId", -1);
      }
      return;
    }
  }

  public void a(ak paramak, String paramString)
  {
    this.l = false;
    this.m = true;
    ay localay = paramak.a();
    localay.a(this, paramString);
    localay.h();
  }

  void a(boolean paramBoolean)
  {
    if (this.l)
      return;
    this.l = true;
    this.m = false;
    if (this.j != null)
    {
      this.j.dismiss();
      this.j = null;
    }
    this.k = true;
    if (this.i >= 0)
    {
      u().a(this.i, 1);
      this.i = -1;
      return;
    }
    ay localay = u().a();
    localay.a(this);
    if (paramBoolean)
    {
      localay.i();
      return;
    }
    localay.h();
  }

  public LayoutInflater b(Bundle paramBundle)
  {
    if (!this.h)
      return super.b(paramBundle);
    this.j = c(paramBundle);
    if (this.j != null)
    {
      a(this.j, this.e);
      return (LayoutInflater)this.j.getContext().getSystemService("layout_inflater");
    }
    return (LayoutInflater)this.M.i().getSystemService("layout_inflater");
  }

  public void b()
  {
    a(true);
  }

  public void b(boolean paramBoolean)
  {
    this.g = paramBoolean;
    if (this.j != null)
      this.j.setCancelable(paramBoolean);
  }

  public Dialog c()
  {
    return this.j;
  }

  @x
  public Dialog c(Bundle paramBundle)
  {
    return new Dialog(r(), d());
  }

  public void c(boolean paramBoolean)
  {
    this.h = paramBoolean;
  }

  @af
  public int d()
  {
    return this.f;
  }

  public void d(Bundle paramBundle)
  {
    super.d(paramBundle);
    if (!this.h);
    Bundle localBundle;
    do
    {
      do
      {
        return;
        View localView = J();
        if (localView != null)
        {
          if (localView.getParent() != null)
            throw new IllegalStateException("DialogFragment can not be attached to a container view");
          this.j.setContentView(localView);
        }
        this.j.setOwnerActivity(r());
        this.j.setCancelable(this.g);
        this.j.setOnCancelListener(this);
        this.j.setOnDismissListener(this);
      }
      while (paramBundle == null);
      localBundle = paramBundle.getBundle("android:savedDialogState");
    }
    while (localBundle == null);
    this.j.onRestoreInstanceState(localBundle);
  }

  public void e(Bundle paramBundle)
  {
    super.e(paramBundle);
    if (this.j != null)
    {
      Bundle localBundle = this.j.onSaveInstanceState();
      if (localBundle != null)
        paramBundle.putBundle("android:savedDialogState", localBundle);
    }
    if (this.e != 0)
      paramBundle.putInt("android:style", this.e);
    if (this.f != 0)
      paramBundle.putInt("android:theme", this.f);
    if (!this.g)
      paramBundle.putBoolean("android:cancelable", this.g);
    if (!this.h)
      paramBundle.putBoolean("android:showsDialog", this.h);
    if (this.i != -1)
      paramBundle.putInt("android:backStackId", this.i);
  }

  public boolean e()
  {
    return this.g;
  }

  public boolean f()
  {
    return this.h;
  }

  public void g()
  {
    super.g();
    if ((!this.m) && (!this.l))
      this.l = true;
  }

  public void h()
  {
    super.h();
    if (this.j != null)
    {
      this.k = false;
      this.j.show();
    }
  }

  public void i()
  {
    super.i();
    if (this.j != null)
      this.j.hide();
  }

  public void j()
  {
    super.j();
    if (this.j != null)
    {
      this.k = true;
      this.j.dismiss();
      this.j = null;
    }
  }

  public void onCancel(DialogInterface paramDialogInterface)
  {
  }

  public void onDismiss(DialogInterface paramDialogInterface)
  {
    if (!this.k)
      a(true);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.ac
 * JD-Core Version:    0.6.2
 */