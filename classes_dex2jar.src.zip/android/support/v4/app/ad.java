package android.support.v4.app;

import android.support.annotation.y;
import android.view.View;

class ad extends ah
{
  ad(Fragment paramFragment)
  {
  }

  @y
  public View a(int paramInt)
  {
    if (this.a.ab == null)
      throw new IllegalStateException("Fragment does not have a view");
    return this.a.ab.findViewById(paramInt);
  }

  public boolean a()
  {
    return this.a.ab != null;
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.ad
 * JD-Core Version:    0.6.2
 */