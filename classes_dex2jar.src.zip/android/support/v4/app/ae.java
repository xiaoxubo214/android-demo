package android.support.v4.app;

import android.os.Parcel;
import android.os.Parcelable.Creator;

final class ae
  implements Parcelable.Creator<Fragment.SavedState>
{
  public Fragment.SavedState a(Parcel paramParcel)
  {
    return new Fragment.SavedState(paramParcel, null);
  }

  public Fragment.SavedState[] a(int paramInt)
  {
    return new Fragment.SavedState[paramInt];
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.ae
 * JD-Core Version:    0.6.2
 */