package android.support.v4.app;

import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.Resources.NotFoundException;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.os.Parcelable;
import android.support.annotation.y;
import android.support.v4.m.n;
import android.support.v4.m.o;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager.LayoutParams;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

public class af extends x
  implements d.a, h.a
{
  static final String a = "android:support:fragments";
  static final String b = "android:support:next_request_index";
  static final String c = "android:support:request_indicies";
  static final String d = "android:support:request_fragment_who";
  static final int e = 65534;
  static final int f = 1;
  static final int g = 2;
  private static final String u = "FragmentActivity";
  private static final int v = 11;
  final Handler h = new ag(this);
  final ai i = ai.a(new a());
  boolean j;
  boolean k;
  boolean l;
  boolean m;
  boolean n;
  boolean o;
  boolean p;
  int q;
  boolean r;
  o<String> s;
  android.support.v4.media.session.d t;

  private static String a(View paramView)
  {
    char c1 = 'F';
    char c2 = '.';
    StringBuilder localStringBuilder = new StringBuilder(128);
    localStringBuilder.append(paramView.getClass().getName());
    localStringBuilder.append('{');
    localStringBuilder.append(Integer.toHexString(System.identityHashCode(paramView)));
    localStringBuilder.append(' ');
    switch (paramView.getVisibility())
    {
    default:
      localStringBuilder.append(c2);
    case 0:
    case 4:
    case 8:
    }
    while (true)
    {
      char c3;
      label108: char c4;
      label126: char c5;
      label143: char c6;
      label161: char c7;
      label179: char c8;
      label197: char c9;
      label215: label236: char c10;
      label253: int i1;
      Resources localResources;
      if (paramView.isFocusable())
      {
        c3 = c1;
        localStringBuilder.append(c3);
        if (!paramView.isEnabled())
          break label533;
        c4 = 'E';
        localStringBuilder.append(c4);
        if (!paramView.willNotDraw())
          break label539;
        c5 = c2;
        localStringBuilder.append(c5);
        if (!paramView.isHorizontalScrollBarEnabled())
          break label546;
        c6 = 'H';
        localStringBuilder.append(c6);
        if (!paramView.isVerticalScrollBarEnabled())
          break label552;
        c7 = 'V';
        localStringBuilder.append(c7);
        if (!paramView.isClickable())
          break label558;
        c8 = 'C';
        localStringBuilder.append(c8);
        if (!paramView.isLongClickable())
          break label564;
        c9 = 'L';
        localStringBuilder.append(c9);
        localStringBuilder.append(' ');
        if (!paramView.isFocused())
          break label570;
        localStringBuilder.append(c1);
        if (!paramView.isSelected())
          break label575;
        c10 = 'S';
        localStringBuilder.append(c10);
        if (paramView.isPressed())
          c2 = 'P';
        localStringBuilder.append(c2);
        localStringBuilder.append(' ');
        localStringBuilder.append(paramView.getLeft());
        localStringBuilder.append(',');
        localStringBuilder.append(paramView.getTop());
        localStringBuilder.append('-');
        localStringBuilder.append(paramView.getRight());
        localStringBuilder.append(',');
        localStringBuilder.append(paramView.getBottom());
        i1 = paramView.getId();
        if (i1 != -1)
        {
          localStringBuilder.append(" #");
          localStringBuilder.append(Integer.toHexString(i1));
          localResources = paramView.getResources();
          if ((i1 != 0) && (localResources != null))
            switch (0xFF000000 & i1)
            {
            default:
            case 2130706432:
            case 16777216:
            }
        }
      }
      try
      {
        String str1 = localResources.getResourcePackageName(i1);
        while (true)
        {
          String str2 = localResources.getResourceTypeName(i1);
          String str3 = localResources.getResourceEntryName(i1);
          localStringBuilder.append(" ");
          localStringBuilder.append(str1);
          localStringBuilder.append(":");
          localStringBuilder.append(str2);
          localStringBuilder.append("/");
          localStringBuilder.append(str3);
          label485: localStringBuilder.append("}");
          return localStringBuilder.toString();
          localStringBuilder.append('V');
          break;
          localStringBuilder.append('I');
          break;
          localStringBuilder.append('G');
          break;
          c3 = c2;
          break label108;
          label533: c4 = c2;
          break label126;
          label539: c5 = 'D';
          break label143;
          label546: c6 = c2;
          break label161;
          label552: c7 = c2;
          break label179;
          label558: c8 = c2;
          break label197;
          label564: c9 = c2;
          break label215;
          label570: c1 = c2;
          break label236;
          label575: c10 = c2;
          break label253;
          str1 = "app";
          continue;
          str1 = "android";
        }
      }
      catch (Resources.NotFoundException localNotFoundException)
      {
        break label485;
      }
    }
  }

  private void a(Fragment paramFragment, String[] paramArrayOfString, int paramInt)
  {
    if (paramInt == -1)
    {
      d.a(this, paramArrayOfString, paramInt);
      return;
    }
    if ((paramInt & 0xFFFFFF00) != 0)
      throw new IllegalArgumentException("Can only use lower 8 bits for requestCode");
    this.p = true;
    d.a(this, paramArrayOfString, (1 + paramFragment.z << 8) + (paramInt & 0xFF));
  }

  private void a(String paramString, PrintWriter paramPrintWriter, View paramView)
  {
    paramPrintWriter.print(paramString);
    if (paramView == null)
      paramPrintWriter.println("null");
    while (true)
    {
      return;
      paramPrintWriter.println(a(paramView));
      if ((paramView instanceof ViewGroup))
      {
        ViewGroup localViewGroup = (ViewGroup)paramView;
        int i1 = localViewGroup.getChildCount();
        if (i1 > 0)
        {
          String str = paramString + "  ";
          for (int i2 = 0; i2 < i1; i2++)
            a(str, paramPrintWriter, localViewGroup.getChildAt(i2));
        }
      }
    }
  }

  private int b(Fragment paramFragment)
  {
    if (this.s.b() >= 65534)
      throw new IllegalStateException("Too many pending Fragment activity results.");
    while (this.s.g(this.q) >= 0)
      this.q = ((1 + this.q) % 65534);
    int i1 = this.q;
    this.s.b(i1, paramFragment.A);
    this.q = ((1 + this.q) % 65534);
    return i1;
  }

  public final android.support.v4.media.session.d a()
  {
    return this.t;
  }

  final View a(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet)
  {
    return this.i.a(paramView, paramString, paramContext, paramAttributeSet);
  }

  public final void a(int paramInt)
  {
    if (this.p)
      this.p = false;
    while ((paramInt & 0xFFFFFF00) == 0)
      return;
    throw new IllegalArgumentException("Can only use lower 8 bits for requestCode");
  }

  public void a(Fragment paramFragment)
  {
  }

  public void a(Fragment paramFragment, Intent paramIntent, int paramInt)
  {
    a(paramFragment, paramIntent, paramInt, null);
  }

  public void a(Fragment paramFragment, Intent paramIntent, int paramInt, @y Bundle paramBundle)
  {
    this.r = true;
    if (paramInt == -1);
    try
    {
      d.a(this, paramIntent, -1, paramBundle);
      return;
      if ((0xFFFF0000 & paramInt) != 0)
        throw new IllegalArgumentException("Can only use lower 16 bits for requestCode");
    }
    finally
    {
      this.r = false;
    }
    d.a(this, paramIntent, (1 + b(paramFragment) << 16) + (0xFFFF & paramInt), paramBundle);
    this.r = false;
  }

  public void a(co paramco)
  {
    d.a(this, paramco);
  }

  public final void a(android.support.v4.media.session.d paramd)
  {
    this.t = paramd;
    if (Build.VERSION.SDK_INT >= 21)
      f.a(this, paramd.m());
  }

  void a(boolean paramBoolean)
  {
    if (!this.m)
    {
      this.m = true;
      this.n = paramBoolean;
      this.h.removeMessages(1);
      i();
    }
  }

  protected boolean a(View paramView, Menu paramMenu)
  {
    return super.onPreparePanel(0, paramView, paramMenu);
  }

  public void b(co paramco)
  {
    d.b(this, paramco);
  }

  public void c_()
  {
    d.c(this);
  }

  public void dump(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString)
  {
    if (Build.VERSION.SDK_INT >= 11);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("Local FragmentActivity ");
    paramPrintWriter.print(Integer.toHexString(System.identityHashCode(this)));
    paramPrintWriter.println(" State:");
    String str = paramString + "  ";
    paramPrintWriter.print(str);
    paramPrintWriter.print("mCreated=");
    paramPrintWriter.print(this.j);
    paramPrintWriter.print("mResumed=");
    paramPrintWriter.print(this.k);
    paramPrintWriter.print(" mStopped=");
    paramPrintWriter.print(this.l);
    paramPrintWriter.print(" mReallyStopped=");
    paramPrintWriter.println(this.m);
    this.i.a(str, paramFileDescriptor, paramPrintWriter, paramArrayOfString);
    this.i.a().a(paramString, paramFileDescriptor, paramPrintWriter, paramArrayOfString);
    paramPrintWriter.print(paramString);
    paramPrintWriter.println("View Hierarchy:");
    a(paramString + "  ", paramPrintWriter, getWindow().getDecorView());
  }

  protected void e()
  {
    this.i.j();
  }

  public Object f()
  {
    return null;
  }

  public Object g()
  {
    b localb = (b)getLastNonConfigurationInstance();
    if (localb != null)
      return localb.a;
    return null;
  }

  public void h()
  {
    if (Build.VERSION.SDK_INT >= 11)
    {
      i.a(this);
      return;
    }
    this.o = true;
  }

  void i()
  {
    this.i.a(this.n);
    this.i.m();
  }

  public ak j()
  {
    return this.i.a();
  }

  public void j_()
  {
    d.e(this);
  }

  public bi k()
  {
    return this.i.b();
  }

  public void k_()
  {
    d.f(this);
  }

  protected void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent)
  {
    this.i.d();
    int i1 = paramInt1 >> 16;
    if (i1 != 0)
    {
      int i2 = i1 - 1;
      String str = (String)this.s.a(i2);
      this.s.c(i2);
      if (str == null)
      {
        Log.w("FragmentActivity", "Activity result delivered for unknown Fragment.");
        return;
      }
      Fragment localFragment = this.i.a(str);
      if (localFragment == null)
      {
        Log.w("FragmentActivity", "Activity result no fragment exists for who: " + str);
        return;
      }
      localFragment.a(0xFFFF & paramInt1, paramInt2, paramIntent);
      return;
    }
    super.onActivityResult(paramInt1, paramInt2, paramIntent);
  }

  public void onBackPressed()
  {
    if (!this.i.a().e())
      c_();
  }

  public void onConfigurationChanged(Configuration paramConfiguration)
  {
    super.onConfigurationChanged(paramConfiguration);
    this.i.a(paramConfiguration);
  }

  protected void onCreate(@y Bundle paramBundle)
  {
    this.i.a(null);
    super.onCreate(paramBundle);
    b localb = (b)getLastNonConfigurationInstance();
    if (localb != null)
      this.i.a(localb.c);
    List localList;
    int[] arrayOfInt;
    String[] arrayOfString;
    if (paramBundle != null)
    {
      Parcelable localParcelable = paramBundle.getParcelable("android:support:fragments");
      ai localai = this.i;
      if (localb == null)
        break label165;
      localList = localb.b;
      localai.a(localParcelable, localList);
      if (paramBundle.containsKey("android:support:next_request_index"))
      {
        this.q = paramBundle.getInt("android:support:next_request_index");
        arrayOfInt = paramBundle.getIntArray("android:support:request_indicies");
        arrayOfString = paramBundle.getStringArray("android:support:request_fragment_who");
        if ((arrayOfInt != null) && (arrayOfString != null) && (arrayOfInt.length == arrayOfString.length))
          break label171;
        Log.w("FragmentActivity", "Invalid requestCode mapping in savedInstanceState.");
      }
    }
    while (true)
    {
      if (this.s == null)
      {
        this.s = new o();
        this.q = 0;
      }
      this.i.g();
      return;
      label165: localList = null;
      break;
      label171: this.s = new o(arrayOfInt.length);
      for (int i1 = 0; i1 < arrayOfInt.length; i1++)
        this.s.b(arrayOfInt[i1], arrayOfString[i1]);
    }
  }

  public boolean onCreatePanelMenu(int paramInt, Menu paramMenu)
  {
    if (paramInt == 0)
    {
      boolean bool = super.onCreatePanelMenu(paramInt, paramMenu) | this.i.a(paramMenu, getMenuInflater());
      if (Build.VERSION.SDK_INT >= 11)
        return bool;
      return true;
    }
    return super.onCreatePanelMenu(paramInt, paramMenu);
  }

  protected void onDestroy()
  {
    super.onDestroy();
    a(false);
    this.i.o();
    this.i.t();
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if ((Build.VERSION.SDK_INT < 5) && (paramInt == 4) && (paramKeyEvent.getRepeatCount() == 0))
    {
      onBackPressed();
      return true;
    }
    return super.onKeyDown(paramInt, paramKeyEvent);
  }

  public void onLowMemory()
  {
    super.onLowMemory();
    this.i.p();
  }

  public boolean onMenuItemSelected(int paramInt, MenuItem paramMenuItem)
  {
    if (super.onMenuItemSelected(paramInt, paramMenuItem))
      return true;
    switch (paramInt)
    {
    default:
      return false;
    case 0:
      return this.i.a(paramMenuItem);
    case 6:
    }
    return this.i.b(paramMenuItem);
  }

  protected void onNewIntent(Intent paramIntent)
  {
    super.onNewIntent(paramIntent);
    this.i.d();
  }

  public void onPanelClosed(int paramInt, Menu paramMenu)
  {
    switch (paramInt)
    {
    default:
    case 0:
    }
    while (true)
    {
      super.onPanelClosed(paramInt, paramMenu);
      return;
      this.i.b(paramMenu);
    }
  }

  protected void onPause()
  {
    super.onPause();
    this.k = false;
    if (this.h.hasMessages(2))
    {
      this.h.removeMessages(2);
      e();
    }
    this.i.k();
  }

  protected void onPostResume()
  {
    super.onPostResume();
    this.h.removeMessages(2);
    e();
    this.i.q();
  }

  public boolean onPreparePanel(int paramInt, View paramView, Menu paramMenu)
  {
    if ((paramInt == 0) && (paramMenu != null))
    {
      if (this.o)
      {
        this.o = false;
        paramMenu.clear();
        onCreatePanelMenu(paramInt, paramMenu);
      }
      return a(paramView, paramMenu) | this.i.a(paramMenu);
    }
    return super.onPreparePanel(paramInt, paramView, paramMenu);
  }

  public void onRequestPermissionsResult(int paramInt, @android.support.annotation.x String[] paramArrayOfString, @android.support.annotation.x int[] paramArrayOfInt)
  {
    int i1 = 0xFF & paramInt >> 8;
    int i2;
    int i3;
    if (i1 != 0)
    {
      i2 = i1 - 1;
      i3 = this.i.c();
      if ((i3 == 0) || (i2 < 0) || (i2 >= i3))
        Log.w("FragmentActivity", "Activity result fragment index out of range: 0x" + Integer.toHexString(paramInt));
    }
    else
    {
      return;
    }
    Fragment localFragment = (Fragment)this.i.a(new ArrayList(i3)).get(i2);
    if (localFragment == null)
    {
      Log.w("FragmentActivity", "Activity result no fragment exists for index: 0x" + Integer.toHexString(paramInt));
      return;
    }
    localFragment.a(paramInt & 0xFF, paramArrayOfString, paramArrayOfInt);
  }

  protected void onResume()
  {
    super.onResume();
    this.h.sendEmptyMessage(2);
    this.k = true;
    this.i.q();
  }

  public final Object onRetainNonConfigurationInstance()
  {
    if (this.l)
      a(true);
    Object localObject = f();
    List localList = this.i.f();
    n localn = this.i.v();
    if ((localList == null) && (localn == null) && (localObject == null))
      return null;
    b localb = new b();
    localb.a = localObject;
    localb.b = localList;
    localb.c = localn;
    return localb;
  }

  protected void onSaveInstanceState(Bundle paramBundle)
  {
    super.onSaveInstanceState(paramBundle);
    Parcelable localParcelable = this.i.e();
    if (localParcelable != null)
      paramBundle.putParcelable("android:support:fragments", localParcelable);
    if (this.s.b() > 0)
    {
      paramBundle.putInt("android:support:next_request_index", this.q);
      int[] arrayOfInt = new int[this.s.b()];
      String[] arrayOfString = new String[this.s.b()];
      for (int i1 = 0; i1 < this.s.b(); i1++)
      {
        arrayOfInt[i1] = this.s.e(i1);
        arrayOfString[i1] = ((String)this.s.f(i1));
      }
      paramBundle.putIntArray("android:support:request_indicies", arrayOfInt);
      paramBundle.putStringArray("android:support:request_fragment_who", arrayOfString);
    }
  }

  protected void onStart()
  {
    super.onStart();
    this.l = false;
    this.m = false;
    this.h.removeMessages(1);
    if (!this.j)
    {
      this.j = true;
      this.i.h();
    }
    this.i.d();
    this.i.q();
    this.i.r();
    this.i.i();
    this.i.u();
  }

  public void onStateNotSaved()
  {
    this.i.d();
  }

  protected void onStop()
  {
    super.onStop();
    this.l = true;
    this.h.sendEmptyMessage(1);
    this.i.l();
  }

  public void startActivityForResult(Intent paramIntent, int paramInt)
  {
    if ((!this.r) && (paramInt != -1) && ((0xFFFF0000 & paramInt) != 0))
      throw new IllegalArgumentException("Can only use lower 16 bits for requestCode");
    super.startActivityForResult(paramIntent, paramInt);
  }

  class a extends aj<af>
  {
    public a()
    {
      super();
    }

    @y
    public View a(int paramInt)
    {
      return af.this.findViewById(paramInt);
    }

    public void a(Fragment paramFragment, Intent paramIntent, int paramInt)
    {
      af.this.a(paramFragment, paramIntent, paramInt);
    }

    public void a(Fragment paramFragment, Intent paramIntent, int paramInt, @y Bundle paramBundle)
    {
      af.this.a(paramFragment, paramIntent, paramInt, paramBundle);
    }

    public void a(@android.support.annotation.x Fragment paramFragment, @android.support.annotation.x String[] paramArrayOfString, int paramInt)
    {
      af.a(af.this, paramFragment, paramArrayOfString, paramInt);
    }

    public void a(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString)
    {
      af.this.dump(paramString, paramFileDescriptor, paramPrintWriter, paramArrayOfString);
    }

    public boolean a()
    {
      Window localWindow = af.this.getWindow();
      return (localWindow != null) && (localWindow.peekDecorView() != null);
    }

    public boolean a(Fragment paramFragment)
    {
      return !af.this.isFinishing();
    }

    public boolean a(@android.support.annotation.x String paramString)
    {
      return d.a(af.this, paramString);
    }

    public LayoutInflater b()
    {
      return af.this.getLayoutInflater().cloneInContext(af.this);
    }

    public void b(Fragment paramFragment)
    {
      af.this.a(paramFragment);
    }

    public af c()
    {
      return af.this;
    }

    public void d()
    {
      af.this.h();
    }

    public boolean e()
    {
      return af.this.getWindow() != null;
    }

    public int f()
    {
      Window localWindow = af.this.getWindow();
      if (localWindow == null)
        return 0;
      return localWindow.getAttributes().windowAnimations;
    }
  }

  static final class b
  {
    Object a;
    List<Fragment> b;
    n<String, bi> c;
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.af
 * JD-Core Version:    0.6.2
 */