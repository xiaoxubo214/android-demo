package android.support.v4.app;

import android.os.Handler;
import android.os.Message;

class ag extends Handler
{
  ag(af paramaf)
  {
  }

  public void handleMessage(Message paramMessage)
  {
    switch (paramMessage.what)
    {
    default:
      super.handleMessage(paramMessage);
    case 1:
      do
        return;
      while (!this.a.l);
      this.a.a(false);
      return;
    case 2:
    }
    this.a.e();
    this.a.i.q();
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.ag
 * JD-Core Version:    0.6.2
 */