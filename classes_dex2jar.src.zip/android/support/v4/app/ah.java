package android.support.v4.app;

import android.support.annotation.p;
import android.support.annotation.y;
import android.view.View;

public abstract class ah
{
  @y
  public abstract View a(@p int paramInt);

  public abstract boolean a();
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.ah
 * JD-Core Version:    0.6.2
 */