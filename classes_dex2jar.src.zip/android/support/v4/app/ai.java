package android.support.v4.app;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Parcelable;
import android.support.annotation.y;
import android.support.v4.m.n;
import android.util.AttributeSet;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

public class ai
{
  private final aj<?> a;

  private ai(aj<?> paramaj)
  {
    this.a = paramaj;
  }

  public static final ai a(aj<?> paramaj)
  {
    return new ai(paramaj);
  }

  @y
  Fragment a(String paramString)
  {
    return this.a.d.b(paramString);
  }

  public ak a()
  {
    return this.a.k();
  }

  public View a(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet)
  {
    return this.a.d.a(paramView, paramString, paramContext, paramAttributeSet);
  }

  public List<Fragment> a(List<Fragment> paramList)
  {
    if (this.a.d.l == null)
      return null;
    if (paramList == null)
      paramList = new ArrayList(c());
    paramList.addAll(this.a.d.l);
    return paramList;
  }

  public void a(Configuration paramConfiguration)
  {
    this.a.d.a(paramConfiguration);
  }

  public void a(Parcelable paramParcelable, List<Fragment> paramList)
  {
    this.a.d.a(paramParcelable, paramList);
  }

  public void a(Fragment paramFragment)
  {
    this.a.d.a(this.a, this.a, paramFragment);
  }

  public void a(n<String, bi> paramn)
  {
    this.a.a(paramn);
  }

  public void a(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString)
  {
    this.a.b(paramString, paramFileDescriptor, paramPrintWriter, paramArrayOfString);
  }

  public void a(boolean paramBoolean)
  {
    this.a.a(paramBoolean);
  }

  public boolean a(Menu paramMenu)
  {
    return this.a.d.a(paramMenu);
  }

  public boolean a(Menu paramMenu, MenuInflater paramMenuInflater)
  {
    return this.a.d.a(paramMenu, paramMenuInflater);
  }

  public boolean a(MenuItem paramMenuItem)
  {
    return this.a.d.a(paramMenuItem);
  }

  public bi b()
  {
    return this.a.l();
  }

  public void b(Menu paramMenu)
  {
    this.a.d.b(paramMenu);
  }

  public boolean b(MenuItem paramMenuItem)
  {
    return this.a.d.b(paramMenuItem);
  }

  public int c()
  {
    ArrayList localArrayList = this.a.d.l;
    if (localArrayList == null)
      return 0;
    return localArrayList.size();
  }

  public void d()
  {
    this.a.d.n();
  }

  public Parcelable e()
  {
    return this.a.d.m();
  }

  public List<Fragment> f()
  {
    return this.a.d.l();
  }

  public void g()
  {
    this.a.d.o();
  }

  public void h()
  {
    this.a.d.p();
  }

  public void i()
  {
    this.a.d.q();
  }

  public void j()
  {
    this.a.d.r();
  }

  public void k()
  {
    this.a.d.s();
  }

  public void l()
  {
    this.a.d.t();
  }

  public void m()
  {
    this.a.d.u();
  }

  public void n()
  {
    this.a.d.v();
  }

  public void o()
  {
    this.a.d.w();
  }

  public void p()
  {
    this.a.d.x();
  }

  public boolean q()
  {
    return this.a.d.j();
  }

  public void r()
  {
    this.a.n();
  }

  public void s()
  {
    this.a.o();
  }

  public void t()
  {
    this.a.p();
  }

  public void u()
  {
    this.a.q();
  }

  public n<String, bi> v()
  {
    return this.a.r();
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.ai
 * JD-Core Version:    0.6.2
 */