package android.support.v4.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.x;
import android.support.annotation.y;
import android.support.v4.m.n;
import android.view.LayoutInflater;
import android.view.View;
import java.io.FileDescriptor;
import java.io.PrintWriter;

public abstract class aj<E> extends ah
{
  private final Activity a;
  final Context b;
  final int c;
  final al d = new al();
  private final Handler e;
  private n<String, bi> f;
  private boolean g;
  private bj h;
  private boolean i;
  private boolean j;

  aj(Activity paramActivity, Context paramContext, Handler paramHandler, int paramInt)
  {
    this.a = paramActivity;
    this.b = paramContext;
    this.e = paramHandler;
    this.c = paramInt;
  }

  public aj(Context paramContext, Handler paramHandler, int paramInt)
  {
    this(null, paramContext, paramHandler, paramInt);
  }

  aj(af paramaf)
  {
    this(paramaf, paramaf, paramaf.h, 0);
  }

  bj a(String paramString, boolean paramBoolean1, boolean paramBoolean2)
  {
    if (this.f == null)
      this.f = new n();
    bj localbj = (bj)this.f.get(paramString);
    if (localbj == null)
    {
      if (paramBoolean2)
      {
        localbj = new bj(paramString, this, paramBoolean1);
        this.f.put(paramString, localbj);
      }
      return localbj;
    }
    localbj.a(this);
    return localbj;
  }

  @y
  public View a(int paramInt)
  {
    return null;
  }

  public void a(Fragment paramFragment, Intent paramIntent, int paramInt)
  {
    a(paramFragment, paramIntent, paramInt, null);
  }

  public void a(Fragment paramFragment, Intent paramIntent, int paramInt, @y Bundle paramBundle)
  {
    if (paramInt != -1)
      throw new IllegalStateException("Starting activity with a requestCode requires a FragmentActivity host");
    this.b.startActivity(paramIntent);
  }

  public void a(@x Fragment paramFragment, @x String[] paramArrayOfString, int paramInt)
  {
  }

  void a(n<String, bi> paramn)
  {
    this.f = paramn;
  }

  public void a(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString)
  {
  }

  void a(boolean paramBoolean)
  {
    this.g = paramBoolean;
    if (this.h == null);
    while (!this.j)
      return;
    this.j = false;
    if (paramBoolean)
    {
      this.h.d();
      return;
    }
    this.h.c();
  }

  public boolean a()
  {
    return true;
  }

  public boolean a(Fragment paramFragment)
  {
    return true;
  }

  public boolean a(@x String paramString)
  {
    return false;
  }

  public LayoutInflater b()
  {
    return (LayoutInflater)this.b.getSystemService("layout_inflater");
  }

  void b(Fragment paramFragment)
  {
  }

  void b(String paramString)
  {
    if (this.f != null)
    {
      bj localbj = (bj)this.f.get(paramString);
      if ((localbj != null) && (!localbj.g))
      {
        localbj.h();
        this.f.remove(paramString);
      }
    }
  }

  void b(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString)
  {
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mLoadersStarted=");
    paramPrintWriter.println(this.j);
    if (this.h != null)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("Loader Manager ");
      paramPrintWriter.print(Integer.toHexString(System.identityHashCode(this.h)));
      paramPrintWriter.println(":");
      this.h.a(paramString + "  ", paramFileDescriptor, paramPrintWriter, paramArrayOfString);
    }
  }

  public void d()
  {
  }

  public boolean e()
  {
    return true;
  }

  public int f()
  {
    return this.c;
  }

  @y
  public abstract E g();

  Activity h()
  {
    return this.a;
  }

  Context i()
  {
    return this.b;
  }

  Handler j()
  {
    return this.e;
  }

  al k()
  {
    return this.d;
  }

  bj l()
  {
    if (this.h != null)
      return this.h;
    this.i = true;
    this.h = a("(root)", this.j, true);
    return this.h;
  }

  boolean m()
  {
    return this.g;
  }

  void n()
  {
    if (this.j)
      return;
    this.j = true;
    if (this.h != null)
      this.h.b();
    while (true)
    {
      this.i = true;
      return;
      if (!this.i)
      {
        this.h = a("(root)", this.j, false);
        if ((this.h != null) && (!this.h.f))
          this.h.b();
      }
    }
  }

  void o()
  {
    if (this.h == null)
      return;
    this.h.d();
  }

  void p()
  {
    if (this.h == null)
      return;
    this.h.h();
  }

  void q()
  {
    if (this.f != null)
    {
      int k = this.f.size();
      bj[] arrayOfbj = new bj[k];
      for (int m = k - 1; m >= 0; m--)
        arrayOfbj[m] = ((bj)this.f.c(m));
      for (int n = 0; n < k; n++)
      {
        bj localbj = arrayOfbj[n];
        localbj.e();
        localbj.g();
      }
    }
  }

  n<String, bi> r()
  {
    int k = 0;
    int m;
    if (this.f != null)
    {
      int n = this.f.size();
      bj[] arrayOfbj = new bj[n];
      for (int i1 = n - 1; i1 >= 0; i1--)
        arrayOfbj[i1] = ((bj)this.f.c(i1));
      m = 0;
      if (k < n)
      {
        bj localbj = arrayOfbj[k];
        if (localbj.g)
          m = 1;
        while (true)
        {
          k++;
          break;
          localbj.h();
          this.f.remove(localbj.e);
        }
      }
    }
    else
    {
      m = 0;
    }
    if (m != 0)
      return this.f;
    return null;
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.aj
 * JD-Core Version:    0.6.2
 */