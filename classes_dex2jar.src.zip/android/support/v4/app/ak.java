package android.support.v4.app;

import android.os.Bundle;
import android.support.annotation.ae;
import android.support.annotation.p;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.List;

public abstract class ak
{
  public static final int a = 1;

  public static void a(boolean paramBoolean)
  {
    al.b = paramBoolean;
  }

  public abstract Fragment.SavedState a(Fragment paramFragment);

  public abstract Fragment a(@p int paramInt);

  public abstract Fragment a(Bundle paramBundle, String paramString);

  public abstract Fragment a(String paramString);

  public abstract ay a();

  public abstract void a(int paramInt1, int paramInt2);

  public abstract void a(Bundle paramBundle, String paramString, Fragment paramFragment);

  public abstract void a(b paramb);

  public abstract void a(String paramString, int paramInt);

  public abstract void a(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString);

  public abstract a b(int paramInt);

  @Deprecated
  public ay b()
  {
    return a();
  }

  public abstract void b(b paramb);

  public abstract boolean b(int paramInt1, int paramInt2);

  public abstract boolean b(String paramString, int paramInt);

  public abstract boolean c();

  public abstract void d();

  public abstract boolean e();

  public abstract int f();

  public abstract List<Fragment> g();

  public abstract boolean h();

  public static abstract interface a
  {
    public abstract int a();

    @ae
    public abstract int b();

    @ae
    public abstract int c();

    public abstract CharSequence d();

    public abstract CharSequence e();

    public abstract String j();
  }

  public static abstract interface b
  {
    public abstract void a();
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.ak
 * JD-Core Version:    0.6.2
 */