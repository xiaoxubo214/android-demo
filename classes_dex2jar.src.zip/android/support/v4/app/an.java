package android.support.v4.app;

class an
  implements Runnable
{
  an(al paramal)
  {
  }

  public void run()
  {
    this.a.a(this.a.u.j(), null, -1, 0);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.an
 * JD-Core Version:    0.6.2
 */