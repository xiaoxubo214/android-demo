package android.support.v4.app;

import android.view.View;
import android.view.animation.Animation;

class aq extends al.a
{
  aq(al paramal, View paramView, Animation paramAnimation, Fragment paramFragment)
  {
    super(paramView, paramAnimation);
  }

  public void onAnimationEnd(Animation paramAnimation)
  {
    super.onAnimationEnd(paramAnimation);
    if (this.a.v != null)
    {
      this.a.v = null;
      this.b.a(this.a, this.a.w, 0, 0, false);
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.aq
 * JD-Core Version:    0.6.2
 */