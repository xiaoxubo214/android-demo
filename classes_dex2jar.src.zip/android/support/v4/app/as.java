package android.support.v4.app;

import android.support.v4.view.aw;

class as
  implements Runnable
{
  as(al.a parama)
  {
  }

  public void run()
  {
    aw.a(al.a.a(this.a), 0, null);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.as
 * JD-Core Version:    0.6.2
 */