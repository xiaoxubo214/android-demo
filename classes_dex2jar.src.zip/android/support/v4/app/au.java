package android.support.v4.app;

import android.os.Parcelable;
import android.view.View;
import android.view.ViewGroup;

public abstract class au extends android.support.v4.view.ak
{
  private static final String a = "FragmentPagerAdapter";
  private static final boolean b;
  private final ak c;
  private ay d = null;
  private Fragment e = null;

  public au(ak paramak)
  {
    this.c = paramak;
  }

  private static String a(int paramInt, long paramLong)
  {
    return "android:switcher:" + paramInt + ":" + paramLong;
  }

  public abstract Fragment a(int paramInt);

  public long b(int paramInt)
  {
    return paramInt;
  }

  public void destroyItem(ViewGroup paramViewGroup, int paramInt, Object paramObject)
  {
    if (this.d == null)
      this.d = this.c.a();
    this.d.d((Fragment)paramObject);
  }

  public void finishUpdate(ViewGroup paramViewGroup)
  {
    if (this.d != null)
    {
      this.d.i();
      this.d = null;
      this.c.c();
    }
  }

  public Object instantiateItem(ViewGroup paramViewGroup, int paramInt)
  {
    if (this.d == null)
      this.d = this.c.a();
    long l = b(paramInt);
    String str = a(paramViewGroup.getId(), l);
    Fragment localFragment = this.c.a(str);
    if (localFragment != null)
      this.d.e(localFragment);
    while (true)
    {
      if (localFragment != this.e)
      {
        localFragment.f(false);
        localFragment.g(false);
      }
      return localFragment;
      localFragment = a(paramInt);
      this.d.a(paramViewGroup.getId(), localFragment, a(paramViewGroup.getId(), l));
    }
  }

  public boolean isViewFromObject(View paramView, Object paramObject)
  {
    return ((Fragment)paramObject).J() == paramView;
  }

  public void restoreState(Parcelable paramParcelable, ClassLoader paramClassLoader)
  {
  }

  public Parcelable saveState()
  {
    return null;
  }

  public void setPrimaryItem(ViewGroup paramViewGroup, int paramInt, Object paramObject)
  {
    Fragment localFragment = (Fragment)paramObject;
    if (localFragment != this.e)
    {
      if (this.e != null)
      {
        this.e.f(false);
        this.e.g(false);
      }
      if (localFragment != null)
      {
        localFragment.f(true);
        localFragment.g(true);
      }
      this.e = localFragment;
    }
  }

  public void startUpdate(ViewGroup paramViewGroup)
  {
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.au
 * JD-Core Version:    0.6.2
 */