package android.support.v4.app;

import android.os.Parcel;
import android.os.Parcelable.Creator;

final class av
  implements Parcelable.Creator<FragmentState>
{
  public FragmentState a(Parcel paramParcel)
  {
    return new FragmentState(paramParcel);
  }

  public FragmentState[] a(int paramInt)
  {
    return new FragmentState[paramInt];
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.av
 * JD-Core Version:    0.6.2
 */