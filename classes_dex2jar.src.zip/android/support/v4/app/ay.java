package android.support.v4.app;

import android.support.annotation.a;
import android.support.annotation.ae;
import android.support.annotation.af;
import android.support.annotation.p;
import android.support.annotation.y;
import android.view.View;

public abstract class ay
{
  public static final int F = 4096;
  public static final int G = 8192;
  public static final int H = -1;
  public static final int I = 0;
  public static final int J = 4097;
  public static final int K = 8194;
  public static final int L = 4099;

  public abstract ay a(int paramInt);

  public abstract ay a(@a int paramInt1, @a int paramInt2);

  public abstract ay a(@a int paramInt1, @a int paramInt2, @a int paramInt3, @a int paramInt4);

  public abstract ay a(@p int paramInt, Fragment paramFragment);

  public abstract ay a(@p int paramInt, Fragment paramFragment, @y String paramString);

  public abstract ay a(Fragment paramFragment);

  public abstract ay a(Fragment paramFragment, String paramString);

  public abstract ay a(View paramView, String paramString);

  public abstract ay a(CharSequence paramCharSequence);

  public abstract ay a(@y String paramString);

  public abstract ay b(@af int paramInt);

  public abstract ay b(@p int paramInt, Fragment paramFragment);

  public abstract ay b(@p int paramInt, Fragment paramFragment, @y String paramString);

  public abstract ay b(Fragment paramFragment);

  public abstract ay b(CharSequence paramCharSequence);

  public abstract ay c(@ae int paramInt);

  public abstract ay c(Fragment paramFragment);

  public abstract ay d(@ae int paramInt);

  public abstract ay d(Fragment paramFragment);

  public abstract ay e(Fragment paramFragment);

  public abstract boolean f();

  public abstract ay g();

  public abstract int h();

  public abstract int i();

  public abstract boolean m();
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.ay
 * JD-Core Version:    0.6.2
 */