package android.support.v4.app;

import android.graphics.Rect;
import android.transition.Transition;
import android.transition.TransitionManager;
import android.transition.TransitionSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

class az
{
  public static Object a(Object paramObject)
  {
    if (paramObject != null)
      paramObject = ((Transition)paramObject).clone();
    return paramObject;
  }

  public static Object a(Object paramObject, View paramView1, ArrayList<View> paramArrayList, Map<String, View> paramMap, View paramView2)
  {
    if (paramObject != null)
    {
      b(paramArrayList, paramView1);
      if (paramMap != null)
        paramArrayList.removeAll(paramMap.values());
      if (paramArrayList.isEmpty())
        paramObject = null;
    }
    else
    {
      return paramObject;
    }
    paramArrayList.add(paramView2);
    b((Transition)paramObject, paramArrayList);
    return paramObject;
  }

  public static Object a(Object paramObject1, Object paramObject2, Object paramObject3, boolean paramBoolean)
  {
    Transition localTransition1 = (Transition)paramObject1;
    Transition localTransition2 = (Transition)paramObject2;
    Transition localTransition3 = (Transition)paramObject3;
    if ((localTransition1 != null) && (localTransition2 != null));
    while (true)
    {
      if (paramBoolean)
      {
        TransitionSet localTransitionSet1 = new TransitionSet();
        if (localTransition1 != null)
          localTransitionSet1.addTransition(localTransition1);
        if (localTransition2 != null)
          localTransitionSet1.addTransition(localTransition2);
        if (localTransition3 != null)
          localTransitionSet1.addTransition(localTransition3);
        return localTransitionSet1;
      }
      Object localObject;
      if ((localTransition2 != null) && (localTransition1 != null))
        localObject = new TransitionSet().addTransition(localTransition2).addTransition(localTransition1).setOrdering(1);
      while (localTransition3 != null)
      {
        TransitionSet localTransitionSet2 = new TransitionSet();
        if (localObject != null)
          localTransitionSet2.addTransition((Transition)localObject);
        localTransitionSet2.addTransition(localTransition3);
        return localTransitionSet2;
        if (localTransition2 != null)
        {
          localObject = localTransition2;
        }
        else
        {
          localObject = null;
          if (localTransition1 != null)
            localObject = localTransition1;
        }
      }
      return localObject;
      paramBoolean = true;
    }
  }

  public static String a(View paramView)
  {
    return paramView.getTransitionName();
  }

  private static void a(Transition paramTransition, a parama)
  {
    if (paramTransition != null)
      paramTransition.setEpicenterCallback(new bc(parama));
  }

  public static void a(View paramView1, View paramView2, Object paramObject1, ArrayList<View> paramArrayList1, Object paramObject2, ArrayList<View> paramArrayList2, Object paramObject3, ArrayList<View> paramArrayList3, Object paramObject4, ArrayList<View> paramArrayList4, Map<String, View> paramMap)
  {
    Transition localTransition1 = (Transition)paramObject1;
    Transition localTransition2 = (Transition)paramObject2;
    Transition localTransition3 = (Transition)paramObject3;
    Transition localTransition4 = (Transition)paramObject4;
    if (localTransition4 != null)
      paramView1.getViewTreeObserver().addOnPreDrawListener(new bd(paramView1, localTransition1, paramArrayList1, localTransition2, paramArrayList2, localTransition3, paramArrayList3, paramMap, paramArrayList4, localTransition4, paramView2));
  }

  public static void a(ViewGroup paramViewGroup, Object paramObject)
  {
    TransitionManager.beginDelayedTransition(paramViewGroup, (Transition)paramObject);
  }

  public static void a(Object paramObject, View paramView)
  {
    ((Transition)paramObject).setEpicenterCallback(new ba(c(paramView)));
  }

  public static void a(Object paramObject, View paramView, Map<String, View> paramMap, ArrayList<View> paramArrayList)
  {
    TransitionSet localTransitionSet = (TransitionSet)paramObject;
    paramArrayList.clear();
    paramArrayList.addAll(paramMap.values());
    List localList = localTransitionSet.getTargets();
    localList.clear();
    int i = paramArrayList.size();
    for (int j = 0; j < i; j++)
      a(localList, (View)paramArrayList.get(j));
    paramArrayList.add(paramView);
    b(localTransitionSet, paramArrayList);
  }

  public static void a(Object paramObject, View paramView, boolean paramBoolean)
  {
    ((Transition)paramObject).excludeTarget(paramView, paramBoolean);
  }

  public static void a(Object paramObject1, Object paramObject2, View paramView1, b paramb, View paramView2, a parama, Map<String, String> paramMap, ArrayList<View> paramArrayList1, Map<String, View> paramMap1, Map<String, View> paramMap2, ArrayList<View> paramArrayList2)
  {
    if ((paramObject1 != null) || (paramObject2 != null))
    {
      Transition localTransition = (Transition)paramObject1;
      if (localTransition != null)
        localTransition.addTarget(paramView2);
      if (paramObject2 != null)
        a(paramObject2, paramView2, paramMap1, paramArrayList2);
      if (paramb != null)
        paramView1.getViewTreeObserver().addOnPreDrawListener(new bb(paramView1, localTransition, paramView2, paramb, paramMap, paramMap2, paramArrayList1));
      a(localTransition, parama);
    }
  }

  public static void a(Object paramObject, ArrayList<View> paramArrayList)
  {
    Transition localTransition = (Transition)paramObject;
    if ((localTransition instanceof TransitionSet))
    {
      TransitionSet localTransitionSet = (TransitionSet)localTransition;
      int j = localTransitionSet.getTransitionCount();
      for (int k = 0; k < j; k++)
        a(localTransitionSet.getTransitionAt(k), paramArrayList);
    }
    if (!a(localTransition))
    {
      List localList = localTransition.getTargets();
      if ((localList != null) && (localList.size() == paramArrayList.size()) && (localList.containsAll(paramArrayList)))
        for (int i = -1 + paramArrayList.size(); i >= 0; i--)
          localTransition.removeTarget((View)paramArrayList.get(i));
    }
  }

  private static void a(List<View> paramList, View paramView)
  {
    int i = paramList.size();
    if (a(paramList, paramView, i));
    while (true)
    {
      return;
      paramList.add(paramView);
      for (int j = i; j < paramList.size(); j++)
      {
        View localView1 = (View)paramList.get(j);
        if ((localView1 instanceof ViewGroup))
        {
          ViewGroup localViewGroup = (ViewGroup)localView1;
          int k = localViewGroup.getChildCount();
          for (int m = 0; m < k; m++)
          {
            View localView2 = localViewGroup.getChildAt(m);
            if (!a(paramList, localView2, i))
              paramList.add(localView2);
          }
        }
      }
    }
  }

  public static void a(Map<String, View> paramMap, View paramView)
  {
    if (paramView.getVisibility() == 0)
    {
      String str = paramView.getTransitionName();
      if (str != null)
        paramMap.put(str, paramView);
      if ((paramView instanceof ViewGroup))
      {
        ViewGroup localViewGroup = (ViewGroup)paramView;
        int i = localViewGroup.getChildCount();
        for (int j = 0; j < i; j++)
          a(paramMap, localViewGroup.getChildAt(j));
      }
    }
  }

  private static boolean a(Transition paramTransition)
  {
    return (!a(paramTransition.getTargetIds())) || (!a(paramTransition.getTargetNames())) || (!a(paramTransition.getTargetTypes()));
  }

  private static boolean a(List paramList)
  {
    return (paramList == null) || (paramList.isEmpty());
  }

  private static boolean a(List<View> paramList, View paramView, int paramInt)
  {
    for (int i = 0; ; i++)
    {
      boolean bool = false;
      if (i < paramInt)
      {
        if (paramList.get(i) == paramView)
          bool = true;
      }
      else
        return bool;
    }
  }

  public static Object b(Object paramObject)
  {
    if (paramObject == null);
    Transition localTransition;
    do
    {
      return null;
      localTransition = (Transition)paramObject;
    }
    while (localTransition == null);
    TransitionSet localTransitionSet = new TransitionSet();
    localTransitionSet.addTransition(localTransition);
    return localTransitionSet;
  }

  public static void b(Object paramObject, ArrayList<View> paramArrayList)
  {
    int i = 0;
    Transition localTransition = (Transition)paramObject;
    if ((localTransition instanceof TransitionSet))
    {
      TransitionSet localTransitionSet = (TransitionSet)localTransition;
      int m = localTransitionSet.getTransitionCount();
      while (i < m)
      {
        b(localTransitionSet.getTransitionAt(i), paramArrayList);
        i++;
      }
    }
    if ((!a(localTransition)) && (a(localTransition.getTargets())))
    {
      int j = paramArrayList.size();
      for (int k = 0; k < j; k++)
        localTransition.addTarget((View)paramArrayList.get(k));
    }
  }

  private static void b(ArrayList<View> paramArrayList, View paramView)
  {
    ViewGroup localViewGroup;
    if (paramView.getVisibility() == 0)
    {
      if (!(paramView instanceof ViewGroup))
        break label65;
      localViewGroup = (ViewGroup)paramView;
      if (!localViewGroup.isTransitionGroup())
        break label33;
      paramArrayList.add(localViewGroup);
    }
    while (true)
    {
      return;
      label33: int i = localViewGroup.getChildCount();
      for (int j = 0; j < i; j++)
        b(paramArrayList, localViewGroup.getChildAt(j));
    }
    label65: paramArrayList.add(paramView);
  }

  private static Rect c(View paramView)
  {
    Rect localRect = new Rect();
    int[] arrayOfInt = new int[2];
    paramView.getLocationOnScreen(arrayOfInt);
    localRect.set(arrayOfInt[0], arrayOfInt[1], arrayOfInt[0] + paramView.getWidth(), arrayOfInt[1] + paramView.getHeight());
    return localRect;
  }

  public static class a
  {
    public View a;
  }

  public static abstract interface b
  {
    public abstract View a();
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.az
 * JD-Core Version:    0.6.2
 */