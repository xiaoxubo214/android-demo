package android.support.v4.app;

import android.app.ActionBar;
import android.app.Activity;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import java.lang.reflect.Method;

class b
{
  private static final String a = "ActionBarDrawerToggleHoneycomb";
  private static final int[] b = { 16843531 };

  public static Drawable a(Activity paramActivity)
  {
    TypedArray localTypedArray = paramActivity.obtainStyledAttributes(b);
    Drawable localDrawable = localTypedArray.getDrawable(0);
    localTypedArray.recycle();
    return localDrawable;
  }

  public static Object a(Object paramObject, Activity paramActivity, int paramInt)
  {
    if (paramObject == null);
    for (Object localObject = new a(paramActivity); ; localObject = paramObject)
    {
      a locala = (a)localObject;
      if (locala.a != null);
      try
      {
        ActionBar localActionBar = paramActivity.getActionBar();
        Method localMethod = locala.b;
        Object[] arrayOfObject = new Object[1];
        arrayOfObject[0] = Integer.valueOf(paramInt);
        localMethod.invoke(localActionBar, arrayOfObject);
        if (Build.VERSION.SDK_INT <= 19)
          localActionBar.setSubtitle(localActionBar.getSubtitle());
        return localObject;
      }
      catch (Exception localException)
      {
        Log.w("ActionBarDrawerToggleHoneycomb", "Couldn't set content description via JB-MR2 API", localException);
        return localObject;
      }
    }
  }

  public static Object a(Object paramObject, Activity paramActivity, Drawable paramDrawable, int paramInt)
  {
    if (paramObject == null);
    for (Object localObject = new a(paramActivity); ; localObject = paramObject)
    {
      a locala = (a)localObject;
      if (locala.a != null)
        try
        {
          ActionBar localActionBar = paramActivity.getActionBar();
          locala.a.invoke(localActionBar, new Object[] { paramDrawable });
          Method localMethod = locala.b;
          Object[] arrayOfObject = new Object[1];
          arrayOfObject[0] = Integer.valueOf(paramInt);
          localMethod.invoke(localActionBar, arrayOfObject);
          return localObject;
        }
        catch (Exception localException)
        {
          Log.w("ActionBarDrawerToggleHoneycomb", "Couldn't set home-as-up indicator via JB-MR2 API", localException);
          return localObject;
        }
      if (locala.c != null)
      {
        locala.c.setImageDrawable(paramDrawable);
        return localObject;
      }
      Log.w("ActionBarDrawerToggleHoneycomb", "Couldn't set home-as-up indicator");
      return localObject;
    }
  }

  private static class a
  {
    public Method a;
    public Method b;
    public ImageView c;

    a(Activity paramActivity)
    {
      while (true)
      {
        View localView2;
        View localView3;
        try
        {
          this.a = ActionBar.class.getDeclaredMethod("setHomeAsUpIndicator", new Class[] { Drawable.class });
          Class[] arrayOfClass = new Class[1];
          arrayOfClass[0] = Integer.TYPE;
          this.b = ActionBar.class.getDeclaredMethod("setHomeActionContentDescription", arrayOfClass);
          return;
        }
        catch (NoSuchMethodException localNoSuchMethodException)
        {
          View localView1 = paramActivity.findViewById(16908332);
          if (localView1 == null)
            continue;
          ViewGroup localViewGroup = (ViewGroup)localView1.getParent();
          if (localViewGroup.getChildCount() != 2)
            continue;
          localView2 = localViewGroup.getChildAt(0);
          localView3 = localViewGroup.getChildAt(1);
          if (localView2.getId() != 16908332);
        }
        while ((localView3 instanceof ImageView))
        {
          this.c = ((ImageView)localView3);
          return;
          localView3 = localView2;
        }
      }
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.b
 * JD-Core Version:    0.6.2
 */