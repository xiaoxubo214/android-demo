package android.support.v4.app;

import android.graphics.Rect;
import android.transition.Transition;
import android.transition.Transition.EpicenterCallback;

final class ba extends Transition.EpicenterCallback
{
  ba(Rect paramRect)
  {
  }

  public Rect onGetEpicenter(Transition paramTransition)
  {
    return this.a;
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.ba
 * JD-Core Version:    0.6.2
 */