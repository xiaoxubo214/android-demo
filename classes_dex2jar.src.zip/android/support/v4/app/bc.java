package android.support.v4.app;

import android.graphics.Rect;
import android.transition.Transition;
import android.transition.Transition.EpicenterCallback;

final class bc extends Transition.EpicenterCallback
{
  private Rect b;

  bc(az.a parama)
  {
  }

  public Rect onGetEpicenter(Transition paramTransition)
  {
    if ((this.b == null) && (this.a.a != null))
      this.b = az.b(this.a.a);
    return this.b;
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.bc
 * JD-Core Version:    0.6.2
 */