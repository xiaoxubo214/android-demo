package android.support.v4.app;

import android.os.Bundle;
import android.support.v4.c.r;
import java.io.FileDescriptor;
import java.io.PrintWriter;

public abstract class bi
{
  public static void a(boolean paramBoolean)
  {
    bj.b = paramBoolean;
  }

  public abstract <D> r<D> a(int paramInt, Bundle paramBundle, a<D> parama);

  public abstract void a(int paramInt);

  public abstract void a(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString);

  public boolean a()
  {
    return false;
  }

  public abstract <D> r<D> b(int paramInt);

  public abstract <D> r<D> b(int paramInt, Bundle paramBundle, a<D> parama);

  public static abstract interface a<D>
  {
    public abstract r<D> a(int paramInt, Bundle paramBundle);

    public abstract void a(r<D> paramr);

    public abstract void a(r<D> paramr, D paramD);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.bi
 * JD-Core Version:    0.6.2
 */