package android.support.v4.app;

import android.os.Bundle;
import android.support.v4.c.r;
import android.support.v4.c.r.b;
import android.support.v4.c.r.c;
import android.support.v4.m.g;
import android.support.v4.m.o;
import android.util.Log;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.lang.reflect.Modifier;

class bj extends bi
{
  static final String a = "LoaderManager";
  static boolean b = false;
  final o<a> c = new o();
  final o<a> d = new o();
  final String e;
  boolean f;
  boolean g;
  boolean h;
  boolean i;
  private aj j;

  bj(String paramString, aj paramaj, boolean paramBoolean)
  {
    this.e = paramString;
    this.j = paramaj;
    this.f = paramBoolean;
  }

  private a c(int paramInt, Bundle paramBundle, bi.a<Object> parama)
  {
    a locala = new a(paramInt, paramBundle, parama);
    locala.d = parama.a(paramInt, paramBundle);
    return locala;
  }

  private a d(int paramInt, Bundle paramBundle, bi.a<Object> parama)
  {
    try
    {
      this.i = true;
      a locala = c(paramInt, paramBundle, parama);
      a(locala);
      return locala;
    }
    finally
    {
      this.i = false;
    }
  }

  public <D> r<D> a(int paramInt, Bundle paramBundle, bi.a<D> parama)
  {
    if (this.i)
      throw new IllegalStateException("Called while creating a loader");
    a locala = (a)this.c.a(paramInt);
    if (b)
      Log.v("LoaderManager", "initLoader in " + this + ": args=" + paramBundle);
    if (locala == null)
    {
      locala = d(paramInt, paramBundle, parama);
      if (b)
        Log.v("LoaderManager", "  Created new loader " + locala);
    }
    while (true)
    {
      if ((locala.e) && (this.f))
        locala.b(locala.d, locala.g);
      return locala.d;
      if (b)
        Log.v("LoaderManager", "  Re-using existing loader " + locala);
      locala.c = parama;
    }
  }

  public void a(int paramInt)
  {
    if (this.i)
      throw new IllegalStateException("Called while creating a loader");
    if (b)
      Log.v("LoaderManager", "destroyLoader in " + this + " of " + paramInt);
    int k = this.c.g(paramInt);
    if (k >= 0)
    {
      a locala2 = (a)this.c.f(k);
      this.c.d(k);
      locala2.g();
    }
    int m = this.d.g(paramInt);
    if (m >= 0)
    {
      a locala1 = (a)this.d.f(m);
      this.d.d(m);
      locala1.g();
    }
    if ((this.j != null) && (!a()))
      this.j.d.i();
  }

  void a(aj paramaj)
  {
    this.j = paramaj;
  }

  void a(a parama)
  {
    this.c.b(parama.a, parama);
    if (this.f)
      parama.a();
  }

  public void a(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString)
  {
    int k = 0;
    if (this.c.b() > 0)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.println("Active Loaders:");
      String str2 = paramString + "    ";
      for (int m = 0; m < this.c.b(); m++)
      {
        a locala2 = (a)this.c.f(m);
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("  #");
        paramPrintWriter.print(this.c.e(m));
        paramPrintWriter.print(": ");
        paramPrintWriter.println(locala2.toString());
        locala2.a(str2, paramFileDescriptor, paramPrintWriter, paramArrayOfString);
      }
    }
    if (this.d.b() > 0)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.println("Inactive Loaders:");
      String str1 = paramString + "    ";
      while (k < this.d.b())
      {
        a locala1 = (a)this.d.f(k);
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("  #");
        paramPrintWriter.print(this.d.e(k));
        paramPrintWriter.print(": ");
        paramPrintWriter.println(locala1.toString());
        locala1.a(str1, paramFileDescriptor, paramPrintWriter, paramArrayOfString);
        k++;
      }
    }
  }

  public boolean a()
  {
    int k = this.c.b();
    int m = 0;
    boolean bool1 = false;
    if (m < k)
    {
      a locala = (a)this.c.f(m);
      if ((locala.h) && (!locala.f));
      for (boolean bool2 = true; ; bool2 = false)
      {
        bool1 |= bool2;
        m++;
        break;
      }
    }
    return bool1;
  }

  public <D> r<D> b(int paramInt)
  {
    if (this.i)
      throw new IllegalStateException("Called while creating a loader");
    a locala = (a)this.c.a(paramInt);
    if (locala != null)
    {
      if (locala.n != null)
        return locala.n.d;
      return locala.d;
    }
    return null;
  }

  public <D> r<D> b(int paramInt, Bundle paramBundle, bi.a<D> parama)
  {
    if (this.i)
      throw new IllegalStateException("Called while creating a loader");
    a locala1 = (a)this.c.a(paramInt);
    if (b)
      Log.v("LoaderManager", "restartLoader in " + this + ": args=" + paramBundle);
    if (locala1 != null)
    {
      a locala2 = (a)this.d.a(paramInt);
      if (locala2 == null)
        break label323;
      if (!locala1.e)
        break label173;
      if (b)
        Log.v("LoaderManager", "  Removing last inactive loader: " + locala1);
      locala2.f = false;
      locala2.g();
      locala1.d.B();
      this.d.b(paramInt, locala1);
    }
    while (true)
    {
      return d(paramInt, paramBundle, parama).d;
      label173: if (!locala1.h)
      {
        if (b)
          Log.v("LoaderManager", "  Current loader is stopped; replacing");
        this.c.b(paramInt, null);
        locala1.g();
      }
      else
      {
        if (b)
          Log.v("LoaderManager", "  Current loader is running; attempting to cancel");
        locala1.f();
        if (locala1.n != null)
        {
          if (b)
            Log.v("LoaderManager", "  Removing pending loader: " + locala1.n);
          locala1.n.g();
          locala1.n = null;
        }
        if (b)
          Log.v("LoaderManager", "  Enqueuing as new pending loader");
        locala1.n = c(paramInt, paramBundle, parama);
        return locala1.n.d;
        label323: if (b)
          Log.v("LoaderManager", "  Making last loader inactive: " + locala1);
        locala1.d.B();
        this.d.b(paramInt, locala1);
      }
    }
  }

  void b()
  {
    if (b)
      Log.v("LoaderManager", "Starting in " + this);
    if (this.f)
    {
      RuntimeException localRuntimeException = new RuntimeException("here");
      localRuntimeException.fillInStackTrace();
      Log.w("LoaderManager", "Called doStart when already started: " + this, localRuntimeException);
    }
    while (true)
    {
      return;
      this.f = true;
      for (int k = -1 + this.c.b(); k >= 0; k--)
        ((a)this.c.f(k)).a();
    }
  }

  void c()
  {
    if (b)
      Log.v("LoaderManager", "Stopping in " + this);
    if (!this.f)
    {
      RuntimeException localRuntimeException = new RuntimeException("here");
      localRuntimeException.fillInStackTrace();
      Log.w("LoaderManager", "Called doStop when not started: " + this, localRuntimeException);
      return;
    }
    for (int k = -1 + this.c.b(); k >= 0; k--)
      ((a)this.c.f(k)).e();
    this.f = false;
  }

  void d()
  {
    if (b)
      Log.v("LoaderManager", "Retaining in " + this);
    if (!this.f)
    {
      RuntimeException localRuntimeException = new RuntimeException("here");
      localRuntimeException.fillInStackTrace();
      Log.w("LoaderManager", "Called doRetain when not started: " + this, localRuntimeException);
    }
    while (true)
    {
      return;
      this.g = true;
      this.f = false;
      for (int k = -1 + this.c.b(); k >= 0; k--)
        ((a)this.c.f(k)).b();
    }
  }

  void e()
  {
    if (this.g)
    {
      if (b)
        Log.v("LoaderManager", "Finished Retaining in " + this);
      this.g = false;
      for (int k = -1 + this.c.b(); k >= 0; k--)
        ((a)this.c.f(k)).c();
    }
  }

  void f()
  {
    for (int k = -1 + this.c.b(); k >= 0; k--)
      ((a)this.c.f(k)).k = true;
  }

  void g()
  {
    for (int k = -1 + this.c.b(); k >= 0; k--)
      ((a)this.c.f(k)).d();
  }

  void h()
  {
    if (!this.g)
    {
      if (b)
        Log.v("LoaderManager", "Destroying Active in " + this);
      for (int m = -1 + this.c.b(); m >= 0; m--)
        ((a)this.c.f(m)).g();
      this.c.c();
    }
    if (b)
      Log.v("LoaderManager", "Destroying Inactive in " + this);
    for (int k = -1 + this.d.b(); k >= 0; k--)
      ((a)this.d.f(k)).g();
    this.d.c();
  }

  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder(128);
    localStringBuilder.append("LoaderManager{");
    localStringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    localStringBuilder.append(" in ");
    g.a(this.j, localStringBuilder);
    localStringBuilder.append("}}");
    return localStringBuilder.toString();
  }

  final class a
    implements r.b<Object>, r.c<Object>
  {
    final int a;
    final Bundle b;
    bi.a<Object> c;
    r<Object> d;
    boolean e;
    boolean f;
    Object g;
    boolean h;
    boolean i;
    boolean j;
    boolean k;
    boolean l;
    boolean m;
    a n;

    public a(Bundle parama, bi.a<Object> arg3)
    {
      this.a = parama;
      Object localObject1;
      this.b = localObject1;
      Object localObject2;
      this.c = localObject2;
    }

    void a()
    {
      if ((this.i) && (this.j))
        this.h = true;
      do
      {
        do
          return;
        while (this.h);
        this.h = true;
        if (bj.b)
          Log.v("LoaderManager", "  Starting: " + this);
        if ((this.d == null) && (this.c != null))
          this.d = this.c.a(this.a, this.b);
      }
      while (this.d == null);
      if ((this.d.getClass().isMemberClass()) && (!Modifier.isStatic(this.d.getClass().getModifiers())))
        throw new IllegalArgumentException("Object returned from onCreateLoader must not be a non-static inner member class: " + this.d);
      if (!this.m)
      {
        this.d.a(this.a, this);
        this.d.a(this);
        this.m = true;
      }
      this.d.x();
    }

    public void a(r<Object> paramr)
    {
      if (bj.b)
        Log.v("LoaderManager", "onLoadCanceled: " + this);
      if (this.l)
        if (bj.b)
          Log.v("LoaderManager", "  Ignoring load canceled -- destroyed");
      a locala;
      do
      {
        do
        {
          return;
          if (bj.this.c.a(this.a) == this)
            break;
        }
        while (!bj.b);
        Log.v("LoaderManager", "  Ignoring load canceled -- not active");
        return;
        locala = this.n;
      }
      while (locala == null);
      if (bj.b)
        Log.v("LoaderManager", "  Switching to pending loader: " + locala);
      this.n = null;
      bj.this.c.b(this.a, null);
      g();
      bj.this.a(locala);
    }

    public void a(r<Object> paramr, Object paramObject)
    {
      if (bj.b)
        Log.v("LoaderManager", "onLoadComplete: " + this);
      if (this.l)
        if (bj.b)
          Log.v("LoaderManager", "  Ignoring load complete -- destroyed");
      do
      {
        do
        {
          return;
          if (bj.this.c.a(this.a) == this)
            break;
        }
        while (!bj.b);
        Log.v("LoaderManager", "  Ignoring load complete -- not active");
        return;
        a locala1 = this.n;
        if (locala1 != null)
        {
          if (bj.b)
            Log.v("LoaderManager", "  Switching to pending loader: " + locala1);
          this.n = null;
          bj.this.c.b(this.a, null);
          g();
          bj.this.a(locala1);
          return;
        }
        if ((this.g != paramObject) || (!this.e))
        {
          this.g = paramObject;
          this.e = true;
          if (this.h)
            b(paramr, paramObject);
        }
        a locala2 = (a)bj.this.d.a(this.a);
        if ((locala2 != null) && (locala2 != this))
        {
          locala2.f = false;
          locala2.g();
          bj.this.d.c(this.a);
        }
      }
      while ((bj.a(bj.this) == null) || (bj.this.a()));
      bj.a(bj.this).d.i();
    }

    public void a(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mId=");
      paramPrintWriter.print(this.a);
      paramPrintWriter.print(" mArgs=");
      paramPrintWriter.println(this.b);
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mCallbacks=");
      paramPrintWriter.println(this.c);
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mLoader=");
      paramPrintWriter.println(this.d);
      if (this.d != null)
        this.d.a(paramString + "  ", paramFileDescriptor, paramPrintWriter, paramArrayOfString);
      if ((this.e) || (this.f))
      {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mHaveData=");
        paramPrintWriter.print(this.e);
        paramPrintWriter.print("  mDeliveredData=");
        paramPrintWriter.println(this.f);
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mData=");
        paramPrintWriter.println(this.g);
      }
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mStarted=");
      paramPrintWriter.print(this.h);
      paramPrintWriter.print(" mReportNextStart=");
      paramPrintWriter.print(this.k);
      paramPrintWriter.print(" mDestroyed=");
      paramPrintWriter.println(this.l);
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mRetaining=");
      paramPrintWriter.print(this.i);
      paramPrintWriter.print(" mRetainingStarted=");
      paramPrintWriter.print(this.j);
      paramPrintWriter.print(" mListenerRegistered=");
      paramPrintWriter.println(this.m);
      if (this.n != null)
      {
        paramPrintWriter.print(paramString);
        paramPrintWriter.println("Pending Loader ");
        paramPrintWriter.print(this.n);
        paramPrintWriter.println(":");
        this.n.a(paramString + "  ", paramFileDescriptor, paramPrintWriter, paramArrayOfString);
      }
    }

    void b()
    {
      if (bj.b)
        Log.v("LoaderManager", "  Retaining: " + this);
      this.i = true;
      this.j = this.h;
      this.h = false;
      this.c = null;
    }

    void b(r<Object> paramr, Object paramObject)
    {
      String str2;
      if (this.c != null)
      {
        if (bj.a(bj.this) == null)
          break label167;
        str2 = bj.a(bj.this).d.C;
        bj.a(bj.this).d.C = "onLoadFinished";
      }
      label167: for (String str1 = str2; ; str1 = null)
        try
        {
          if (bj.b)
            Log.v("LoaderManager", "  onLoadFinished in " + paramr + ": " + paramr.c(paramObject));
          this.c.a(paramr, paramObject);
          if (bj.a(bj.this) != null)
            bj.a(bj.this).d.C = str1;
          this.f = true;
          return;
        }
        finally
        {
          if (bj.a(bj.this) != null)
            bj.a(bj.this).d.C = str1;
        }
    }

    void c()
    {
      if (this.i)
      {
        if (bj.b)
          Log.v("LoaderManager", "  Finished Retaining: " + this);
        this.i = false;
        if ((this.h != this.j) && (!this.h))
          e();
      }
      if ((this.h) && (this.e) && (!this.k))
        b(this.d, this.g);
    }

    void d()
    {
      if ((this.h) && (this.k))
      {
        this.k = false;
        if (this.e)
          b(this.d, this.g);
      }
    }

    void e()
    {
      if (bj.b)
        Log.v("LoaderManager", "  Stopping: " + this);
      this.h = false;
      if ((!this.i) && (this.d != null) && (this.m))
      {
        this.m = false;
        this.d.a(this);
        this.d.b(this);
        this.d.A();
      }
    }

    void f()
    {
      if (bj.b)
        Log.v("LoaderManager", "  Canceling: " + this);
      if ((this.h) && (this.d != null) && (this.m) && (!this.d.y()))
        a(this.d);
    }

    void g()
    {
      if (bj.b)
        Log.v("LoaderManager", "  Destroying: " + this);
      this.l = true;
      boolean bool = this.f;
      this.f = false;
      String str2;
      if ((this.c != null) && (this.d != null) && (this.e) && (bool))
      {
        if (bj.b)
          Log.v("LoaderManager", "  Reseting: " + this);
        if (bj.a(bj.this) == null)
          break label284;
        str2 = bj.a(bj.this).d.C;
        bj.a(bj.this).d.C = "onLoaderReset";
      }
      label284: for (String str1 = str2; ; str1 = null)
        try
        {
          this.c.a(this.d);
          if (bj.a(bj.this) != null)
            bj.a(bj.this).d.C = str1;
          this.c = null;
          this.g = null;
          this.e = false;
          if (this.d != null)
          {
            if (this.m)
            {
              this.m = false;
              this.d.a(this);
              this.d.b(this);
            }
            this.d.D();
          }
          if (this.n != null)
            this.n.g();
          return;
        }
        finally
        {
          if (bj.a(bj.this) != null)
            bj.a(bj.this).d.C = str1;
        }
    }

    public String toString()
    {
      StringBuilder localStringBuilder = new StringBuilder(64);
      localStringBuilder.append("LoaderInfo{");
      localStringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
      localStringBuilder.append(" #");
      localStringBuilder.append(this.a);
      localStringBuilder.append(" : ");
      g.a(this.d, localStringBuilder);
      localStringBuilder.append("}}");
      return localStringBuilder.toString();
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.bj
 * JD-Core Version:    0.6.2
 */