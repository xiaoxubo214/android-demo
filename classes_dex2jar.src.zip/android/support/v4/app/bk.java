package android.support.v4.app;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.support.annotation.y;
import android.support.v4.c.o;
import android.util.Log;

public final class bk
{
  public static final String a = "android.support.PARENT_ACTIVITY";
  private static final String b = "NavUtils";
  private static final a c = new b();

  static
  {
    if (Build.VERSION.SDK_INT >= 16)
    {
      c = new c();
      return;
    }
  }

  public static Intent a(Context paramContext, ComponentName paramComponentName)
    throws PackageManager.NameNotFoundException
  {
    String str = b(paramContext, paramComponentName);
    if (str == null)
      return null;
    ComponentName localComponentName = new ComponentName(paramComponentName.getPackageName(), str);
    if (b(paramContext, localComponentName) == null)
      return o.a(localComponentName);
    return new Intent().setComponent(localComponentName);
  }

  public static Intent a(Context paramContext, Class<?> paramClass)
    throws PackageManager.NameNotFoundException
  {
    String str = b(paramContext, new ComponentName(paramContext, paramClass));
    if (str == null)
      return null;
    ComponentName localComponentName = new ComponentName(paramContext, str);
    if (b(paramContext, localComponentName) == null)
      return o.a(localComponentName);
    return new Intent().setComponent(localComponentName);
  }

  public static void a(Activity paramActivity)
  {
    Intent localIntent = b(paramActivity);
    if (localIntent == null)
      throw new IllegalArgumentException("Activity " + paramActivity.getClass().getSimpleName() + " does not have a parent activity name specified." + " (Did you forget to add the android.support.PARENT_ACTIVITY <meta-data> " + " element in your manifest?)");
    b(paramActivity, localIntent);
  }

  public static boolean a(Activity paramActivity, Intent paramIntent)
  {
    return c.a(paramActivity, paramIntent);
  }

  public static Intent b(Activity paramActivity)
  {
    return c.a(paramActivity);
  }

  @y
  public static String b(Context paramContext, ComponentName paramComponentName)
    throws PackageManager.NameNotFoundException
  {
    ActivityInfo localActivityInfo = paramContext.getPackageManager().getActivityInfo(paramComponentName, 128);
    return c.a(paramContext, localActivityInfo);
  }

  public static void b(Activity paramActivity, Intent paramIntent)
  {
    c.b(paramActivity, paramIntent);
  }

  @y
  public static String c(Activity paramActivity)
  {
    try
    {
      String str = b(paramActivity, paramActivity.getComponentName());
      return str;
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException)
    {
      throw new IllegalArgumentException(localNameNotFoundException);
    }
  }

  static abstract interface a
  {
    public abstract Intent a(Activity paramActivity);

    public abstract String a(Context paramContext, ActivityInfo paramActivityInfo);

    public abstract boolean a(Activity paramActivity, Intent paramIntent);

    public abstract void b(Activity paramActivity, Intent paramIntent);
  }

  static class b
    implements bk.a
  {
    public Intent a(Activity paramActivity)
    {
      String str = bk.c(paramActivity);
      if (str == null)
        return null;
      ComponentName localComponentName = new ComponentName(paramActivity, str);
      try
      {
        if (bk.b(paramActivity, localComponentName) == null)
          return o.a(localComponentName);
        Intent localIntent = new Intent().setComponent(localComponentName);
        return localIntent;
      }
      catch (PackageManager.NameNotFoundException localNameNotFoundException)
      {
        Log.e("NavUtils", "getParentActivityIntent: bad parentActivityName '" + str + "' in manifest");
      }
      return null;
    }

    public String a(Context paramContext, ActivityInfo paramActivityInfo)
    {
      String str;
      if (paramActivityInfo.metaData == null)
        str = null;
      do
      {
        return str;
        str = paramActivityInfo.metaData.getString("android.support.PARENT_ACTIVITY");
        if (str == null)
          return null;
      }
      while (str.charAt(0) != '.');
      return paramContext.getPackageName() + str;
    }

    public boolean a(Activity paramActivity, Intent paramIntent)
    {
      String str = paramActivity.getIntent().getAction();
      return (str != null) && (!str.equals("android.intent.action.MAIN"));
    }

    public void b(Activity paramActivity, Intent paramIntent)
    {
      paramIntent.addFlags(67108864);
      paramActivity.startActivity(paramIntent);
      paramActivity.finish();
    }
  }

  static class c extends bk.b
  {
    public Intent a(Activity paramActivity)
    {
      Intent localIntent = bl.a(paramActivity);
      if (localIntent == null)
        localIntent = b(paramActivity);
      return localIntent;
    }

    public String a(Context paramContext, ActivityInfo paramActivityInfo)
    {
      String str = bl.a(paramActivityInfo);
      if (str == null)
        str = super.a(paramContext, paramActivityInfo);
      return str;
    }

    public boolean a(Activity paramActivity, Intent paramIntent)
    {
      return bl.a(paramActivity, paramIntent);
    }

    Intent b(Activity paramActivity)
    {
      return super.a(paramActivity);
    }

    public void b(Activity paramActivity, Intent paramIntent)
    {
      bl.b(paramActivity, paramIntent);
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.bk
 * JD-Core Version:    0.6.2
 */