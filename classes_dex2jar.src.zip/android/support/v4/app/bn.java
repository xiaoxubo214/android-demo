package android.support.v4.app;

abstract interface bn
{
  public abstract void a(bu.a parama);
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.bn
 * JD-Core Version:    0.6.2
 */