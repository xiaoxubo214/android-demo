package android.support.v4.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.annotation.j;
import android.widget.RemoteViews;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class bp
{
  public static final String A = "android.bigText";
  public static final String B = "android.icon";
  public static final String C = "android.largeIcon";
  public static final String D = "android.largeIcon.big";
  public static final String E = "android.progress";
  public static final String F = "android.progressMax";
  public static final String G = "android.progressIndeterminate";
  public static final String H = "android.showChronometer";
  public static final String I = "android.showWhen";
  public static final String J = "android.picture";
  public static final String K = "android.textLines";
  public static final String L = "android.template";
  public static final String M = "android.people";
  public static final String N = "android.backgroundImageUri";
  public static final String O = "android.mediaSession";
  public static final String P = "android.compactActions";

  @j
  public static final int Q = 0;
  public static final int R = 1;
  public static final int S = 0;
  public static final int T = -1;
  public static final String U = "call";
  public static final String V = "msg";
  public static final String W = "email";
  public static final String X = "event";
  public static final String Y = "promo";
  public static final String Z = "alarm";
  public static final int a = -1;
  public static final String aa = "progress";
  public static final String ab = "social";
  public static final String ac = "err";
  public static final String ad = "transport";
  public static final String ae = "sys";
  public static final String af = "service";
  public static final String ag = "recommendation";
  public static final String ah = "status";
  private static final i ai = new l();
  public static final int b = 1;
  public static final int c = 2;
  public static final int d = 4;
  public static final int e = -1;
  public static final int f = 1;
  public static final int g = 2;
  public static final int h = 4;
  public static final int i = 8;
  public static final int j = 16;
  public static final int k = 32;
  public static final int l = 64;
  public static final int m = 128;
  public static final int n = 256;
  public static final int o = 512;
  public static final int p = 0;
  public static final int q = -1;
  public static final int r = -2;
  public static final int s = 1;
  public static final int t = 2;
  public static final String u = "android.title";
  public static final String v = "android.title.big";
  public static final String w = "android.text";
  public static final String x = "android.subText";
  public static final String y = "android.infoText";
  public static final String z = "android.summaryText";

  static
  {
    if (Build.VERSION.SDK_INT >= 21)
    {
      ai = new k();
      return;
    }
    if (Build.VERSION.SDK_INT >= 20)
    {
      ai = new j();
      return;
    }
    if (Build.VERSION.SDK_INT >= 19)
    {
      ai = new q();
      return;
    }
    if (Build.VERSION.SDK_INT >= 16)
    {
      ai = new p();
      return;
    }
    if (Build.VERSION.SDK_INT >= 14)
    {
      ai = new o();
      return;
    }
    if (Build.VERSION.SDK_INT >= 11)
    {
      ai = new n();
      return;
    }
    if (Build.VERSION.SDK_INT >= 9)
    {
      ai = new m();
      return;
    }
  }

  public static Bundle a(Notification paramNotification)
  {
    return ai.a(paramNotification);
  }

  public static a a(Notification paramNotification, int paramInt)
  {
    return ai.a(paramNotification, paramInt);
  }

  public static int b(Notification paramNotification)
  {
    return ai.b(paramNotification);
  }

  private static void b(bn parambn, ArrayList<a> paramArrayList)
  {
    Iterator localIterator = paramArrayList.iterator();
    while (localIterator.hasNext())
      parambn.a((a)localIterator.next());
  }

  private static void b(bo parambo, r paramr)
  {
    if (paramr != null)
    {
      if (!(paramr instanceof c))
        break label42;
      c localc = (c)paramr;
      bz.a(parambo, localc.e, localc.g, localc.f, localc.a);
    }
    label42: 
    do
    {
      return;
      if ((paramr instanceof h))
      {
        h localh = (h)paramr;
        bz.a(parambo, localh.e, localh.g, localh.f, localh.a);
        return;
      }
    }
    while (!(paramr instanceof b));
    b localb = (b)paramr;
    bz.a(parambo, localb.e, localb.g, localb.f, localb.a, localb.b, localb.c);
  }

  private static Notification[] b(Bundle paramBundle, String paramString)
  {
    Parcelable[] arrayOfParcelable = paramBundle.getParcelableArray(paramString);
    if (((arrayOfParcelable instanceof Notification[])) || (arrayOfParcelable == null))
      return (Notification[])arrayOfParcelable;
    Notification[] arrayOfNotification = new Notification[arrayOfParcelable.length];
    for (int i1 = 0; i1 < arrayOfParcelable.length; i1++)
      arrayOfNotification[i1] = ((Notification)arrayOfParcelable[i1]);
    paramBundle.putParcelableArray(paramString, arrayOfNotification);
    return arrayOfNotification;
  }

  public static String c(Notification paramNotification)
  {
    return ai.c(paramNotification);
  }

  public static boolean d(Notification paramNotification)
  {
    return ai.d(paramNotification);
  }

  public static String e(Notification paramNotification)
  {
    return ai.e(paramNotification);
  }

  public static boolean f(Notification paramNotification)
  {
    return ai.f(paramNotification);
  }

  public static String g(Notification paramNotification)
  {
    return ai.g(paramNotification);
  }

  public static class a extends bu.a
  {
    public static final bu.a.a d = new bq();
    public int a;
    public CharSequence b;
    public PendingIntent c;
    private final Bundle e;
    private final cf[] f;

    public a(int paramInt, CharSequence paramCharSequence, PendingIntent paramPendingIntent)
    {
      this(paramInt, paramCharSequence, paramPendingIntent, new Bundle(), null);
    }

    private a(int paramInt, CharSequence paramCharSequence, PendingIntent paramPendingIntent, Bundle paramBundle, cf[] paramArrayOfcf)
    {
      this.a = paramInt;
      this.b = bp.d.f(paramCharSequence);
      this.c = paramPendingIntent;
      if (paramBundle != null);
      while (true)
      {
        this.e = paramBundle;
        this.f = paramArrayOfcf;
        return;
        paramBundle = new Bundle();
      }
    }

    public int a()
    {
      return this.a;
    }

    public CharSequence b()
    {
      return this.b;
    }

    public PendingIntent c()
    {
      return this.c;
    }

    public Bundle d()
    {
      return this.e;
    }

    public cf[] e()
    {
      return this.f;
    }

    public static final class a
    {
      private final int a;
      private final CharSequence b;
      private final PendingIntent c;
      private final Bundle d;
      private ArrayList<cf> e;

      public a(int paramInt, CharSequence paramCharSequence, PendingIntent paramPendingIntent)
      {
        this(paramInt, paramCharSequence, paramPendingIntent, new Bundle());
      }

      private a(int paramInt, CharSequence paramCharSequence, PendingIntent paramPendingIntent, Bundle paramBundle)
      {
        this.a = paramInt;
        this.b = bp.d.f(paramCharSequence);
        this.c = paramPendingIntent;
        this.d = paramBundle;
      }

      public a(bp.a parama)
      {
        this(parama.a, parama.b, parama.c, new Bundle(bp.a.a(parama)));
      }

      public Bundle a()
      {
        return this.d;
      }

      public a a(Bundle paramBundle)
      {
        if (paramBundle != null)
          this.d.putAll(paramBundle);
        return this;
      }

      public a a(bp.a.b paramb)
      {
        paramb.a(this);
        return this;
      }

      public a a(cf paramcf)
      {
        if (this.e == null)
          this.e = new ArrayList();
        this.e.add(paramcf);
        return this;
      }

      public bp.a b()
      {
        if (this.e != null);
        for (cf[] arrayOfcf = (cf[])this.e.toArray(new cf[this.e.size()]); ; arrayOfcf = null)
          return new bp.a(this.a, this.b, this.c, this.d, arrayOfcf, null);
      }
    }

    public static abstract interface b
    {
      public abstract bp.a.a a(bp.a.a parama);
    }

    public static final class c
      implements bp.a.b
    {
      private static final String a = "android.wearable.EXTENSIONS";
      private static final String b = "flags";
      private static final String c = "inProgressLabel";
      private static final String d = "confirmLabel";
      private static final String e = "cancelLabel";
      private static final int f = 1;
      private static final int g = 1;
      private int h = 1;
      private CharSequence i;
      private CharSequence j;
      private CharSequence k;

      public c()
      {
      }

      public c(bp.a parama)
      {
        Bundle localBundle = parama.d().getBundle("android.wearable.EXTENSIONS");
        if (localBundle != null)
        {
          this.h = localBundle.getInt("flags", 1);
          this.i = localBundle.getCharSequence("inProgressLabel");
          this.j = localBundle.getCharSequence("confirmLabel");
          this.k = localBundle.getCharSequence("cancelLabel");
        }
      }

      private void a(int paramInt, boolean paramBoolean)
      {
        if (paramBoolean)
        {
          this.h = (paramInt | this.h);
          return;
        }
        this.h &= (paramInt ^ 0xFFFFFFFF);
      }

      public bp.a.a a(bp.a.a parama)
      {
        Bundle localBundle = new Bundle();
        if (this.h != 1)
          localBundle.putInt("flags", this.h);
        if (this.i != null)
          localBundle.putCharSequence("inProgressLabel", this.i);
        if (this.j != null)
          localBundle.putCharSequence("confirmLabel", this.j);
        if (this.k != null)
          localBundle.putCharSequence("cancelLabel", this.k);
        parama.a().putBundle("android.wearable.EXTENSIONS", localBundle);
        return parama;
      }

      public c a()
      {
        c localc = new c();
        localc.h = this.h;
        localc.i = this.i;
        localc.j = this.j;
        localc.k = this.k;
        return localc;
      }

      public c a(CharSequence paramCharSequence)
      {
        this.i = paramCharSequence;
        return this;
      }

      public c a(boolean paramBoolean)
      {
        a(1, paramBoolean);
        return this;
      }

      public c b(CharSequence paramCharSequence)
      {
        this.j = paramCharSequence;
        return this;
      }

      public boolean b()
      {
        return (0x1 & this.h) != 0;
      }

      public c c(CharSequence paramCharSequence)
      {
        this.k = paramCharSequence;
        return this;
      }

      public CharSequence c()
      {
        return this.i;
      }

      public CharSequence d()
      {
        return this.j;
      }

      public CharSequence e()
      {
        return this.k;
      }
    }
  }

  public static class b extends bp.r
  {
    Bitmap a;
    Bitmap b;
    boolean c;

    public b()
    {
    }

    public b(bp.d paramd)
    {
      a(paramd);
    }

    public b a(Bitmap paramBitmap)
    {
      this.a = paramBitmap;
      return this;
    }

    public b a(CharSequence paramCharSequence)
    {
      this.e = bp.d.f(paramCharSequence);
      return this;
    }

    public b b(Bitmap paramBitmap)
    {
      this.b = paramBitmap;
      this.c = true;
      return this;
    }

    public b b(CharSequence paramCharSequence)
    {
      this.f = bp.d.f(paramCharSequence);
      this.g = true;
      return this;
    }
  }

  public static class c extends bp.r
  {
    CharSequence a;

    public c()
    {
    }

    public c(bp.d paramd)
    {
      a(paramd);
    }

    public c a(CharSequence paramCharSequence)
    {
      this.e = bp.d.f(paramCharSequence);
      return this;
    }

    public c b(CharSequence paramCharSequence)
    {
      this.f = bp.d.f(paramCharSequence);
      this.g = true;
      return this;
    }

    public c c(CharSequence paramCharSequence)
    {
      this.a = bp.d.f(paramCharSequence);
      return this;
    }
  }

  public static class d
  {
    private static final int D = 5120;
    Notification A;
    public Notification B = new Notification();
    public ArrayList<String> C;
    public Context a;
    public CharSequence b;
    public CharSequence c;
    PendingIntent d;
    PendingIntent e;
    RemoteViews f;
    public Bitmap g;
    public CharSequence h;
    public int i;
    int j;
    boolean k = true;
    public boolean l;
    public bp.r m;
    public CharSequence n;
    int o;
    int p;
    boolean q;
    String r;
    boolean s;
    String t;
    public ArrayList<bp.a> u = new ArrayList();
    boolean v = false;
    String w;
    Bundle x;
    int y = 0;
    int z = 0;

    public d(Context paramContext)
    {
      this.a = paramContext;
      this.B.when = System.currentTimeMillis();
      this.B.audioStreamType = -1;
      this.j = 0;
      this.C = new ArrayList();
    }

    private void a(int paramInt, boolean paramBoolean)
    {
      if (paramBoolean)
      {
        Notification localNotification2 = this.B;
        localNotification2.flags = (paramInt | localNotification2.flags);
        return;
      }
      Notification localNotification1 = this.B;
      localNotification1.flags &= (paramInt ^ 0xFFFFFFFF);
    }

    protected static CharSequence f(CharSequence paramCharSequence)
    {
      if (paramCharSequence == null);
      while (paramCharSequence.length() <= 5120)
        return paramCharSequence;
      return paramCharSequence.subSequence(0, 5120);
    }

    public Bundle a()
    {
      if (this.x == null)
        this.x = new Bundle();
      return this.x;
    }

    public d a(int paramInt)
    {
      this.B.icon = paramInt;
      return this;
    }

    public d a(int paramInt1, int paramInt2)
    {
      this.B.icon = paramInt1;
      this.B.iconLevel = paramInt2;
      return this;
    }

    public d a(@j int paramInt1, int paramInt2, int paramInt3)
    {
      int i1 = 1;
      this.B.ledARGB = paramInt1;
      this.B.ledOnMS = paramInt2;
      this.B.ledOffMS = paramInt3;
      int i2;
      Notification localNotification;
      int i3;
      if ((this.B.ledOnMS != 0) && (this.B.ledOffMS != 0))
      {
        i2 = i1;
        localNotification = this.B;
        i3 = 0xFFFFFFFE & this.B.flags;
        if (i2 == 0)
          break label92;
      }
      while (true)
      {
        localNotification.flags = (i3 | i1);
        return this;
        i2 = 0;
        break;
        label92: i1 = 0;
      }
    }

    public d a(int paramInt1, int paramInt2, boolean paramBoolean)
    {
      this.o = paramInt1;
      this.p = paramInt2;
      this.q = paramBoolean;
      return this;
    }

    public d a(int paramInt, CharSequence paramCharSequence, PendingIntent paramPendingIntent)
    {
      this.u.add(new bp.a(paramInt, paramCharSequence, paramPendingIntent));
      return this;
    }

    public d a(long paramLong)
    {
      this.B.when = paramLong;
      return this;
    }

    public d a(Notification paramNotification)
    {
      this.A = paramNotification;
      return this;
    }

    public d a(PendingIntent paramPendingIntent)
    {
      this.d = paramPendingIntent;
      return this;
    }

    public d a(PendingIntent paramPendingIntent, boolean paramBoolean)
    {
      this.e = paramPendingIntent;
      a(128, paramBoolean);
      return this;
    }

    public d a(Bitmap paramBitmap)
    {
      this.g = paramBitmap;
      return this;
    }

    public d a(Uri paramUri)
    {
      this.B.sound = paramUri;
      this.B.audioStreamType = -1;
      return this;
    }

    public d a(Uri paramUri, int paramInt)
    {
      this.B.sound = paramUri;
      this.B.audioStreamType = paramInt;
      return this;
    }

    public d a(Bundle paramBundle)
    {
      if (paramBundle != null)
      {
        if (this.x == null)
          this.x = new Bundle(paramBundle);
      }
      else
        return this;
      this.x.putAll(paramBundle);
      return this;
    }

    public d a(bp.a parama)
    {
      this.u.add(parama);
      return this;
    }

    public d a(bp.g paramg)
    {
      paramg.a(this);
      return this;
    }

    public d a(bp.r paramr)
    {
      if (this.m != paramr)
      {
        this.m = paramr;
        if (this.m != null)
          this.m.a(this);
      }
      return this;
    }

    public d a(RemoteViews paramRemoteViews)
    {
      this.B.contentView = paramRemoteViews;
      return this;
    }

    public d a(CharSequence paramCharSequence)
    {
      this.b = f(paramCharSequence);
      return this;
    }

    public d a(CharSequence paramCharSequence, RemoteViews paramRemoteViews)
    {
      this.B.tickerText = f(paramCharSequence);
      this.f = paramRemoteViews;
      return this;
    }

    public d a(String paramString)
    {
      this.w = paramString;
      return this;
    }

    public d a(boolean paramBoolean)
    {
      this.k = paramBoolean;
      return this;
    }

    public d a(long[] paramArrayOfLong)
    {
      this.B.vibrate = paramArrayOfLong;
      return this;
    }

    @Deprecated
    public Notification b()
    {
      return c();
    }

    public d b(int paramInt)
    {
      this.i = paramInt;
      return this;
    }

    public d b(PendingIntent paramPendingIntent)
    {
      this.B.deleteIntent = paramPendingIntent;
      return this;
    }

    public d b(Bundle paramBundle)
    {
      this.x = paramBundle;
      return this;
    }

    public d b(CharSequence paramCharSequence)
    {
      this.c = f(paramCharSequence);
      return this;
    }

    public d b(String paramString)
    {
      this.C.add(paramString);
      return this;
    }

    public d b(boolean paramBoolean)
    {
      this.l = paramBoolean;
      return this;
    }

    public Notification c()
    {
      return bp.a().a(this, d());
    }

    public d c(int paramInt)
    {
      this.B.defaults = paramInt;
      if ((paramInt & 0x4) != 0)
      {
        Notification localNotification = this.B;
        localNotification.flags = (0x1 | localNotification.flags);
      }
      return this;
    }

    public d c(CharSequence paramCharSequence)
    {
      this.n = f(paramCharSequence);
      return this;
    }

    public d c(String paramString)
    {
      this.r = paramString;
      return this;
    }

    public d c(boolean paramBoolean)
    {
      a(2, paramBoolean);
      return this;
    }

    public d d(int paramInt)
    {
      this.j = paramInt;
      return this;
    }

    public d d(CharSequence paramCharSequence)
    {
      this.h = f(paramCharSequence);
      return this;
    }

    public d d(String paramString)
    {
      this.t = paramString;
      return this;
    }

    public d d(boolean paramBoolean)
    {
      a(8, paramBoolean);
      return this;
    }

    protected bp.e d()
    {
      return new bp.e();
    }

    public d e(@j int paramInt)
    {
      this.y = paramInt;
      return this;
    }

    public d e(CharSequence paramCharSequence)
    {
      this.B.tickerText = f(paramCharSequence);
      return this;
    }

    public d e(boolean paramBoolean)
    {
      a(16, paramBoolean);
      return this;
    }

    public d f(int paramInt)
    {
      this.z = paramInt;
      return this;
    }

    public d f(boolean paramBoolean)
    {
      this.v = paramBoolean;
      return this;
    }

    public d g(boolean paramBoolean)
    {
      this.s = paramBoolean;
      return this;
    }
  }

  protected static class e
  {
    public Notification a(bp.d paramd, bo parambo)
    {
      return parambo.b();
    }
  }

  public static final class f
    implements bp.g
  {
    private static final String a = "CarExtender";
    private static final String b = "android.car.EXTENSIONS";
    private static final String c = "large_icon";
    private static final String d = "car_conversation";
    private static final String e = "app_color";
    private Bitmap f;
    private a g;
    private int h = 0;

    public f()
    {
    }

    public f(Notification paramNotification)
    {
      if (Build.VERSION.SDK_INT < 21);
      while (true)
      {
        return;
        if (bp.a(paramNotification) == null);
        for (Bundle localBundle1 = null; localBundle1 != null; localBundle1 = bp.a(paramNotification).getBundle("android.car.EXTENSIONS"))
        {
          this.f = ((Bitmap)localBundle1.getParcelable("large_icon"));
          this.h = localBundle1.getInt("app_color", 0);
          Bundle localBundle2 = localBundle1.getBundle("car_conversation");
          this.g = ((a)bp.a().a(localBundle2, a.a, cf.c));
          return;
        }
      }
    }

    @j
    public int a()
    {
      return this.h;
    }

    public bp.d a(bp.d paramd)
    {
      if (Build.VERSION.SDK_INT < 21)
        return paramd;
      Bundle localBundle = new Bundle();
      if (this.f != null)
        localBundle.putParcelable("large_icon", this.f);
      if (this.h != 0)
        localBundle.putInt("app_color", this.h);
      if (this.g != null)
        localBundle.putBundle("car_conversation", bp.a().a(this.g));
      paramd.a().putBundle("android.car.EXTENSIONS", localBundle);
      return paramd;
    }

    public f a(@j int paramInt)
    {
      this.h = paramInt;
      return this;
    }

    public f a(Bitmap paramBitmap)
    {
      this.f = paramBitmap;
      return this;
    }

    public f a(a parama)
    {
      this.g = parama;
      return this;
    }

    public Bitmap b()
    {
      return this.f;
    }

    public a c()
    {
      return this.g;
    }

    public static class a extends bu.b
    {
      static final bu.b.a a = new br();
      private final String[] b;
      private final cf c;
      private final PendingIntent d;
      private final PendingIntent e;
      private final String[] f;
      private final long g;

      a(String[] paramArrayOfString1, cf paramcf, PendingIntent paramPendingIntent1, PendingIntent paramPendingIntent2, String[] paramArrayOfString2, long paramLong)
      {
        this.b = paramArrayOfString1;
        this.c = paramcf;
        this.e = paramPendingIntent2;
        this.d = paramPendingIntent1;
        this.f = paramArrayOfString2;
        this.g = paramLong;
      }

      public String[] a()
      {
        return this.b;
      }

      public cf b()
      {
        return this.c;
      }

      public PendingIntent c()
      {
        return this.d;
      }

      public PendingIntent d()
      {
        return this.e;
      }

      public String[] e()
      {
        return this.f;
      }

      public String f()
      {
        if (this.f.length > 0)
          return this.f[0];
        return null;
      }

      public long g()
      {
        return this.g;
      }

      public static class a
      {
        private final List<String> a = new ArrayList();
        private final String b;
        private cf c;
        private PendingIntent d;
        private PendingIntent e;
        private long f;

        public a(String paramString)
        {
          this.b = paramString;
        }

        public a a(long paramLong)
        {
          this.f = paramLong;
          return this;
        }

        public a a(PendingIntent paramPendingIntent)
        {
          this.d = paramPendingIntent;
          return this;
        }

        public a a(PendingIntent paramPendingIntent, cf paramcf)
        {
          this.c = paramcf;
          this.e = paramPendingIntent;
          return this;
        }

        public a a(String paramString)
        {
          this.a.add(paramString);
          return this;
        }

        public bp.f.a a()
        {
          String[] arrayOfString1 = (String[])this.a.toArray(new String[this.a.size()]);
          String[] arrayOfString2 = new String[1];
          arrayOfString2[0] = this.b;
          return new bp.f.a(arrayOfString1, this.c, this.e, this.d, arrayOfString2, this.f);
        }
      }
    }
  }

  public static abstract interface g
  {
    public abstract bp.d a(bp.d paramd);
  }

  public static class h extends bp.r
  {
    ArrayList<CharSequence> a = new ArrayList();

    public h()
    {
    }

    public h(bp.d paramd)
    {
      a(paramd);
    }

    public h a(CharSequence paramCharSequence)
    {
      this.e = bp.d.f(paramCharSequence);
      return this;
    }

    public h b(CharSequence paramCharSequence)
    {
      this.f = bp.d.f(paramCharSequence);
      this.g = true;
      return this;
    }

    public h c(CharSequence paramCharSequence)
    {
      this.a.add(bp.d.f(paramCharSequence));
      return this;
    }
  }

  static abstract interface i
  {
    public abstract Notification a(bp.d paramd, bp.e parame);

    public abstract Bundle a(Notification paramNotification);

    public abstract Bundle a(bu.b paramb);

    public abstract bp.a a(Notification paramNotification, int paramInt);

    public abstract bu.b a(Bundle paramBundle, bu.b.a parama, ci.a.a parama1);

    public abstract ArrayList<Parcelable> a(bp.a[] paramArrayOfa);

    public abstract bp.a[] a(ArrayList<Parcelable> paramArrayList);

    public abstract int b(Notification paramNotification);

    public abstract String c(Notification paramNotification);

    public abstract boolean d(Notification paramNotification);

    public abstract String e(Notification paramNotification);

    public abstract boolean f(Notification paramNotification);

    public abstract String g(Notification paramNotification);
  }

  static class j extends bp.q
  {
    public Notification a(bp.d paramd, bp.e parame)
    {
      bs.a locala = new bs.a(paramd.a, paramd.B, paramd.b, paramd.c, paramd.h, paramd.f, paramd.i, paramd.d, paramd.e, paramd.g, paramd.o, paramd.p, paramd.q, paramd.k, paramd.l, paramd.j, paramd.n, paramd.v, paramd.C, paramd.x, paramd.r, paramd.s, paramd.t);
      bp.a(locala, paramd.u);
      bp.a(locala, paramd.m);
      return parame.a(paramd, locala);
    }

    public bp.a a(Notification paramNotification, int paramInt)
    {
      return (bp.a)bs.a(paramNotification, paramInt, bp.a.d, cf.c);
    }

    public ArrayList<Parcelable> a(bp.a[] paramArrayOfa)
    {
      return bs.a(paramArrayOfa);
    }

    public bp.a[] a(ArrayList<Parcelable> paramArrayList)
    {
      return (bp.a[])bs.a(paramArrayList, bp.a.d, cf.c);
    }

    public boolean d(Notification paramNotification)
    {
      return bs.a(paramNotification);
    }

    public String e(Notification paramNotification)
    {
      return bs.b(paramNotification);
    }

    public boolean f(Notification paramNotification)
    {
      return bs.c(paramNotification);
    }

    public String g(Notification paramNotification)
    {
      return bs.d(paramNotification);
    }
  }

  static class k extends bp.j
  {
    public Notification a(bp.d paramd, bp.e parame)
    {
      bt.a locala = new bt.a(paramd.a, paramd.B, paramd.b, paramd.c, paramd.h, paramd.f, paramd.i, paramd.d, paramd.e, paramd.g, paramd.o, paramd.p, paramd.q, paramd.k, paramd.l, paramd.j, paramd.n, paramd.v, paramd.w, paramd.C, paramd.x, paramd.y, paramd.z, paramd.A, paramd.r, paramd.s, paramd.t);
      bp.a(locala, paramd.u);
      bp.a(locala, paramd.m);
      return parame.a(paramd, locala);
    }

    public Bundle a(bu.b paramb)
    {
      return bt.a(paramb);
    }

    public bu.b a(Bundle paramBundle, bu.b.a parama, ci.a.a parama1)
    {
      return bt.a(paramBundle, parama, parama1);
    }

    public String c(Notification paramNotification)
    {
      return bt.a(paramNotification);
    }
  }

  static class l
    implements bp.i
  {
    public Notification a(bp.d paramd, bp.e parame)
    {
      Notification localNotification = bu.a(paramd.B, paramd.a, paramd.b, paramd.c, paramd.d);
      if (paramd.j > 0)
        localNotification.flags = (0x80 | localNotification.flags);
      return localNotification;
    }

    public Bundle a(Notification paramNotification)
    {
      return null;
    }

    public Bundle a(bu.b paramb)
    {
      return null;
    }

    public bp.a a(Notification paramNotification, int paramInt)
    {
      return null;
    }

    public bu.b a(Bundle paramBundle, bu.b.a parama, ci.a.a parama1)
    {
      return null;
    }

    public ArrayList<Parcelable> a(bp.a[] paramArrayOfa)
    {
      return null;
    }

    public bp.a[] a(ArrayList<Parcelable> paramArrayList)
    {
      return null;
    }

    public int b(Notification paramNotification)
    {
      return 0;
    }

    public String c(Notification paramNotification)
    {
      return null;
    }

    public boolean d(Notification paramNotification)
    {
      return false;
    }

    public String e(Notification paramNotification)
    {
      return null;
    }

    public boolean f(Notification paramNotification)
    {
      return false;
    }

    public String g(Notification paramNotification)
    {
      return null;
    }
  }

  static class m extends bp.l
  {
    public Notification a(bp.d paramd, bp.e parame)
    {
      Notification localNotification = bw.a(paramd.B, paramd.a, paramd.b, paramd.c, paramd.d, paramd.e);
      if (paramd.j > 0)
        localNotification.flags = (0x80 | localNotification.flags);
      return localNotification;
    }
  }

  static class n extends bp.l
  {
    public Notification a(bp.d paramd, bp.e parame)
    {
      return bx.a(paramd.a, paramd.B, paramd.b, paramd.c, paramd.h, paramd.f, paramd.i, paramd.d, paramd.e, paramd.g);
    }
  }

  static class o extends bp.l
  {
    public Notification a(bp.d paramd, bp.e parame)
    {
      return parame.a(paramd, new by.a(paramd.a, paramd.B, paramd.b, paramd.c, paramd.h, paramd.f, paramd.i, paramd.d, paramd.e, paramd.g, paramd.o, paramd.p, paramd.q));
    }
  }

  static class p extends bp.l
  {
    public Notification a(bp.d paramd, bp.e parame)
    {
      bz.a locala = new bz.a(paramd.a, paramd.B, paramd.b, paramd.c, paramd.h, paramd.f, paramd.i, paramd.d, paramd.e, paramd.g, paramd.o, paramd.p, paramd.q, paramd.l, paramd.j, paramd.n, paramd.v, paramd.x, paramd.r, paramd.s, paramd.t);
      bp.a(locala, paramd.u);
      bp.a(locala, paramd.m);
      return parame.a(paramd, locala);
    }

    public Bundle a(Notification paramNotification)
    {
      return bz.a(paramNotification);
    }

    public bp.a a(Notification paramNotification, int paramInt)
    {
      return (bp.a)bz.a(paramNotification, paramInt, bp.a.d, cf.c);
    }

    public ArrayList<Parcelable> a(bp.a[] paramArrayOfa)
    {
      return bz.a(paramArrayOfa);
    }

    public bp.a[] a(ArrayList<Parcelable> paramArrayList)
    {
      return (bp.a[])bz.a(paramArrayList, bp.a.d, cf.c);
    }

    public int b(Notification paramNotification)
    {
      return bz.b(paramNotification);
    }

    public boolean d(Notification paramNotification)
    {
      return bz.c(paramNotification);
    }

    public String e(Notification paramNotification)
    {
      return bz.d(paramNotification);
    }

    public boolean f(Notification paramNotification)
    {
      return bz.e(paramNotification);
    }

    public String g(Notification paramNotification)
    {
      return bz.f(paramNotification);
    }
  }

  static class q extends bp.p
  {
    public Notification a(bp.d paramd, bp.e parame)
    {
      ca.a locala = new ca.a(paramd.a, paramd.B, paramd.b, paramd.c, paramd.h, paramd.f, paramd.i, paramd.d, paramd.e, paramd.g, paramd.o, paramd.p, paramd.q, paramd.k, paramd.l, paramd.j, paramd.n, paramd.v, paramd.C, paramd.x, paramd.r, paramd.s, paramd.t);
      bp.a(locala, paramd.u);
      bp.a(locala, paramd.m);
      return parame.a(paramd, locala);
    }

    public Bundle a(Notification paramNotification)
    {
      return ca.a(paramNotification);
    }

    public bp.a a(Notification paramNotification, int paramInt)
    {
      return (bp.a)ca.a(paramNotification, paramInt, bp.a.d, cf.c);
    }

    public int b(Notification paramNotification)
    {
      return ca.b(paramNotification);
    }

    public boolean d(Notification paramNotification)
    {
      return ca.c(paramNotification);
    }

    public String e(Notification paramNotification)
    {
      return ca.d(paramNotification);
    }

    public boolean f(Notification paramNotification)
    {
      return ca.e(paramNotification);
    }

    public String g(Notification paramNotification)
    {
      return ca.f(paramNotification);
    }
  }

  public static abstract class r
  {
    bp.d d;
    CharSequence e;
    CharSequence f;
    boolean g = false;

    public Notification a()
    {
      bp.d locald = this.d;
      Notification localNotification = null;
      if (locald != null)
        localNotification = this.d.c();
      return localNotification;
    }

    public void a(bp.d paramd)
    {
      if (this.d != paramd)
      {
        this.d = paramd;
        if (this.d != null)
          this.d.a(this);
      }
    }
  }

  public static final class s
    implements bp.g
  {
    private static final int A = 16;
    private static final int B = 1;
    private static final int C = 8388613;
    private static final int D = 80;
    public static final int a = -1;
    public static final int b = 0;
    public static final int c = 1;
    public static final int d = 2;
    public static final int e = 3;
    public static final int f = 4;
    public static final int g = 5;
    public static final int h = 0;
    public static final int i = -1;
    private static final String j = "android.wearable.EXTENSIONS";
    private static final String k = "actions";
    private static final String l = "flags";
    private static final String m = "displayIntent";
    private static final String n = "pages";
    private static final String o = "background";
    private static final String p = "contentIcon";
    private static final String q = "contentIconGravity";
    private static final String r = "contentActionIndex";
    private static final String s = "customSizePreset";
    private static final String t = "customContentHeight";
    private static final String u = "gravity";
    private static final String v = "hintScreenTimeout";
    private static final int w = 1;
    private static final int x = 2;
    private static final int y = 4;
    private static final int z = 8;
    private ArrayList<bp.a> E = new ArrayList();
    private int F = 1;
    private PendingIntent G;
    private ArrayList<Notification> H = new ArrayList();
    private Bitmap I;
    private int J;
    private int K = 8388613;
    private int L = -1;
    private int M = 0;
    private int N;
    private int O = 80;
    private int P;

    public s()
    {
    }

    public s(Notification paramNotification)
    {
      Bundle localBundle1 = bp.a(paramNotification);
      if (localBundle1 != null);
      for (Bundle localBundle2 = localBundle1.getBundle("android.wearable.EXTENSIONS"); ; localBundle2 = null)
      {
        if (localBundle2 != null)
        {
          bp.a[] arrayOfa = bp.a().a(localBundle2.getParcelableArrayList("actions"));
          if (arrayOfa != null)
            Collections.addAll(this.E, arrayOfa);
          this.F = localBundle2.getInt("flags", 1);
          this.G = ((PendingIntent)localBundle2.getParcelable("displayIntent"));
          Notification[] arrayOfNotification = bp.a(localBundle2, "pages");
          if (arrayOfNotification != null)
            Collections.addAll(this.H, arrayOfNotification);
          this.I = ((Bitmap)localBundle2.getParcelable("background"));
          this.J = localBundle2.getInt("contentIcon");
          this.K = localBundle2.getInt("contentIconGravity", 8388613);
          this.L = localBundle2.getInt("contentActionIndex", -1);
          this.M = localBundle2.getInt("customSizePreset", 0);
          this.N = localBundle2.getInt("customContentHeight");
          this.O = localBundle2.getInt("gravity", 80);
          this.P = localBundle2.getInt("hintScreenTimeout");
        }
        return;
      }
    }

    private void a(int paramInt, boolean paramBoolean)
    {
      if (paramBoolean)
      {
        this.F = (paramInt | this.F);
        return;
      }
      this.F &= (paramInt ^ 0xFFFFFFFF);
    }

    public bp.d a(bp.d paramd)
    {
      Bundle localBundle = new Bundle();
      if (!this.E.isEmpty())
        localBundle.putParcelableArrayList("actions", bp.a().a((bp.a[])this.E.toArray(new bp.a[this.E.size()])));
      if (this.F != 1)
        localBundle.putInt("flags", this.F);
      if (this.G != null)
        localBundle.putParcelable("displayIntent", this.G);
      if (!this.H.isEmpty())
        localBundle.putParcelableArray("pages", (Parcelable[])this.H.toArray(new Notification[this.H.size()]));
      if (this.I != null)
        localBundle.putParcelable("background", this.I);
      if (this.J != 0)
        localBundle.putInt("contentIcon", this.J);
      if (this.K != 8388613)
        localBundle.putInt("contentIconGravity", this.K);
      if (this.L != -1)
        localBundle.putInt("contentActionIndex", this.L);
      if (this.M != 0)
        localBundle.putInt("customSizePreset", this.M);
      if (this.N != 0)
        localBundle.putInt("customContentHeight", this.N);
      if (this.O != 80)
        localBundle.putInt("gravity", this.O);
      if (this.P != 0)
        localBundle.putInt("hintScreenTimeout", this.P);
      paramd.a().putBundle("android.wearable.EXTENSIONS", localBundle);
      return paramd;
    }

    public s a()
    {
      s locals = new s();
      locals.E = new ArrayList(this.E);
      locals.F = this.F;
      locals.G = this.G;
      locals.H = new ArrayList(this.H);
      locals.I = this.I;
      locals.J = this.J;
      locals.K = this.K;
      locals.L = this.L;
      locals.M = this.M;
      locals.N = this.N;
      locals.O = this.O;
      locals.P = this.P;
      return locals;
    }

    public s a(int paramInt)
    {
      this.J = paramInt;
      return this;
    }

    public s a(Notification paramNotification)
    {
      this.H.add(paramNotification);
      return this;
    }

    public s a(PendingIntent paramPendingIntent)
    {
      this.G = paramPendingIntent;
      return this;
    }

    public s a(Bitmap paramBitmap)
    {
      this.I = paramBitmap;
      return this;
    }

    public s a(bp.a parama)
    {
      this.E.add(parama);
      return this;
    }

    public s a(List<bp.a> paramList)
    {
      this.E.addAll(paramList);
      return this;
    }

    public s a(boolean paramBoolean)
    {
      a(8, paramBoolean);
      return this;
    }

    public s b()
    {
      this.E.clear();
      return this;
    }

    public s b(int paramInt)
    {
      this.K = paramInt;
      return this;
    }

    public s b(List<Notification> paramList)
    {
      this.H.addAll(paramList);
      return this;
    }

    public s b(boolean paramBoolean)
    {
      a(1, paramBoolean);
      return this;
    }

    public s c(int paramInt)
    {
      this.L = paramInt;
      return this;
    }

    public s c(boolean paramBoolean)
    {
      a(2, paramBoolean);
      return this;
    }

    public List<bp.a> c()
    {
      return this.E;
    }

    public PendingIntent d()
    {
      return this.G;
    }

    public s d(int paramInt)
    {
      this.O = paramInt;
      return this;
    }

    public s d(boolean paramBoolean)
    {
      a(4, paramBoolean);
      return this;
    }

    public s e()
    {
      this.H.clear();
      return this;
    }

    public s e(int paramInt)
    {
      this.M = paramInt;
      return this;
    }

    public s e(boolean paramBoolean)
    {
      a(16, paramBoolean);
      return this;
    }

    public s f(int paramInt)
    {
      this.N = paramInt;
      return this;
    }

    public List<Notification> f()
    {
      return this.H;
    }

    public Bitmap g()
    {
      return this.I;
    }

    public s g(int paramInt)
    {
      this.P = paramInt;
      return this;
    }

    public int h()
    {
      return this.J;
    }

    public int i()
    {
      return this.K;
    }

    public int j()
    {
      return this.L;
    }

    public int k()
    {
      return this.O;
    }

    public int l()
    {
      return this.M;
    }

    public int m()
    {
      return this.N;
    }

    public boolean n()
    {
      return (0x8 & this.F) != 0;
    }

    public boolean o()
    {
      return (0x1 & this.F) != 0;
    }

    public boolean p()
    {
      return (0x2 & this.F) != 0;
    }

    public boolean q()
    {
      return (0x4 & this.F) != 0;
    }

    public boolean r()
    {
      return (0x10 & this.F) != 0;
    }

    public int s()
    {
      return this.P;
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.bp
 * JD-Core Version:    0.6.2
 */