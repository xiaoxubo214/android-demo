package android.support.v4.app;

import android.app.PendingIntent;
import android.os.Bundle;

final class bq
  implements bu.a.a
{
  public bp.a a(int paramInt, CharSequence paramCharSequence, PendingIntent paramPendingIntent, Bundle paramBundle, ci.a[] paramArrayOfa)
  {
    return new bp.a(paramInt, paramCharSequence, paramPendingIntent, paramBundle, (cf[])paramArrayOfa, null);
  }

  public bp.a[] a(int paramInt)
  {
    return new bp.a[paramInt];
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.bq
 * JD-Core Version:    0.6.2
 */