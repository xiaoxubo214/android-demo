package android.support.v4.app;

import android.app.PendingIntent;

final class br
  implements bu.b.a
{
  public bp.f.a a(String[] paramArrayOfString1, ci.a parama, PendingIntent paramPendingIntent1, PendingIntent paramPendingIntent2, String[] paramArrayOfString2, long paramLong)
  {
    return new bp.f.a(paramArrayOfString1, (cf)parama, paramPendingIntent1, paramPendingIntent2, paramArrayOfString2, paramLong);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.br
 * JD-Core Version:    0.6.2
 */