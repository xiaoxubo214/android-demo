package android.support.v4.app;

import android.app.Notification;
import android.app.Notification.Action;
import android.app.Notification.Action.Builder;
import android.app.Notification.Builder;
import android.app.PendingIntent;
import android.app.RemoteInput;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Parcelable;
import android.widget.RemoteViews;
import java.util.ArrayList;

class bs
{
  private static Notification.Action a(bu.a parama)
  {
    Notification.Action.Builder localBuilder = new Notification.Action.Builder(parama.a(), parama.b(), parama.c()).addExtras(parama.d());
    ci.a[] arrayOfa = parama.f();
    if (arrayOfa != null)
    {
      RemoteInput[] arrayOfRemoteInput = ch.a(arrayOfa);
      int i = arrayOfRemoteInput.length;
      for (int j = 0; j < i; j++)
        localBuilder.addRemoteInput(arrayOfRemoteInput[j]);
    }
    return localBuilder.build();
  }

  private static bu.a a(Notification.Action paramAction, bu.a.a parama, ci.a.a parama1)
  {
    ci.a[] arrayOfa = ch.a(paramAction.getRemoteInputs(), parama1);
    return parama.b(paramAction.icon, paramAction.title, paramAction.actionIntent, paramAction.getExtras(), arrayOfa);
  }

  public static bu.a a(Notification paramNotification, int paramInt, bu.a.a parama, ci.a.a parama1)
  {
    return a(paramNotification.actions[paramInt], parama, parama1);
  }

  public static ArrayList<Parcelable> a(bu.a[] paramArrayOfa)
  {
    Object localObject;
    if (paramArrayOfa == null)
      localObject = null;
    while (true)
    {
      return localObject;
      localObject = new ArrayList(paramArrayOfa.length);
      int i = paramArrayOfa.length;
      for (int j = 0; j < i; j++)
        ((ArrayList)localObject).add(a(paramArrayOfa[j]));
    }
  }

  public static void a(Notification.Builder paramBuilder, bu.a parama)
  {
    Notification.Action.Builder localBuilder = new Notification.Action.Builder(parama.a(), parama.b(), parama.c());
    if (parama.f() != null)
    {
      RemoteInput[] arrayOfRemoteInput = ch.a(parama.f());
      int i = arrayOfRemoteInput.length;
      for (int j = 0; j < i; j++)
        localBuilder.addRemoteInput(arrayOfRemoteInput[j]);
    }
    if (parama.d() != null)
      localBuilder.addExtras(parama.d());
    paramBuilder.addAction(localBuilder.build());
  }

  public static boolean a(Notification paramNotification)
  {
    return (0x100 & paramNotification.flags) != 0;
  }

  public static bu.a[] a(ArrayList<Parcelable> paramArrayList, bu.a.a parama, ci.a.a parama1)
  {
    if (paramArrayList == null)
      return null;
    bu.a[] arrayOfa = parama.b(paramArrayList.size());
    for (int i = 0; i < arrayOfa.length; i++)
      arrayOfa[i] = a((Notification.Action)paramArrayList.get(i), parama, parama1);
    return arrayOfa;
  }

  public static String b(Notification paramNotification)
  {
    return paramNotification.getGroup();
  }

  public static boolean c(Notification paramNotification)
  {
    return (0x200 & paramNotification.flags) != 0;
  }

  public static String d(Notification paramNotification)
  {
    return paramNotification.getSortKey();
  }

  public static class a
    implements bn, bo
  {
    private Notification.Builder a;
    private Bundle b;

    public a(Context paramContext, Notification paramNotification, CharSequence paramCharSequence1, CharSequence paramCharSequence2, CharSequence paramCharSequence3, RemoteViews paramRemoteViews, int paramInt1, PendingIntent paramPendingIntent1, PendingIntent paramPendingIntent2, Bitmap paramBitmap, int paramInt2, int paramInt3, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, int paramInt4, CharSequence paramCharSequence4, boolean paramBoolean4, ArrayList<String> paramArrayList, Bundle paramBundle, String paramString1, boolean paramBoolean5, String paramString2)
    {
      Notification.Builder localBuilder1 = new Notification.Builder(paramContext).setWhen(paramNotification.when).setShowWhen(paramBoolean2).setSmallIcon(paramNotification.icon, paramNotification.iconLevel).setContent(paramNotification.contentView).setTicker(paramNotification.tickerText, paramRemoteViews).setSound(paramNotification.sound, paramNotification.audioStreamType).setVibrate(paramNotification.vibrate).setLights(paramNotification.ledARGB, paramNotification.ledOnMS, paramNotification.ledOffMS);
      boolean bool1;
      boolean bool2;
      label120: boolean bool3;
      label142: Notification.Builder localBuilder4;
      if ((0x2 & paramNotification.flags) != 0)
      {
        bool1 = true;
        Notification.Builder localBuilder2 = localBuilder1.setOngoing(bool1);
        if ((0x8 & paramNotification.flags) == 0)
          break label335;
        bool2 = true;
        Notification.Builder localBuilder3 = localBuilder2.setOnlyAlertOnce(bool2);
        if ((0x10 & paramNotification.flags) == 0)
          break label341;
        bool3 = true;
        localBuilder4 = localBuilder3.setAutoCancel(bool3).setDefaults(paramNotification.defaults).setContentTitle(paramCharSequence1).setContentText(paramCharSequence2).setSubText(paramCharSequence4).setContentInfo(paramCharSequence3).setContentIntent(paramPendingIntent1).setDeleteIntent(paramNotification.deleteIntent);
        if ((0x80 & paramNotification.flags) == 0)
          break label347;
      }
      label335: label341: label347: for (boolean bool4 = true; ; bool4 = false)
      {
        this.a = localBuilder4.setFullScreenIntent(paramPendingIntent2, bool4).setLargeIcon(paramBitmap).setNumber(paramInt1).setUsesChronometer(paramBoolean3).setPriority(paramInt4).setProgress(paramInt2, paramInt3, paramBoolean1).setLocalOnly(paramBoolean4).setGroup(paramString1).setGroupSummary(paramBoolean5).setSortKey(paramString2);
        this.b = new Bundle();
        if (paramBundle != null)
          this.b.putAll(paramBundle);
        if ((paramArrayList != null) && (!paramArrayList.isEmpty()))
          this.b.putStringArray("android.people", (String[])paramArrayList.toArray(new String[paramArrayList.size()]));
        return;
        bool1 = false;
        break;
        bool2 = false;
        break label120;
        bool3 = false;
        break label142;
      }
    }

    public Notification.Builder a()
    {
      return this.a;
    }

    public void a(bu.a parama)
    {
      bs.a(this.a, parama);
    }

    public Notification b()
    {
      this.a.setExtras(this.b);
      return this.a.build();
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.bs
 * JD-Core Version:    0.6.2
 */