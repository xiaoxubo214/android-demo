package android.support.v4.app;

import android.app.Notification;
import android.app.Notification.Builder;
import android.app.PendingIntent;
import android.app.RemoteInput;
import android.app.RemoteInput.Builder;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Parcelable;
import android.widget.RemoteViews;
import java.util.ArrayList;
import java.util.Iterator;

class bt
{
  public static final String a = "call";
  public static final String b = "msg";
  public static final String c = "email";
  public static final String d = "event";
  public static final String e = "promo";
  public static final String f = "alarm";
  public static final String g = "progress";
  public static final String h = "social";
  public static final String i = "err";
  public static final String j = "transport";
  public static final String k = "sys";
  public static final String l = "service";
  public static final String m = "recommendation";
  public static final String n = "status";
  private static final String o = "author";
  private static final String p = "text";
  private static final String q = "messages";
  private static final String r = "remote_input";
  private static final String s = "on_reply";
  private static final String t = "on_read";
  private static final String u = "participants";
  private static final String v = "timestamp";

  private static RemoteInput a(ci.a parama)
  {
    return new RemoteInput.Builder(parama.a()).setLabel(parama.b()).setChoices(parama.c()).setAllowFreeFormInput(parama.d()).addExtras(parama.e()).build();
  }

  static Bundle a(bu.b paramb)
  {
    int i1 = 0;
    if (paramb == null)
      return null;
    Bundle localBundle1 = new Bundle();
    String[] arrayOfString = paramb.e();
    String str = null;
    if (arrayOfString != null)
    {
      int i2 = paramb.e().length;
      str = null;
      if (i2 > 1)
        str = paramb.e()[0];
    }
    Parcelable[] arrayOfParcelable = new Parcelable[paramb.a().length];
    while (i1 < arrayOfParcelable.length)
    {
      Bundle localBundle2 = new Bundle();
      localBundle2.putString("text", paramb.a()[i1]);
      localBundle2.putString("author", str);
      arrayOfParcelable[i1] = localBundle2;
      i1++;
    }
    localBundle1.putParcelableArray("messages", arrayOfParcelable);
    ci.a locala = paramb.h();
    if (locala != null)
      localBundle1.putParcelable("remote_input", a(locala));
    localBundle1.putParcelable("on_reply", paramb.c());
    localBundle1.putParcelable("on_read", paramb.d());
    localBundle1.putStringArray("participants", paramb.e());
    localBundle1.putLong("timestamp", paramb.g());
    return localBundle1;
  }

  static bu.b a(Bundle paramBundle, bu.b.a parama, ci.a.a parama1)
  {
    if (paramBundle == null)
      return null;
    Parcelable[] arrayOfParcelable = paramBundle.getParcelableArray("messages");
    String[] arrayOfString3;
    int i1;
    int i2;
    if (arrayOfParcelable != null)
    {
      arrayOfString3 = new String[arrayOfParcelable.length];
      i1 = 0;
      if (i1 < arrayOfString3.length)
      {
        boolean bool = arrayOfParcelable[i1] instanceof Bundle;
        i2 = 0;
        if (!bool)
          label52: if (i2 == 0)
            break label198;
      }
    }
    for (String[] arrayOfString1 = arrayOfString3; ; arrayOfString1 = null)
    {
      PendingIntent localPendingIntent1 = (PendingIntent)paramBundle.getParcelable("on_read");
      PendingIntent localPendingIntent2 = (PendingIntent)paramBundle.getParcelable("on_reply");
      RemoteInput localRemoteInput = (RemoteInput)paramBundle.getParcelable("remote_input");
      String[] arrayOfString2 = paramBundle.getStringArray("participants");
      if ((arrayOfString2 == null) || (arrayOfString2.length != 1))
        break;
      if (localRemoteInput != null);
      for (ci.a locala = a(localRemoteInput, parama1); ; locala = null)
      {
        return parama.b(arrayOfString1, locala, localPendingIntent2, localPendingIntent1, arrayOfString2, paramBundle.getLong("timestamp"));
        arrayOfString3[i1] = ((Bundle)arrayOfParcelable[i1]).getString("text");
        String str = arrayOfString3[i1];
        i2 = 0;
        if (str == null)
          break label52;
        i1++;
        break;
      }
      i2 = 1;
      break label52;
      label198: break;
    }
  }

  private static ci.a a(RemoteInput paramRemoteInput, ci.a.a parama)
  {
    return parama.b(paramRemoteInput.getResultKey(), paramRemoteInput.getLabel(), paramRemoteInput.getChoices(), paramRemoteInput.getAllowFreeFormInput(), paramRemoteInput.getExtras());
  }

  public static String a(Notification paramNotification)
  {
    return paramNotification.category;
  }

  public static class a
    implements bn, bo
  {
    private Notification.Builder a;

    public a(Context paramContext, Notification paramNotification1, CharSequence paramCharSequence1, CharSequence paramCharSequence2, CharSequence paramCharSequence3, RemoteViews paramRemoteViews, int paramInt1, PendingIntent paramPendingIntent1, PendingIntent paramPendingIntent2, Bitmap paramBitmap, int paramInt2, int paramInt3, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, int paramInt4, CharSequence paramCharSequence4, boolean paramBoolean4, String paramString1, ArrayList<String> paramArrayList, Bundle paramBundle, int paramInt5, int paramInt6, Notification paramNotification2, String paramString2, boolean paramBoolean5, String paramString3)
    {
      Notification.Builder localBuilder1 = new Notification.Builder(paramContext).setWhen(paramNotification1.when).setShowWhen(paramBoolean2).setSmallIcon(paramNotification1.icon, paramNotification1.iconLevel).setContent(paramNotification1.contentView).setTicker(paramNotification1.tickerText, paramRemoteViews).setSound(paramNotification1.sound, paramNotification1.audioStreamType).setVibrate(paramNotification1.vibrate).setLights(paramNotification1.ledARGB, paramNotification1.ledOnMS, paramNotification1.ledOffMS);
      boolean bool1;
      boolean bool2;
      label120: boolean bool3;
      label142: Notification.Builder localBuilder4;
      if ((0x2 & paramNotification1.flags) != 0)
      {
        bool1 = true;
        Notification.Builder localBuilder2 = localBuilder1.setOngoing(bool1);
        if ((0x8 & paramNotification1.flags) == 0)
          break label338;
        bool2 = true;
        Notification.Builder localBuilder3 = localBuilder2.setOnlyAlertOnce(bool2);
        if ((0x10 & paramNotification1.flags) == 0)
          break label344;
        bool3 = true;
        localBuilder4 = localBuilder3.setAutoCancel(bool3).setDefaults(paramNotification1.defaults).setContentTitle(paramCharSequence1).setContentText(paramCharSequence2).setSubText(paramCharSequence4).setContentInfo(paramCharSequence3).setContentIntent(paramPendingIntent1).setDeleteIntent(paramNotification1.deleteIntent);
        if ((0x80 & paramNotification1.flags) == 0)
          break label350;
      }
      label338: label344: label350: for (boolean bool4 = true; ; bool4 = false)
      {
        this.a = localBuilder4.setFullScreenIntent(paramPendingIntent2, bool4).setLargeIcon(paramBitmap).setNumber(paramInt1).setUsesChronometer(paramBoolean3).setPriority(paramInt4).setProgress(paramInt2, paramInt3, paramBoolean1).setLocalOnly(paramBoolean4).setExtras(paramBundle).setGroup(paramString2).setGroupSummary(paramBoolean5).setSortKey(paramString3).setCategory(paramString1).setColor(paramInt5).setVisibility(paramInt6).setPublicVersion(paramNotification2);
        Iterator localIterator = paramArrayList.iterator();
        while (localIterator.hasNext())
        {
          String str = (String)localIterator.next();
          this.a.addPerson(str);
        }
        bool1 = false;
        break;
        bool2 = false;
        break label120;
        bool3 = false;
        break label142;
      }
    }

    public Notification.Builder a()
    {
      return this.a;
    }

    public void a(bu.a parama)
    {
      bs.a(this.a, parama);
    }

    public Notification b()
    {
      return this.a.build();
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.bt
 * JD-Core Version:    0.6.2
 */