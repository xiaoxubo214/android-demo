package android.support.v4.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.os.Bundle;

public class bu
{
  public static Notification a(Notification paramNotification, Context paramContext, CharSequence paramCharSequence1, CharSequence paramCharSequence2, PendingIntent paramPendingIntent)
  {
    paramNotification.setLatestEventInfo(paramContext, paramCharSequence1, paramCharSequence2, paramPendingIntent);
    return paramNotification;
  }

  public static abstract class a
  {
    public abstract int a();

    public abstract CharSequence b();

    public abstract PendingIntent c();

    public abstract Bundle d();

    public abstract ci.a[] f();

    public static abstract interface a
    {
      public abstract bu.a b(int paramInt, CharSequence paramCharSequence, PendingIntent paramPendingIntent, Bundle paramBundle, ci.a[] paramArrayOfa);

      public abstract bu.a[] b(int paramInt);
    }
  }

  public static abstract class b
  {
    abstract String[] a();

    abstract PendingIntent c();

    abstract PendingIntent d();

    abstract String[] e();

    abstract String f();

    abstract long g();

    abstract ci.a h();

    public static abstract interface a
    {
      public abstract bu.b b(String[] paramArrayOfString1, ci.a parama, PendingIntent paramPendingIntent1, PendingIntent paramPendingIntent2, String[] paramArrayOfString2, long paramLong);
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.bu
 * JD-Core Version:    0.6.2
 */