package android.support.v4.app;

public final class bv
{
  public static final String a = "android.support.localOnly";
  public static final String b = "android.support.groupKey";
  public static final String c = "android.support.isGroupSummary";
  public static final String d = "android.support.sortKey";
  public static final String e = "android.support.actionExtras";
  public static final String f = "android.support.remoteInputs";
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.bv
 * JD-Core Version:    0.6.2
 */