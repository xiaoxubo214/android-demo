package android.support.v4.app;

import android.app.Notification;
import android.app.Notification.BigPictureStyle;
import android.app.Notification.BigTextStyle;
import android.app.Notification.Builder;
import android.app.Notification.InboxStyle;
import android.app.PendingIntent;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.util.SparseArray;
import android.widget.RemoteViews;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

class bz
{
  public static final String a = "NotificationCompat";
  static final String b = "android.support.localOnly";
  static final String c = "android.support.actionExtras";
  static final String d = "android.support.remoteInputs";
  static final String e = "android.support.groupKey";
  static final String f = "android.support.isGroupSummary";
  static final String g = "android.support.sortKey";
  static final String h = "android.support.useSideChannel";
  private static final String i = "icon";
  private static final String j = "title";
  private static final String k = "actionIntent";
  private static final String l = "extras";
  private static final String m = "remoteInputs";
  private static final Object n = new Object();
  private static Field o;
  private static boolean p;
  private static final Object q = new Object();
  private static Class<?> r;
  private static Field s;
  private static Field t;
  private static Field u;
  private static Field v;
  private static boolean w;

  public static Bundle a(Notification.Builder paramBuilder, bu.a parama)
  {
    paramBuilder.addAction(parama.a(), parama.b(), parama.c());
    Bundle localBundle = new Bundle(parama.d());
    if (parama.f() != null)
      localBundle.putParcelableArray("android.support.remoteInputs", cj.a(parama.f()));
    return localBundle;
  }

  public static Bundle a(Notification paramNotification)
  {
    synchronized (n)
    {
      if (p)
        return null;
    }
    try
    {
      if (o == null)
      {
        Field localField = Notification.class.getDeclaredField("extras");
        if (!Bundle.class.isAssignableFrom(localField.getType()))
        {
          Log.e("NotificationCompat", "Notification.extras field is not of type Bundle");
          p = true;
          return null;
        }
        localField.setAccessible(true);
        o = localField;
      }
      Bundle localBundle = (Bundle)o.get(paramNotification);
      if (localBundle == null)
      {
        localBundle = new Bundle();
        o.set(paramNotification, localBundle);
      }
      return localBundle;
      localObject2 = finally;
      throw localObject2;
    }
    catch (IllegalAccessException localIllegalAccessException)
    {
      Log.e("NotificationCompat", "Unable to access notification extras", localIllegalAccessException);
      p = true;
      return null;
    }
    catch (NoSuchFieldException localNoSuchFieldException)
    {
      while (true)
        Log.e("NotificationCompat", "Unable to access notification extras", localNoSuchFieldException);
    }
  }

  private static Bundle a(bu.a parama)
  {
    Bundle localBundle = new Bundle();
    localBundle.putInt("icon", parama.a());
    localBundle.putCharSequence("title", parama.b());
    localBundle.putParcelable("actionIntent", parama.c());
    localBundle.putBundle("extras", parama.d());
    localBundle.putParcelableArray("remoteInputs", cj.a(parama.f()));
    return localBundle;
  }

  public static bu.a a(Notification paramNotification, int paramInt, bu.a.a parama, ci.a.a parama1)
  {
    while (true)
    {
      synchronized (q)
      {
        try
        {
          Object localObject3 = g(paramNotification)[paramInt];
          Bundle localBundle1 = a(paramNotification);
          if (localBundle1 != null)
          {
            SparseArray localSparseArray = localBundle1.getSparseParcelableArray("android.support.actionExtras");
            if (localSparseArray != null)
            {
              localBundle2 = (Bundle)localSparseArray.get(paramInt);
              bu.a locala = a(parama, parama1, t.getInt(localObject3), (CharSequence)u.get(localObject3), (PendingIntent)v.get(localObject3), localBundle2);
              return locala;
            }
          }
        }
        catch (IllegalAccessException localIllegalAccessException)
        {
          Log.e("NotificationCompat", "Unable to access notification actions", localIllegalAccessException);
          w = true;
          return null;
        }
      }
      Bundle localBundle2 = null;
    }
  }

  private static bu.a a(Bundle paramBundle, bu.a.a parama, ci.a.a parama1)
  {
    return parama.b(paramBundle.getInt("icon"), paramBundle.getCharSequence("title"), (PendingIntent)paramBundle.getParcelable("actionIntent"), paramBundle.getBundle("extras"), cj.a(ab.a(paramBundle, "remoteInputs"), parama1));
  }

  public static bu.a a(bu.a.a parama, ci.a.a parama1, int paramInt, CharSequence paramCharSequence, PendingIntent paramPendingIntent, Bundle paramBundle)
  {
    ci.a[] arrayOfa = null;
    if (paramBundle != null)
      arrayOfa = cj.a(ab.a(paramBundle, "android.support.remoteInputs"), parama1);
    return parama.b(paramInt, paramCharSequence, paramPendingIntent, paramBundle, arrayOfa);
  }

  public static SparseArray<Bundle> a(List<Bundle> paramList)
  {
    SparseArray localSparseArray = null;
    int i1 = paramList.size();
    for (int i2 = 0; i2 < i1; i2++)
    {
      Bundle localBundle = (Bundle)paramList.get(i2);
      if (localBundle != null)
      {
        if (localSparseArray == null)
          localSparseArray = new SparseArray();
        localSparseArray.put(i2, localBundle);
      }
    }
    return localSparseArray;
  }

  public static ArrayList<Parcelable> a(bu.a[] paramArrayOfa)
  {
    Object localObject;
    if (paramArrayOfa == null)
      localObject = null;
    while (true)
    {
      return localObject;
      localObject = new ArrayList(paramArrayOfa.length);
      int i1 = paramArrayOfa.length;
      for (int i2 = 0; i2 < i1; i2++)
        ((ArrayList)localObject).add(a(paramArrayOfa[i2]));
    }
  }

  public static void a(bo parambo, CharSequence paramCharSequence1, boolean paramBoolean1, CharSequence paramCharSequence2, Bitmap paramBitmap1, Bitmap paramBitmap2, boolean paramBoolean2)
  {
    Notification.BigPictureStyle localBigPictureStyle = new Notification.BigPictureStyle(parambo.a()).setBigContentTitle(paramCharSequence1).bigPicture(paramBitmap1);
    if (paramBoolean2)
      localBigPictureStyle.bigLargeIcon(paramBitmap2);
    if (paramBoolean1)
      localBigPictureStyle.setSummaryText(paramCharSequence2);
  }

  public static void a(bo parambo, CharSequence paramCharSequence1, boolean paramBoolean, CharSequence paramCharSequence2, CharSequence paramCharSequence3)
  {
    Notification.BigTextStyle localBigTextStyle = new Notification.BigTextStyle(parambo.a()).setBigContentTitle(paramCharSequence1).bigText(paramCharSequence3);
    if (paramBoolean)
      localBigTextStyle.setSummaryText(paramCharSequence2);
  }

  public static void a(bo parambo, CharSequence paramCharSequence1, boolean paramBoolean, CharSequence paramCharSequence2, ArrayList<CharSequence> paramArrayList)
  {
    Notification.InboxStyle localInboxStyle = new Notification.InboxStyle(parambo.a()).setBigContentTitle(paramCharSequence1);
    if (paramBoolean)
      localInboxStyle.setSummaryText(paramCharSequence2);
    Iterator localIterator = paramArrayList.iterator();
    while (localIterator.hasNext())
      localInboxStyle.addLine((CharSequence)localIterator.next());
  }

  private static boolean a()
  {
    boolean bool = true;
    if (w)
      return false;
    try
    {
      if (s == null)
      {
        r = Class.forName("android.app.Notification$Action");
        t = r.getDeclaredField("icon");
        u = r.getDeclaredField("title");
        v = r.getDeclaredField("actionIntent");
        s = Notification.class.getDeclaredField("actions");
        s.setAccessible(true);
      }
      if (!w)
        return bool;
    }
    catch (ClassNotFoundException localClassNotFoundException)
    {
      while (true)
      {
        Log.e("NotificationCompat", "Unable to access notification actions", localClassNotFoundException);
        w = bool;
      }
    }
    catch (NoSuchFieldException localNoSuchFieldException)
    {
      while (true)
      {
        Log.e("NotificationCompat", "Unable to access notification actions", localNoSuchFieldException);
        w = bool;
        continue;
        bool = false;
      }
    }
  }

  public static bu.a[] a(ArrayList<Parcelable> paramArrayList, bu.a.a parama, ci.a.a parama1)
  {
    if (paramArrayList == null)
      return null;
    bu.a[] arrayOfa = parama.b(paramArrayList.size());
    for (int i1 = 0; i1 < arrayOfa.length; i1++)
      arrayOfa[i1] = a((Bundle)paramArrayList.get(i1), parama, parama1);
    return arrayOfa;
  }

  public static int b(Notification paramNotification)
  {
    while (true)
    {
      synchronized (q)
      {
        Object[] arrayOfObject = g(paramNotification);
        if (arrayOfObject != null)
        {
          i1 = arrayOfObject.length;
          return i1;
        }
      }
      int i1 = 0;
    }
  }

  public static boolean c(Notification paramNotification)
  {
    return a(paramNotification).getBoolean("android.support.localOnly");
  }

  public static String d(Notification paramNotification)
  {
    return a(paramNotification).getString("android.support.groupKey");
  }

  public static boolean e(Notification paramNotification)
  {
    return a(paramNotification).getBoolean("android.support.isGroupSummary");
  }

  public static String f(Notification paramNotification)
  {
    return a(paramNotification).getString("android.support.sortKey");
  }

  private static Object[] g(Notification paramNotification)
  {
    synchronized (q)
    {
      if (!a())
        return null;
    }
    try
    {
      Object[] arrayOfObject = (Object[])s.get(paramNotification);
      return arrayOfObject;
      localObject2 = finally;
      throw localObject2;
    }
    catch (IllegalAccessException localIllegalAccessException)
    {
      Log.e("NotificationCompat", "Unable to access notification actions", localIllegalAccessException);
      w = true;
    }
    return null;
  }

  public static class a
    implements bn, bo
  {
    private Notification.Builder a;
    private final Bundle b;
    private List<Bundle> c = new ArrayList();

    public a(Context paramContext, Notification paramNotification, CharSequence paramCharSequence1, CharSequence paramCharSequence2, CharSequence paramCharSequence3, RemoteViews paramRemoteViews, int paramInt1, PendingIntent paramPendingIntent1, PendingIntent paramPendingIntent2, Bitmap paramBitmap, int paramInt2, int paramInt3, boolean paramBoolean1, boolean paramBoolean2, int paramInt4, CharSequence paramCharSequence4, boolean paramBoolean3, Bundle paramBundle, String paramString1, boolean paramBoolean4, String paramString2)
    {
      Notification.Builder localBuilder1 = new Notification.Builder(paramContext).setWhen(paramNotification.when).setSmallIcon(paramNotification.icon, paramNotification.iconLevel).setContent(paramNotification.contentView).setTicker(paramNotification.tickerText, paramRemoteViews).setSound(paramNotification.sound, paramNotification.audioStreamType).setVibrate(paramNotification.vibrate).setLights(paramNotification.ledARGB, paramNotification.ledOnMS, paramNotification.ledOffMS);
      boolean bool1;
      boolean bool2;
      label126: boolean bool3;
      label148: boolean bool4;
      if ((0x2 & paramNotification.flags) != 0)
      {
        bool1 = true;
        Notification.Builder localBuilder2 = localBuilder1.setOngoing(bool1);
        if ((0x8 & paramNotification.flags) == 0)
          break label345;
        bool2 = true;
        Notification.Builder localBuilder3 = localBuilder2.setOnlyAlertOnce(bool2);
        if ((0x10 & paramNotification.flags) == 0)
          break label351;
        bool3 = true;
        Notification.Builder localBuilder4 = localBuilder3.setAutoCancel(bool3).setDefaults(paramNotification.defaults).setContentTitle(paramCharSequence1).setContentText(paramCharSequence2).setSubText(paramCharSequence4).setContentInfo(paramCharSequence3).setContentIntent(paramPendingIntent1).setDeleteIntent(paramNotification.deleteIntent);
        if ((0x80 & paramNotification.flags) == 0)
          break label357;
        bool4 = true;
        label209: this.a = localBuilder4.setFullScreenIntent(paramPendingIntent2, bool4).setLargeIcon(paramBitmap).setNumber(paramInt1).setUsesChronometer(paramBoolean2).setPriority(paramInt4).setProgress(paramInt2, paramInt3, paramBoolean1);
        this.b = new Bundle();
        if (paramBundle != null)
          this.b.putAll(paramBundle);
        if (paramBoolean3)
          this.b.putBoolean("android.support.localOnly", true);
        if (paramString1 != null)
        {
          this.b.putString("android.support.groupKey", paramString1);
          if (!paramBoolean4)
            break label363;
          this.b.putBoolean("android.support.isGroupSummary", true);
        }
      }
      while (true)
      {
        if (paramString2 != null)
          this.b.putString("android.support.sortKey", paramString2);
        return;
        bool1 = false;
        break;
        label345: bool2 = false;
        break label126;
        label351: bool3 = false;
        break label148;
        label357: bool4 = false;
        break label209;
        label363: this.b.putBoolean("android.support.useSideChannel", true);
      }
    }

    public Notification.Builder a()
    {
      return this.a;
    }

    public void a(bu.a parama)
    {
      this.c.add(bz.a(this.a, parama));
    }

    public Notification b()
    {
      Notification localNotification = this.a.build();
      Bundle localBundle1 = bz.a(localNotification);
      Bundle localBundle2 = new Bundle(this.b);
      Iterator localIterator = this.b.keySet().iterator();
      while (localIterator.hasNext())
      {
        String str = (String)localIterator.next();
        if (localBundle1.containsKey(str))
          localBundle2.remove(str);
      }
      localBundle1.putAll(localBundle2);
      SparseArray localSparseArray = bz.a(this.c);
      if (localSparseArray != null)
        bz.a(localNotification).putSparseParcelableArray("android.support.actionExtras", localSparseArray);
      return localNotification;
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.bz
 * JD-Core Version:    0.6.2
 */