package android.support.v4.app;

import android.app.Notification;
import android.app.NotificationManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.DeadObjectException;
import android.os.Handler;
import android.os.Handler.Callback;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Message;
import android.os.RemoteException;
import android.provider.Settings.Secure;
import android.util.Log;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public final class cc
{
  public static final String a = "android.support.useSideChannel";
  public static final String b = "android.support.BIND_NOTIFICATION_SIDE_CHANNEL";
  static final int c = 19;
  private static final String d = "NotifManCompat";
  private static final int e = 1000;
  private static final int f = 6;
  private static final String g = "enabled_notification_listeners";
  private static final int h;
  private static final Object i = new Object();
  private static String j;
  private static Set<String> k = new HashSet();
  private static final Object n = new Object();
  private static h o;
  private static final b p;
  private final Context l;
  private final NotificationManager m;

  static
  {
    if (Build.VERSION.SDK_INT >= 14)
      p = new e();
    while (true)
    {
      h = p.a();
      return;
      if (Build.VERSION.SDK_INT >= 5)
        p = new d();
      else
        p = new c();
    }
  }

  private cc(Context paramContext)
  {
    this.l = paramContext;
    this.m = ((NotificationManager)this.l.getSystemService("notification"));
  }

  public static cc a(Context paramContext)
  {
    return new cc(paramContext);
  }

  private void a(i parami)
  {
    synchronized (n)
    {
      if (o == null)
        o = new h(this.l.getApplicationContext());
      o.a(parami);
      return;
    }
  }

  private static boolean a(Notification paramNotification)
  {
    Bundle localBundle = bp.a(paramNotification);
    return (localBundle != null) && (localBundle.getBoolean("android.support.useSideChannel"));
  }

  public static Set<String> b(Context paramContext)
  {
    String str = Settings.Secure.getString(paramContext.getContentResolver(), "enabled_notification_listeners");
    HashSet localHashSet;
    if ((str != null) && (!str.equals(j)))
    {
      String[] arrayOfString = str.split(":");
      localHashSet = new HashSet(arrayOfString.length);
      int i1 = arrayOfString.length;
      for (int i2 = 0; i2 < i1; i2++)
      {
        ComponentName localComponentName = ComponentName.unflattenFromString(arrayOfString[i2]);
        if (localComponentName != null)
          localHashSet.add(localComponentName.getPackageName());
      }
    }
    synchronized (i)
    {
      k = localHashSet;
      j = str;
      return k;
    }
  }

  public void a()
  {
    this.m.cancelAll();
    if (Build.VERSION.SDK_INT <= 19)
      a(new a(this.l.getPackageName()));
  }

  public void a(int paramInt)
  {
    a(null, paramInt);
  }

  public void a(int paramInt, Notification paramNotification)
  {
    a(null, paramInt, paramNotification);
  }

  public void a(String paramString, int paramInt)
  {
    p.a(this.m, paramString, paramInt);
    if (Build.VERSION.SDK_INT <= 19)
      a(new a(this.l.getPackageName(), paramInt, paramString));
  }

  public void a(String paramString, int paramInt, Notification paramNotification)
  {
    if (a(paramNotification))
    {
      a(new f(this.l.getPackageName(), paramInt, paramString, paramNotification));
      p.a(this.m, paramString, paramInt);
      return;
    }
    p.a(this.m, paramString, paramInt, paramNotification);
  }

  private static class a
    implements cc.i
  {
    final String a;
    final int b;
    final String c;
    final boolean d;

    public a(String paramString)
    {
      this.a = paramString;
      this.b = 0;
      this.c = null;
      this.d = true;
    }

    public a(String paramString1, int paramInt, String paramString2)
    {
      this.a = paramString1;
      this.b = paramInt;
      this.c = paramString2;
      this.d = false;
    }

    public void a(be parambe)
      throws RemoteException
    {
      if (this.d)
      {
        parambe.a(this.a);
        return;
      }
      parambe.a(this.a, this.b, this.c);
    }

    public String toString()
    {
      StringBuilder localStringBuilder = new StringBuilder("CancelTask[");
      localStringBuilder.append("packageName:").append(this.a);
      localStringBuilder.append(", id:").append(this.b);
      localStringBuilder.append(", tag:").append(this.c);
      localStringBuilder.append(", all:").append(this.d);
      localStringBuilder.append("]");
      return localStringBuilder.toString();
    }
  }

  static abstract interface b
  {
    public abstract int a();

    public abstract void a(NotificationManager paramNotificationManager, String paramString, int paramInt);

    public abstract void a(NotificationManager paramNotificationManager, String paramString, int paramInt, Notification paramNotification);
  }

  static class c
    implements cc.b
  {
    public int a()
    {
      return 1;
    }

    public void a(NotificationManager paramNotificationManager, String paramString, int paramInt)
    {
      paramNotificationManager.cancel(paramInt);
    }

    public void a(NotificationManager paramNotificationManager, String paramString, int paramInt, Notification paramNotification)
    {
      paramNotificationManager.notify(paramInt, paramNotification);
    }
  }

  static class d extends cc.c
  {
    public void a(NotificationManager paramNotificationManager, String paramString, int paramInt)
    {
      cd.a(paramNotificationManager, paramString, paramInt);
    }

    public void a(NotificationManager paramNotificationManager, String paramString, int paramInt, Notification paramNotification)
    {
      cd.a(paramNotificationManager, paramString, paramInt, paramNotification);
    }
  }

  static class e extends cc.d
  {
    public int a()
    {
      return 33;
    }
  }

  private static class f
    implements cc.i
  {
    final String a;
    final int b;
    final String c;
    final Notification d;

    public f(String paramString1, int paramInt, String paramString2, Notification paramNotification)
    {
      this.a = paramString1;
      this.b = paramInt;
      this.c = paramString2;
      this.d = paramNotification;
    }

    public void a(be parambe)
      throws RemoteException
    {
      parambe.a(this.a, this.b, this.c, this.d);
    }

    public String toString()
    {
      StringBuilder localStringBuilder = new StringBuilder("NotifyTask[");
      localStringBuilder.append("packageName:").append(this.a);
      localStringBuilder.append(", id:").append(this.b);
      localStringBuilder.append(", tag:").append(this.c);
      localStringBuilder.append("]");
      return localStringBuilder.toString();
    }
  }

  private static class g
  {
    final ComponentName a;
    final IBinder b;

    public g(ComponentName paramComponentName, IBinder paramIBinder)
    {
      this.a = paramComponentName;
      this.b = paramIBinder;
    }
  }

  private static class h
    implements ServiceConnection, Handler.Callback
  {
    private static final int a = 0;
    private static final int b = 1;
    private static final int c = 2;
    private static final int d = 3;
    private static final String e = "binder";
    private final Context f;
    private final HandlerThread g;
    private final Handler h;
    private final Map<ComponentName, a> i = new HashMap();
    private Set<String> j = new HashSet();

    public h(Context paramContext)
    {
      this.f = paramContext;
      this.g = new HandlerThread("NotificationManagerCompat");
      this.g.start();
      this.h = new Handler(this.g.getLooper(), this);
    }

    private void a()
    {
      Set localSet = cc.b(this.f);
      if (localSet.equals(this.j));
      while (true)
      {
        return;
        this.j = localSet;
        List localList = this.f.getPackageManager().queryIntentServices(new Intent().setAction("android.support.BIND_NOTIFICATION_SIDE_CHANNEL"), 4);
        HashSet localHashSet = new HashSet();
        Iterator localIterator1 = localList.iterator();
        while (localIterator1.hasNext())
        {
          ResolveInfo localResolveInfo = (ResolveInfo)localIterator1.next();
          if (localSet.contains(localResolveInfo.serviceInfo.packageName))
          {
            ComponentName localComponentName2 = new ComponentName(localResolveInfo.serviceInfo.packageName, localResolveInfo.serviceInfo.name);
            if (localResolveInfo.serviceInfo.permission != null)
              Log.w("NotifManCompat", "Permission present on component " + localComponentName2 + ", not adding listener record.");
            else
              localHashSet.add(localComponentName2);
          }
        }
        Iterator localIterator2 = localHashSet.iterator();
        while (localIterator2.hasNext())
        {
          ComponentName localComponentName1 = (ComponentName)localIterator2.next();
          if (!this.i.containsKey(localComponentName1))
          {
            if (Log.isLoggable("NotifManCompat", 3))
              Log.d("NotifManCompat", "Adding listener record for " + localComponentName1);
            this.i.put(localComponentName1, new a(localComponentName1));
          }
        }
        Iterator localIterator3 = this.i.entrySet().iterator();
        while (localIterator3.hasNext())
        {
          Map.Entry localEntry = (Map.Entry)localIterator3.next();
          if (!localHashSet.contains(localEntry.getKey()))
          {
            if (Log.isLoggable("NotifManCompat", 3))
              Log.d("NotifManCompat", "Removing listener record for " + localEntry.getKey());
            b((a)localEntry.getValue());
            localIterator3.remove();
          }
        }
      }
    }

    private void a(ComponentName paramComponentName)
    {
      a locala = (a)this.i.get(paramComponentName);
      if (locala != null)
        b(locala);
    }

    private void a(ComponentName paramComponentName, IBinder paramIBinder)
    {
      a locala = (a)this.i.get(paramComponentName);
      if (locala != null)
      {
        locala.c = be.a.a(paramIBinder);
        locala.e = 0;
        d(locala);
      }
    }

    private boolean a(a parama)
    {
      if (parama.b)
        return true;
      Intent localIntent = new Intent("android.support.BIND_NOTIFICATION_SIDE_CHANNEL").setComponent(parama.a);
      parama.b = this.f.bindService(localIntent, this, cc.b());
      if (parama.b)
        parama.e = 0;
      while (true)
      {
        return parama.b;
        Log.w("NotifManCompat", "Unable to bind to listener " + parama.a);
        this.f.unbindService(this);
      }
    }

    private void b(ComponentName paramComponentName)
    {
      a locala = (a)this.i.get(paramComponentName);
      if (locala != null)
        d(locala);
    }

    private void b(a parama)
    {
      if (parama.b)
      {
        this.f.unbindService(this);
        parama.b = false;
      }
      parama.c = null;
    }

    private void b(cc.i parami)
    {
      a();
      Iterator localIterator = this.i.values().iterator();
      while (localIterator.hasNext())
      {
        a locala = (a)localIterator.next();
        locala.d.add(parami);
        d(locala);
      }
    }

    private void c(a parama)
    {
      if (this.h.hasMessages(3, parama.a))
        return;
      parama.e = (1 + parama.e);
      if (parama.e > 6)
      {
        Log.w("NotifManCompat", "Giving up on delivering " + parama.d.size() + " tasks to " + parama.a + " after " + parama.e + " retries");
        parama.d.clear();
        return;
      }
      int k = 1000 * (1 << -1 + parama.e);
      if (Log.isLoggable("NotifManCompat", 3))
        Log.d("NotifManCompat", "Scheduling retry for " + k + " ms");
      Message localMessage = this.h.obtainMessage(3, parama.a);
      this.h.sendMessageDelayed(localMessage, k);
    }

    private void d(a parama)
    {
      if (Log.isLoggable("NotifManCompat", 3))
        Log.d("NotifManCompat", "Processing component " + parama.a + ", " + parama.d.size() + " queued tasks");
      if (parama.d.isEmpty());
      while (true)
      {
        return;
        if ((!a(parama)) || (parama.c == null))
        {
          c(parama);
          return;
        }
        try
        {
          Object localObject;
          do
          {
            if (Log.isLoggable("NotifManCompat", 3))
              Log.d("NotifManCompat", "Sending task " + localObject);
            ((cc.i)localObject).a(parama.c);
            parama.d.remove();
            localObject = (cc.i)parama.d.peek();
          }
          while (localObject != null);
          if (parama.d.isEmpty())
            continue;
          c(parama);
          return;
        }
        catch (DeadObjectException localDeadObjectException)
        {
          while (true)
            if (Log.isLoggable("NotifManCompat", 3))
              Log.d("NotifManCompat", "Remote service has died: " + parama.a);
        }
        catch (RemoteException localRemoteException)
        {
          while (true)
            Log.w("NotifManCompat", "RemoteException communicating with " + parama.a, localRemoteException);
        }
      }
    }

    public void a(cc.i parami)
    {
      this.h.obtainMessage(0, parami).sendToTarget();
    }

    public boolean handleMessage(Message paramMessage)
    {
      switch (paramMessage.what)
      {
      default:
        return false;
      case 0:
        b((cc.i)paramMessage.obj);
        return true;
      case 1:
        cc.g localg = (cc.g)paramMessage.obj;
        a(localg.a, localg.b);
        return true;
      case 2:
        a((ComponentName)paramMessage.obj);
        return true;
      case 3:
      }
      b((ComponentName)paramMessage.obj);
      return true;
    }

    public void onServiceConnected(ComponentName paramComponentName, IBinder paramIBinder)
    {
      if (Log.isLoggable("NotifManCompat", 3))
        Log.d("NotifManCompat", "Connected to service " + paramComponentName);
      this.h.obtainMessage(1, new cc.g(paramComponentName, paramIBinder)).sendToTarget();
    }

    public void onServiceDisconnected(ComponentName paramComponentName)
    {
      if (Log.isLoggable("NotifManCompat", 3))
        Log.d("NotifManCompat", "Disconnected from service " + paramComponentName);
      this.h.obtainMessage(2, paramComponentName).sendToTarget();
    }

    private static class a
    {
      public final ComponentName a;
      public boolean b = false;
      public be c;
      public LinkedList<cc.i> d = new LinkedList();
      public int e = 0;

      public a(ComponentName paramComponentName)
      {
        this.a = paramComponentName;
      }
    }
  }

  private static abstract interface i
  {
    public abstract void a(be parambe)
      throws RemoteException;
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.cc
 * JD-Core Version:    0.6.2
 */