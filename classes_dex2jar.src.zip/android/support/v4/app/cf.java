package android.support.v4.app;

import android.content.Intent;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.util.Log;

public final class cf extends ci.a
{
  public static final String a = "android.remoteinput.results";
  public static final String b = "android.remoteinput.resultsData";
  public static final ci.a.a c;
  private static final String d = "RemoteInput";
  private static final b j;
  private final String e;
  private final CharSequence f;
  private final CharSequence[] g;
  private final boolean h;
  private final Bundle i;

  static
  {
    if (Build.VERSION.SDK_INT >= 20)
      j = new c();
    while (true)
    {
      c = new cg();
      return;
      if (Build.VERSION.SDK_INT >= 16)
        j = new e();
      else
        j = new d();
    }
  }

  private cf(String paramString, CharSequence paramCharSequence, CharSequence[] paramArrayOfCharSequence, boolean paramBoolean, Bundle paramBundle)
  {
    this.e = paramString;
    this.f = paramCharSequence;
    this.g = paramArrayOfCharSequence;
    this.h = paramBoolean;
    this.i = paramBundle;
  }

  public static Bundle a(Intent paramIntent)
  {
    return j.a(paramIntent);
  }

  public static void a(cf[] paramArrayOfcf, Intent paramIntent, Bundle paramBundle)
  {
    j.a(paramArrayOfcf, paramIntent, paramBundle);
  }

  public String a()
  {
    return this.e;
  }

  public CharSequence b()
  {
    return this.f;
  }

  public CharSequence[] c()
  {
    return this.g;
  }

  public boolean d()
  {
    return this.h;
  }

  public Bundle e()
  {
    return this.i;
  }

  public static final class a
  {
    private final String a;
    private CharSequence b;
    private CharSequence[] c;
    private boolean d = true;
    private Bundle e = new Bundle();

    public a(String paramString)
    {
      if (paramString == null)
        throw new IllegalArgumentException("Result key can't be null");
      this.a = paramString;
    }

    public Bundle a()
    {
      return this.e;
    }

    public a a(Bundle paramBundle)
    {
      if (paramBundle != null)
        this.e.putAll(paramBundle);
      return this;
    }

    public a a(CharSequence paramCharSequence)
    {
      this.b = paramCharSequence;
      return this;
    }

    public a a(boolean paramBoolean)
    {
      this.d = paramBoolean;
      return this;
    }

    public a a(CharSequence[] paramArrayOfCharSequence)
    {
      this.c = paramArrayOfCharSequence;
      return this;
    }

    public cf b()
    {
      return new cf(this.a, this.b, this.c, this.d, this.e, null);
    }
  }

  static abstract interface b
  {
    public abstract Bundle a(Intent paramIntent);

    public abstract void a(cf[] paramArrayOfcf, Intent paramIntent, Bundle paramBundle);
  }

  static class c
    implements cf.b
  {
    public Bundle a(Intent paramIntent)
    {
      return ch.a(paramIntent);
    }

    public void a(cf[] paramArrayOfcf, Intent paramIntent, Bundle paramBundle)
    {
      ch.a(paramArrayOfcf, paramIntent, paramBundle);
    }
  }

  static class d
    implements cf.b
  {
    public Bundle a(Intent paramIntent)
    {
      Log.w("RemoteInput", "RemoteInput is only supported from API Level 16");
      return null;
    }

    public void a(cf[] paramArrayOfcf, Intent paramIntent, Bundle paramBundle)
    {
      Log.w("RemoteInput", "RemoteInput is only supported from API Level 16");
    }
  }

  static class e
    implements cf.b
  {
    public Bundle a(Intent paramIntent)
    {
      return cj.a(paramIntent);
    }

    public void a(cf[] paramArrayOfcf, Intent paramIntent, Bundle paramBundle)
    {
      cj.a(paramArrayOfcf, paramIntent, paramBundle);
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.cf
 * JD-Core Version:    0.6.2
 */