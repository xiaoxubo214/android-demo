package android.support.v4.app;

import android.os.Bundle;

final class cg
  implements ci.a.a
{
  public cf a(String paramString, CharSequence paramCharSequence, CharSequence[] paramArrayOfCharSequence, boolean paramBoolean, Bundle paramBundle)
  {
    return new cf(paramString, paramCharSequence, paramArrayOfCharSequence, paramBoolean, paramBundle, null);
  }

  public cf[] a(int paramInt)
  {
    return new cf[paramInt];
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.cg
 * JD-Core Version:    0.6.2
 */