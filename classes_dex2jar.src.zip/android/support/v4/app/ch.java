package android.support.v4.app;

import android.app.RemoteInput;
import android.app.RemoteInput.Builder;
import android.content.Intent;
import android.os.Bundle;

class ch
{
  static Bundle a(Intent paramIntent)
  {
    return RemoteInput.getResultsFromIntent(paramIntent);
  }

  static void a(ci.a[] paramArrayOfa, Intent paramIntent, Bundle paramBundle)
  {
    RemoteInput.addResultsToIntent(a(paramArrayOfa), paramIntent, paramBundle);
  }

  static RemoteInput[] a(ci.a[] paramArrayOfa)
  {
    if (paramArrayOfa == null)
      return null;
    RemoteInput[] arrayOfRemoteInput = new RemoteInput[paramArrayOfa.length];
    for (int i = 0; i < paramArrayOfa.length; i++)
    {
      ci.a locala = paramArrayOfa[i];
      arrayOfRemoteInput[i] = new RemoteInput.Builder(locala.a()).setLabel(locala.b()).setChoices(locala.c()).setAllowFreeFormInput(locala.d()).addExtras(locala.e()).build();
    }
    return arrayOfRemoteInput;
  }

  static ci.a[] a(RemoteInput[] paramArrayOfRemoteInput, ci.a.a parama)
  {
    if (paramArrayOfRemoteInput == null)
      return null;
    ci.a[] arrayOfa = parama.b(paramArrayOfRemoteInput.length);
    for (int i = 0; i < paramArrayOfRemoteInput.length; i++)
    {
      RemoteInput localRemoteInput = paramArrayOfRemoteInput[i];
      arrayOfa[i] = parama.b(localRemoteInput.getResultKey(), localRemoteInput.getLabel(), localRemoteInput.getChoices(), localRemoteInput.getAllowFreeFormInput(), localRemoteInput.getExtras());
    }
    return arrayOfa;
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.ch
 * JD-Core Version:    0.6.2
 */