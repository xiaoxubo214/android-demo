package android.support.v4.app;

import android.os.Bundle;

class ci
{
  public static abstract class a
  {
    protected abstract String a();

    protected abstract CharSequence b();

    protected abstract CharSequence[] c();

    protected abstract boolean d();

    protected abstract Bundle e();

    public static abstract interface a
    {
      public abstract ci.a b(String paramString, CharSequence paramCharSequence, CharSequence[] paramArrayOfCharSequence, boolean paramBoolean, Bundle paramBundle);

      public abstract ci.a[] b(int paramInt);
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.ci
 * JD-Core Version:    0.6.2
 */