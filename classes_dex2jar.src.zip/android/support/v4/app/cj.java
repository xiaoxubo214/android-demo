package android.support.v4.app;

import android.content.ClipData;
import android.content.ClipData.Item;
import android.content.ClipDescription;
import android.content.Intent;
import android.os.Bundle;

class cj
{
  public static final String a = "android.remoteinput.results";
  public static final String b = "android.remoteinput.resultsData";
  private static final String c = "resultKey";
  private static final String d = "label";
  private static final String e = "choices";
  private static final String f = "allowFreeFormInput";
  private static final String g = "extras";

  static Bundle a(Intent paramIntent)
  {
    ClipData localClipData = paramIntent.getClipData();
    if (localClipData == null);
    ClipDescription localClipDescription;
    do
    {
      return null;
      localClipDescription = localClipData.getDescription();
    }
    while ((!localClipDescription.hasMimeType("text/vnd.android.intent")) || (!localClipDescription.getLabel().equals("android.remoteinput.results")));
    return (Bundle)localClipData.getItemAt(0).getIntent().getExtras().getParcelable("android.remoteinput.resultsData");
  }

  static Bundle a(ci.a parama)
  {
    Bundle localBundle = new Bundle();
    localBundle.putString("resultKey", parama.a());
    localBundle.putCharSequence("label", parama.b());
    localBundle.putCharSequenceArray("choices", parama.c());
    localBundle.putBoolean("allowFreeFormInput", parama.d());
    localBundle.putBundle("extras", parama.e());
    return localBundle;
  }

  static ci.a a(Bundle paramBundle, ci.a.a parama)
  {
    return parama.b(paramBundle.getString("resultKey"), paramBundle.getCharSequence("label"), paramBundle.getCharSequenceArray("choices"), paramBundle.getBoolean("allowFreeFormInput"), paramBundle.getBundle("extras"));
  }

  static void a(ci.a[] paramArrayOfa, Intent paramIntent, Bundle paramBundle)
  {
    Bundle localBundle = new Bundle();
    int i = paramArrayOfa.length;
    for (int j = 0; j < i; j++)
    {
      ci.a locala = paramArrayOfa[j];
      Object localObject = paramBundle.get(locala.a());
      if ((localObject instanceof CharSequence))
        localBundle.putCharSequence(locala.a(), (CharSequence)localObject);
    }
    Intent localIntent = new Intent();
    localIntent.putExtra("android.remoteinput.resultsData", localBundle);
    paramIntent.setClipData(ClipData.newIntent("android.remoteinput.results", localIntent));
  }

  static Bundle[] a(ci.a[] paramArrayOfa)
  {
    if (paramArrayOfa == null)
      return null;
    Bundle[] arrayOfBundle = new Bundle[paramArrayOfa.length];
    for (int i = 0; i < paramArrayOfa.length; i++)
      arrayOfBundle[i] = a(paramArrayOfa[i]);
    return arrayOfBundle;
  }

  static ci.a[] a(Bundle[] paramArrayOfBundle, ci.a.a parama)
  {
    if (paramArrayOfBundle == null)
      return null;
    ci.a[] arrayOfa = parama.b(paramArrayOfBundle.length);
    for (int i = 0; i < paramArrayOfBundle.length; i++)
      arrayOfa[i] = a(paramArrayOfBundle[i], parama);
    return arrayOfa;
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.cj
 * JD-Core Version:    0.6.2
 */