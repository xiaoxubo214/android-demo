package android.support.v4.app;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Parcelable;
import android.support.annotation.ae;
import android.text.Html;
import android.text.Spanned;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import java.util.ArrayList;

public final class cl
{
  public static final String a = "android.support.v4.app.EXTRA_CALLING_PACKAGE";
  public static final String b = "android.support.v4.app.EXTRA_CALLING_ACTIVITY";
  private static c c = new d();

  static
  {
    if (Build.VERSION.SDK_INT >= 16)
    {
      c = new f();
      return;
    }
    if (Build.VERSION.SDK_INT >= 14)
    {
      c = new e();
      return;
    }
  }

  public static String a(Activity paramActivity)
  {
    String str = paramActivity.getCallingPackage();
    if (str == null)
      str = paramActivity.getIntent().getStringExtra("android.support.v4.app.EXTRA_CALLING_PACKAGE");
    return str;
  }

  public static void a(Menu paramMenu, int paramInt, a parama)
  {
    MenuItem localMenuItem = paramMenu.findItem(paramInt);
    if (localMenuItem == null)
      throw new IllegalArgumentException("Could not find menu item with id " + paramInt + " in the supplied menu");
    a(localMenuItem, parama);
  }

  public static void a(MenuItem paramMenuItem, a parama)
  {
    c.a(paramMenuItem, parama);
  }

  public static ComponentName b(Activity paramActivity)
  {
    ComponentName localComponentName = paramActivity.getCallingActivity();
    if (localComponentName == null)
      localComponentName = (ComponentName)paramActivity.getIntent().getParcelableExtra("android.support.v4.app.EXTRA_CALLING_ACTIVITY");
    return localComponentName;
  }

  public static class a
  {
    private Activity a;
    private Intent b;
    private CharSequence c;
    private ArrayList<String> d;
    private ArrayList<String> e;
    private ArrayList<String> f;
    private ArrayList<Uri> g;

    private a(Activity paramActivity)
    {
      this.a = paramActivity;
      this.b = new Intent().setAction("android.intent.action.SEND");
      this.b.putExtra("android.support.v4.app.EXTRA_CALLING_PACKAGE", paramActivity.getPackageName());
      this.b.putExtra("android.support.v4.app.EXTRA_CALLING_ACTIVITY", paramActivity.getComponentName());
      this.b.addFlags(524288);
    }

    public static a a(Activity paramActivity)
    {
      return new a(paramActivity);
    }

    private void a(String paramString, ArrayList<String> paramArrayList)
    {
      String[] arrayOfString1 = this.b.getStringArrayExtra(paramString);
      if (arrayOfString1 != null);
      for (int i = arrayOfString1.length; ; i = 0)
      {
        String[] arrayOfString2 = new String[i + paramArrayList.size()];
        paramArrayList.toArray(arrayOfString2);
        if (arrayOfString1 != null)
          System.arraycopy(arrayOfString1, 0, arrayOfString2, paramArrayList.size(), i);
        this.b.putExtra(paramString, arrayOfString2);
        return;
      }
    }

    private void a(String paramString, String[] paramArrayOfString)
    {
      Intent localIntent = a();
      String[] arrayOfString1 = localIntent.getStringArrayExtra(paramString);
      if (arrayOfString1 != null);
      for (int i = arrayOfString1.length; ; i = 0)
      {
        String[] arrayOfString2 = new String[i + paramArrayOfString.length];
        if (arrayOfString1 != null)
          System.arraycopy(arrayOfString1, 0, arrayOfString2, 0, i);
        System.arraycopy(paramArrayOfString, 0, arrayOfString2, i, paramArrayOfString.length);
        localIntent.putExtra(paramString, arrayOfString2);
        return;
      }
    }

    public Intent a()
    {
      if (this.d != null)
      {
        a("android.intent.extra.EMAIL", this.d);
        this.d = null;
      }
      if (this.e != null)
      {
        a("android.intent.extra.CC", this.e);
        this.e = null;
      }
      if (this.f != null)
      {
        a("android.intent.extra.BCC", this.f);
        this.f = null;
      }
      int i;
      if ((this.g != null) && (this.g.size() > 1))
      {
        i = 1;
        boolean bool = this.b.getAction().equals("android.intent.action.SEND_MULTIPLE");
        if ((i == 0) && (bool))
        {
          this.b.setAction("android.intent.action.SEND");
          if ((this.g == null) || (this.g.isEmpty()))
            break label219;
          this.b.putExtra("android.intent.extra.STREAM", (Parcelable)this.g.get(0));
          label155: this.g = null;
        }
        if ((i != 0) && (!bool))
        {
          this.b.setAction("android.intent.action.SEND_MULTIPLE");
          if ((this.g == null) || (this.g.isEmpty()))
            break label231;
          this.b.putParcelableArrayListExtra("android.intent.extra.STREAM", this.g);
        }
      }
      while (true)
      {
        return this.b;
        i = 0;
        break;
        label219: this.b.removeExtra("android.intent.extra.STREAM");
        break label155;
        label231: this.b.removeExtra("android.intent.extra.STREAM");
      }
    }

    public a a(@ae int paramInt)
    {
      return a(this.a.getText(paramInt));
    }

    public a a(Uri paramUri)
    {
      if (!this.b.getAction().equals("android.intent.action.SEND"))
        this.b.setAction("android.intent.action.SEND");
      this.g = null;
      this.b.putExtra("android.intent.extra.STREAM", paramUri);
      return this;
    }

    public a a(CharSequence paramCharSequence)
    {
      this.c = paramCharSequence;
      return this;
    }

    public a a(String paramString)
    {
      this.b.setType(paramString);
      return this;
    }

    public a a(String[] paramArrayOfString)
    {
      if (this.d != null)
        this.d = null;
      this.b.putExtra("android.intent.extra.EMAIL", paramArrayOfString);
      return this;
    }

    Activity b()
    {
      return this.a;
    }

    public a b(Uri paramUri)
    {
      Uri localUri = (Uri)this.b.getParcelableExtra("android.intent.extra.STREAM");
      if (localUri == null)
        return a(paramUri);
      if (this.g == null)
        this.g = new ArrayList();
      if (localUri != null)
      {
        this.b.removeExtra("android.intent.extra.STREAM");
        this.g.add(localUri);
      }
      this.g.add(paramUri);
      return this;
    }

    public a b(CharSequence paramCharSequence)
    {
      this.b.putExtra("android.intent.extra.TEXT", paramCharSequence);
      return this;
    }

    public a b(String paramString)
    {
      this.b.putExtra("android.intent.extra.HTML_TEXT", paramString);
      if (!this.b.hasExtra("android.intent.extra.TEXT"))
        b(Html.fromHtml(paramString));
      return this;
    }

    public a b(String[] paramArrayOfString)
    {
      a("android.intent.extra.EMAIL", paramArrayOfString);
      return this;
    }

    public Intent c()
    {
      return Intent.createChooser(a(), this.c);
    }

    public a c(String paramString)
    {
      if (this.d == null)
        this.d = new ArrayList();
      this.d.add(paramString);
      return this;
    }

    public a c(String[] paramArrayOfString)
    {
      this.b.putExtra("android.intent.extra.CC", paramArrayOfString);
      return this;
    }

    public a d(String paramString)
    {
      if (this.e == null)
        this.e = new ArrayList();
      this.e.add(paramString);
      return this;
    }

    public a d(String[] paramArrayOfString)
    {
      a("android.intent.extra.CC", paramArrayOfString);
      return this;
    }

    public void d()
    {
      this.a.startActivity(c());
    }

    public a e(String paramString)
    {
      if (this.f == null)
        this.f = new ArrayList();
      this.f.add(paramString);
      return this;
    }

    public a e(String[] paramArrayOfString)
    {
      this.b.putExtra("android.intent.extra.BCC", paramArrayOfString);
      return this;
    }

    public a f(String paramString)
    {
      this.b.putExtra("android.intent.extra.SUBJECT", paramString);
      return this;
    }

    public a f(String[] paramArrayOfString)
    {
      a("android.intent.extra.BCC", paramArrayOfString);
      return this;
    }
  }

  public static class b
  {
    private static final String a = "IntentReader";
    private Activity b;
    private Intent c;
    private String d;
    private ComponentName e;
    private ArrayList<Uri> f;

    private b(Activity paramActivity)
    {
      this.b = paramActivity;
      this.c = paramActivity.getIntent();
      this.d = cl.a(paramActivity);
      this.e = cl.b(paramActivity);
    }

    public static b a(Activity paramActivity)
    {
      return new b(paramActivity);
    }

    public Uri a(int paramInt)
    {
      if ((this.f == null) && (c()))
        this.f = this.c.getParcelableArrayListExtra("android.intent.extra.STREAM");
      if (this.f != null)
        return (Uri)this.f.get(paramInt);
      if (paramInt == 0)
        return (Uri)this.c.getParcelableExtra("android.intent.extra.STREAM");
      throw new IndexOutOfBoundsException("Stream items available: " + h() + " index requested: " + paramInt);
    }

    public boolean a()
    {
      String str = this.c.getAction();
      return ("android.intent.action.SEND".equals(str)) || ("android.intent.action.SEND_MULTIPLE".equals(str));
    }

    public boolean b()
    {
      return "android.intent.action.SEND".equals(this.c.getAction());
    }

    public boolean c()
    {
      return "android.intent.action.SEND_MULTIPLE".equals(this.c.getAction());
    }

    public String d()
    {
      return this.c.getType();
    }

    public CharSequence e()
    {
      return this.c.getCharSequenceExtra("android.intent.extra.TEXT");
    }

    public String f()
    {
      String str = this.c.getStringExtra("android.intent.extra.HTML_TEXT");
      if (str == null)
      {
        CharSequence localCharSequence = e();
        if ((localCharSequence instanceof Spanned))
          return Html.toHtml((Spanned)localCharSequence);
        if (localCharSequence != null)
          return cl.a().a(localCharSequence);
      }
      return str;
    }

    public Uri g()
    {
      return (Uri)this.c.getParcelableExtra("android.intent.extra.STREAM");
    }

    public int h()
    {
      if ((this.f == null) && (c()))
        this.f = this.c.getParcelableArrayListExtra("android.intent.extra.STREAM");
      if (this.f != null)
        return this.f.size();
      if (this.c.hasExtra("android.intent.extra.STREAM"))
        return 1;
      return 0;
    }

    public String[] i()
    {
      return this.c.getStringArrayExtra("android.intent.extra.EMAIL");
    }

    public String[] j()
    {
      return this.c.getStringArrayExtra("android.intent.extra.CC");
    }

    public String[] k()
    {
      return this.c.getStringArrayExtra("android.intent.extra.BCC");
    }

    public String l()
    {
      return this.c.getStringExtra("android.intent.extra.SUBJECT");
    }

    public String m()
    {
      return this.d;
    }

    public ComponentName n()
    {
      return this.e;
    }

    public Drawable o()
    {
      if (this.e == null)
        return null;
      PackageManager localPackageManager = this.b.getPackageManager();
      try
      {
        Drawable localDrawable = localPackageManager.getActivityIcon(this.e);
        return localDrawable;
      }
      catch (PackageManager.NameNotFoundException localNameNotFoundException)
      {
        Log.e("IntentReader", "Could not retrieve icon for calling activity", localNameNotFoundException);
      }
      return null;
    }

    public Drawable p()
    {
      if (this.d == null)
        return null;
      PackageManager localPackageManager = this.b.getPackageManager();
      try
      {
        Drawable localDrawable = localPackageManager.getApplicationIcon(this.d);
        return localDrawable;
      }
      catch (PackageManager.NameNotFoundException localNameNotFoundException)
      {
        Log.e("IntentReader", "Could not retrieve icon for calling application", localNameNotFoundException);
      }
      return null;
    }

    public CharSequence q()
    {
      if (this.d == null)
        return null;
      PackageManager localPackageManager = this.b.getPackageManager();
      try
      {
        CharSequence localCharSequence = localPackageManager.getApplicationLabel(localPackageManager.getApplicationInfo(this.d, 0));
        return localCharSequence;
      }
      catch (PackageManager.NameNotFoundException localNameNotFoundException)
      {
        Log.e("IntentReader", "Could not retrieve label for calling application", localNameNotFoundException);
      }
      return null;
    }
  }

  static abstract interface c
  {
    public abstract String a(CharSequence paramCharSequence);

    public abstract void a(MenuItem paramMenuItem, cl.a parama);
  }

  static class d
    implements cl.c
  {
    private static void a(StringBuilder paramStringBuilder, CharSequence paramCharSequence, int paramInt1, int paramInt2)
    {
      int i = paramInt1;
      if (i < paramInt2)
      {
        char c = paramCharSequence.charAt(i);
        if (c == '<')
          paramStringBuilder.append("&lt;");
        while (true)
        {
          i++;
          break;
          if (c == '>')
          {
            paramStringBuilder.append("&gt;");
          }
          else if (c == '&')
          {
            paramStringBuilder.append("&amp;");
          }
          else if ((c > '~') || (c < ' '))
          {
            paramStringBuilder.append("&#" + c + ";");
          }
          else if (c == ' ')
          {
            while ((i + 1 < paramInt2) && (paramCharSequence.charAt(i + 1) == ' '))
            {
              paramStringBuilder.append("&nbsp;");
              i++;
            }
            paramStringBuilder.append(' ');
          }
          else
          {
            paramStringBuilder.append(c);
          }
        }
      }
    }

    public String a(CharSequence paramCharSequence)
    {
      StringBuilder localStringBuilder = new StringBuilder();
      a(localStringBuilder, paramCharSequence, 0, paramCharSequence.length());
      return localStringBuilder.toString();
    }

    public void a(MenuItem paramMenuItem, cl.a parama)
    {
      paramMenuItem.setIntent(parama.c());
    }
  }

  static class e extends cl.d
  {
    public void a(MenuItem paramMenuItem, cl.a parama)
    {
      cm.a(paramMenuItem, parama.b(), parama.a());
      if (a(paramMenuItem))
        paramMenuItem.setIntent(parama.c());
    }

    boolean a(MenuItem paramMenuItem)
    {
      return !paramMenuItem.hasSubMenu();
    }
  }

  static class f extends cl.e
  {
    public String a(CharSequence paramCharSequence)
    {
      return cn.a(paramCharSequence);
    }

    boolean a(MenuItem paramMenuItem)
    {
      return false;
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.cl
 * JD-Core Version:    0.6.2
 */