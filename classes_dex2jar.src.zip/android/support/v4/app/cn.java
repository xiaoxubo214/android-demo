package android.support.v4.app;

import android.text.Html;

class cn
{
  public static String a(CharSequence paramCharSequence)
  {
    return Html.escapeHtml(paramCharSequence);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.cn
 * JD-Core Version:    0.6.2
 */