package android.support.v4.app;

import android.util.AndroidRuntimeException;

final class cp extends AndroidRuntimeException
{
  public cp(String paramString)
  {
    super(paramString);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.cp
 * JD-Core Version:    0.6.2
 */