package android.support.v4.app;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.support.v4.c.d;
import android.util.Log;
import java.util.ArrayList;
import java.util.Iterator;

public final class cq
  implements Iterable<Intent>
{
  private static final String a = "TaskStackBuilder";
  private static final b b = new c();
  private final ArrayList<Intent> c = new ArrayList();
  private final Context d;

  static
  {
    if (Build.VERSION.SDK_INT >= 11)
    {
      b = new d();
      return;
    }
  }

  private cq(Context paramContext)
  {
    this.d = paramContext;
  }

  public static cq a(Context paramContext)
  {
    return new cq(paramContext);
  }

  public static cq b(Context paramContext)
  {
    return a(paramContext);
  }

  public int a()
  {
    return this.c.size();
  }

  public PendingIntent a(int paramInt1, int paramInt2)
  {
    return a(paramInt1, paramInt2, null);
  }

  public PendingIntent a(int paramInt1, int paramInt2, Bundle paramBundle)
  {
    if (this.c.isEmpty())
      throw new IllegalStateException("No intents added to TaskStackBuilder; cannot getPendingIntent");
    Intent[] arrayOfIntent = (Intent[])this.c.toArray(new Intent[this.c.size()]);
    arrayOfIntent[0] = new Intent(arrayOfIntent[0]).addFlags(268484608);
    return b.a(this.d, arrayOfIntent, paramInt1, paramInt2, paramBundle);
  }

  public Intent a(int paramInt)
  {
    return b(paramInt);
  }

  public cq a(Activity paramActivity)
  {
    boolean bool = paramActivity instanceof a;
    Intent localIntent1 = null;
    if (bool)
      localIntent1 = ((a)paramActivity).b_();
    if (localIntent1 == null);
    for (Intent localIntent2 = bk.b(paramActivity); ; localIntent2 = localIntent1)
    {
      if (localIntent2 != null)
      {
        ComponentName localComponentName = localIntent2.getComponent();
        if (localComponentName == null)
          localComponentName = localIntent2.resolveActivity(this.d.getPackageManager());
        a(localComponentName);
        a(localIntent2);
      }
      return this;
    }
  }

  public cq a(ComponentName paramComponentName)
  {
    int i = this.c.size();
    try
    {
      Intent localIntent;
      for (Object localObject = bk.a(this.d, paramComponentName); localObject != null; localObject = localIntent)
      {
        this.c.add(i, localObject);
        localIntent = bk.a(this.d, ((Intent)localObject).getComponent());
      }
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException)
    {
      Log.e("TaskStackBuilder", "Bad ComponentName while traversing activity parent metadata");
      throw new IllegalArgumentException(localNameNotFoundException);
    }
    return this;
  }

  public cq a(Intent paramIntent)
  {
    this.c.add(paramIntent);
    return this;
  }

  public cq a(Class<?> paramClass)
  {
    return a(new ComponentName(this.d, paramClass));
  }

  public void a(Bundle paramBundle)
  {
    if (this.c.isEmpty())
      throw new IllegalStateException("No intents added to TaskStackBuilder; cannot startActivities");
    Intent[] arrayOfIntent = (Intent[])this.c.toArray(new Intent[this.c.size()]);
    arrayOfIntent[0] = new Intent(arrayOfIntent[0]).addFlags(268484608);
    if (!d.a(this.d, arrayOfIntent, paramBundle))
    {
      Intent localIntent = new Intent(arrayOfIntent[(-1 + arrayOfIntent.length)]);
      localIntent.addFlags(268435456);
      this.d.startActivity(localIntent);
    }
  }

  public Intent b(int paramInt)
  {
    return (Intent)this.c.get(paramInt);
  }

  public cq b(Intent paramIntent)
  {
    ComponentName localComponentName = paramIntent.getComponent();
    if (localComponentName == null)
      localComponentName = paramIntent.resolveActivity(this.d.getPackageManager());
    if (localComponentName != null)
      a(localComponentName);
    a(paramIntent);
    return this;
  }

  public void b()
  {
    a(null);
  }

  public Intent[] c()
  {
    Intent[] arrayOfIntent = new Intent[this.c.size()];
    if (arrayOfIntent.length == 0)
      return arrayOfIntent;
    arrayOfIntent[0] = new Intent((Intent)this.c.get(0)).addFlags(268484608);
    for (int i = 1; i < arrayOfIntent.length; i++)
      arrayOfIntent[i] = new Intent((Intent)this.c.get(i));
    return arrayOfIntent;
  }

  public Iterator<Intent> iterator()
  {
    return this.c.iterator();
  }

  public static abstract interface a
  {
    public abstract Intent b_();
  }

  static abstract interface b
  {
    public abstract PendingIntent a(Context paramContext, Intent[] paramArrayOfIntent, int paramInt1, int paramInt2, Bundle paramBundle);
  }

  static class c
    implements cq.b
  {
    public PendingIntent a(Context paramContext, Intent[] paramArrayOfIntent, int paramInt1, int paramInt2, Bundle paramBundle)
    {
      Intent localIntent = new Intent(paramArrayOfIntent[(-1 + paramArrayOfIntent.length)]);
      localIntent.addFlags(268435456);
      return PendingIntent.getActivity(paramContext, paramInt1, localIntent, paramInt2);
    }
  }

  static class d
    implements cq.b
  {
    public PendingIntent a(Context paramContext, Intent[] paramArrayOfIntent, int paramInt1, int paramInt2, Bundle paramBundle)
    {
      paramArrayOfIntent[0] = new Intent(paramArrayOfIntent[0]).addFlags(268484608);
      return cr.a(paramContext, paramInt1, paramArrayOfIntent, paramInt2);
    }
  }

  static class e
    implements cq.b
  {
    public PendingIntent a(Context paramContext, Intent[] paramArrayOfIntent, int paramInt1, int paramInt2, Bundle paramBundle)
    {
      paramArrayOfIntent[0] = new Intent(paramArrayOfIntent[0]).addFlags(268484608);
      return cs.a(paramContext, paramInt1, paramArrayOfIntent, paramInt2, paramBundle);
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.cq
 * JD-Core Version:    0.6.2
 */