package android.support.v4.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Matrix;
import android.graphics.RectF;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Parcelable;
import android.support.annotation.x;
import android.support.annotation.y;
import android.view.View;
import java.util.List;
import java.util.Map;

public class d extends android.support.v4.c.d
{
  private static f.a a(co paramco)
  {
    b localb = null;
    if (paramco != null)
      localb = new b(paramco);
    return localb;
  }

  public static void a(Activity paramActivity, Intent paramIntent, int paramInt, @y Bundle paramBundle)
  {
    if (Build.VERSION.SDK_INT >= 16)
    {
      j.a(paramActivity, paramIntent, paramInt, paramBundle);
      return;
    }
    paramActivity.startActivityForResult(paramIntent, paramInt);
  }

  public static void a(Activity paramActivity, Intent paramIntent, @y Bundle paramBundle)
  {
    if (Build.VERSION.SDK_INT >= 16)
    {
      j.a(paramActivity, paramIntent, paramBundle);
      return;
    }
    paramActivity.startActivity(paramIntent);
  }

  public static void a(Activity paramActivity, co paramco)
  {
    if (Build.VERSION.SDK_INT >= 21)
      f.a(paramActivity, a(paramco));
  }

  public static void a(@x Activity paramActivity, @x String[] paramArrayOfString, int paramInt)
  {
    if (Build.VERSION.SDK_INT >= 23)
      h.a(paramActivity, paramArrayOfString, paramInt);
    while (!(paramActivity instanceof a))
      return;
    new Handler(Looper.getMainLooper()).post(new e(paramArrayOfString, paramActivity, paramInt));
  }

  public static boolean a(Activity paramActivity)
  {
    if (Build.VERSION.SDK_INT >= 11)
    {
      i.a(paramActivity);
      return true;
    }
    return false;
  }

  public static boolean a(@x Activity paramActivity, @x String paramString)
  {
    if (Build.VERSION.SDK_INT >= 23)
      return h.a(paramActivity, paramString);
    return false;
  }

  public static void b(Activity paramActivity)
  {
    if (Build.VERSION.SDK_INT >= 16)
    {
      j.a(paramActivity);
      return;
    }
    paramActivity.finish();
  }

  public static void b(Activity paramActivity, co paramco)
  {
    if (Build.VERSION.SDK_INT >= 21)
      f.b(paramActivity, a(paramco));
  }

  public static void c(Activity paramActivity)
  {
    if (Build.VERSION.SDK_INT >= 21)
    {
      f.a(paramActivity);
      return;
    }
    paramActivity.finish();
  }

  public static void e(Activity paramActivity)
  {
    if (Build.VERSION.SDK_INT >= 21)
      f.b(paramActivity);
  }

  public static void f(Activity paramActivity)
  {
    if (Build.VERSION.SDK_INT >= 21)
      f.c(paramActivity);
  }

  public Uri d(Activity paramActivity)
  {
    Uri localUri;
    if (Build.VERSION.SDK_INT >= 22)
      localUri = g.a(paramActivity);
    Intent localIntent;
    do
    {
      return localUri;
      localIntent = paramActivity.getIntent();
      localUri = (Uri)localIntent.getParcelableExtra("android.intent.extra.REFERRER");
    }
    while (localUri != null);
    String str = localIntent.getStringExtra("android.intent.extra.REFERRER_NAME");
    if (str != null)
      return Uri.parse(str);
    return null;
  }

  public static abstract interface a
  {
    public abstract void onRequestPermissionsResult(int paramInt, @x String[] paramArrayOfString, @x int[] paramArrayOfInt);
  }

  private static class b extends f.a
  {
    private co a;

    public b(co paramco)
    {
      this.a = paramco;
    }

    public Parcelable a(View paramView, Matrix paramMatrix, RectF paramRectF)
    {
      return this.a.a(paramView, paramMatrix, paramRectF);
    }

    public View a(Context paramContext, Parcelable paramParcelable)
    {
      return this.a.a(paramContext, paramParcelable);
    }

    public void a(List<View> paramList)
    {
      this.a.a(paramList);
    }

    public void a(List<String> paramList, List<View> paramList1, List<View> paramList2)
    {
      this.a.a(paramList, paramList1, paramList2);
    }

    public void a(List<String> paramList, Map<String, View> paramMap)
    {
      this.a.a(paramList, paramMap);
    }

    public void b(List<String> paramList, List<View> paramList1, List<View> paramList2)
    {
      this.a.b(paramList, paramList1, paramList2);
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.d
 * JD-Core Version:    0.6.2
 */