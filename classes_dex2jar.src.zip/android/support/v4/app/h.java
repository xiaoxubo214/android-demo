package android.support.v4.app;

import android.app.Activity;

class h
{
  public static void a(Activity paramActivity, String[] paramArrayOfString, int paramInt)
  {
    if ((paramActivity instanceof a))
      ((a)paramActivity).a(paramInt);
    paramActivity.requestPermissions(paramArrayOfString, paramInt);
  }

  public static boolean a(Activity paramActivity, String paramString)
  {
    return paramActivity.shouldShowRequestPermissionRationale(paramString);
  }

  public static abstract interface a
  {
    public abstract void a(int paramInt);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.h
 * JD-Core Version:    0.6.2
 */