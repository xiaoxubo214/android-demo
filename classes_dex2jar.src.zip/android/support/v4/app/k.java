package android.support.v4.app;

import android.app.ActivityManager;
import android.os.Build.VERSION;
import android.support.annotation.x;

public final class k
{
  public static boolean a(@x ActivityManager paramActivityManager)
  {
    if (Build.VERSION.SDK_INT >= 19)
      return l.a(paramActivityManager);
    return false;
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.k
 * JD-Core Version:    0.6.2
 */