package android.support.v4.app;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.support.v4.m.l;
import android.view.View;

public class m
{
  public static m a(Activity paramActivity, View paramView, String paramString)
  {
    if (Build.VERSION.SDK_INT >= 21)
      return new a(n.a(paramActivity, paramView, paramString));
    return new m();
  }

  public static m a(Activity paramActivity, l<View, String>[] paramArrayOfl)
  {
    View[] arrayOfView2;
    String[] arrayOfString1;
    if (Build.VERSION.SDK_INT >= 21)
    {
      if (paramArrayOfl == null)
        break label100;
      arrayOfView2 = new View[paramArrayOfl.length];
      String[] arrayOfString2 = new String[paramArrayOfl.length];
      for (int i = 0; i < paramArrayOfl.length; i++)
      {
        arrayOfView2[i] = ((View)paramArrayOfl[i].a);
        arrayOfString2[i] = ((String)paramArrayOfl[i].b);
      }
      arrayOfString1 = arrayOfString2;
    }
    for (View[] arrayOfView1 = arrayOfView2; ; arrayOfView1 = null)
    {
      return new a(n.a(paramActivity, arrayOfView1, arrayOfString1));
      return new m();
      label100: arrayOfString1 = null;
    }
  }

  public static m a(Context paramContext, int paramInt1, int paramInt2)
  {
    if (Build.VERSION.SDK_INT >= 16)
      return new b(o.a(paramContext, paramInt1, paramInt2));
    return new m();
  }

  public static m a(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (Build.VERSION.SDK_INT >= 16)
      return new b(o.a(paramView, paramInt1, paramInt2, paramInt3, paramInt4));
    return new m();
  }

  public static m a(View paramView, Bitmap paramBitmap, int paramInt1, int paramInt2)
  {
    if (Build.VERSION.SDK_INT >= 16)
      return new b(o.a(paramView, paramBitmap, paramInt1, paramInt2));
    return new m();
  }

  public Bundle a()
  {
    return null;
  }

  public void a(m paramm)
  {
  }

  private static class a extends m
  {
    private final n a;

    a(n paramn)
    {
      this.a = paramn;
    }

    public Bundle a()
    {
      return this.a.a();
    }

    public void a(m paramm)
    {
      if ((paramm instanceof a))
      {
        a locala = (a)paramm;
        this.a.a(locala.a);
      }
    }
  }

  private static class b extends m
  {
    private final o a;

    b(o paramo)
    {
      this.a = paramo;
    }

    public Bundle a()
    {
      return this.a.a();
    }

    public void a(m paramm)
    {
      if ((paramm instanceof b))
      {
        b localb = (b)paramm;
        this.a.a(localb.a);
      }
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.m
 * JD-Core Version:    0.6.2
 */