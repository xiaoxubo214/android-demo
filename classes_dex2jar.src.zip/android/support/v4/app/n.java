package android.support.v4.app;

import android.app.Activity;
import android.app.ActivityOptions;
import android.os.Bundle;
import android.util.Pair;
import android.view.View;

class n
{
  private final ActivityOptions a;

  private n(ActivityOptions paramActivityOptions)
  {
    this.a = paramActivityOptions;
  }

  public static n a(Activity paramActivity, View paramView, String paramString)
  {
    return new n(ActivityOptions.makeSceneTransitionAnimation(paramActivity, paramView, paramString));
  }

  public static n a(Activity paramActivity, View[] paramArrayOfView, String[] paramArrayOfString)
  {
    Object localObject = null;
    if (paramArrayOfView != null)
    {
      Pair[] arrayOfPair = new Pair[paramArrayOfView.length];
      for (int i = 0; i < arrayOfPair.length; i++)
        arrayOfPair[i] = Pair.create(paramArrayOfView[i], paramArrayOfString[i]);
      localObject = arrayOfPair;
    }
    return new n(ActivityOptions.makeSceneTransitionAnimation(paramActivity, localObject));
  }

  public Bundle a()
  {
    return this.a.toBundle();
  }

  public void a(n paramn)
  {
    this.a.update(paramn.a);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.n
 * JD-Core Version:    0.6.2
 */