package android.support.v4.app;

import android.app.ActivityOptions;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;

class o
{
  private final ActivityOptions a;

  private o(ActivityOptions paramActivityOptions)
  {
    this.a = paramActivityOptions;
  }

  public static o a(Context paramContext, int paramInt1, int paramInt2)
  {
    return new o(ActivityOptions.makeCustomAnimation(paramContext, paramInt1, paramInt2));
  }

  public static o a(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    return new o(ActivityOptions.makeScaleUpAnimation(paramView, paramInt1, paramInt2, paramInt3, paramInt4));
  }

  public static o a(View paramView, Bitmap paramBitmap, int paramInt1, int paramInt2)
  {
    return new o(ActivityOptions.makeThumbnailScaleUpAnimation(paramView, paramBitmap, paramInt1, paramInt2));
  }

  public Bundle a()
  {
    return this.a.toBundle();
  }

  public void a(o paramo)
  {
    this.a.update(paramo.a);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.o
 * JD-Core Version:    0.6.2
 */