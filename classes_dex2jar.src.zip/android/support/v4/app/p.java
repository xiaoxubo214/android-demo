package android.support.v4.app;

import android.content.Context;
import android.os.Build.VERSION;
import android.support.annotation.x;

public final class p
{
  public static final int a = 0;
  public static final int b = 1;
  public static final int c = 3;
  private static final b d = new b(null);

  static
  {
    if (Build.VERSION.SDK_INT >= 23)
    {
      d = new a(null);
      return;
    }
  }

  public static int a(@x Context paramContext, @x String paramString1, int paramInt, @x String paramString2)
  {
    return d.a(paramContext, paramString1, paramInt, paramString2);
  }

  public static int a(@x Context paramContext, @x String paramString1, @x String paramString2)
  {
    return d.a(paramContext, paramString1, paramString2);
  }

  public static String a(@x String paramString)
  {
    return d.a(paramString);
  }

  private static class a extends p.b
  {
    private a()
    {
      super();
    }

    public int a(Context paramContext, String paramString1, int paramInt, String paramString2)
    {
      return q.a(paramContext, paramString1, paramInt, paramString2);
    }

    public int a(Context paramContext, String paramString1, String paramString2)
    {
      return q.a(paramContext, paramString1, paramString2);
    }

    public String a(String paramString)
    {
      return q.a(paramString);
    }
  }

  private static class b
  {
    public int a(Context paramContext, String paramString1, int paramInt, String paramString2)
    {
      return 1;
    }

    public int a(Context paramContext, String paramString1, String paramString2)
    {
      return 1;
    }

    public String a(String paramString)
    {
      return null;
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.p
 * JD-Core Version:    0.6.2
 */