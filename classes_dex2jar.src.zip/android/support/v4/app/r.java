package android.support.v4.app;

import android.content.Context;
import android.os.Build.VERSION;
import android.support.v4.m.a;
import android.support.v4.m.h;
import android.util.Log;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;

final class r extends ay
  implements ak.a, Runnable
{
  static final String a = "FragmentManager";
  static final boolean b = false;
  static final int d = 0;
  static final int e = 1;
  static final int f = 2;
  static final int g = 3;
  static final int h = 4;
  static final int i = 5;
  static final int j = 6;
  static final int k = 7;
  CharSequence A;
  int B;
  CharSequence C;
  ArrayList<String> D;
  ArrayList<String> E;
  final al c;
  a l;
  a m;
  int n;
  int o;
  int p;
  int q;
  int r;
  int s;
  int t;
  boolean u;
  boolean v = true;
  String w;
  boolean x;
  int y = -1;
  int z;

  static
  {
    if (Build.VERSION.SDK_INT >= 21);
    for (boolean bool = true; ; bool = false)
    {
      b = bool;
      return;
    }
  }

  public r(al paramal)
  {
    this.c = paramal;
  }

  private b a(SparseArray<Fragment> paramSparseArray1, SparseArray<Fragment> paramSparseArray2, boolean paramBoolean)
  {
    a(paramSparseArray2);
    b localb = new b();
    localb.d = new View(this.c.u.i());
    int i1 = 0;
    int i2 = 0;
    int i3 = paramSparseArray1.size();
    int i4 = 0;
    if (i1 < i3)
      if (!a(paramSparseArray1.keyAt(i1), localb, paramBoolean, paramSparseArray1, paramSparseArray2))
        break label150;
    label150: for (int i6 = 1; ; i6 = i2)
    {
      i1++;
      i2 = i6;
      break;
      while (i4 < paramSparseArray2.size())
      {
        int i5 = paramSparseArray2.keyAt(i4);
        if ((paramSparseArray1.get(i5) == null) && (a(i5, localb, paramBoolean, paramSparseArray1, paramSparseArray2)))
          i2 = 1;
        i4++;
      }
      if (i2 == 0)
        localb = null;
      return localb;
    }
  }

  private a<String, View> a(b paramb, Fragment paramFragment, boolean paramBoolean)
  {
    a locala = new a();
    if (this.D != null)
    {
      az.a(locala, paramFragment.J());
      if (!paramBoolean)
        break label74;
      locala.c(this.E);
    }
    while (paramBoolean)
    {
      if (paramFragment.aq != null)
        paramFragment.aq.a(this.E, locala);
      a(paramb, locala, false);
      return locala;
      label74: locala = a(this.D, this.E, locala);
    }
    if (paramFragment.ar != null)
      paramFragment.ar.a(this.E, locala);
    b(paramb, locala, false);
    return locala;
  }

  private a<String, View> a(b paramb, boolean paramBoolean, Fragment paramFragment)
  {
    a locala = b(paramb, paramFragment, paramBoolean);
    if (paramBoolean)
    {
      if (paramFragment.ar != null)
        paramFragment.ar.a(this.E, locala);
      a(paramb, locala, true);
      return locala;
    }
    if (paramFragment.aq != null)
      paramFragment.aq.a(this.E, locala);
    b(paramb, locala, true);
    return locala;
  }

  private static a<String, View> a(ArrayList<String> paramArrayList1, ArrayList<String> paramArrayList2, a<String, View> parama)
  {
    if (parama.isEmpty())
      return parama;
    a locala = new a();
    int i1 = paramArrayList1.size();
    for (int i2 = 0; i2 < i1; i2++)
    {
      View localView = (View)parama.get(paramArrayList1.get(i2));
      if (localView != null)
        locala.put(paramArrayList2.get(i2), localView);
    }
    return locala;
  }

  private static Object a(Fragment paramFragment1, Fragment paramFragment2, boolean paramBoolean)
  {
    if ((paramFragment1 == null) || (paramFragment2 == null))
      return null;
    if (paramBoolean);
    for (Object localObject = paramFragment2.U(); ; localObject = paramFragment1.T())
      return az.b(localObject);
  }

  private static Object a(Fragment paramFragment, boolean paramBoolean)
  {
    if (paramFragment == null)
      return null;
    if (paramBoolean);
    for (Object localObject = paramFragment.S(); ; localObject = paramFragment.P())
      return az.a(localObject);
  }

  private static Object a(Object paramObject, Fragment paramFragment, ArrayList<View> paramArrayList, a<String, View> parama, View paramView)
  {
    if (paramObject != null)
      paramObject = az.a(paramObject, paramFragment.J(), paramArrayList, parama, paramView);
    return paramObject;
  }

  private void a(int paramInt1, Fragment paramFragment, String paramString, int paramInt2)
  {
    paramFragment.L = this.c;
    if (paramString != null)
    {
      if ((paramFragment.R != null) && (!paramString.equals(paramFragment.R)))
        throw new IllegalStateException("Can't change tag of fragment " + paramFragment + ": was " + paramFragment.R + " now " + paramString);
      paramFragment.R = paramString;
    }
    if (paramInt1 != 0)
    {
      if ((paramFragment.P != 0) && (paramFragment.P != paramInt1))
        throw new IllegalStateException("Can't change container ID of fragment " + paramFragment + ": was " + paramFragment.P + " now " + paramInt1);
      paramFragment.P = paramInt1;
      paramFragment.Q = paramInt1;
    }
    a locala = new a();
    locala.c = paramInt2;
    locala.d = paramFragment;
    a(locala);
  }

  private void a(b paramb, int paramInt, Object paramObject)
  {
    if (this.c.m != null)
    {
      int i1 = 0;
      if (i1 < this.c.m.size())
      {
        Fragment localFragment = (Fragment)this.c.m.get(i1);
        if ((localFragment.ab != null) && (localFragment.aa != null) && (localFragment.Q == paramInt))
        {
          if (!localFragment.S)
            break label122;
          if (!paramb.b.contains(localFragment.ab))
          {
            az.a(paramObject, localFragment.ab, true);
            paramb.b.add(localFragment.ab);
          }
        }
        while (true)
        {
          i1++;
          break;
          label122: az.a(paramObject, localFragment.ab, false);
          paramb.b.remove(localFragment.ab);
        }
      }
    }
  }

  private void a(b paramb, Fragment paramFragment1, Fragment paramFragment2, boolean paramBoolean, a<String, View> parama)
  {
    if (paramBoolean);
    for (co localco = paramFragment2.aq; ; localco = paramFragment1.aq)
    {
      if (localco != null)
        localco.b(new ArrayList(parama.keySet()), new ArrayList(parama.values()), null);
      return;
    }
  }

  private void a(b paramb, a<String, View> parama, boolean paramBoolean)
  {
    int i1;
    int i2;
    label13: String str1;
    String str2;
    if (this.E == null)
    {
      i1 = 0;
      i2 = 0;
      if (i2 >= i1)
        return;
      str1 = (String)this.D.get(i2);
      View localView = (View)parama.get((String)this.E.get(i2));
      if (localView != null)
      {
        str2 = az.a(localView);
        if (!paramBoolean)
          break label100;
        a(paramb.a, str1, str2);
      }
    }
    while (true)
    {
      i2++;
      break label13;
      i1 = this.E.size();
      break;
      label100: a(paramb.a, str2, str1);
    }
  }

  private void a(b paramb, View paramView, Object paramObject, Fragment paramFragment1, Fragment paramFragment2, boolean paramBoolean, ArrayList<View> paramArrayList)
  {
    paramView.getViewTreeObserver().addOnPreDrawListener(new t(this, paramView, paramObject, paramArrayList, paramb, paramBoolean, paramFragment1, paramFragment2));
  }

  private static void a(b paramb, ArrayList<String> paramArrayList1, ArrayList<String> paramArrayList2)
  {
    if (paramArrayList1 != null)
      for (int i1 = 0; i1 < paramArrayList1.size(); i1++)
      {
        String str1 = (String)paramArrayList1.get(i1);
        String str2 = (String)paramArrayList2.get(i1);
        a(paramb.a, str1, str2);
      }
  }

  private void a(a<String, View> parama, b paramb)
  {
    if ((this.E != null) && (!parama.isEmpty()))
    {
      View localView = (View)parama.get(this.E.get(0));
      if (localView != null)
        paramb.c.a = localView;
    }
  }

  private static void a(a<String, String> parama, String paramString1, String paramString2)
  {
    if ((paramString1 != null) && (paramString2 != null));
    for (int i1 = 0; i1 < parama.size(); i1++)
      if (paramString1.equals(parama.c(i1)))
      {
        parama.a(i1, paramString2);
        return;
      }
    parama.put(paramString1, paramString2);
  }

  private void a(SparseArray<Fragment> paramSparseArray)
  {
    int i1 = paramSparseArray.size();
    for (int i2 = 0; i2 < i1; i2++)
    {
      Fragment localFragment = (Fragment)paramSparseArray.valueAt(i2);
      if (localFragment.u < 1)
      {
        this.c.d(localFragment);
        this.c.a(localFragment, 1, 0, 0, false);
      }
    }
  }

  private static void a(SparseArray<Fragment> paramSparseArray1, SparseArray<Fragment> paramSparseArray2, Fragment paramFragment)
  {
    if (paramFragment != null)
    {
      int i1 = paramFragment.Q;
      if ((i1 != 0) && (!paramFragment.D()))
      {
        if ((paramFragment.x()) && (paramFragment.J() != null) && (paramSparseArray1.get(i1) == null))
          paramSparseArray1.put(i1, paramFragment);
        if (paramSparseArray2.get(i1) == paramFragment)
          paramSparseArray2.remove(i1);
      }
    }
  }

  private void a(View paramView, b paramb, int paramInt, Object paramObject)
  {
    paramView.getViewTreeObserver().addOnPreDrawListener(new u(this, paramView, paramb, paramInt, paramObject));
  }

  private boolean a(int paramInt, b paramb, boolean paramBoolean, SparseArray<Fragment> paramSparseArray1, SparseArray<Fragment> paramSparseArray2)
  {
    ViewGroup localViewGroup = (ViewGroup)this.c.w.a(paramInt);
    if (localViewGroup == null)
      return false;
    Fragment localFragment1 = (Fragment)paramSparseArray2.get(paramInt);
    Fragment localFragment2 = (Fragment)paramSparseArray1.get(paramInt);
    Object localObject1 = a(localFragment1, paramBoolean);
    Object localObject2 = a(localFragment1, localFragment2, paramBoolean);
    Object localObject3 = b(localFragment2, paramBoolean);
    ArrayList localArrayList1 = new ArrayList();
    a locala1 = null;
    Object localObject4;
    if (localObject2 != null)
    {
      locala1 = a(paramb, localFragment2, paramBoolean);
      if (locala1.isEmpty())
      {
        locala1 = null;
        localObject4 = null;
        if ((localObject1 != null) || (localObject4 != null) || (localObject3 != null))
          break label208;
        return false;
      }
      if (!paramBoolean)
        break label198;
    }
    label198: for (co localco = localFragment2.aq; ; localco = localFragment1.aq)
    {
      if (localco != null)
        localco.a(new ArrayList(locala1.keySet()), new ArrayList(locala1.values()), null);
      a(paramb, localViewGroup, localObject2, localFragment1, localFragment2, paramBoolean, localArrayList1);
      localObject4 = localObject2;
      break;
    }
    label208: ArrayList localArrayList2 = new ArrayList();
    View localView1 = paramb.d;
    Object localObject5 = a(localObject3, localFragment2, localArrayList2, locala1, localView1);
    if ((this.E != null) && (locala1 != null))
    {
      Object localObject7 = this.E.get(0);
      View localView3 = (View)locala1.get(localObject7);
      if (localView3 != null)
      {
        if (localObject5 != null)
          az.a(localObject5, localView3);
        if (localObject4 != null)
          az.a(localObject4, localView3);
      }
    }
    s locals = new s(this, localFragment1);
    ArrayList localArrayList3 = new ArrayList();
    a locala2 = new a();
    boolean bool = true;
    if (localFragment1 != null)
      if (!paramBoolean)
        break label478;
    label478: for (bool = localFragment1.W(); ; bool = localFragment1.V())
    {
      Object localObject6 = az.a(localObject1, localObject5, localObject4, bool);
      if (localObject6 != null)
      {
        az.a(localObject1, localObject4, localViewGroup, locals, paramb.d, paramb.c, paramb.a, localArrayList3, locala1, locala2, localArrayList1);
        a(localViewGroup, paramb, paramInt, localObject6);
        az.a(localObject6, paramb.d, true);
        a(paramb, paramInt, localObject6);
        az.a(localViewGroup, localObject6);
        View localView2 = paramb.d;
        ArrayList localArrayList4 = paramb.b;
        az.a(localViewGroup, localView2, localObject1, localArrayList3, localObject5, localArrayList2, localObject4, localArrayList1, localObject6, localArrayList4, locala2);
      }
      if (localObject6 == null)
        break;
      return true;
    }
    return false;
  }

  private a<String, View> b(b paramb, Fragment paramFragment, boolean paramBoolean)
  {
    a locala = new a();
    View localView = paramFragment.J();
    if ((localView != null) && (this.D != null))
    {
      az.a(locala, localView);
      if (paramBoolean)
        locala = a(this.D, this.E, locala);
    }
    else
    {
      return locala;
    }
    locala.c(this.E);
    return locala;
  }

  private static Object b(Fragment paramFragment, boolean paramBoolean)
  {
    if (paramFragment == null)
      return null;
    if (paramBoolean);
    for (Object localObject = paramFragment.Q(); ; localObject = paramFragment.R())
      return az.a(localObject);
  }

  private void b(b paramb, a<String, View> parama, boolean paramBoolean)
  {
    int i1 = parama.size();
    int i2 = 0;
    if (i2 < i1)
    {
      String str1 = (String)parama.b(i2);
      String str2 = az.a((View)parama.c(i2));
      if (paramBoolean)
        a(paramb.a, str1, str2);
      while (true)
      {
        i2++;
        break;
        a(paramb.a, str2, str1);
      }
    }
  }

  private void b(SparseArray<Fragment> paramSparseArray1, SparseArray<Fragment> paramSparseArray2)
  {
    if (!this.c.w.a());
    a locala;
    do
    {
      return;
      locala = this.l;
    }
    while (locala == null);
    switch (locala.c)
    {
    default:
    case 1:
    case 2:
    case 3:
    case 4:
    case 5:
    case 6:
    case 7:
    }
    while (true)
    {
      locala = locala.a;
      break;
      b(paramSparseArray1, paramSparseArray2, locala.d);
      continue;
      Fragment localFragment1 = locala.d;
      if (this.c.m != null)
      {
        Fragment localFragment2 = localFragment1;
        int i1 = 0;
        if (i1 < this.c.m.size())
        {
          Fragment localFragment3 = (Fragment)this.c.m.get(i1);
          if ((localFragment2 == null) || (localFragment3.Q == localFragment2.Q))
          {
            if (localFragment3 != localFragment2)
              break label187;
            localFragment2 = null;
            paramSparseArray2.remove(localFragment3.Q);
          }
          while (true)
          {
            i1++;
            break;
            label187: a(paramSparseArray1, paramSparseArray2, localFragment3);
          }
        }
      }
      b(paramSparseArray1, paramSparseArray2, locala.d);
      continue;
      a(paramSparseArray1, paramSparseArray2, locala.d);
      continue;
      a(paramSparseArray1, paramSparseArray2, locala.d);
      continue;
      b(paramSparseArray1, paramSparseArray2, locala.d);
      continue;
      a(paramSparseArray1, paramSparseArray2, locala.d);
      continue;
      b(paramSparseArray1, paramSparseArray2, locala.d);
    }
  }

  private void b(SparseArray<Fragment> paramSparseArray1, SparseArray<Fragment> paramSparseArray2, Fragment paramFragment)
  {
    if (paramFragment != null)
    {
      int i1 = paramFragment.Q;
      if (i1 != 0)
      {
        if (!paramFragment.x())
          paramSparseArray2.put(i1, paramFragment);
        if (paramSparseArray1.get(i1) == paramFragment)
          paramSparseArray1.remove(i1);
      }
    }
  }

  public int a()
  {
    return this.y;
  }

  int a(boolean paramBoolean)
  {
    if (this.x)
      throw new IllegalStateException("commit already called");
    if (al.b)
    {
      Log.v("FragmentManager", "Commit: " + this);
      a("  ", null, new PrintWriter(new h("FragmentManager")), null);
    }
    this.x = true;
    if (this.u);
    for (this.y = this.c.a(this); ; this.y = -1)
    {
      this.c.a(this, paramBoolean);
      return this.y;
    }
  }

  public ay a(int paramInt)
  {
    this.s = paramInt;
    return this;
  }

  public ay a(int paramInt1, int paramInt2)
  {
    return a(paramInt1, paramInt2, 0, 0);
  }

  public ay a(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    this.o = paramInt1;
    this.p = paramInt2;
    this.q = paramInt3;
    this.r = paramInt4;
    return this;
  }

  public ay a(int paramInt, Fragment paramFragment)
  {
    a(paramInt, paramFragment, null, 1);
    return this;
  }

  public ay a(int paramInt, Fragment paramFragment, String paramString)
  {
    a(paramInt, paramFragment, paramString, 1);
    return this;
  }

  public ay a(Fragment paramFragment)
  {
    a locala = new a();
    locala.c = 3;
    locala.d = paramFragment;
    a(locala);
    return this;
  }

  public ay a(Fragment paramFragment, String paramString)
  {
    a(0, paramFragment, paramString, 1);
    return this;
  }

  public ay a(View paramView, String paramString)
  {
    if (b)
    {
      String str = az.a(paramView);
      if (str == null)
        throw new IllegalArgumentException("Unique transitionNames are required for all sharedElements");
      if (this.D == null)
      {
        this.D = new ArrayList();
        this.E = new ArrayList();
      }
      this.D.add(str);
      this.E.add(paramString);
    }
    return this;
  }

  public ay a(CharSequence paramCharSequence)
  {
    this.z = 0;
    this.A = paramCharSequence;
    return this;
  }

  public ay a(String paramString)
  {
    if (!this.v)
      throw new IllegalStateException("This FragmentTransaction is not allowed to be added to the back stack.");
    this.u = true;
    this.w = paramString;
    return this;
  }

  public b a(boolean paramBoolean, b paramb, SparseArray<Fragment> paramSparseArray1, SparseArray<Fragment> paramSparseArray2)
  {
    if (al.b)
    {
      Log.v("FragmentManager", "popFromBackStack: " + this);
      a("  ", null, new PrintWriter(new h("FragmentManager")), null);
    }
    if (b)
    {
      if (paramb != null)
        break label216;
      if ((paramSparseArray1.size() != 0) || (paramSparseArray2.size() != 0))
        paramb = a(paramSparseArray1, paramSparseArray2, true);
    }
    label91: e(-1);
    int i1;
    label103: int i2;
    label110: a locala;
    int i3;
    if (paramb != null)
    {
      i1 = 0;
      if (paramb == null)
        break label244;
      i2 = 0;
      locala = this.m;
      if (locala == null)
        break label569;
      if (paramb == null)
        break label253;
      i3 = 0;
      label128: if (paramb == null)
        break label263;
    }
    label263: for (int i4 = 0; ; i4 = locala.h)
      switch (locala.c)
      {
      default:
        throw new IllegalArgumentException("Unknown cmd: " + locala.c);
        label216: if (paramBoolean)
          break label91;
        a(paramb, this.E, this.D);
        break label91;
        i1 = this.t;
        break label103;
        label244: i2 = this.s;
        break label110;
        label253: i3 = locala.g;
        break label128;
      case 1:
      case 2:
      case 3:
      case 4:
      case 5:
      case 6:
      case 7:
      }
    Fragment localFragment8 = locala.d;
    localFragment8.Z = i4;
    this.c.a(localFragment8, al.d(i2), i1);
    while (true)
    {
      locala = locala.b;
      break;
      Fragment localFragment6 = locala.d;
      if (localFragment6 != null)
      {
        localFragment6.Z = i4;
        this.c.a(localFragment6, al.d(i2), i1);
      }
      if (locala.i != null)
      {
        for (int i5 = 0; i5 < locala.i.size(); i5++)
        {
          Fragment localFragment7 = (Fragment)locala.i.get(i5);
          localFragment7.Z = i3;
          this.c.a(localFragment7, false);
        }
        Fragment localFragment5 = locala.d;
        localFragment5.Z = i3;
        this.c.a(localFragment5, false);
        continue;
        Fragment localFragment4 = locala.d;
        localFragment4.Z = i3;
        this.c.c(localFragment4, al.d(i2), i1);
        continue;
        Fragment localFragment3 = locala.d;
        localFragment3.Z = i4;
        this.c.b(localFragment3, al.d(i2), i1);
        continue;
        Fragment localFragment2 = locala.d;
        localFragment2.Z = i3;
        this.c.e(localFragment2, al.d(i2), i1);
        continue;
        Fragment localFragment1 = locala.d;
        localFragment1.Z = i3;
        this.c.d(localFragment1, al.d(i2), i1);
      }
    }
    label569: if (paramBoolean)
    {
      this.c.a(this.c.t, al.d(i2), i1, true);
      paramb = null;
    }
    if (this.y >= 0)
    {
      this.c.c(this.y);
      this.y = -1;
    }
    return paramb;
  }

  void a(a parama)
  {
    if (this.l == null)
    {
      this.m = parama;
      this.l = parama;
    }
    while (true)
    {
      parama.e = this.o;
      parama.f = this.p;
      parama.g = this.q;
      parama.h = this.r;
      this.n = (1 + this.n);
      return;
      parama.b = this.m;
      this.m.a = parama;
      this.m = parama;
    }
  }

  public void a(SparseArray<Fragment> paramSparseArray1, SparseArray<Fragment> paramSparseArray2)
  {
    if (!this.c.w.a());
    a locala;
    do
    {
      return;
      locala = this.m;
    }
    while (locala == null);
    switch (locala.c)
    {
    default:
    case 1:
    case 2:
    case 3:
    case 4:
    case 5:
    case 6:
    case 7:
    }
    while (true)
    {
      locala = locala.b;
      break;
      a(paramSparseArray1, paramSparseArray2, locala.d);
      continue;
      if (locala.i != null)
        for (int i1 = -1 + locala.i.size(); i1 >= 0; i1--)
          b(paramSparseArray1, paramSparseArray2, (Fragment)locala.i.get(i1));
      a(paramSparseArray1, paramSparseArray2, locala.d);
      continue;
      b(paramSparseArray1, paramSparseArray2, locala.d);
      continue;
      b(paramSparseArray1, paramSparseArray2, locala.d);
      continue;
      a(paramSparseArray1, paramSparseArray2, locala.d);
      continue;
      b(paramSparseArray1, paramSparseArray2, locala.d);
      continue;
      a(paramSparseArray1, paramSparseArray2, locala.d);
    }
  }

  public void a(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString)
  {
    a(paramString, paramPrintWriter, true);
  }

  public void a(String paramString, PrintWriter paramPrintWriter, boolean paramBoolean)
  {
    if (paramBoolean)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mName=");
      paramPrintWriter.print(this.w);
      paramPrintWriter.print(" mIndex=");
      paramPrintWriter.print(this.y);
      paramPrintWriter.print(" mCommitted=");
      paramPrintWriter.println(this.x);
      if (this.s != 0)
      {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mTransition=#");
        paramPrintWriter.print(Integer.toHexString(this.s));
        paramPrintWriter.print(" mTransitionStyle=#");
        paramPrintWriter.println(Integer.toHexString(this.t));
      }
      if ((this.o != 0) || (this.p != 0))
      {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mEnterAnim=#");
        paramPrintWriter.print(Integer.toHexString(this.o));
        paramPrintWriter.print(" mExitAnim=#");
        paramPrintWriter.println(Integer.toHexString(this.p));
      }
      if ((this.q != 0) || (this.r != 0))
      {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mPopEnterAnim=#");
        paramPrintWriter.print(Integer.toHexString(this.q));
        paramPrintWriter.print(" mPopExitAnim=#");
        paramPrintWriter.println(Integer.toHexString(this.r));
      }
      if ((this.z != 0) || (this.A != null))
      {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mBreadCrumbTitleRes=#");
        paramPrintWriter.print(Integer.toHexString(this.z));
        paramPrintWriter.print(" mBreadCrumbTitleText=");
        paramPrintWriter.println(this.A);
      }
      if ((this.B != 0) || (this.C != null))
      {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mBreadCrumbShortTitleRes=#");
        paramPrintWriter.print(Integer.toHexString(this.B));
        paramPrintWriter.print(" mBreadCrumbShortTitleText=");
        paramPrintWriter.println(this.C);
      }
    }
    if (this.l != null)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.println("Operations:");
      String str1 = paramString + "    ";
      a locala1 = this.l;
      int i1 = 0;
      a locala2 = locala1;
      while (locala2 != null)
      {
        String str2;
        int i2;
        switch (locala2.c)
        {
        default:
          str2 = "cmd=" + locala2.c;
          paramPrintWriter.print(paramString);
          paramPrintWriter.print("  Op #");
          paramPrintWriter.print(i1);
          paramPrintWriter.print(": ");
          paramPrintWriter.print(str2);
          paramPrintWriter.print(" ");
          paramPrintWriter.println(locala2.d);
          if (paramBoolean)
          {
            if ((locala2.e != 0) || (locala2.f != 0))
            {
              paramPrintWriter.print(paramString);
              paramPrintWriter.print("enterAnim=#");
              paramPrintWriter.print(Integer.toHexString(locala2.e));
              paramPrintWriter.print(" exitAnim=#");
              paramPrintWriter.println(Integer.toHexString(locala2.f));
            }
            if ((locala2.g != 0) || (locala2.h != 0))
            {
              paramPrintWriter.print(paramString);
              paramPrintWriter.print("popEnterAnim=#");
              paramPrintWriter.print(Integer.toHexString(locala2.g));
              paramPrintWriter.print(" popExitAnim=#");
              paramPrintWriter.println(Integer.toHexString(locala2.h));
            }
          }
          if ((locala2.i == null) || (locala2.i.size() <= 0))
            break label808;
          i2 = 0;
          label645: if (i2 >= locala2.i.size())
            break label808;
          paramPrintWriter.print(str1);
          if (locala2.i.size() == 1)
            paramPrintWriter.print("Removed: ");
          break;
        case 0:
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
        case 6:
        case 7:
        }
        while (true)
        {
          paramPrintWriter.println(locala2.i.get(i2));
          i2++;
          break label645;
          str2 = "NULL";
          break;
          str2 = "ADD";
          break;
          str2 = "REPLACE";
          break;
          str2 = "REMOVE";
          break;
          str2 = "HIDE";
          break;
          str2 = "SHOW";
          break;
          str2 = "DETACH";
          break;
          str2 = "ATTACH";
          break;
          if (i2 == 0)
            paramPrintWriter.println("Removed:");
          paramPrintWriter.print(str1);
          paramPrintWriter.print("  #");
          paramPrintWriter.print(i2);
          paramPrintWriter.print(": ");
        }
        label808: locala2 = locala2.a;
        i1++;
      }
    }
  }

  public int b()
  {
    return this.z;
  }

  public ay b(int paramInt)
  {
    this.t = paramInt;
    return this;
  }

  public ay b(int paramInt, Fragment paramFragment)
  {
    return b(paramInt, paramFragment, null);
  }

  public ay b(int paramInt, Fragment paramFragment, String paramString)
  {
    if (paramInt == 0)
      throw new IllegalArgumentException("Must use non-zero containerViewId");
    a(paramInt, paramFragment, paramString, 2);
    return this;
  }

  public ay b(Fragment paramFragment)
  {
    a locala = new a();
    locala.c = 4;
    locala.d = paramFragment;
    a(locala);
    return this;
  }

  public ay b(CharSequence paramCharSequence)
  {
    this.B = 0;
    this.C = paramCharSequence;
    return this;
  }

  public int c()
  {
    return this.B;
  }

  public ay c(int paramInt)
  {
    this.z = paramInt;
    this.A = null;
    return this;
  }

  public ay c(Fragment paramFragment)
  {
    a locala = new a();
    locala.c = 5;
    locala.d = paramFragment;
    a(locala);
    return this;
  }

  public ay d(int paramInt)
  {
    this.B = paramInt;
    this.C = null;
    return this;
  }

  public ay d(Fragment paramFragment)
  {
    a locala = new a();
    locala.c = 6;
    locala.d = paramFragment;
    a(locala);
    return this;
  }

  public CharSequence d()
  {
    if (this.z != 0)
      return this.c.u.i().getText(this.z);
    return this.A;
  }

  public ay e(Fragment paramFragment)
  {
    a locala = new a();
    locala.c = 7;
    locala.d = paramFragment;
    a(locala);
    return this;
  }

  public CharSequence e()
  {
    if (this.B != 0)
      return this.c.u.i().getText(this.B);
    return this.C;
  }

  void e(int paramInt)
  {
    if (!this.u);
    while (true)
    {
      return;
      if (al.b)
        Log.v("FragmentManager", "Bump nesting in " + this + " by " + paramInt);
      for (a locala = this.l; locala != null; locala = locala.a)
      {
        if (locala.d != null)
        {
          Fragment localFragment2 = locala.d;
          localFragment2.K = (paramInt + localFragment2.K);
          if (al.b)
            Log.v("FragmentManager", "Bump nesting of " + locala.d + " to " + locala.d.K);
        }
        if (locala.i != null)
          for (int i1 = -1 + locala.i.size(); i1 >= 0; i1--)
          {
            Fragment localFragment1 = (Fragment)locala.i.get(i1);
            localFragment1.K = (paramInt + localFragment1.K);
            if (al.b)
              Log.v("FragmentManager", "Bump nesting of " + localFragment1 + " to " + localFragment1.K);
          }
      }
    }
  }

  public boolean f()
  {
    return this.v;
  }

  public ay g()
  {
    if (this.u)
      throw new IllegalStateException("This transaction is already being added to the back stack");
    this.v = false;
    return this;
  }

  public int h()
  {
    return a(false);
  }

  public int i()
  {
    return a(true);
  }

  public String j()
  {
    return this.w;
  }

  public int k()
  {
    return this.s;
  }

  public int l()
  {
    return this.t;
  }

  public boolean m()
  {
    return this.n == 0;
  }

  public void run()
  {
    if (al.b)
      Log.v("FragmentManager", "Run: " + this);
    if ((this.u) && (this.y < 0))
      throw new IllegalStateException("addToBackStack() called after commit()");
    e(1);
    SparseArray localSparseArray1;
    SparseArray localSparseArray2;
    if (b)
    {
      localSparseArray1 = new SparseArray();
      localSparseArray2 = new SparseArray();
      b(localSparseArray1, localSparseArray2);
    }
    for (b localb = a(localSparseArray1, localSparseArray2, false); ; localb = null)
    {
      int i1;
      label105: int i2;
      label112: a locala;
      int i3;
      if (localb != null)
      {
        i1 = 0;
        if (localb == null)
          break label225;
        i2 = 0;
        locala = this.l;
        if (locala == null)
          break label727;
        if (localb == null)
          break label234;
        i3 = 0;
        label130: if (localb == null)
          break label244;
      }
      label225: label234: label244: for (int i4 = 0; ; i4 = locala.f)
        switch (locala.c)
        {
        default:
          throw new IllegalArgumentException("Unknown cmd: " + locala.c);
          i1 = this.t;
          break label105;
          i2 = this.s;
          break label112;
          i3 = locala.e;
          break label130;
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
        case 6:
        case 7:
        }
      Fragment localFragment7 = locala.d;
      localFragment7.Z = i3;
      this.c.a(localFragment7, false);
      while (true)
      {
        locala = locala.a;
        break;
        Object localObject1 = locala.d;
        int i5 = ((Fragment)localObject1).Q;
        if (this.c.m != null)
        {
          int i6 = -1 + this.c.m.size();
          if (i6 >= 0)
          {
            Fragment localFragment6 = (Fragment)this.c.m.get(i6);
            if (al.b)
              Log.v("FragmentManager", "OP_REPLACE: adding=" + localObject1 + " old=" + localFragment6);
            Object localObject2;
            if (localFragment6.Q == i5)
              if (localFragment6 == localObject1)
              {
                localObject2 = null;
                locala.d = null;
              }
            while (true)
            {
              i6--;
              localObject1 = localObject2;
              break;
              if (locala.i == null)
                locala.i = new ArrayList();
              locala.i.add(localFragment6);
              localFragment6.Z = i4;
              if (this.u)
              {
                localFragment6.K = (1 + localFragment6.K);
                if (al.b)
                  Log.v("FragmentManager", "Bump nesting of " + localFragment6 + " to " + localFragment6.K);
              }
              this.c.a(localFragment6, i2, i1);
              localObject2 = localObject1;
            }
          }
        }
        if (localObject1 != null)
        {
          ((Fragment)localObject1).Z = i3;
          this.c.a((Fragment)localObject1, false);
          continue;
          Fragment localFragment5 = locala.d;
          localFragment5.Z = i4;
          this.c.a(localFragment5, i2, i1);
          continue;
          Fragment localFragment4 = locala.d;
          localFragment4.Z = i4;
          this.c.b(localFragment4, i2, i1);
          continue;
          Fragment localFragment3 = locala.d;
          localFragment3.Z = i3;
          this.c.c(localFragment3, i2, i1);
          continue;
          Fragment localFragment2 = locala.d;
          localFragment2.Z = i4;
          this.c.d(localFragment2, i2, i1);
          continue;
          Fragment localFragment1 = locala.d;
          localFragment1.Z = i3;
          this.c.e(localFragment1, i2, i1);
        }
      }
      label727: this.c.a(this.c.t, i2, i1, true);
      if (this.u)
        this.c.b(this);
      return;
    }
  }

  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder(128);
    localStringBuilder.append("BackStackEntry{");
    localStringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    if (this.y >= 0)
    {
      localStringBuilder.append(" #");
      localStringBuilder.append(this.y);
    }
    if (this.w != null)
    {
      localStringBuilder.append(" ");
      localStringBuilder.append(this.w);
    }
    localStringBuilder.append("}");
    return localStringBuilder.toString();
  }

  static final class a
  {
    a a;
    a b;
    int c;
    Fragment d;
    int e;
    int f;
    int g;
    int h;
    ArrayList<Fragment> i;
  }

  public class b
  {
    public a<String, String> a = new a();
    public ArrayList<View> b = new ArrayList();
    public az.a c = new az.a();
    public View d;

    public b()
    {
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.r
 * JD-Core Version:    0.6.2
 */