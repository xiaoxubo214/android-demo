package android.support.v4.app;

import android.view.View;

class s
  implements az.b
{
  s(r paramr, Fragment paramFragment)
  {
  }

  public View a()
  {
    return this.a.J();
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.s
 * JD-Core Version:    0.6.2
 */