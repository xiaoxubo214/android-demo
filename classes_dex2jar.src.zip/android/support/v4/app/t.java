package android.support.v4.app;

import android.support.v4.m.a;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.ViewTreeObserver.OnPreDrawListener;
import java.util.ArrayList;

class t
  implements ViewTreeObserver.OnPreDrawListener
{
  t(r paramr, View paramView, Object paramObject, ArrayList paramArrayList, r.b paramb, boolean paramBoolean, Fragment paramFragment1, Fragment paramFragment2)
  {
  }

  public boolean onPreDraw()
  {
    this.a.getViewTreeObserver().removeOnPreDrawListener(this);
    if (this.b != null)
    {
      az.a(this.b, this.c);
      this.c.clear();
      a locala = r.a(this.h, this.d, this.e, this.f);
      az.a(this.b, this.d.d, locala, this.c);
      r.a(this.h, locala, this.d);
      r.a(this.h, this.d, this.f, this.g, this.e, locala);
    }
    return true;
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.t
 * JD-Core Version:    0.6.2
 */