package android.support.v4.app;

import android.view.View;
import android.view.ViewTreeObserver;
import android.view.ViewTreeObserver.OnPreDrawListener;

class u
  implements ViewTreeObserver.OnPreDrawListener
{
  u(r paramr, View paramView, r.b paramb, int paramInt, Object paramObject)
  {
  }

  public boolean onPreDraw()
  {
    this.a.getViewTreeObserver().removeOnPreDrawListener(this);
    r.a(this.e, this.b, this.c, this.d);
    return true;
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.u
 * JD-Core Version:    0.6.2
 */