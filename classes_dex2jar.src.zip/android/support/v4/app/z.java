package android.support.v4.app;

import java.lang.reflect.Method;

class z
{
  private static final String a = "BundleCompatDonut";
  private static Method b;
  private static boolean c;
  private static Method d;
  private static boolean e;

  // ERROR //
  public static android.os.IBinder a(android.os.Bundle paramBundle, String paramString)
  {
    // Byte code:
    //   0: getstatic 29	android/support/v4/app/z:c	Z
    //   3: ifne +33 -> 36
    //   6: ldc 31
    //   8: ldc 33
    //   10: iconst_1
    //   11: anewarray 35	java/lang/Class
    //   14: dup
    //   15: iconst_0
    //   16: ldc 37
    //   18: aastore
    //   19: invokevirtual 41	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   22: putstatic 43	android/support/v4/app/z:b	Ljava/lang/reflect/Method;
    //   25: getstatic 43	android/support/v4/app/z:b	Ljava/lang/reflect/Method;
    //   28: iconst_1
    //   29: invokevirtual 49	java/lang/reflect/Method:setAccessible	(Z)V
    //   32: iconst_1
    //   33: putstatic 29	android/support/v4/app/z:c	Z
    //   36: getstatic 43	android/support/v4/app/z:b	Ljava/lang/reflect/Method;
    //   39: ifnull +55 -> 94
    //   42: getstatic 43	android/support/v4/app/z:b	Ljava/lang/reflect/Method;
    //   45: aload_0
    //   46: iconst_1
    //   47: anewarray 4	java/lang/Object
    //   50: dup
    //   51: iconst_0
    //   52: aload_1
    //   53: aastore
    //   54: invokevirtual 53	java/lang/reflect/Method:invoke	(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   57: checkcast 55	android/os/IBinder
    //   60: astore 4
    //   62: aload 4
    //   64: areturn
    //   65: astore 5
    //   67: ldc 8
    //   69: ldc 57
    //   71: aload 5
    //   73: invokestatic 63	android/util/Log:i	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   76: pop
    //   77: goto -45 -> 32
    //   80: astore_2
    //   81: ldc 8
    //   83: ldc 65
    //   85: aload_2
    //   86: invokestatic 63	android/util/Log:i	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   89: pop
    //   90: aconst_null
    //   91: putstatic 43	android/support/v4/app/z:b	Ljava/lang/reflect/Method;
    //   94: aconst_null
    //   95: areturn
    //   96: astore_2
    //   97: goto -16 -> 81
    //   100: astore_2
    //   101: goto -20 -> 81
    //
    // Exception table:
    //   from	to	target	type
    //   6	32	65	java/lang/NoSuchMethodException
    //   42	62	80	java/lang/IllegalAccessException
    //   42	62	96	java/lang/IllegalArgumentException
    //   42	62	100	java/lang/reflect/InvocationTargetException
  }

  // ERROR //
  public static void a(android.os.Bundle paramBundle, String paramString, android.os.IBinder paramIBinder)
  {
    // Byte code:
    //   0: getstatic 68	android/support/v4/app/z:e	Z
    //   3: ifne +38 -> 41
    //   6: ldc 31
    //   8: ldc 70
    //   10: iconst_2
    //   11: anewarray 35	java/lang/Class
    //   14: dup
    //   15: iconst_0
    //   16: ldc 37
    //   18: aastore
    //   19: dup
    //   20: iconst_1
    //   21: ldc 55
    //   23: aastore
    //   24: invokevirtual 41	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   27: putstatic 72	android/support/v4/app/z:d	Ljava/lang/reflect/Method;
    //   30: getstatic 72	android/support/v4/app/z:d	Ljava/lang/reflect/Method;
    //   33: iconst_1
    //   34: invokevirtual 49	java/lang/reflect/Method:setAccessible	(Z)V
    //   37: iconst_1
    //   38: putstatic 68	android/support/v4/app/z:e	Z
    //   41: getstatic 72	android/support/v4/app/z:d	Ljava/lang/reflect/Method;
    //   44: ifnull +23 -> 67
    //   47: getstatic 72	android/support/v4/app/z:d	Ljava/lang/reflect/Method;
    //   50: aload_0
    //   51: iconst_2
    //   52: anewarray 4	java/lang/Object
    //   55: dup
    //   56: iconst_0
    //   57: aload_1
    //   58: aastore
    //   59: dup
    //   60: iconst_1
    //   61: aload_2
    //   62: aastore
    //   63: invokevirtual 53	java/lang/reflect/Method:invoke	(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   66: pop
    //   67: return
    //   68: astore 6
    //   70: ldc 8
    //   72: ldc 74
    //   74: aload 6
    //   76: invokestatic 63	android/util/Log:i	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   79: pop
    //   80: goto -43 -> 37
    //   83: astore_3
    //   84: ldc 8
    //   86: ldc 76
    //   88: aload_3
    //   89: invokestatic 63	android/util/Log:i	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   92: pop
    //   93: aconst_null
    //   94: putstatic 72	android/support/v4/app/z:d	Ljava/lang/reflect/Method;
    //   97: return
    //   98: astore_3
    //   99: goto -15 -> 84
    //   102: astore_3
    //   103: goto -19 -> 84
    //
    // Exception table:
    //   from	to	target	type
    //   6	37	68	java/lang/NoSuchMethodException
    //   47	67	83	java/lang/IllegalAccessException
    //   47	67	98	java/lang/IllegalArgumentException
    //   47	67	102	java/lang/reflect/InvocationTargetException
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.z
 * JD-Core Version:    0.6.2
 */