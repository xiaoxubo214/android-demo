package android.support.v4.b;

import android.os.Build.VERSION;
import android.view.View;

public final class a
{
  private static final c a = new e();

  static
  {
    if (Build.VERSION.SDK_INT >= 12)
    {
      a = new g();
      return;
    }
  }

  public static i a()
  {
    return a.a();
  }

  public static void a(View paramView)
  {
    a.a(paramView);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.b.a
 * JD-Core Version:    0.6.2
 */