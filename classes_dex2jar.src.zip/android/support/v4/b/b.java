package android.support.v4.b;

public abstract interface b
{
  public abstract void a(i parami);

  public abstract void b(i parami);

  public abstract void c(i parami);

  public abstract void d(i parami);
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.b.b
 * JD-Core Version:    0.6.2
 */