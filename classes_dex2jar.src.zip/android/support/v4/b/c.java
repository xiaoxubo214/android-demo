package android.support.v4.b;

import android.view.View;

abstract interface c
{
  public abstract i a();

  public abstract void a(View paramView);
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.b.c
 * JD-Core Version:    0.6.2
 */