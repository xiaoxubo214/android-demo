package android.support.v4.b;

import android.view.View;
import java.util.ArrayList;
import java.util.List;

class e
  implements c
{
  public i a()
  {
    return new a();
  }

  public void a(View paramView)
  {
  }

  private static class a
    implements i
  {
    List<b> a = new ArrayList();
    List<d> b = new ArrayList();
    View c;
    private long d;
    private long e = 200L;
    private float f = 0.0F;
    private boolean g = false;
    private boolean h = false;
    private Runnable i = new f(this);

    private void d()
    {
      for (int j = -1 + this.b.size(); j >= 0; j--)
        ((d)this.b.get(j)).a(this);
    }

    private long e()
    {
      return this.c.getDrawingTime();
    }

    private void f()
    {
      for (int j = -1 + this.a.size(); j >= 0; j--)
        ((b)this.a.get(j)).a(this);
    }

    private void g()
    {
      for (int j = -1 + this.a.size(); j >= 0; j--)
        ((b)this.a.get(j)).b(this);
    }

    private void h()
    {
      for (int j = -1 + this.a.size(); j >= 0; j--)
        ((b)this.a.get(j)).c(this);
    }

    public void a()
    {
      if (this.g)
        return;
      this.g = true;
      f();
      this.f = 0.0F;
      this.d = e();
      this.c.postDelayed(this.i, 16L);
    }

    public void a(long paramLong)
    {
      if (!this.g)
        this.e = paramLong;
    }

    public void a(b paramb)
    {
      this.a.add(paramb);
    }

    public void a(d paramd)
    {
      this.b.add(paramd);
    }

    public void a(View paramView)
    {
      this.c = paramView;
    }

    public void b()
    {
      if (this.h)
        return;
      this.h = true;
      if (this.g)
        h();
      g();
    }

    public float c()
    {
      return this.f;
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.b.e
 * JD-Core Version:    0.6.2
 */