package android.support.v4.b;

import android.view.View;

class f
  implements Runnable
{
  f(e.a parama)
  {
  }

  public void run()
  {
    float f = 1.0F * (float)(e.a.a(this.a) - e.a.b(this.a)) / (float)e.a.c(this.a);
    if ((f > 1.0F) || (this.a.c.getParent() == null))
      f = 1.0F;
    e.a.a(this.a, f);
    e.a.d(this.a);
    if (e.a.e(this.a) >= 1.0F)
    {
      e.a.f(this.a);
      return;
    }
    this.a.c.postDelayed(e.a.g(this.a), 16L);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.b.f
 * JD-Core Version:    0.6.2
 */