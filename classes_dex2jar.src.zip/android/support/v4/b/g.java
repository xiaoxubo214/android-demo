package android.support.v4.b;

import android.animation.Animator;
import android.animation.Animator.AnimatorListener;
import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.view.View;
import android.view.ViewPropertyAnimator;

class g
  implements c
{
  private TimeInterpolator a;

  public i a()
  {
    return new b(ValueAnimator.ofFloat(new float[] { 0.0F, 1.0F }));
  }

  public void a(View paramView)
  {
    if (this.a == null)
      this.a = new ValueAnimator().getInterpolator();
    paramView.animate().setInterpolator(this.a);
  }

  static class a
    implements Animator.AnimatorListener
  {
    final b a;
    final i b;

    public a(b paramb, i parami)
    {
      this.a = paramb;
      this.b = parami;
    }

    public void onAnimationCancel(Animator paramAnimator)
    {
      this.a.c(this.b);
    }

    public void onAnimationEnd(Animator paramAnimator)
    {
      this.a.b(this.b);
    }

    public void onAnimationRepeat(Animator paramAnimator)
    {
      this.a.d(this.b);
    }

    public void onAnimationStart(Animator paramAnimator)
    {
      this.a.a(this.b);
    }
  }

  static class b
    implements i
  {
    final Animator a;

    public b(Animator paramAnimator)
    {
      this.a = paramAnimator;
    }

    public void a()
    {
      this.a.start();
    }

    public void a(long paramLong)
    {
      this.a.setDuration(paramLong);
    }

    public void a(b paramb)
    {
      this.a.addListener(new g.a(paramb, this));
    }

    public void a(d paramd)
    {
      if ((this.a instanceof ValueAnimator))
        ((ValueAnimator)this.a).addUpdateListener(new h(this, paramd));
    }

    public void a(View paramView)
    {
      this.a.setTarget(paramView);
    }

    public void b()
    {
      this.a.cancel();
    }

    public float c()
    {
      return ((ValueAnimator)this.a).getAnimatedFraction();
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.b.g
 * JD-Core Version:    0.6.2
 */