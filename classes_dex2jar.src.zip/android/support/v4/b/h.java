package android.support.v4.b;

import android.animation.ValueAnimator;
import android.animation.ValueAnimator.AnimatorUpdateListener;

class h
  implements ValueAnimator.AnimatorUpdateListener
{
  h(g.b paramb, d paramd)
  {
  }

  public void onAnimationUpdate(ValueAnimator paramValueAnimator)
  {
    this.a.a(this.b);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.b.h
 * JD-Core Version:    0.6.2
 */