package android.support.v4.b;

import android.view.View;

public abstract interface i
{
  public abstract void a();

  public abstract void a(long paramLong);

  public abstract void a(b paramb);

  public abstract void a(d paramd);

  public abstract void a(View paramView);

  public abstract void b();

  public abstract float c();
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.b.i
 * JD-Core Version:    0.6.2
 */