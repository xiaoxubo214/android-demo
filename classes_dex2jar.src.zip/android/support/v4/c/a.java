package android.support.v4.c;

import android.content.Context;
import android.os.Handler;
import android.os.SystemClock;
import android.support.v4.m.p;
import android.support.v4.os.h;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executor;

public abstract class a<D> extends r<D>
{
  static final String a = "AsyncTaskLoader";
  static final boolean b;
  volatile a<D>.a c;
  volatile a<D>.a d;
  long e;
  long f = -10000L;
  Handler g;
  private final Executor h;

  public a(Context paramContext)
  {
    this(paramContext, u.c);
  }

  private a(Context paramContext, Executor paramExecutor)
  {
    super(paramContext);
    this.h = paramExecutor;
  }

  protected void a()
  {
    super.a();
    y();
    this.c = new a();
    c();
  }

  public void a(long paramLong)
  {
    this.e = paramLong;
    if (paramLong != 0L)
      this.g = new Handler();
  }

  void a(a<D>.a parama, D paramD)
  {
    a(paramD);
    if (this.d == parama)
    {
      G();
      this.f = SystemClock.uptimeMillis();
      this.d = null;
      r();
      c();
    }
  }

  public void a(D paramD)
  {
  }

  public void a(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString)
  {
    super.a(paramString, paramFileDescriptor, paramPrintWriter, paramArrayOfString);
    if (this.c != null)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mTask=");
      paramPrintWriter.print(this.c);
      paramPrintWriter.print(" waiting=");
      paramPrintWriter.println(this.c.a);
    }
    if (this.d != null)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mCancellingTask=");
      paramPrintWriter.print(this.d);
      paramPrintWriter.print(" waiting=");
      paramPrintWriter.println(this.d.a);
    }
    if (this.e != 0L)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mUpdateThrottle=");
      p.a(this.e, paramPrintWriter);
      paramPrintWriter.print(" mLastLoadCompleteTime=");
      p.a(this.f, SystemClock.uptimeMillis(), paramPrintWriter);
      paramPrintWriter.println();
    }
  }

  void b(a<D>.a parama, D paramD)
  {
    if (this.c != parama)
    {
      a(parama, paramD);
      return;
    }
    if (v())
    {
      a(paramD);
      return;
    }
    F();
    this.f = SystemClock.uptimeMillis();
    this.c = null;
    b(paramD);
  }

  protected boolean b()
  {
    if (this.c != null)
    {
      if (this.d != null)
      {
        if (this.c.a)
        {
          this.c.a = false;
          this.g.removeCallbacks(this.c);
        }
        this.c = null;
      }
    }
    else
      return false;
    if (this.c.a)
    {
      this.c.a = false;
      this.g.removeCallbacks(this.c);
      this.c = null;
      return false;
    }
    boolean bool = this.c.a(false);
    if (bool)
    {
      this.d = this.c;
      f();
    }
    this.c = null;
    return bool;
  }

  void c()
  {
    if ((this.d == null) && (this.c != null))
    {
      if (this.c.a)
      {
        this.c.a = false;
        this.g.removeCallbacks(this.c);
      }
      if ((this.e > 0L) && (SystemClock.uptimeMillis() < this.f + this.e))
      {
        this.c.a = true;
        this.g.postAtTime(this.c, this.f + this.e);
      }
    }
    else
    {
      return;
    }
    this.c.a(this.h, (Void[])null);
  }

  public abstract D d();

  protected D e()
  {
    return d();
  }

  public void f()
  {
  }

  public boolean g()
  {
    return this.d != null;
  }

  public void h()
  {
    a locala = this.c;
    if (locala != null)
      locala.a();
  }

  final class a extends u<Void, Void, D>
    implements Runnable
  {
    boolean a;
    private final CountDownLatch d = new CountDownLatch(1);

    a()
    {
    }

    protected D a(Void[] paramArrayOfVoid)
    {
      try
      {
        Object localObject = a.this.e();
        return localObject;
      }
      catch (h localh)
      {
        if (!e())
          throw localh;
      }
      return null;
    }

    public void a()
    {
      try
      {
        this.d.await();
        return;
      }
      catch (InterruptedException localInterruptedException)
      {
      }
    }

    protected void a(D paramD)
    {
      try
      {
        a.this.b(this, paramD);
        return;
      }
      finally
      {
        this.d.countDown();
      }
    }

    protected void b(D paramD)
    {
      try
      {
        a.this.a(this, paramD);
        return;
      }
      finally
      {
        this.d.countDown();
      }
    }

    public void run()
    {
      this.a = false;
      a.this.c();
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.c.a
 * JD-Core Version:    0.6.2
 */