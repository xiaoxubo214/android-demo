package android.support.v4.c.a;

public final class a
{
  public static final int a = 512;
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.c.a.a
 * JD-Core Version:    0.6.2
 */