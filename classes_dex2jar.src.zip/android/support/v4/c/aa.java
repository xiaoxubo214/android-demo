package android.support.v4.c;

import android.content.SharedPreferences.Editor;
import android.os.Build.VERSION;
import android.support.annotation.x;

public final class aa
{
  public static final class a
  {
    private static a a;
    private final c b;

    private a()
    {
      if (Build.VERSION.SDK_INT >= 9)
      {
        this.b = new a(null);
        return;
      }
      this.b = new b(null);
    }

    public static a a()
    {
      if (a == null)
        a = new a();
      return a;
    }

    public void a(@x SharedPreferences.Editor paramEditor)
    {
      this.b.a(paramEditor);
    }

    private static class a
      implements aa.a.c
    {
      public void a(@x SharedPreferences.Editor paramEditor)
      {
        l.a(paramEditor);
      }
    }

    private static class b
      implements aa.a.c
    {
      public void a(@x SharedPreferences.Editor paramEditor)
      {
        paramEditor.commit();
      }
    }

    private static abstract interface c
    {
      public abstract void a(@x SharedPreferences.Editor paramEditor);
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.c.aa
 * JD-Core Version:    0.6.2
 */