package android.support.v4.c;

import android.content.ContentResolver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build.VERSION;
import android.support.v4.os.h;

public final class b
{
  private static final a a = new b();

  static
  {
    if (Build.VERSION.SDK_INT >= 16)
    {
      a = new c();
      return;
    }
  }

  public static Cursor a(ContentResolver paramContentResolver, Uri paramUri, String[] paramArrayOfString1, String paramString1, String[] paramArrayOfString2, String paramString2, android.support.v4.os.c paramc)
  {
    return a.a(paramContentResolver, paramUri, paramArrayOfString1, paramString1, paramArrayOfString2, paramString2, paramc);
  }

  static abstract interface a
  {
    public abstract Cursor a(ContentResolver paramContentResolver, Uri paramUri, String[] paramArrayOfString1, String paramString1, String[] paramArrayOfString2, String paramString2, android.support.v4.os.c paramc);
  }

  static class b
    implements b.a
  {
    public Cursor a(ContentResolver paramContentResolver, Uri paramUri, String[] paramArrayOfString1, String paramString1, String[] paramArrayOfString2, String paramString2, android.support.v4.os.c paramc)
    {
      if (paramc != null)
        paramc.b();
      return paramContentResolver.query(paramUri, paramArrayOfString1, paramString1, paramArrayOfString2, paramString2);
    }
  }

  static class c extends b.b
  {
    public Cursor a(ContentResolver paramContentResolver, Uri paramUri, String[] paramArrayOfString1, String paramString1, String[] paramArrayOfString2, String paramString2, android.support.v4.os.c paramc)
    {
      if (paramc != null);
      try
      {
        for (Object localObject = paramc.d(); ; localObject = null)
        {
          Cursor localCursor = c.a(paramContentResolver, paramUri, paramArrayOfString1, paramString1, paramArrayOfString2, paramString2, localObject);
          return localCursor;
        }
      }
      catch (Exception localException)
      {
        if (c.a(localException))
          throw new h();
        throw localException;
      }
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.c.b
 * JD-Core Version:    0.6.2
 */