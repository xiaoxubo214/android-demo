package android.support.v4.c.b;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.Resources.NotFoundException;
import android.content.res.Resources.Theme;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.support.annotation.j;
import android.support.annotation.k;
import android.support.annotation.m;
import android.support.annotation.x;
import android.support.annotation.y;

public final class a
{
  @y
  public static Drawable a(@x Resources paramResources, @m int paramInt1, int paramInt2, @y Resources.Theme paramTheme)
    throws Resources.NotFoundException
  {
    if (Build.VERSION.SDK_INT >= 21)
      return b.a(paramResources, paramInt1, paramInt2, paramTheme);
    if (Build.VERSION.SDK_INT >= 15)
      return d.a(paramResources, paramInt1, paramInt2);
    return paramResources.getDrawable(paramInt1);
  }

  @y
  public static Drawable a(@x Resources paramResources, @m int paramInt, @y Resources.Theme paramTheme)
    throws Resources.NotFoundException
  {
    if (Build.VERSION.SDK_INT >= 21)
      return b.a(paramResources, paramInt, paramTheme);
    return paramResources.getDrawable(paramInt);
  }

  @j
  public static int b(@x Resources paramResources, @k int paramInt, @y Resources.Theme paramTheme)
    throws Resources.NotFoundException
  {
    if (Build.VERSION.SDK_INT >= 23)
      return c.a(paramResources, paramInt, paramTheme);
    return paramResources.getColor(paramInt);
  }

  @y
  public static ColorStateList c(@x Resources paramResources, @k int paramInt, @y Resources.Theme paramTheme)
    throws Resources.NotFoundException
  {
    if (Build.VERSION.SDK_INT >= 23)
      return c.b(paramResources, paramInt, paramTheme);
    return paramResources.getColorStateList(paramInt);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.c.b.a
 * JD-Core Version:    0.6.2
 */