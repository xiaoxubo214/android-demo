package android.support.v4.c.b;

import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.support.annotation.ag;
import android.support.annotation.c;

public class e
{
  public static int a(TypedArray paramTypedArray, @ag int paramInt1, @ag int paramInt2, int paramInt3)
  {
    return paramTypedArray.getInt(paramInt1, paramTypedArray.getInt(paramInt2, paramInt3));
  }

  public static Drawable a(TypedArray paramTypedArray, @ag int paramInt1, @ag int paramInt2)
  {
    Drawable localDrawable = paramTypedArray.getDrawable(paramInt1);
    if (localDrawable == null)
      localDrawable = paramTypedArray.getDrawable(paramInt2);
    return localDrawable;
  }

  public static boolean a(TypedArray paramTypedArray, @ag int paramInt1, @ag int paramInt2, boolean paramBoolean)
  {
    return paramTypedArray.getBoolean(paramInt1, paramTypedArray.getBoolean(paramInt2, paramBoolean));
  }

  @c
  public static int b(TypedArray paramTypedArray, @ag int paramInt1, @ag int paramInt2, @c int paramInt3)
  {
    return paramTypedArray.getResourceId(paramInt1, paramTypedArray.getResourceId(paramInt2, paramInt3));
  }

  public static String b(TypedArray paramTypedArray, @ag int paramInt1, @ag int paramInt2)
  {
    String str = paramTypedArray.getString(paramInt1);
    if (str == null)
      str = paramTypedArray.getString(paramInt2);
    return str;
  }

  public static CharSequence[] c(TypedArray paramTypedArray, @ag int paramInt1, @ag int paramInt2)
  {
    CharSequence[] arrayOfCharSequence = paramTypedArray.getTextArray(paramInt1);
    if (arrayOfCharSequence == null)
      arrayOfCharSequence = paramTypedArray.getTextArray(paramInt2);
    return arrayOfCharSequence;
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.c.b.e
 * JD-Core Version:    0.6.2
 */