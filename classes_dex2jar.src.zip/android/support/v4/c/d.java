package android.support.v4.c;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Environment;
import android.os.Process;
import android.support.annotation.x;
import android.util.Log;
import java.io.File;

public class d
{
  private static final String a = "ContextCompat";
  private static final String b = "Android";
  private static final String c = "data";
  private static final String d = "obb";
  private static final String e = "files";
  private static final String f = "cache";

  public static final Drawable a(Context paramContext, int paramInt)
  {
    if (Build.VERSION.SDK_INT >= 21)
      return e.a(paramContext, paramInt);
    return paramContext.getResources().getDrawable(paramInt);
  }

  private static File a(File paramFile)
  {
    try
    {
      if ((!paramFile.exists()) && (!paramFile.mkdirs()))
      {
        boolean bool = paramFile.exists();
        if (!bool)
          break label31;
      }
      while (true)
      {
        return paramFile;
        label31: Log.w("ContextCompat", "Unable to create files subdir " + paramFile.getPath());
        paramFile = null;
      }
    }
    finally
    {
    }
  }

  private static File a(File paramFile, String[] paramArrayOfString)
  {
    int i = paramArrayOfString.length;
    int j = 0;
    Object localObject1 = paramFile;
    String str;
    Object localObject2;
    if (j < i)
    {
      str = paramArrayOfString[j];
      if (localObject1 == null)
        localObject2 = new File(str);
    }
    while (true)
    {
      j++;
      localObject1 = localObject2;
      break;
      if (str != null)
      {
        localObject2 = new File((File)localObject1, str);
        continue;
        return localObject1;
      }
      else
      {
        localObject2 = localObject1;
      }
    }
  }

  public static boolean a(Context paramContext, Intent[] paramArrayOfIntent)
  {
    return a(paramContext, paramArrayOfIntent, null);
  }

  public static boolean a(Context paramContext, Intent[] paramArrayOfIntent, Bundle paramBundle)
  {
    int i = Build.VERSION.SDK_INT;
    if (i >= 16)
    {
      i.a(paramContext, paramArrayOfIntent, paramBundle);
      return true;
    }
    if (i >= 11)
    {
      h.a(paramContext, paramArrayOfIntent);
      return true;
    }
    return false;
  }

  public static File[] a(Context paramContext)
  {
    int i = Build.VERSION.SDK_INT;
    if (i >= 19)
      return j.b(paramContext);
    if (i >= 11);
    File localFile1;
    String[] arrayOfString;
    for (File localFile2 = h.a(paramContext); ; localFile2 = a(localFile1, arrayOfString))
    {
      return new File[] { localFile2 };
      localFile1 = Environment.getExternalStorageDirectory();
      arrayOfString = new String[3];
      arrayOfString[0] = "Android";
      arrayOfString[1] = "obb";
      arrayOfString[2] = paramContext.getPackageName();
    }
  }

  public static File[] a(Context paramContext, String paramString)
  {
    int i = Build.VERSION.SDK_INT;
    if (i >= 19)
      return j.a(paramContext, paramString);
    if (i >= 8);
    File localFile1;
    String[] arrayOfString;
    for (File localFile2 = g.a(paramContext, paramString); ; localFile2 = a(localFile1, arrayOfString))
    {
      return new File[] { localFile2 };
      localFile1 = Environment.getExternalStorageDirectory();
      arrayOfString = new String[5];
      arrayOfString[0] = "Android";
      arrayOfString[1] = "data";
      arrayOfString[2] = paramContext.getPackageName();
      arrayOfString[3] = "files";
      arrayOfString[4] = paramString;
    }
  }

  public static int b(@x Context paramContext, @x String paramString)
  {
    if (paramString == null)
      throw new IllegalArgumentException("permission is null");
    return paramContext.checkPermission(paramString, Process.myPid(), Process.myUid());
  }

  public static final ColorStateList b(Context paramContext, int paramInt)
  {
    if (Build.VERSION.SDK_INT >= 23)
      return f.a(paramContext, paramInt);
    return paramContext.getResources().getColorStateList(paramInt);
  }

  public static File[] b(Context paramContext)
  {
    int i = Build.VERSION.SDK_INT;
    if (i >= 19)
      return j.a(paramContext);
    if (i >= 8);
    File localFile1;
    String[] arrayOfString;
    for (File localFile2 = g.a(paramContext); ; localFile2 = a(localFile1, arrayOfString))
    {
      return new File[] { localFile2 };
      localFile1 = Environment.getExternalStorageDirectory();
      arrayOfString = new String[4];
      arrayOfString[0] = "Android";
      arrayOfString[1] = "data";
      arrayOfString[2] = paramContext.getPackageName();
      arrayOfString[3] = "cache";
    }
  }

  public static final int c(Context paramContext, int paramInt)
  {
    if (Build.VERSION.SDK_INT >= 23)
      return f.b(paramContext, paramInt);
    return paramContext.getResources().getColor(paramInt);
  }

  public static File d(Context paramContext)
  {
    if (Build.VERSION.SDK_INT >= 21)
      return e.b(paramContext);
    return a(new File(paramContext.getApplicationInfo().dataDir, "code_cache"));
  }

  public final File c(Context paramContext)
  {
    if (Build.VERSION.SDK_INT >= 21)
      return e.a(paramContext);
    return a(new File(paramContext.getApplicationInfo().dataDir, "no_backup"));
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.c.d
 * JD-Core Version:    0.6.2
 */