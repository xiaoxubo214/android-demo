package android.support.v4.c;

import android.content.Context;
import android.graphics.drawable.Drawable;
import java.io.File;

class e
{
  public static Drawable a(Context paramContext, int paramInt)
  {
    return paramContext.getDrawable(paramInt);
  }

  public static File a(Context paramContext)
  {
    return paramContext.getNoBackupFilesDir();
  }

  public static File b(Context paramContext)
  {
    return paramContext.getCodeCacheDir();
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.c.e
 * JD-Core Version:    0.6.2
 */