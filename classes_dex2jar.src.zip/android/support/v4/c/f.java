package android.support.v4.c;

import android.content.Context;
import android.content.res.ColorStateList;

class f
{
  public static ColorStateList a(Context paramContext, int paramInt)
  {
    return paramContext.getColorStateList(paramInt);
  }

  public static int b(Context paramContext, int paramInt)
  {
    return paramContext.getColor(paramInt);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.c.f
 * JD-Core Version:    0.6.2
 */