package android.support.v4.c;

import android.content.Context;
import java.io.File;

class g
{
  public static File a(Context paramContext)
  {
    return paramContext.getExternalCacheDir();
  }

  public static File a(Context paramContext, String paramString)
  {
    return paramContext.getExternalFilesDir(paramString);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.c.g
 * JD-Core Version:    0.6.2
 */