package android.support.v4.c;

import android.content.Context;
import android.content.Intent;
import java.io.File;

class h
{
  public static File a(Context paramContext)
  {
    return paramContext.getObbDir();
  }

  static void a(Context paramContext, Intent[] paramArrayOfIntent)
  {
    paramContext.startActivities(paramArrayOfIntent);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.c.h
 * JD-Core Version:    0.6.2
 */