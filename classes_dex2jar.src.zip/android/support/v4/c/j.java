package android.support.v4.c;

import android.content.Context;
import java.io.File;

class j
{
  public static File[] a(Context paramContext)
  {
    return paramContext.getExternalCacheDirs();
  }

  public static File[] a(Context paramContext, String paramString)
  {
    return paramContext.getExternalFilesDirs(paramString);
  }

  public static File[] b(Context paramContext)
  {
    return paramContext.getObbDirs();
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.c.j
 * JD-Core Version:    0.6.2
 */