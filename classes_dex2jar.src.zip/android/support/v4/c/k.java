package android.support.v4.c;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.support.v4.os.c;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.Arrays;

public class k extends a<Cursor>
{
  final r<Cursor>.a h = new r.a(this);
  Uri i;
  String[] j;
  String k;
  String[] l;
  String m;
  Cursor n;
  c o;

  public k(Context paramContext)
  {
    super(paramContext);
  }

  public k(Context paramContext, Uri paramUri, String[] paramArrayOfString1, String paramString1, String[] paramArrayOfString2, String paramString2)
  {
    super(paramContext);
    this.i = paramUri;
    this.j = paramArrayOfString1;
    this.k = paramString1;
    this.l = paramArrayOfString2;
    this.m = paramString2;
  }

  public void a(Cursor paramCursor)
  {
    if (w())
      if (paramCursor != null)
        paramCursor.close();
    Cursor localCursor;
    do
    {
      return;
      localCursor = this.n;
      this.n = paramCursor;
      if (u())
        super.b(paramCursor);
    }
    while ((localCursor == null) || (localCursor == paramCursor) || (localCursor.isClosed()));
    localCursor.close();
  }

  public void a(Uri paramUri)
  {
    this.i = paramUri;
  }

  public void a(String paramString)
  {
    this.k = paramString;
  }

  public void a(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString)
  {
    super.a(paramString, paramFileDescriptor, paramPrintWriter, paramArrayOfString);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mUri=");
    paramPrintWriter.println(this.i);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mProjection=");
    paramPrintWriter.println(Arrays.toString(this.j));
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mSelection=");
    paramPrintWriter.println(this.k);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mSelectionArgs=");
    paramPrintWriter.println(Arrays.toString(this.l));
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mSortOrder=");
    paramPrintWriter.println(this.m);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mCursor=");
    paramPrintWriter.println(this.n);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mContentChanged=");
    paramPrintWriter.println(this.w);
  }

  public void a(String[] paramArrayOfString)
  {
    this.j = paramArrayOfString;
  }

  public void b(Cursor paramCursor)
  {
    if ((paramCursor != null) && (!paramCursor.isClosed()))
      paramCursor.close();
  }

  public void b(String paramString)
  {
    this.m = paramString;
  }

  public void b(String[] paramArrayOfString)
  {
    this.l = paramArrayOfString;
  }

  public void f()
  {
    super.f();
    try
    {
      if (this.o != null)
        this.o.c();
      return;
    }
    finally
    {
    }
  }

  // ERROR //
  public Cursor i()
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual 132	android/support/v4/c/k:g	()Z
    //   6: ifeq +16 -> 22
    //   9: new 134	android/support/v4/os/h
    //   12: dup
    //   13: invokespecial 136	android/support/v4/os/h:<init>	()V
    //   16: athrow
    //   17: astore_1
    //   18: aload_0
    //   19: monitorexit
    //   20: aload_1
    //   21: athrow
    //   22: aload_0
    //   23: new 124	android/support/v4/os/c
    //   26: dup
    //   27: invokespecial 137	android/support/v4/os/c:<init>	()V
    //   30: putfield 122	android/support/v4/c/k:o	Landroid/support/v4/os/c;
    //   33: aload_0
    //   34: monitorexit
    //   35: aload_0
    //   36: invokevirtual 141	android/support/v4/c/k:s	()Landroid/content/Context;
    //   39: invokevirtual 147	android/content/Context:getContentResolver	()Landroid/content/ContentResolver;
    //   42: aload_0
    //   43: getfield 34	android/support/v4/c/k:i	Landroid/net/Uri;
    //   46: aload_0
    //   47: getfield 36	android/support/v4/c/k:j	[Ljava/lang/String;
    //   50: aload_0
    //   51: getfield 38	android/support/v4/c/k:k	Ljava/lang/String;
    //   54: aload_0
    //   55: getfield 40	android/support/v4/c/k:l	[Ljava/lang/String;
    //   58: aload_0
    //   59: getfield 42	android/support/v4/c/k:m	Ljava/lang/String;
    //   62: aload_0
    //   63: getfield 122	android/support/v4/c/k:o	Landroid/support/v4/os/c;
    //   66: invokestatic 152	android/support/v4/c/b:a	(Landroid/content/ContentResolver;Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Landroid/support/v4/os/c;)Landroid/database/Cursor;
    //   69: astore 4
    //   71: aload 4
    //   73: ifnull +22 -> 95
    //   76: aload 4
    //   78: invokeinterface 156 1 0
    //   83: pop
    //   84: aload 4
    //   86: aload_0
    //   87: getfield 31	android/support/v4/c/k:h	Landroid/support/v4/c/r$a;
    //   90: invokeinterface 160 2 0
    //   95: aload_0
    //   96: monitorenter
    //   97: aload_0
    //   98: aconst_null
    //   99: putfield 122	android/support/v4/c/k:o	Landroid/support/v4/os/c;
    //   102: aload_0
    //   103: monitorexit
    //   104: aload 4
    //   106: areturn
    //   107: astore 6
    //   109: aload 4
    //   111: invokeinterface 54 1 0
    //   116: aload 6
    //   118: athrow
    //   119: astore_2
    //   120: aload_0
    //   121: monitorenter
    //   122: aload_0
    //   123: aconst_null
    //   124: putfield 122	android/support/v4/c/k:o	Landroid/support/v4/os/c;
    //   127: aload_0
    //   128: monitorexit
    //   129: aload_2
    //   130: athrow
    //   131: astore 5
    //   133: aload_0
    //   134: monitorexit
    //   135: aload 5
    //   137: athrow
    //   138: astore_3
    //   139: aload_0
    //   140: monitorexit
    //   141: aload_3
    //   142: athrow
    //
    // Exception table:
    //   from	to	target	type
    //   2	17	17	finally
    //   18	20	17	finally
    //   22	35	17	finally
    //   76	95	107	java/lang/RuntimeException
    //   35	71	119	finally
    //   76	95	119	finally
    //   109	119	119	finally
    //   97	104	131	finally
    //   133	135	131	finally
    //   122	129	138	finally
    //   139	141	138	finally
  }

  protected void j()
  {
    if (this.n != null)
      a(this.n);
    if ((E()) || (this.n == null))
      z();
  }

  protected void k()
  {
    y();
  }

  protected void l()
  {
    super.l();
    k();
    if ((this.n != null) && (!this.n.isClosed()))
      this.n.close();
    this.n = null;
  }

  public Uri m()
  {
    return this.i;
  }

  public String[] n()
  {
    return this.j;
  }

  public String o()
  {
    return this.k;
  }

  public String[] p()
  {
    return this.l;
  }

  public String q()
  {
    return this.m;
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.c.k
 * JD-Core Version:    0.6.2
 */