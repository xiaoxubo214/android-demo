package android.support.v4.c;

import android.content.SharedPreferences.Editor;
import android.support.annotation.x;

class l
{
  public static void a(@x SharedPreferences.Editor paramEditor)
  {
    try
    {
      paramEditor.apply();
      return;
    }
    catch (AbstractMethodError localAbstractMethodError)
    {
      paramEditor.commit();
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.c.l
 * JD-Core Version:    0.6.2
 */