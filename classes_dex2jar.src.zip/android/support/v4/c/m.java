package android.support.v4.c;

import android.os.AsyncTask;
import java.util.concurrent.Executor;

class m
{
  public static Executor a()
  {
    return AsyncTask.THREAD_POOL_EXECUTOR;
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.c.m
 * JD-Core Version:    0.6.2
 */