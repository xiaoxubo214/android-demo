package android.support.v4.c;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.pm.ProviderInfo;
import android.content.res.XmlResourceParser;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.net.Uri.Builder;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.text.TextUtils;
import android.webkit.MimeTypeMap;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;
import org.xmlpull.v1.XmlPullParserException;

public class n extends ContentProvider
{
  private static final String[] a = { "_display_name", "_size" };
  private static final String b = "android.support.FILE_PROVIDER_PATHS";
  private static final String c = "root-path";
  private static final String d = "files-path";
  private static final String e = "cache-path";
  private static final String f = "external-path";
  private static final String g = "name";
  private static final String h = "path";
  private static final File i = new File("/");
  private static HashMap<String, a> j = new HashMap();
  private a k;

  private static int a(String paramString)
  {
    if ("r".equals(paramString))
      return 268435456;
    if (("w".equals(paramString)) || ("wt".equals(paramString)))
      return 738197504;
    if ("wa".equals(paramString))
      return 704643072;
    if ("rw".equals(paramString))
      return 939524096;
    if ("rwt".equals(paramString))
      return 1006632960;
    throw new IllegalArgumentException("Invalid mode: " + paramString);
  }

  public static Uri a(Context paramContext, String paramString, File paramFile)
  {
    return a(paramContext, paramString).a(paramFile);
  }

  private static a a(Context paramContext, String paramString)
  {
    Object localObject2;
    synchronized (j)
    {
      localObject2 = (a)j.get(paramString);
      if (localObject2 != null);
    }
    try
    {
      a locala = b(paramContext, paramString);
      localObject2 = locala;
      j.put(paramString, localObject2);
      return localObject2;
    }
    catch (IOException localIOException)
    {
      throw new IllegalArgumentException("Failed to parse android.support.FILE_PROVIDER_PATHS meta-data", localIOException);
      localObject1 = finally;
      throw localObject1;
    }
    catch (XmlPullParserException localXmlPullParserException)
    {
      throw new IllegalArgumentException("Failed to parse android.support.FILE_PROVIDER_PATHS meta-data", localXmlPullParserException);
    }
  }

  private static File a(File paramFile, String[] paramArrayOfString)
  {
    int m = paramArrayOfString.length;
    int n = 0;
    Object localObject1 = paramFile;
    String str;
    if (n < m)
    {
      str = paramArrayOfString[n];
      if (str == null)
        break label49;
    }
    label49: for (Object localObject2 = new File((File)localObject1, str); ; localObject2 = localObject1)
    {
      n++;
      localObject1 = localObject2;
      break;
      return localObject1;
    }
  }

  private static Object[] a(Object[] paramArrayOfObject, int paramInt)
  {
    Object[] arrayOfObject = new Object[paramInt];
    System.arraycopy(paramArrayOfObject, 0, arrayOfObject, 0, paramInt);
    return arrayOfObject;
  }

  private static String[] a(String[] paramArrayOfString, int paramInt)
  {
    String[] arrayOfString = new String[paramInt];
    System.arraycopy(paramArrayOfString, 0, arrayOfString, 0, paramInt);
    return arrayOfString;
  }

  private static a b(Context paramContext, String paramString)
    throws IOException, XmlPullParserException
  {
    b localb = new b(paramString);
    XmlResourceParser localXmlResourceParser = paramContext.getPackageManager().resolveContentProvider(paramString, 128).loadXmlMetaData(paramContext.getPackageManager(), "android.support.FILE_PROVIDER_PATHS");
    if (localXmlResourceParser == null)
      throw new IllegalArgumentException("Missing android.support.FILE_PROVIDER_PATHS meta-data");
    label235: 
    while (true)
    {
      int m = localXmlResourceParser.next();
      String str1;
      String str2;
      String str3;
      File localFile;
      if (m != 1)
      {
        if (m == 2)
        {
          str1 = localXmlResourceParser.getName();
          str2 = localXmlResourceParser.getAttributeValue(null, "name");
          str3 = localXmlResourceParser.getAttributeValue(null, "path");
          if ("root-path".equals(str1))
            localFile = a(i, new String[] { str3 });
        }
      }
      else
        while (true)
        {
          if (localFile == null)
            break label235;
          localb.a(str2, localFile);
          break;
          if ("files-path".equals(str1))
          {
            localFile = a(paramContext.getFilesDir(), new String[] { str3 });
          }
          else if ("cache-path".equals(str1))
          {
            localFile = a(paramContext.getCacheDir(), new String[] { str3 });
          }
          else if ("external-path".equals(str1))
          {
            localFile = a(Environment.getExternalStorageDirectory(), new String[] { str3 });
            continue;
            return localb;
          }
          else
          {
            localFile = null;
          }
        }
    }
  }

  public void attachInfo(Context paramContext, ProviderInfo paramProviderInfo)
  {
    super.attachInfo(paramContext, paramProviderInfo);
    if (paramProviderInfo.exported)
      throw new SecurityException("Provider must not be exported");
    if (!paramProviderInfo.grantUriPermissions)
      throw new SecurityException("Provider must grant uri permissions");
    this.k = a(paramContext, paramProviderInfo.authority);
  }

  public int delete(Uri paramUri, String paramString, String[] paramArrayOfString)
  {
    if (this.k.a(paramUri).delete())
      return 1;
    return 0;
  }

  public String getType(Uri paramUri)
  {
    File localFile = this.k.a(paramUri);
    int m = localFile.getName().lastIndexOf('.');
    if (m >= 0)
    {
      String str1 = localFile.getName().substring(m + 1);
      String str2 = MimeTypeMap.getSingleton().getMimeTypeFromExtension(str1);
      if (str2 != null)
        return str2;
    }
    return "application/octet-stream";
  }

  public Uri insert(Uri paramUri, ContentValues paramContentValues)
  {
    throw new UnsupportedOperationException("No external inserts");
  }

  public boolean onCreate()
  {
    return true;
  }

  public ParcelFileDescriptor openFile(Uri paramUri, String paramString)
    throws FileNotFoundException
  {
    return ParcelFileDescriptor.open(this.k.a(paramUri), a(paramString));
  }

  public Cursor query(Uri paramUri, String[] paramArrayOfString1, String paramString1, String[] paramArrayOfString2, String paramString2)
  {
    File localFile = this.k.a(paramUri);
    if (paramArrayOfString1 == null)
      paramArrayOfString1 = a;
    String[] arrayOfString1 = new String[paramArrayOfString1.length];
    Object[] arrayOfObject1 = new Object[paramArrayOfString1.length];
    int m = paramArrayOfString1.length;
    int n = 0;
    int i1 = 0;
    String str;
    int i2;
    if (n < m)
    {
      str = paramArrayOfString1[n];
      if ("_display_name".equals(str))
      {
        arrayOfString1[i1] = "_display_name";
        i2 = i1 + 1;
        arrayOfObject1[i1] = localFile.getName();
      }
    }
    while (true)
    {
      n++;
      i1 = i2;
      break;
      if ("_size".equals(str))
      {
        arrayOfString1[i1] = "_size";
        i2 = i1 + 1;
        arrayOfObject1[i1] = Long.valueOf(localFile.length());
        continue;
        String[] arrayOfString2 = a(arrayOfString1, i1);
        Object[] arrayOfObject2 = a(arrayOfObject1, i1);
        MatrixCursor localMatrixCursor = new MatrixCursor(arrayOfString2, 1);
        localMatrixCursor.addRow(arrayOfObject2);
        return localMatrixCursor;
      }
      else
      {
        i2 = i1;
      }
    }
  }

  public int update(Uri paramUri, ContentValues paramContentValues, String paramString, String[] paramArrayOfString)
  {
    throw new UnsupportedOperationException("No external updates");
  }

  static abstract interface a
  {
    public abstract Uri a(File paramFile);

    public abstract File a(Uri paramUri);
  }

  static class b
    implements n.a
  {
    private final String a;
    private final HashMap<String, File> b = new HashMap();

    public b(String paramString)
    {
      this.a = paramString;
    }

    public Uri a(File paramFile)
    {
      while (true)
      {
        String str1;
        Object localObject1;
        try
        {
          str1 = paramFile.getCanonicalPath();
          localObject1 = null;
          Iterator localIterator = this.b.entrySet().iterator();
          if (localIterator.hasNext())
          {
            localObject2 = (Map.Entry)localIterator.next();
            String str5 = ((File)((Map.Entry)localObject2).getValue()).getPath();
            if ((!str1.startsWith(str5)) || ((localObject1 != null) && (str5.length() <= ((File)localObject1.getValue()).getPath().length())))
              break label287;
            localObject1 = localObject2;
            continue;
          }
        }
        catch (IOException localIOException)
        {
          throw new IllegalArgumentException("Failed to resolve canonical path for " + paramFile);
        }
        if (localObject1 == null)
          throw new IllegalArgumentException("Failed to find configured root that contains " + str1);
        String str2 = ((File)localObject1.getValue()).getPath();
        if (str2.endsWith("/"));
        for (String str3 = str1.substring(str2.length()); ; str3 = str1.substring(1 + str2.length()))
        {
          String str4 = Uri.encode((String)localObject1.getKey()) + '/' + Uri.encode(str3, "/");
          return new Uri.Builder().scheme("content").authority(this.a).encodedPath(str4).build();
        }
        label287: Object localObject2 = localObject1;
      }
    }

    public File a(Uri paramUri)
    {
      String str1 = paramUri.getEncodedPath();
      int i = str1.indexOf('/', 1);
      String str2 = Uri.decode(str1.substring(1, i));
      String str3 = Uri.decode(str1.substring(i + 1));
      File localFile1 = (File)this.b.get(str2);
      if (localFile1 == null)
        throw new IllegalArgumentException("Unable to find configured root for " + paramUri);
      File localFile2 = new File(localFile1, str3);
      File localFile3;
      try
      {
        localFile3 = localFile2.getCanonicalFile();
        if (!localFile3.getPath().startsWith(localFile1.getPath()))
          throw new SecurityException("Resolved path jumped beyond configured root");
      }
      catch (IOException localIOException)
      {
        throw new IllegalArgumentException("Failed to resolve canonical path for " + localFile2);
      }
      return localFile3;
    }

    public void a(String paramString, File paramFile)
    {
      if (TextUtils.isEmpty(paramString))
        throw new IllegalArgumentException("Name must not be empty");
      try
      {
        File localFile = paramFile.getCanonicalFile();
        this.b.put(paramString, localFile);
        return;
      }
      catch (IOException localIOException)
      {
        throw new IllegalArgumentException("Failed to resolve canonical path for " + paramFile, localIOException);
      }
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.c.n
 * JD-Core Version:    0.6.2
 */