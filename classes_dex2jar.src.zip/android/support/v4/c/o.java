package android.support.v4.c;

import android.content.ComponentName;
import android.content.Intent;
import android.os.Build.VERSION;

public final class o
{
  public static final String a = "android.intent.action.EXTERNAL_APPLICATIONS_AVAILABLE";
  public static final String b = "android.intent.action.EXTERNAL_APPLICATIONS_UNAVAILABLE";
  public static final String c = "android.intent.extra.changed_package_list";
  public static final String d = "android.intent.extra.changed_uid_list";
  public static final String e = "android.intent.extra.HTML_TEXT";
  public static final int f = 16384;
  public static final int g = 32768;
  private static final a h = new b();

  static
  {
    int i = Build.VERSION.SDK_INT;
    if (i >= 15)
    {
      h = new d();
      return;
    }
    if (i >= 11)
    {
      h = new c();
      return;
    }
  }

  public static Intent a(ComponentName paramComponentName)
  {
    return h.a(paramComponentName);
  }

  public static Intent a(String paramString1, String paramString2)
  {
    return h.a(paramString1, paramString2);
  }

  public static Intent b(ComponentName paramComponentName)
  {
    return h.b(paramComponentName);
  }

  static abstract interface a
  {
    public abstract Intent a(ComponentName paramComponentName);

    public abstract Intent a(String paramString1, String paramString2);

    public abstract Intent b(ComponentName paramComponentName);
  }

  static class b
    implements o.a
  {
    public Intent a(ComponentName paramComponentName)
    {
      Intent localIntent = new Intent("android.intent.action.MAIN");
      localIntent.setComponent(paramComponentName);
      localIntent.addCategory("android.intent.category.LAUNCHER");
      return localIntent;
    }

    public Intent a(String paramString1, String paramString2)
    {
      Intent localIntent = new Intent(paramString1);
      localIntent.addCategory(paramString2);
      return localIntent;
    }

    public Intent b(ComponentName paramComponentName)
    {
      Intent localIntent = a(paramComponentName);
      localIntent.addFlags(268468224);
      return localIntent;
    }
  }

  static class c extends o.b
  {
    public Intent a(ComponentName paramComponentName)
    {
      return p.a(paramComponentName);
    }

    public Intent b(ComponentName paramComponentName)
    {
      return p.b(paramComponentName);
    }
  }

  static class d extends o.c
  {
    public Intent a(String paramString1, String paramString2)
    {
      return q.a(paramString1, paramString2);
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.c.o
 * JD-Core Version:    0.6.2
 */