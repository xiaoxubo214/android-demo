package android.support.v4.c;

import android.content.Intent;

class q
{
  public static Intent a(String paramString1, String paramString2)
  {
    return Intent.makeMainSelectorActivity(paramString1, paramString2);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.c.q
 * JD-Core Version:    0.6.2
 */