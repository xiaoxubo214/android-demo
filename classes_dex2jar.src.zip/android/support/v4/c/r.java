package android.support.v4.c;

import android.content.Context;
import android.database.ContentObserver;
import android.os.Handler;
import android.support.v4.m.g;
import java.io.FileDescriptor;
import java.io.PrintWriter;

public class r<D>
{
  int p;
  c<D> q;
  b<D> r;
  Context s;
  boolean t = false;
  boolean u = false;
  boolean v = true;
  boolean w = false;
  boolean x = false;

  public r(Context paramContext)
  {
    this.s = paramContext.getApplicationContext();
  }

  public void A()
  {
    this.t = false;
    k();
  }

  public void B()
  {
    this.u = true;
    C();
  }

  protected void C()
  {
  }

  public void D()
  {
    l();
    this.v = true;
    this.t = false;
    this.u = false;
    this.w = false;
    this.x = false;
  }

  public boolean E()
  {
    boolean bool = this.w;
    this.w = false;
    this.x = (bool | this.x);
    return bool;
  }

  public void F()
  {
    this.x = false;
  }

  public void G()
  {
    if (this.x)
      this.w = true;
  }

  public void H()
  {
    if (this.t)
    {
      z();
      return;
    }
    this.w = true;
  }

  protected void a()
  {
  }

  public void a(int paramInt, c<D> paramc)
  {
    if (this.q != null)
      throw new IllegalStateException("There is already a listener registered");
    this.q = paramc;
    this.p = paramInt;
  }

  public void a(b<D> paramb)
  {
    if (this.r != null)
      throw new IllegalStateException("There is already a listener registered");
    this.r = paramb;
  }

  public void a(c<D> paramc)
  {
    if (this.q == null)
      throw new IllegalStateException("No listener register");
    if (this.q != paramc)
      throw new IllegalArgumentException("Attempting to unregister the wrong listener");
    this.q = null;
  }

  public void a(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString)
  {
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mId=");
    paramPrintWriter.print(this.p);
    paramPrintWriter.print(" mListener=");
    paramPrintWriter.println(this.q);
    if ((this.t) || (this.w) || (this.x))
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mStarted=");
      paramPrintWriter.print(this.t);
      paramPrintWriter.print(" mContentChanged=");
      paramPrintWriter.print(this.w);
      paramPrintWriter.print(" mProcessingChange=");
      paramPrintWriter.println(this.x);
    }
    if ((this.u) || (this.v))
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mAbandoned=");
      paramPrintWriter.print(this.u);
      paramPrintWriter.print(" mReset=");
      paramPrintWriter.println(this.v);
    }
  }

  public void b(b<D> paramb)
  {
    if (this.r == null)
      throw new IllegalStateException("No listener register");
    if (this.r != paramb)
      throw new IllegalArgumentException("Attempting to unregister the wrong listener");
    this.r = null;
  }

  public void b(D paramD)
  {
    if (this.q != null)
      this.q.a(this, paramD);
  }

  protected boolean b()
  {
    return false;
  }

  public String c(D paramD)
  {
    StringBuilder localStringBuilder = new StringBuilder(64);
    g.a(paramD, localStringBuilder);
    localStringBuilder.append("}");
    return localStringBuilder.toString();
  }

  protected void j()
  {
  }

  protected void k()
  {
  }

  protected void l()
  {
  }

  public void r()
  {
    if (this.r != null)
      this.r.a(this);
  }

  public Context s()
  {
    return this.s;
  }

  public int t()
  {
    return this.p;
  }

  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder(64);
    g.a(this, localStringBuilder);
    localStringBuilder.append(" id=");
    localStringBuilder.append(this.p);
    localStringBuilder.append("}");
    return localStringBuilder.toString();
  }

  public boolean u()
  {
    return this.t;
  }

  public boolean v()
  {
    return this.u;
  }

  public boolean w()
  {
    return this.v;
  }

  public final void x()
  {
    this.t = true;
    this.v = false;
    this.u = false;
    j();
  }

  public boolean y()
  {
    return b();
  }

  public void z()
  {
    a();
  }

  public final class a extends ContentObserver
  {
    public a()
    {
      super();
    }

    public boolean deliverSelfNotifications()
    {
      return true;
    }

    public void onChange(boolean paramBoolean)
    {
      r.this.H();
    }
  }

  public static abstract interface b<D>
  {
    public abstract void a(r<D> paramr);
  }

  public static abstract interface c<D>
  {
    public abstract void a(r<D> paramr, D paramD);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.c.r
 * JD-Core Version:    0.6.2
 */