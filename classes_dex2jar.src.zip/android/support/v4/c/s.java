package android.support.v4.c;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Handler;
import android.util.Log;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;

public final class s
{
  static final int a = 1;
  private static final String b = "LocalBroadcastManager";
  private static final boolean c;
  private static final Object i = new Object();
  private static s j;
  private final Context d;
  private final HashMap<BroadcastReceiver, ArrayList<IntentFilter>> e = new HashMap();
  private final HashMap<String, ArrayList<b>> f = new HashMap();
  private final ArrayList<a> g = new ArrayList();
  private final Handler h;

  private s(Context paramContext)
  {
    this.d = paramContext;
    this.h = new t(this, paramContext.getMainLooper());
  }

  public static s a(Context paramContext)
  {
    synchronized (i)
    {
      if (j == null)
        j = new s(paramContext.getApplicationContext());
      s locals = j;
      return locals;
    }
  }

  private void a()
  {
    while (true)
    {
      int m;
      synchronized (this.e)
      {
        int k = this.g.size();
        if (k <= 0)
          return;
        a[] arrayOfa = new a[k];
        this.g.toArray(arrayOfa);
        this.g.clear();
        m = 0;
        if (m >= arrayOfa.length)
          continue;
        a locala = arrayOfa[m];
        int n = 0;
        if (n < locala.b.size())
        {
          ((b)locala.b.get(n)).b.onReceive(this.d, locala.a);
          n++;
        }
      }
      m++;
    }
  }

  public void a(BroadcastReceiver paramBroadcastReceiver)
  {
    while (true)
    {
      int m;
      synchronized (this.e)
      {
        ArrayList localArrayList1 = (ArrayList)this.e.remove(paramBroadcastReceiver);
        if (localArrayList1 != null)
          break label174;
        return;
        if (k < localArrayList1.size())
        {
          IntentFilter localIntentFilter = (IntentFilter)localArrayList1.get(k);
          m = 0;
          if (m >= localIntentFilter.countActions())
            break label195;
          String str = localIntentFilter.getAction(m);
          ArrayList localArrayList2 = (ArrayList)this.f.get(str);
          if (localArrayList2 == null)
            break label189;
          n = 0;
          if (n < localArrayList2.size())
          {
            if (((b)localArrayList2.get(n)).b == paramBroadcastReceiver)
            {
              localArrayList2.remove(n);
              i1 = n - 1;
              break label180;
            }
          }
          else
          {
            if (localArrayList2.size() > 0)
              break label189;
            this.f.remove(str);
            break label189;
          }
        }
        else
        {
          return;
        }
      }
      int i1 = n;
      break label180;
      label174: int k = 0;
      continue;
      label180: int n = i1 + 1;
      continue;
      label189: m++;
      continue;
      label195: k++;
    }
  }

  public void a(BroadcastReceiver paramBroadcastReceiver, IntentFilter paramIntentFilter)
  {
    synchronized (this.e)
    {
      b localb = new b(paramIntentFilter, paramBroadcastReceiver);
      ArrayList localArrayList1 = (ArrayList)this.e.get(paramBroadcastReceiver);
      if (localArrayList1 == null)
      {
        localArrayList1 = new ArrayList(1);
        this.e.put(paramBroadcastReceiver, localArrayList1);
      }
      localArrayList1.add(paramIntentFilter);
      for (int k = 0; k < paramIntentFilter.countActions(); k++)
      {
        String str = paramIntentFilter.getAction(k);
        ArrayList localArrayList2 = (ArrayList)this.f.get(str);
        if (localArrayList2 == null)
        {
          localArrayList2 = new ArrayList(1);
          this.f.put(str, localArrayList2);
        }
        localArrayList2.add(localb);
      }
      return;
    }
  }

  public boolean a(Intent paramIntent)
  {
    int k;
    label162: int m;
    Object localObject2;
    Object localObject3;
    int i1;
    synchronized (this.e)
    {
      String str1 = paramIntent.getAction();
      String str2 = paramIntent.resolveTypeIfNeeded(this.d.getContentResolver());
      Uri localUri = paramIntent.getData();
      String str3 = paramIntent.getScheme();
      Set localSet = paramIntent.getCategories();
      if ((0x8 & paramIntent.getFlags()) == 0)
        break label515;
      k = 1;
      if (k != 0)
        Log.v("LocalBroadcastManager", "Resolving type " + str2 + " scheme " + str3 + " of intent " + paramIntent);
      ArrayList localArrayList = (ArrayList)this.f.get(paramIntent.getAction());
      if (localArrayList == null)
        break label485;
      if (k == 0)
        break label496;
      Log.v("LocalBroadcastManager", "Action list: " + localArrayList);
      break label496;
      if (m >= localArrayList.size())
        break label556;
      b localb = (b)localArrayList.get(m);
      if (k != 0)
        Log.v("LocalBroadcastManager", "Matching against filter " + localb.a);
      if (localb.c)
      {
        if (k == 0)
          break label521;
        Log.v("LocalBroadcastManager", "  Filter's target already added");
        localObject3 = localObject2;
      }
      else
      {
        i1 = localb.a.match(str1, str2, str3, localUri, localSet, "LocalBroadcastManager");
        if (i1 >= 0)
        {
          if (k != 0)
            Log.v("LocalBroadcastManager", "  Filter matched!  match=0x" + Integer.toHexString(i1));
          if (localObject2 != null)
            break label489;
          localObject3 = new ArrayList();
          label321: ((ArrayList)localObject3).add(localb);
          localb.c = true;
        }
      }
    }
    String str4;
    if (k != 0)
      switch (i1)
      {
      default:
        str4 = "unknown reason";
        label384: Log.v("LocalBroadcastManager", "  Filter did not match: " + str4);
        break;
      case -3:
      case -4:
      case -2:
      case -1:
      }
    while (true)
    {
      int n;
      if (n < ((ArrayList)localObject2).size())
      {
        ((b)((ArrayList)localObject2).get(n)).c = false;
        n++;
      }
      else
      {
        this.g.add(new a(paramIntent, (ArrayList)localObject2));
        if (!this.h.hasMessages(1))
          this.h.sendEmptyMessage(1);
        return true;
        label485: label489: label496: 
        do
        {
          return false;
          localObject3 = localObject2;
          break label321;
          localObject2 = null;
          m = 0;
          break label162;
          while (true)
          {
            m++;
            localObject2 = localObject3;
            break label162;
            k = 0;
            break;
            localObject3 = localObject2;
          }
          str4 = "action";
          break label384;
          str4 = "category";
          break label384;
          str4 = "data";
          break label384;
          str4 = "type";
          break label384;
        }
        while (localObject2 == null);
        label515: label521: label556: n = 0;
      }
    }
  }

  public void b(Intent paramIntent)
  {
    if (a(paramIntent))
      a();
  }

  private static class a
  {
    final Intent a;
    final ArrayList<s.b> b;

    a(Intent paramIntent, ArrayList<s.b> paramArrayList)
    {
      this.a = paramIntent;
      this.b = paramArrayList;
    }
  }

  private static class b
  {
    final IntentFilter a;
    final BroadcastReceiver b;
    boolean c;

    b(IntentFilter paramIntentFilter, BroadcastReceiver paramBroadcastReceiver)
    {
      this.a = paramIntentFilter;
      this.b = paramBroadcastReceiver;
    }

    public String toString()
    {
      StringBuilder localStringBuilder = new StringBuilder(128);
      localStringBuilder.append("Receiver{");
      localStringBuilder.append(this.b);
      localStringBuilder.append(" filter=");
      localStringBuilder.append(this.a);
      localStringBuilder.append("}");
      return localStringBuilder.toString();
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.c.s
 * JD-Core Version:    0.6.2
 */