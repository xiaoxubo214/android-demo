package android.support.v4.c;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;

class t extends Handler
{
  t(s params, Looper paramLooper)
  {
    super(paramLooper);
  }

  public void handleMessage(Message paramMessage)
  {
    switch (paramMessage.what)
    {
    default:
      super.handleMessage(paramMessage);
      return;
    case 1:
    }
    s.a(this.a);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.c.t
 * JD-Core Version:    0.6.2
 */