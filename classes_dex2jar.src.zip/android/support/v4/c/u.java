package android.support.v4.c;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.FutureTask;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicBoolean;

abstract class u<Params, Progress, Result>
{
  private static final String a = "AsyncTask";
  private static final int b = 5;
  public static final Executor c = new ThreadPoolExecutor(5, 128, 1L, TimeUnit.SECONDS, g, f);
  private static final int d = 128;
  private static final int e = 1;
  private static final ThreadFactory f = new v();
  private static final BlockingQueue<Runnable> g = new LinkedBlockingQueue(10);
  private static final int h = 1;
  private static final int i = 2;
  private static b j;
  private static volatile Executor k = c;
  private final d<Params, Result> l = new w(this);
  private final FutureTask<Result> m = new x(this, this.l);
  private volatile c n = c.a;
  private final AtomicBoolean o = new AtomicBoolean();

  private static Handler a()
  {
    try
    {
      if (j == null)
        j = new b();
      b localb = j;
      return localb;
    }
    finally
    {
    }
  }

  public static void a(Runnable paramRunnable)
  {
    k.execute(paramRunnable);
  }

  public static void a(Executor paramExecutor)
  {
    k = paramExecutor;
  }

  private void c(Result paramResult)
  {
    if (!this.o.get())
      d(paramResult);
  }

  private Result d(Result paramResult)
  {
    a().obtainMessage(1, new a(this, new Object[] { paramResult })).sendToTarget();
    return paramResult;
  }

  private void e(Result paramResult)
  {
    if (e())
      b(paramResult);
    while (true)
    {
      this.n = c.c;
      return;
      a(paramResult);
    }
  }

  public final u<Params, Progress, Result> a(Executor paramExecutor, Params[] paramArrayOfParams)
  {
    if (this.n != c.a);
    switch (1.a[this.n.ordinal()])
    {
    default:
      this.n = c.b;
      c();
      this.l.b = paramArrayOfParams;
      paramExecutor.execute(this.m);
      return this;
    case 1:
      throw new IllegalStateException("Cannot execute task: the task is already running.");
    case 2:
    }
    throw new IllegalStateException("Cannot execute task: the task has already been executed (a task can be executed only once)");
  }

  public final Result a(long paramLong, TimeUnit paramTimeUnit)
    throws InterruptedException, ExecutionException, TimeoutException
  {
    return this.m.get(paramLong, paramTimeUnit);
  }

  protected abstract Result a(Params[] paramArrayOfParams);

  protected void a(Result paramResult)
  {
  }

  public final boolean a(boolean paramBoolean)
  {
    return this.m.cancel(paramBoolean);
  }

  public final c b()
  {
    return this.n;
  }

  protected void b(Result paramResult)
  {
    d();
  }

  protected void b(Progress[] paramArrayOfProgress)
  {
  }

  public final u<Params, Progress, Result> c(Params[] paramArrayOfParams)
  {
    return a(k, paramArrayOfParams);
  }

  protected void c()
  {
  }

  protected void d()
  {
  }

  protected final void d(Progress[] paramArrayOfProgress)
  {
    if (!e())
      a().obtainMessage(2, new a(this, paramArrayOfProgress)).sendToTarget();
  }

  public final boolean e()
  {
    return this.m.isCancelled();
  }

  public final Result f()
    throws InterruptedException, ExecutionException
  {
    return this.m.get();
  }

  private static class a<Data>
  {
    final u a;
    final Data[] b;

    a(u paramu, Data[] paramArrayOfData)
    {
      this.a = paramu;
      this.b = paramArrayOfData;
    }
  }

  private static class b extends Handler
  {
    public b()
    {
      super();
    }

    public void handleMessage(Message paramMessage)
    {
      u.a locala = (u.a)paramMessage.obj;
      switch (paramMessage.what)
      {
      default:
        return;
      case 1:
        u.c(locala.a, locala.b[0]);
        return;
      case 2:
      }
      locala.a.b(locala.b);
    }
  }

  public static enum c
  {
    static
    {
      c[] arrayOfc = new c[3];
      arrayOfc[0] = a;
      arrayOfc[1] = b;
      arrayOfc[2] = c;
    }
  }

  private static abstract class d<Params, Result>
    implements Callable<Result>
  {
    Params[] b;
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.c.u
 * JD-Core Version:    0.6.2
 */