package android.support.v4.c;

import android.os.Process;
import java.util.concurrent.atomic.AtomicBoolean;

class w extends u.d<Params, Result>
{
  w(u paramu)
  {
    super(null);
  }

  public Result call()
    throws Exception
  {
    u.a(this.a).set(true);
    Process.setThreadPriority(10);
    return u.a(this.a, this.a.a(this.b));
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.c.w
 * JD-Core Version:    0.6.2
 */