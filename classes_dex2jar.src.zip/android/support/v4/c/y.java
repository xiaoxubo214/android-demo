package android.support.v4.c;

import android.os.Build.VERSION;
import java.util.concurrent.Executor;

public final class y
{
  public static Executor a()
  {
    if (Build.VERSION.SDK_INT >= 11)
      return m.a();
    return u.c;
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.c.y
 * JD-Core Version:    0.6.2
 */