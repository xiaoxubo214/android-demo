package android.support.v4.c;

import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Binder;
import android.os.Process;
import android.support.annotation.x;
import android.support.v4.app.p;
import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

public final class z
{
  public static final int a = 0;
  public static final int b = -1;
  public static final int c = -2;

  public static int a(@x Context paramContext, @x String paramString)
  {
    return a(paramContext, paramString, Process.myPid(), Process.myUid(), paramContext.getPackageName());
  }

  public static int a(@x Context paramContext, @x String paramString1, int paramInt1, int paramInt2, String paramString2)
  {
    if (paramContext.checkPermission(paramString1, paramInt1, paramInt2) == -1);
    String str;
    String[] arrayOfString;
    do
    {
      return -1;
      str = p.a(paramString1);
      if (str == null)
        return 0;
      if (paramString2 != null)
        break;
      arrayOfString = paramContext.getPackageManager().getPackagesForUid(paramInt2);
    }
    while ((arrayOfString == null) || (arrayOfString.length <= 0));
    paramString2 = arrayOfString[0];
    if (p.a(paramContext, str, paramString2) != 0)
      return -2;
    return 0;
  }

  public static int a(@x Context paramContext, @x String paramString1, String paramString2)
  {
    if (Binder.getCallingPid() == Process.myPid())
      return -1;
    return a(paramContext, paramString1, Binder.getCallingPid(), Binder.getCallingUid(), paramString2);
  }

  public static int b(@x Context paramContext, @x String paramString)
  {
    if (Binder.getCallingPid() == Process.myPid());
    for (String str = paramContext.getPackageName(); ; str = null)
      return a(paramContext, paramString, Binder.getCallingPid(), Binder.getCallingUid(), str);
  }

  @Retention(RetentionPolicy.SOURCE)
  public static @interface a
  {
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.c.z
 * JD-Core Version:    0.6.2
 */