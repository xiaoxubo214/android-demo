package android.support.v4.e;

import android.graphics.Bitmap;
import android.os.Build.VERSION;

public final class a
{
  static final b a = new a();

  static
  {
    int i = Build.VERSION.SDK_INT;
    if (i >= 19)
    {
      a = new e();
      return;
    }
    if (i >= 18)
    {
      a = new d();
      return;
    }
    if (i >= 12)
    {
      a = new c();
      return;
    }
  }

  public static void a(Bitmap paramBitmap, boolean paramBoolean)
  {
    a.a(paramBitmap, paramBoolean);
  }

  public static boolean a(Bitmap paramBitmap)
  {
    return a.a(paramBitmap);
  }

  public static int b(Bitmap paramBitmap)
  {
    return a.b(paramBitmap);
  }

  static class a
    implements a.b
  {
    public void a(Bitmap paramBitmap, boolean paramBoolean)
    {
    }

    public boolean a(Bitmap paramBitmap)
    {
      return false;
    }

    public int b(Bitmap paramBitmap)
    {
      return paramBitmap.getRowBytes() * paramBitmap.getHeight();
    }
  }

  static abstract interface b
  {
    public abstract void a(Bitmap paramBitmap, boolean paramBoolean);

    public abstract boolean a(Bitmap paramBitmap);

    public abstract int b(Bitmap paramBitmap);
  }

  static class c extends a.a
  {
    public int b(Bitmap paramBitmap)
    {
      return b.a(paramBitmap);
    }
  }

  static class d extends a.c
  {
    public void a(Bitmap paramBitmap, boolean paramBoolean)
    {
      c.a(paramBitmap, paramBoolean);
    }

    public boolean a(Bitmap paramBitmap)
    {
      return c.a(paramBitmap);
    }
  }

  static class e extends a.d
  {
    public int b(Bitmap paramBitmap)
    {
      return d.a(paramBitmap);
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.e.a
 * JD-Core Version:    0.6.2
 */