package android.support.v4.e.a;

import android.graphics.drawable.Drawable;

class b
{
  public static int a(Drawable paramDrawable)
  {
    return paramDrawable.getLayoutDirection();
  }

  public static void a(Drawable paramDrawable, int paramInt)
  {
    paramDrawable.setLayoutDirection(paramInt);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.e.a.b
 * JD-Core Version:    0.6.2
 */