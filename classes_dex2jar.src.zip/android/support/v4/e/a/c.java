package android.support.v4.e.a;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.Resources.Theme;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import java.io.IOException;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

class c
{
  public static Drawable a(Drawable paramDrawable)
  {
    if (!(paramDrawable instanceof j))
      paramDrawable = new j(paramDrawable);
    return paramDrawable;
  }

  public static void a(Drawable paramDrawable, int paramInt)
  {
    if ((paramDrawable instanceof i))
      ((i)paramDrawable).a(paramInt);
  }

  public static void a(Drawable paramDrawable, ColorStateList paramColorStateList)
  {
    if ((paramDrawable instanceof i))
      ((i)paramDrawable).a(paramColorStateList);
  }

  public static void a(Drawable paramDrawable, Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme)
    throws IOException, XmlPullParserException
  {
    paramDrawable.inflate(paramResources, paramXmlPullParser, paramAttributeSet);
  }

  public static void a(Drawable paramDrawable, PorterDuff.Mode paramMode)
  {
    if ((paramDrawable instanceof i))
      ((i)paramDrawable).a(paramMode);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.e.a.c
 * JD-Core Version:    0.6.2
 */