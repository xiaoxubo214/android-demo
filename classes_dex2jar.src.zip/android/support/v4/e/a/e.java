package android.support.v4.e.a;

import android.graphics.drawable.Drawable;

class e
{
  public static void a(Drawable paramDrawable)
  {
    paramDrawable.jumpToCurrentState();
  }

  public static Drawable b(Drawable paramDrawable)
  {
    if (!(paramDrawable instanceof l))
      paramDrawable = new l(paramDrawable);
    return paramDrawable;
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.e.a.e
 * JD-Core Version:    0.6.2
 */