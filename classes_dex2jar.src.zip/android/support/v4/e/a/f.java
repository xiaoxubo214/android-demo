package android.support.v4.e.a;

import android.graphics.drawable.Drawable;
import android.util.Log;
import java.lang.reflect.Method;

class f
{
  private static final String a = "DrawableCompatJellybeanMr1";
  private static Method b;
  private static boolean c;
  private static Method d;
  private static boolean e;

  public static int a(Drawable paramDrawable)
  {
    if (!e);
    try
    {
      d = Drawable.class.getDeclaredMethod("getLayoutDirection", new Class[0]);
      d.setAccessible(true);
      e = true;
      if (d == null);
    }
    catch (NoSuchMethodException localNoSuchMethodException)
    {
      try
      {
        int i = ((Integer)d.invoke(paramDrawable, new Object[0])).intValue();
        return i;
        localNoSuchMethodException = localNoSuchMethodException;
        Log.i("DrawableCompatJellybeanMr1", "Failed to retrieve getLayoutDirection() method", localNoSuchMethodException);
      }
      catch (Exception localException)
      {
        Log.i("DrawableCompatJellybeanMr1", "Failed to invoke getLayoutDirection() via reflection", localException);
        d = null;
      }
    }
    return -1;
  }

  public static void a(Drawable paramDrawable, int paramInt)
  {
    if (!c);
    try
    {
      Class[] arrayOfClass = new Class[1];
      arrayOfClass[0] = Integer.TYPE;
      b = Drawable.class.getDeclaredMethod("setLayoutDirection", arrayOfClass);
      b.setAccessible(true);
      c = true;
      if (b == null);
    }
    catch (NoSuchMethodException localNoSuchMethodException)
    {
      try
      {
        Method localMethod = b;
        Object[] arrayOfObject = new Object[1];
        arrayOfObject[0] = Integer.valueOf(paramInt);
        localMethod.invoke(paramDrawable, arrayOfObject);
        return;
        localNoSuchMethodException = localNoSuchMethodException;
        Log.i("DrawableCompatJellybeanMr1", "Failed to retrieve setLayoutDirection(int) method", localNoSuchMethodException);
      }
      catch (Exception localException)
      {
        Log.i("DrawableCompatJellybeanMr1", "Failed to invoke setLayoutDirection(int) via reflection", localException);
        b = null;
      }
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.e.a.f
 * JD-Core Version:    0.6.2
 */