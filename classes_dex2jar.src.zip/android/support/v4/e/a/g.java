package android.support.v4.e.a;

import android.graphics.drawable.Drawable;

class g
{
  public static void a(Drawable paramDrawable, boolean paramBoolean)
  {
    paramDrawable.setAutoMirrored(paramBoolean);
  }

  public static boolean a(Drawable paramDrawable)
  {
    return paramDrawable.isAutoMirrored();
  }

  public static Drawable b(Drawable paramDrawable)
  {
    if (!(paramDrawable instanceof m))
      paramDrawable = new m(paramDrawable);
    return paramDrawable;
  }

  public static int c(Drawable paramDrawable)
  {
    return paramDrawable.getAlpha();
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.e.a.g
 * JD-Core Version:    0.6.2
 */