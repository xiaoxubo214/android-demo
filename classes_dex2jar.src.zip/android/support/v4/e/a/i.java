package android.support.v4.e.a;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.Drawable;

public abstract interface i
{
  public abstract Drawable a();

  public abstract void a(int paramInt);

  public abstract void a(ColorStateList paramColorStateList);

  public abstract void a(PorterDuff.Mode paramMode);

  public abstract void a(Drawable paramDrawable);
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.e.a.i
 * JD-Core Version:    0.6.2
 */