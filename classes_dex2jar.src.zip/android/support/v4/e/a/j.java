package android.support.v4.e.a;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff.Mode;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Drawable.Callback;
import android.graphics.drawable.Drawable.ConstantState;
import android.support.annotation.x;
import android.support.annotation.y;

class j extends Drawable
  implements Drawable.Callback, i
{
  static final PorterDuff.Mode a = PorterDuff.Mode.SRC_IN;
  a b;
  Drawable c;
  private int d;
  private PorterDuff.Mode e;
  private boolean f;
  private boolean g;

  j(@y Drawable paramDrawable)
  {
    this.b = b();
    this.c = paramDrawable;
  }

  j(@x a parama, @y Resources paramResources)
  {
    this.b = parama;
    a(paramResources);
  }

  private void a(@y Resources paramResources)
  {
    if ((this.b != null) && (this.b.b != null))
      a(a(this.b.b, paramResources));
  }

  private boolean a(int[] paramArrayOfInt)
  {
    if (!c());
    PorterDuff.Mode localMode;
    int i;
    do
    {
      return false;
      ColorStateList localColorStateList = this.b.c;
      localMode = this.b.d;
      if ((localColorStateList == null) || (localMode == null))
        break;
      i = localColorStateList.getColorForState(paramArrayOfInt, localColorStateList.getDefaultColor());
    }
    while ((this.f) && (i == this.d) && (localMode == this.e));
    setColorFilter(i, localMode);
    this.d = i;
    this.e = localMode;
    this.f = true;
    return true;
    this.f = false;
    clearColorFilter();
    return false;
  }

  public Drawable a()
  {
    return this.c;
  }

  protected Drawable a(@x Drawable.ConstantState paramConstantState, @y Resources paramResources)
  {
    return paramConstantState.newDrawable();
  }

  public void a(int paramInt)
  {
    a(ColorStateList.valueOf(paramInt));
  }

  public void a(ColorStateList paramColorStateList)
  {
    this.b.c = paramColorStateList;
    a(getState());
  }

  public void a(PorterDuff.Mode paramMode)
  {
    this.b.d = paramMode;
    a(getState());
  }

  public void a(Drawable paramDrawable)
  {
    if (this.c != null)
      this.c.setCallback(null);
    this.c = paramDrawable;
    if (paramDrawable != null)
    {
      paramDrawable.setCallback(this);
      paramDrawable.setVisible(isVisible(), true);
      paramDrawable.setState(getState());
      paramDrawable.setLevel(getLevel());
      paramDrawable.setBounds(getBounds());
      if (this.b != null)
        this.b.b = paramDrawable.getConstantState();
    }
    invalidateSelf();
  }

  a b()
  {
    return new b(this.b, null);
  }

  protected boolean c()
  {
    return true;
  }

  public void draw(Canvas paramCanvas)
  {
    this.c.draw(paramCanvas);
  }

  public int getChangingConfigurations()
  {
    int i = super.getChangingConfigurations();
    if (this.b != null);
    for (int j = this.b.getChangingConfigurations(); ; j = 0)
      return j | i | this.c.getChangingConfigurations();
  }

  @y
  public Drawable.ConstantState getConstantState()
  {
    if ((this.b != null) && (this.b.a()))
    {
      this.b.a = getChangingConfigurations();
      return this.b;
    }
    return null;
  }

  public Drawable getCurrent()
  {
    return this.c.getCurrent();
  }

  public int getIntrinsicHeight()
  {
    return this.c.getIntrinsicHeight();
  }

  public int getIntrinsicWidth()
  {
    return this.c.getIntrinsicWidth();
  }

  public int getMinimumHeight()
  {
    return this.c.getMinimumHeight();
  }

  public int getMinimumWidth()
  {
    return this.c.getMinimumWidth();
  }

  public int getOpacity()
  {
    return this.c.getOpacity();
  }

  public boolean getPadding(Rect paramRect)
  {
    return this.c.getPadding(paramRect);
  }

  public int[] getState()
  {
    return this.c.getState();
  }

  public Region getTransparentRegion()
  {
    return this.c.getTransparentRegion();
  }

  public void invalidateDrawable(Drawable paramDrawable)
  {
    invalidateSelf();
  }

  public boolean isStateful()
  {
    if (c());
    for (ColorStateList localColorStateList = this.b.c; ((localColorStateList != null) && (localColorStateList.isStateful())) || (this.c.isStateful()); localColorStateList = null)
      return true;
    return false;
  }

  public Drawable mutate()
  {
    a locala;
    if ((!this.g) && (super.mutate() == this))
    {
      this.b = b();
      if (this.c != null)
        this.c.mutate();
      if (this.b != null)
      {
        locala = this.b;
        if (this.c == null)
          break label77;
      }
    }
    label77: for (Drawable.ConstantState localConstantState = this.c.getConstantState(); ; localConstantState = null)
    {
      locala.b = localConstantState;
      this.g = true;
      return this;
    }
  }

  protected void onBoundsChange(Rect paramRect)
  {
    if (this.c != null)
      this.c.setBounds(paramRect);
  }

  protected boolean onLevelChange(int paramInt)
  {
    return this.c.setLevel(paramInt);
  }

  public void scheduleDrawable(Drawable paramDrawable, Runnable paramRunnable, long paramLong)
  {
    scheduleSelf(paramRunnable, paramLong);
  }

  public void setAlpha(int paramInt)
  {
    this.c.setAlpha(paramInt);
  }

  public void setChangingConfigurations(int paramInt)
  {
    this.c.setChangingConfigurations(paramInt);
  }

  public void setColorFilter(ColorFilter paramColorFilter)
  {
    this.c.setColorFilter(paramColorFilter);
  }

  public void setDither(boolean paramBoolean)
  {
    this.c.setDither(paramBoolean);
  }

  public void setFilterBitmap(boolean paramBoolean)
  {
    this.c.setFilterBitmap(paramBoolean);
  }

  public boolean setState(int[] paramArrayOfInt)
  {
    boolean bool = this.c.setState(paramArrayOfInt);
    return (a(paramArrayOfInt)) || (bool);
  }

  public boolean setVisible(boolean paramBoolean1, boolean paramBoolean2)
  {
    return (super.setVisible(paramBoolean1, paramBoolean2)) || (this.c.setVisible(paramBoolean1, paramBoolean2));
  }

  public void unscheduleDrawable(Drawable paramDrawable, Runnable paramRunnable)
  {
    unscheduleSelf(paramRunnable);
  }

  protected static abstract class a extends Drawable.ConstantState
  {
    int a;
    Drawable.ConstantState b;
    ColorStateList c = null;
    PorterDuff.Mode d = j.a;

    a(@y a parama, @y Resources paramResources)
    {
      if (parama != null)
      {
        this.a = parama.a;
        this.b = parama.b;
        this.c = parama.c;
        this.d = parama.d;
      }
    }

    boolean a()
    {
      return this.b != null;
    }

    public int getChangingConfigurations()
    {
      int i = this.a;
      if (this.b != null);
      for (int j = this.b.getChangingConfigurations(); ; j = 0)
        return j | i;
    }

    public Drawable newDrawable()
    {
      return newDrawable(null);
    }

    public abstract Drawable newDrawable(@y Resources paramResources);
  }

  private static class b extends j.a
  {
    b(@y j.a parama, @y Resources paramResources)
    {
      super(paramResources);
    }

    public Drawable newDrawable(@y Resources paramResources)
    {
      return new j(this, paramResources);
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.e.a.j
 * JD-Core Version:    0.6.2
 */