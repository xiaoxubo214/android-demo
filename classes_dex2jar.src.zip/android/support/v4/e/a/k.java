package android.support.v4.e.a;

import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Drawable.ConstantState;
import android.support.annotation.y;

class k extends j
{
  k(Drawable paramDrawable)
  {
    super(paramDrawable);
  }

  k(j.a parama, Resources paramResources)
  {
    super(parama, paramResources);
  }

  protected Drawable a(Drawable.ConstantState paramConstantState, Resources paramResources)
  {
    return paramConstantState.newDrawable(paramResources);
  }

  j.a b()
  {
    return new a(this.b, null);
  }

  private static class a extends j.a
  {
    a(@y j.a parama, @y Resources paramResources)
    {
      super(paramResources);
    }

    public Drawable newDrawable(@y Resources paramResources)
    {
      return new k(this, paramResources);
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.e.a.k
 * JD-Core Version:    0.6.2
 */