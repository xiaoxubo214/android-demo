package android.support.v4.e.a;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader.TileMode;
import android.graphics.drawable.Drawable;
import android.util.DisplayMetrics;

public abstract class o extends Drawable
{
  private static final int c = 3;
  final Bitmap a;
  final Rect b = new Rect();
  private int d = 160;
  private int e = 119;
  private final Paint f = new Paint(3);
  private final BitmapShader g;
  private final Matrix h = new Matrix();
  private float i;
  private final RectF j = new RectF();
  private boolean k = true;
  private boolean l;
  private int m;
  private int n;

  o(Resources paramResources, Bitmap paramBitmap)
  {
    if (paramResources != null)
      this.d = paramResources.getDisplayMetrics().densityDpi;
    this.a = paramBitmap;
    if (this.a != null)
    {
      i();
      this.g = new BitmapShader(this.a, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
      return;
    }
    this.n = -1;
    this.m = -1;
    this.g = null;
  }

  private static boolean b(float paramFloat)
  {
    return paramFloat > 0.05F;
  }

  private void i()
  {
    this.m = this.a.getScaledWidth(this.d);
    this.n = this.a.getScaledHeight(this.d);
  }

  private void j()
  {
    this.i = (Math.min(this.n, this.m) / 2);
  }

  public final Paint a()
  {
    return this.f;
  }

  public void a(float paramFloat)
  {
    if (this.i == paramFloat)
      return;
    this.l = false;
    if (b(paramFloat))
      this.f.setShader(this.g);
    while (true)
    {
      this.i = paramFloat;
      invalidateSelf();
      return;
      this.f.setShader(null);
    }
  }

  public void a(int paramInt)
  {
    if (this.d != paramInt)
    {
      if (paramInt == 0)
        paramInt = 160;
      this.d = paramInt;
      if (this.a != null)
        i();
      invalidateSelf();
    }
  }

  void a(int paramInt1, int paramInt2, int paramInt3, Rect paramRect1, Rect paramRect2)
  {
    throw new UnsupportedOperationException();
  }

  public void a(Canvas paramCanvas)
  {
    a(paramCanvas.getDensity());
  }

  public void a(DisplayMetrics paramDisplayMetrics)
  {
    a(paramDisplayMetrics.densityDpi);
  }

  public void a(boolean paramBoolean)
  {
    throw new UnsupportedOperationException();
  }

  public final Bitmap b()
  {
    return this.a;
  }

  public void b(int paramInt)
  {
    if (this.e != paramInt)
    {
      this.e = paramInt;
      this.k = true;
      invalidateSelf();
    }
  }

  public void b(boolean paramBoolean)
  {
    this.f.setAntiAlias(paramBoolean);
    invalidateSelf();
  }

  public int c()
  {
    return this.e;
  }

  public void c(boolean paramBoolean)
  {
    this.l = paramBoolean;
    this.k = true;
    if (paramBoolean)
    {
      j();
      this.f.setShader(this.g);
      invalidateSelf();
      return;
    }
    a(0.0F);
  }

  public boolean d()
  {
    throw new UnsupportedOperationException();
  }

  public void draw(Canvas paramCanvas)
  {
    Bitmap localBitmap = this.a;
    if (localBitmap == null)
      return;
    f();
    if (this.f.getShader() == null)
    {
      paramCanvas.drawBitmap(localBitmap, null, this.b, this.f);
      return;
    }
    paramCanvas.drawRoundRect(this.j, this.i, this.i, this.f);
  }

  public boolean e()
  {
    return this.f.isAntiAlias();
  }

  void f()
  {
    if (this.k)
    {
      if (!this.l)
        break label228;
      int i1 = Math.min(this.m, this.n);
      a(this.e, i1, i1, getBounds(), this.b);
      int i2 = Math.min(this.b.width(), this.b.height());
      int i3 = Math.max(0, (this.b.width() - i2) / 2);
      int i4 = Math.max(0, (this.b.height() - i2) / 2);
      this.b.inset(i3, i4);
      this.i = (0.5F * i2);
    }
    while (true)
    {
      this.j.set(this.b);
      if (this.g != null)
      {
        this.h.setTranslate(this.j.left, this.j.top);
        this.h.preScale(this.j.width() / this.a.getWidth(), this.j.height() / this.a.getHeight());
        this.g.setLocalMatrix(this.h);
        this.f.setShader(this.g);
      }
      this.k = false;
      return;
      label228: a(this.e, this.m, this.n, getBounds(), this.b);
    }
  }

  public boolean g()
  {
    return this.l;
  }

  public int getAlpha()
  {
    return this.f.getAlpha();
  }

  public ColorFilter getColorFilter()
  {
    return this.f.getColorFilter();
  }

  public int getIntrinsicHeight()
  {
    return this.n;
  }

  public int getIntrinsicWidth()
  {
    return this.m;
  }

  public int getOpacity()
  {
    if ((this.e != 119) || (this.l));
    Bitmap localBitmap;
    do
    {
      return -3;
      localBitmap = this.a;
    }
    while ((localBitmap == null) || (localBitmap.hasAlpha()) || (this.f.getAlpha() < 255) || (b(this.i)));
    return -1;
  }

  public float h()
  {
    return this.i;
  }

  protected void onBoundsChange(Rect paramRect)
  {
    super.onBoundsChange(paramRect);
    if (this.l)
      j();
    this.k = true;
  }

  public void setAlpha(int paramInt)
  {
    if (paramInt != this.f.getAlpha())
    {
      this.f.setAlpha(paramInt);
      invalidateSelf();
    }
  }

  public void setColorFilter(ColorFilter paramColorFilter)
  {
    this.f.setColorFilter(paramColorFilter);
    invalidateSelf();
  }

  public void setDither(boolean paramBoolean)
  {
    this.f.setDither(paramBoolean);
    invalidateSelf();
  }

  public void setFilterBitmap(boolean paramBoolean)
  {
    this.f.setFilterBitmap(paramBoolean);
    invalidateSelf();
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.e.a.o
 * JD-Core Version:    0.6.2
 */