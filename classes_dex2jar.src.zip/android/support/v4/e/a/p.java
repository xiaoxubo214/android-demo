package android.support.v4.e.a;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Outline;
import android.graphics.Rect;
import android.view.Gravity;

class p extends o
{
  protected p(Resources paramResources, Bitmap paramBitmap)
  {
    super(paramResources, paramBitmap);
  }

  void a(int paramInt1, int paramInt2, int paramInt3, Rect paramRect1, Rect paramRect2)
  {
    Gravity.apply(paramInt1, paramInt2, paramInt3, paramRect1, paramRect2, 0);
  }

  public void a(boolean paramBoolean)
  {
    if (this.a != null)
    {
      this.a.setHasMipMap(paramBoolean);
      invalidateSelf();
    }
  }

  public boolean d()
  {
    return (this.a != null) && (this.a.hasMipMap());
  }

  public void getOutline(Outline paramOutline)
  {
    f();
    paramOutline.setRoundRect(this.b, h());
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.e.a.p
 * JD-Core Version:    0.6.2
 */