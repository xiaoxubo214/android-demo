package android.support.v4.e.a;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Rect;
import android.os.Build.VERSION;
import android.support.v4.e.a;
import android.support.v4.view.j;
import android.util.Log;
import java.io.InputStream;

public final class q
{
  private static final String a = "RoundedBitmapDrawableFactory";

  public static o a(Resources paramResources, Bitmap paramBitmap)
  {
    if (Build.VERSION.SDK_INT >= 21)
      return new p(paramResources, paramBitmap);
    return new a(paramResources, paramBitmap);
  }

  public static o a(Resources paramResources, InputStream paramInputStream)
  {
    o localo = a(paramResources, BitmapFactory.decodeStream(paramInputStream));
    if (localo.b() == null)
      Log.w("RoundedBitmapDrawableFactory", "RoundedBitmapDrawable cannot decode " + paramInputStream);
    return localo;
  }

  public static o a(Resources paramResources, String paramString)
  {
    o localo = a(paramResources, BitmapFactory.decodeFile(paramString));
    if (localo.b() == null)
      Log.w("RoundedBitmapDrawableFactory", "RoundedBitmapDrawable cannot decode " + paramString);
    return localo;
  }

  private static class a extends o
  {
    a(Resources paramResources, Bitmap paramBitmap)
    {
      super(paramBitmap);
    }

    void a(int paramInt1, int paramInt2, int paramInt3, Rect paramRect1, Rect paramRect2)
    {
      j.a(paramInt1, paramInt2, paramInt3, paramRect1, paramRect2, 0);
    }

    public void a(boolean paramBoolean)
    {
      if (this.a != null)
      {
        a.a(this.a, paramBoolean);
        invalidateSelf();
      }
    }

    public boolean d()
    {
      return (this.a != null) && (a.a(this.a));
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.e.a.q
 * JD-Core Version:    0.6.2
 */