package android.support.v4.e;

import android.graphics.Bitmap;

class c
{
  public static void a(Bitmap paramBitmap, boolean paramBoolean)
  {
    paramBitmap.setHasMipMap(paramBoolean);
  }

  public static boolean a(Bitmap paramBitmap)
  {
    return paramBitmap.hasMipMap();
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.e.c
 * JD-Core Version:    0.6.2
 */