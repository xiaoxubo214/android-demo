package android.support.v4.f.a;

import android.content.Context;
import android.os.Build.VERSION;
import android.view.Display;
import android.view.WindowManager;
import java.util.WeakHashMap;

public abstract class a
{
  public static final String a = "android.hardware.display.category.PRESENTATION";
  private static final WeakHashMap<Context, a> b = new WeakHashMap();

  public static a a(Context paramContext)
  {
    synchronized (b)
    {
      Object localObject2 = (a)b.get(paramContext);
      if (localObject2 == null)
      {
        if (Build.VERSION.SDK_INT >= 17)
        {
          localObject2 = new a(paramContext);
          b.put(paramContext, localObject2);
        }
      }
      else
        return localObject2;
      localObject2 = new b(paramContext);
    }
  }

  public abstract Display a(int paramInt);

  public abstract Display[] a();

  public abstract Display[] a(String paramString);

  private static class a extends a
  {
    private final Object b;

    public a(Context paramContext)
    {
      this.b = b.a(paramContext);
    }

    public Display a(int paramInt)
    {
      return b.a(this.b, paramInt);
    }

    public Display[] a()
    {
      return b.a(this.b);
    }

    public Display[] a(String paramString)
    {
      return b.a(this.b, paramString);
    }
  }

  private static class b extends a
  {
    private final WindowManager b;

    public b(Context paramContext)
    {
      this.b = ((WindowManager)paramContext.getSystemService("window"));
    }

    public Display a(int paramInt)
    {
      Display localDisplay = this.b.getDefaultDisplay();
      if (localDisplay.getDisplayId() == paramInt)
        return localDisplay;
      return null;
    }

    public Display[] a()
    {
      Display[] arrayOfDisplay = new Display[1];
      arrayOfDisplay[0] = this.b.getDefaultDisplay();
      return arrayOfDisplay;
    }

    public Display[] a(String paramString)
    {
      if (paramString == null)
        return a();
      return new Display[0];
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.f.a.a
 * JD-Core Version:    0.6.2
 */