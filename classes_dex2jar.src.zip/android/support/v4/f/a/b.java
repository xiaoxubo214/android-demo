package android.support.v4.f.a;

import android.content.Context;
import android.hardware.display.DisplayManager;
import android.view.Display;

final class b
{
  public static Display a(Object paramObject, int paramInt)
  {
    return ((DisplayManager)paramObject).getDisplay(paramInt);
  }

  public static Object a(Context paramContext)
  {
    return paramContext.getSystemService("display");
  }

  public static Display[] a(Object paramObject)
  {
    return ((DisplayManager)paramObject).getDisplays();
  }

  public static Display[] a(Object paramObject, String paramString)
  {
    return ((DisplayManager)paramObject).getDisplays(paramString);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.f.a.b
 * JD-Core Version:    0.6.2
 */