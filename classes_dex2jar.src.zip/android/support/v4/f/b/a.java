package android.support.v4.f.b;

import android.content.Context;
import android.os.Build.VERSION;
import android.os.Handler;
import android.support.annotation.x;
import android.support.annotation.y;
import java.security.Signature;
import javax.crypto.Cipher;
import javax.crypto.Mac;

public final class a
{
  static final e a = new f();
  private Context b;

  static
  {
    if (Build.VERSION.SDK_INT >= 23)
    {
      a = new a();
      return;
    }
  }

  private a(Context paramContext)
  {
    this.b = paramContext;
  }

  public static a a(Context paramContext)
  {
    return new a(paramContext);
  }

  public void a(@y d paramd, int paramInt, @y android.support.v4.os.c paramc, @x b paramb, @y Handler paramHandler)
  {
    a.a(this.b, paramd, paramInt, paramc, paramb, paramHandler);
  }

  public boolean a()
  {
    return a.a(this.b);
  }

  public boolean b()
  {
    return a.b(this.b);
  }

  private static class a
    implements a.e
  {
    private static c.a a(a.b paramb)
    {
      return new b(paramb);
    }

    private static c.c a(a.d paramd)
    {
      if (paramd == null);
      do
      {
        return null;
        if (paramd.b() != null)
          return new c.c(paramd.b());
        if (paramd.a() != null)
          return new c.c(paramd.a());
      }
      while (paramd.c() == null);
      return new c.c(paramd.c());
    }

    private static a.d b(c.c paramc)
    {
      if (paramc == null);
      do
      {
        return null;
        if (paramc.b() != null)
          return new a.d(paramc.b());
        if (paramc.a() != null)
          return new a.d(paramc.a());
      }
      while (paramc.c() == null);
      return new a.d(paramc.c());
    }

    public void a(Context paramContext, a.d paramd, int paramInt, android.support.v4.os.c paramc, a.b paramb, Handler paramHandler)
    {
      c.c localc = a(paramd);
      if (paramc != null);
      for (Object localObject = paramc.d(); ; localObject = null)
      {
        c.a(paramContext, localc, paramInt, localObject, a(paramb), paramHandler);
        return;
      }
    }

    public boolean a(Context paramContext)
    {
      return c.a(paramContext);
    }

    public boolean b(Context paramContext)
    {
      return c.b(paramContext);
    }
  }

  public static abstract class b
  {
    public void a()
    {
    }

    public void a(int paramInt, CharSequence paramCharSequence)
    {
    }

    public void a(a.c paramc)
    {
    }

    public void b(int paramInt, CharSequence paramCharSequence)
    {
    }
  }

  public static final class c
  {
    private a.d a;

    public c(a.d paramd)
    {
      this.a = paramd;
    }

    public a.d a()
    {
      return this.a;
    }
  }

  public static class d
  {
    private final Signature a;
    private final Cipher b;
    private final Mac c;

    public d(Signature paramSignature)
    {
      this.a = paramSignature;
      this.b = null;
      this.c = null;
    }

    public d(Cipher paramCipher)
    {
      this.b = paramCipher;
      this.a = null;
      this.c = null;
    }

    public d(Mac paramMac)
    {
      this.c = paramMac;
      this.b = null;
      this.a = null;
    }

    public Signature a()
    {
      return this.a;
    }

    public Cipher b()
    {
      return this.b;
    }

    public Mac c()
    {
      return this.c;
    }
  }

  private static abstract interface e
  {
    public abstract void a(Context paramContext, a.d paramd, int paramInt, android.support.v4.os.c paramc, a.b paramb, Handler paramHandler);

    public abstract boolean a(Context paramContext);

    public abstract boolean b(Context paramContext);
  }

  private static class f
    implements a.e
  {
    public void a(Context paramContext, a.d paramd, int paramInt, android.support.v4.os.c paramc, a.b paramb, Handler paramHandler)
    {
    }

    public boolean a(Context paramContext)
    {
      return false;
    }

    public boolean b(Context paramContext)
    {
      return false;
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.f.b.a
 * JD-Core Version:    0.6.2
 */