package android.support.v4.f.b;

final class b extends c.a
{
  b(a.b paramb)
  {
  }

  public void a()
  {
    this.a.a();
  }

  public void a(int paramInt, CharSequence paramCharSequence)
  {
    this.a.a(paramInt, paramCharSequence);
  }

  public void a(c.b paramb)
  {
    this.a.a(new a.c(a.a.a(paramb.a())));
  }

  public void b(int paramInt, CharSequence paramCharSequence)
  {
    this.a.b(paramInt, paramCharSequence);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.f.b.b
 * JD-Core Version:    0.6.2
 */