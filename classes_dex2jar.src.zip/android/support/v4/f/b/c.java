package android.support.v4.f.b;

import android.content.Context;
import android.hardware.fingerprint.FingerprintManager;
import android.hardware.fingerprint.FingerprintManager.AuthenticationCallback;
import android.hardware.fingerprint.FingerprintManager.CryptoObject;
import android.os.CancellationSignal;
import android.os.Handler;
import java.security.Signature;
import javax.crypto.Cipher;
import javax.crypto.Mac;

public final class c
{
  private static FingerprintManager.AuthenticationCallback a(a parama)
  {
    return new d(parama);
  }

  private static FingerprintManager.CryptoObject a(c paramc)
  {
    if (paramc == null);
    do
    {
      return null;
      if (paramc.b() != null)
        return new FingerprintManager.CryptoObject(paramc.b());
      if (paramc.a() != null)
        return new FingerprintManager.CryptoObject(paramc.a());
    }
    while (paramc.c() == null);
    return new FingerprintManager.CryptoObject(paramc.c());
  }

  public static void a(Context paramContext, c paramc, int paramInt, Object paramObject, a parama, Handler paramHandler)
  {
    c(paramContext).authenticate(a(paramc), (CancellationSignal)paramObject, paramInt, a(parama), paramHandler);
  }

  public static boolean a(Context paramContext)
  {
    return c(paramContext).hasEnrolledFingerprints();
  }

  private static c b(FingerprintManager.CryptoObject paramCryptoObject)
  {
    if (paramCryptoObject == null);
    do
    {
      return null;
      if (paramCryptoObject.getCipher() != null)
        return new c(paramCryptoObject.getCipher());
      if (paramCryptoObject.getSignature() != null)
        return new c(paramCryptoObject.getSignature());
    }
    while (paramCryptoObject.getMac() == null);
    return new c(paramCryptoObject.getMac());
  }

  public static boolean b(Context paramContext)
  {
    return c(paramContext).isHardwareDetected();
  }

  private static FingerprintManager c(Context paramContext)
  {
    return (FingerprintManager)paramContext.getSystemService(FingerprintManager.class);
  }

  public static abstract class a
  {
    public void a()
    {
    }

    public void a(int paramInt, CharSequence paramCharSequence)
    {
    }

    public void a(c.b paramb)
    {
    }

    public void b(int paramInt, CharSequence paramCharSequence)
    {
    }
  }

  public static final class b
  {
    private c.c a;

    public b(c.c paramc)
    {
      this.a = paramc;
    }

    public c.c a()
    {
      return this.a;
    }
  }

  public static class c
  {
    private final Signature a;
    private final Cipher b;
    private final Mac c;

    public c(Signature paramSignature)
    {
      this.a = paramSignature;
      this.b = null;
      this.c = null;
    }

    public c(Cipher paramCipher)
    {
      this.b = paramCipher;
      this.a = null;
      this.c = null;
    }

    public c(Mac paramMac)
    {
      this.c = paramMac;
      this.b = null;
      this.a = null;
    }

    public Signature a()
    {
      return this.a;
    }

    public Cipher b()
    {
      return this.b;
    }

    public Mac c()
    {
      return this.c;
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.f.b.c
 * JD-Core Version:    0.6.2
 */