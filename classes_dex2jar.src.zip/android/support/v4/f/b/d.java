package android.support.v4.f.b;

import android.hardware.fingerprint.FingerprintManager.AuthenticationCallback;
import android.hardware.fingerprint.FingerprintManager.AuthenticationResult;

final class d extends FingerprintManager.AuthenticationCallback
{
  d(c.a parama)
  {
  }

  public void onAuthenticationError(int paramInt, CharSequence paramCharSequence)
  {
    this.a.a(paramInt, paramCharSequence);
  }

  public void onAuthenticationFailed()
  {
    this.a.a();
  }

  public void onAuthenticationHelp(int paramInt, CharSequence paramCharSequence)
  {
    this.a.b(paramInt, paramCharSequence);
  }

  public void onAuthenticationSucceeded(FingerprintManager.AuthenticationResult paramAuthenticationResult)
  {
    this.a.a(new c.b(c.a(paramAuthenticationResult.getCryptoObject())));
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.f.b.d
 * JD-Core Version:    0.6.2
 */