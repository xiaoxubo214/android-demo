package android.support.v4.g.a;

import android.view.Menu;

public abstract interface a extends Menu
{
  public static final int a = 65535;
  public static final int b = 0;
  public static final int c = -65536;
  public static final int d = 16;
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.g.a.a
 * JD-Core Version:    0.6.2
 */