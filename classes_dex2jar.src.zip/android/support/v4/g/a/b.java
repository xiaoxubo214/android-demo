package android.support.v4.g.a;

import android.support.v4.view.h;
import android.support.v4.view.x.e;
import android.view.MenuItem;
import android.view.View;

public abstract interface b extends MenuItem
{
  public static final int a = 0;
  public static final int b = 1;
  public static final int c = 2;
  public static final int d = 4;
  public static final int e = 8;

  public abstract b a(h paramh);

  public abstract b a(x.e parame);

  public abstract h a();

  public abstract boolean collapseActionView();

  public abstract boolean expandActionView();

  public abstract View getActionView();

  public abstract boolean isActionViewExpanded();

  public abstract MenuItem setActionView(int paramInt);

  public abstract MenuItem setActionView(View paramView);

  public abstract void setShowAsAction(int paramInt);

  public abstract MenuItem setShowAsActionFlags(int paramInt);
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.g.a.b
 * JD-Core Version:    0.6.2
 */