package android.support.v4.g.a;

import android.view.SubMenu;

public abstract interface c extends a, SubMenu
{
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.g.a.c
 * JD-Core Version:    0.6.2
 */