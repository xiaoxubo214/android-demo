package android.support.v4.h;

import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build.VERSION;

public final class a
{
  private static final b a = new a();

  static
  {
    if (Build.VERSION.SDK_INT >= 16)
    {
      a = new e();
      return;
    }
    if (Build.VERSION.SDK_INT >= 13)
    {
      a = new d();
      return;
    }
    if (Build.VERSION.SDK_INT >= 8)
    {
      a = new c();
      return;
    }
  }

  public static NetworkInfo a(ConnectivityManager paramConnectivityManager, Intent paramIntent)
  {
    NetworkInfo localNetworkInfo = (NetworkInfo)paramIntent.getParcelableExtra("networkInfo");
    if (localNetworkInfo != null)
      return paramConnectivityManager.getNetworkInfo(localNetworkInfo.getType());
    return null;
  }

  public static boolean a(ConnectivityManager paramConnectivityManager)
  {
    return a.a(paramConnectivityManager);
  }

  static class a
    implements a.b
  {
    public boolean a(ConnectivityManager paramConnectivityManager)
    {
      NetworkInfo localNetworkInfo = paramConnectivityManager.getActiveNetworkInfo();
      if (localNetworkInfo == null)
        return true;
      switch (localNetworkInfo.getType())
      {
      case 0:
      default:
        return true;
      case 1:
      }
      return false;
    }
  }

  static abstract interface b
  {
    public abstract boolean a(ConnectivityManager paramConnectivityManager);
  }

  static class c
    implements a.b
  {
    public boolean a(ConnectivityManager paramConnectivityManager)
    {
      return b.a(paramConnectivityManager);
    }
  }

  static class d
    implements a.b
  {
    public boolean a(ConnectivityManager paramConnectivityManager)
    {
      return c.a(paramConnectivityManager);
    }
  }

  static class e
    implements a.b
  {
    public boolean a(ConnectivityManager paramConnectivityManager)
    {
      return d.a(paramConnectivityManager);
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.h.a
 * JD-Core Version:    0.6.2
 */