package android.support.v4.h;

import android.net.ConnectivityManager;

class d
{
  public static boolean a(ConnectivityManager paramConnectivityManager)
  {
    return paramConnectivityManager.isActiveNetworkMetered();
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.h.d
 * JD-Core Version:    0.6.2
 */