package android.support.v4.h;

import android.os.Build.VERSION;
import java.net.Socket;
import java.net.SocketException;

public final class e
{
  private static final c a = new a();

  static
  {
    if (Build.VERSION.SDK_INT >= 14)
    {
      a = new b();
      return;
    }
  }

  public static void a()
  {
    a.a();
  }

  public static void a(int paramInt)
  {
    a.a(paramInt);
  }

  public static void a(int paramInt1, int paramInt2)
  {
    a.a(paramInt1, paramInt2);
  }

  public static void a(Socket paramSocket)
    throws SocketException
  {
    a.a(paramSocket);
  }

  public static int b()
  {
    return a.b();
  }

  public static void b(int paramInt)
  {
    a.b(paramInt);
  }

  public static void b(Socket paramSocket)
    throws SocketException
  {
    a.b(paramSocket);
  }

  static class a
    implements e.c
  {
    private ThreadLocal<a> a = new f(this);

    public void a()
    {
      ((a)this.a.get()).a = -1;
    }

    public void a(int paramInt)
    {
    }

    public void a(int paramInt1, int paramInt2)
    {
    }

    public void a(Socket paramSocket)
    {
    }

    public int b()
    {
      return ((a)this.a.get()).a;
    }

    public void b(int paramInt)
    {
      ((a)this.a.get()).a = paramInt;
    }

    public void b(Socket paramSocket)
    {
    }

    private static class a
    {
      public int a = -1;
    }
  }

  static class b
    implements e.c
  {
    public void a()
    {
      g.a();
    }

    public void a(int paramInt)
    {
      g.a(paramInt);
    }

    public void a(int paramInt1, int paramInt2)
    {
      g.a(paramInt1, paramInt2);
    }

    public void a(Socket paramSocket)
      throws SocketException
    {
      g.a(paramSocket);
    }

    public int b()
    {
      return g.b();
    }

    public void b(int paramInt)
    {
      g.b(paramInt);
    }

    public void b(Socket paramSocket)
      throws SocketException
    {
      g.b(paramSocket);
    }
  }

  static abstract interface c
  {
    public abstract void a();

    public abstract void a(int paramInt);

    public abstract void a(int paramInt1, int paramInt2);

    public abstract void a(Socket paramSocket)
      throws SocketException;

    public abstract int b();

    public abstract void b(int paramInt);

    public abstract void b(Socket paramSocket)
      throws SocketException;
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.h.e
 * JD-Core Version:    0.6.2
 */