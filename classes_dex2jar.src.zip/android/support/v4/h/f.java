package android.support.v4.h;

class f extends ThreadLocal<e.a.a>
{
  f(e.a parama)
  {
  }

  protected e.a.a a()
  {
    return new e.a.a(null);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.h.f
 * JD-Core Version:    0.6.2
 */