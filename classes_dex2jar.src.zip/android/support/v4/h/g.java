package android.support.v4.h;

import android.net.TrafficStats;
import java.net.Socket;
import java.net.SocketException;

class g
{
  public static void a()
  {
    TrafficStats.clearThreadStatsTag();
  }

  public static void a(int paramInt)
  {
    TrafficStats.incrementOperationCount(paramInt);
  }

  public static void a(int paramInt1, int paramInt2)
  {
    TrafficStats.incrementOperationCount(paramInt1, paramInt2);
  }

  public static void a(Socket paramSocket)
    throws SocketException
  {
    TrafficStats.tagSocket(paramSocket);
  }

  public static int b()
  {
    return TrafficStats.getThreadStatsTag();
  }

  public static void b(int paramInt)
  {
    TrafficStats.setThreadStatsTag(paramInt);
  }

  public static void b(Socket paramSocket)
    throws SocketException
  {
    TrafficStats.untagSocket(paramSocket);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.h.g
 * JD-Core Version:    0.6.2
 */