package android.support.v4.i;

import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build.VERSION;
import java.io.FileNotFoundException;

public final class a
{
  public static final int a = 1;
  public static final int b = 2;
  public static final int c = 1;
  public static final int d = 2;
  public static final int e = 1;
  public static final int f = 2;
  d g;

  public a(Context paramContext)
  {
    if (a())
    {
      this.g = new b(paramContext);
      return;
    }
    this.g = new c(null);
  }

  public static boolean a()
  {
    return Build.VERSION.SDK_INT >= 19;
  }

  public void a(int paramInt)
  {
    this.g.a(paramInt);
  }

  public void a(String paramString, Bitmap paramBitmap)
  {
    this.g.a(paramString, paramBitmap, null);
  }

  public void a(String paramString, Bitmap paramBitmap, a parama)
  {
    this.g.a(paramString, paramBitmap, parama);
  }

  public void a(String paramString, Uri paramUri)
    throws FileNotFoundException
  {
    this.g.a(paramString, paramUri, null);
  }

  public void a(String paramString, Uri paramUri, a parama)
    throws FileNotFoundException
  {
    this.g.a(paramString, paramUri, parama);
  }

  public int b()
  {
    return this.g.a();
  }

  public void b(int paramInt)
  {
    this.g.b(paramInt);
  }

  public int c()
  {
    return this.g.b();
  }

  public void c(int paramInt)
  {
    this.g.c(paramInt);
  }

  public int d()
  {
    return this.g.c();
  }

  public static abstract interface a
  {
    public abstract void a();
  }

  private static final class b
    implements a.d
  {
    private final d a;

    b(Context paramContext)
    {
      this.a = new d(paramContext);
    }

    public int a()
    {
      return this.a.a();
    }

    public void a(int paramInt)
    {
      this.a.a(paramInt);
    }

    public void a(String paramString, Bitmap paramBitmap, a.a parama)
    {
      b localb = null;
      if (parama != null)
        localb = new b(this, parama);
      this.a.a(paramString, paramBitmap, localb);
    }

    public void a(String paramString, Uri paramUri, a.a parama)
      throws FileNotFoundException
    {
      c localc = null;
      if (parama != null)
        localc = new c(this, parama);
      this.a.a(paramString, paramUri, localc);
    }

    public int b()
    {
      return this.a.c();
    }

    public void b(int paramInt)
    {
      this.a.b(paramInt);
    }

    public int c()
    {
      return this.a.b();
    }

    public void c(int paramInt)
    {
      this.a.c(paramInt);
    }
  }

  private static final class c
    implements a.d
  {
    int a = 2;
    int b = 2;
    int c = 1;

    public int a()
    {
      return this.a;
    }

    public void a(int paramInt)
    {
      this.a = paramInt;
    }

    public void a(String paramString, Bitmap paramBitmap, a.a parama)
    {
    }

    public void a(String paramString, Uri paramUri, a.a parama)
    {
    }

    public int b()
    {
      return this.b;
    }

    public void b(int paramInt)
    {
      this.b = paramInt;
    }

    public int c()
    {
      return this.c;
    }

    public void c(int paramInt)
    {
      this.c = paramInt;
    }
  }

  static abstract interface d
  {
    public abstract int a();

    public abstract void a(int paramInt);

    public abstract void a(String paramString, Bitmap paramBitmap, a.a parama);

    public abstract void a(String paramString, Uri paramUri, a.a parama)
      throws FileNotFoundException;

    public abstract int b();

    public abstract void b(int paramInt);

    public abstract int c();

    public abstract void c(int paramInt);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.i.a
 * JD-Core Version:    0.6.2
 */