package android.support.v4.i;

class b
  implements d.a
{
  b(a.b paramb, a.a parama)
  {
  }

  public void a()
  {
    this.a.a();
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.i.b
 * JD-Core Version:    0.6.2
 */