package android.support.v4.i;

class c
  implements d.a
{
  c(a.b paramb, a.a parama)
  {
  }

  public void a()
  {
    this.a.a();
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.i.c
 * JD-Core Version:    0.6.2
 */