package android.support.v4.i;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentAdapter.LayoutResultCallback;
import android.print.PrintDocumentInfo;
import android.print.PrintDocumentInfo.Builder;

class e extends PrintDocumentAdapter
{
  private PrintAttributes f;

  e(d paramd, String paramString, Bitmap paramBitmap, int paramInt, d.a parama)
  {
  }

  public void onFinish()
  {
    if (this.d != null)
      this.d.a();
  }

  public void onLayout(PrintAttributes paramPrintAttributes1, PrintAttributes paramPrintAttributes2, CancellationSignal paramCancellationSignal, PrintDocumentAdapter.LayoutResultCallback paramLayoutResultCallback, Bundle paramBundle)
  {
    int i = 1;
    this.f = paramPrintAttributes2;
    PrintDocumentInfo localPrintDocumentInfo = new PrintDocumentInfo.Builder(this.a).setContentType(i).setPageCount(i).build();
    if (!paramPrintAttributes2.equals(paramPrintAttributes1));
    while (true)
    {
      paramLayoutResultCallback.onLayoutFinished(localPrintDocumentInfo, i);
      return;
      int j = 0;
    }
  }

  // ERROR //
  public void onWrite(android.print.PageRange[] paramArrayOfPageRange, android.os.ParcelFileDescriptor paramParcelFileDescriptor, CancellationSignal paramCancellationSignal, android.print.PrintDocumentAdapter.WriteResultCallback paramWriteResultCallback)
  {
    // Byte code:
    //   0: new 74	android/print/pdf/PrintedPdfDocument
    //   3: dup
    //   4: aload_0
    //   5: getfield 20	android/support/v4/i/e:e	Landroid/support/v4/i/d;
    //   8: getfield 79	android/support/v4/i/d:a	Landroid/content/Context;
    //   11: aload_0
    //   12: getfield 40	android/support/v4/i/e:f	Landroid/print/PrintAttributes;
    //   15: invokespecial 82	android/print/pdf/PrintedPdfDocument:<init>	(Landroid/content/Context;Landroid/print/PrintAttributes;)V
    //   18: astore 5
    //   20: aload_0
    //   21: getfield 20	android/support/v4/i/e:e	Landroid/support/v4/i/d;
    //   24: aload_0
    //   25: getfield 24	android/support/v4/i/e:b	Landroid/graphics/Bitmap;
    //   28: aload_0
    //   29: getfield 40	android/support/v4/i/e:f	Landroid/print/PrintAttributes;
    //   32: invokevirtual 86	android/print/PrintAttributes:getColorMode	()I
    //   35: invokestatic 89	android/support/v4/i/d:a	(Landroid/support/v4/i/d;Landroid/graphics/Bitmap;I)Landroid/graphics/Bitmap;
    //   38: astore 6
    //   40: aload 5
    //   42: iconst_1
    //   43: invokevirtual 93	android/print/pdf/PrintedPdfDocument:startPage	(I)Landroid/graphics/pdf/PdfDocument$Page;
    //   46: astore 9
    //   48: new 95	android/graphics/RectF
    //   51: dup
    //   52: aload 9
    //   54: invokevirtual 101	android/graphics/pdf/PdfDocument$Page:getInfo	()Landroid/graphics/pdf/PdfDocument$PageInfo;
    //   57: invokevirtual 107	android/graphics/pdf/PdfDocument$PageInfo:getContentRect	()Landroid/graphics/Rect;
    //   60: invokespecial 110	android/graphics/RectF:<init>	(Landroid/graphics/Rect;)V
    //   63: astore 10
    //   65: aload_0
    //   66: getfield 20	android/support/v4/i/e:e	Landroid/support/v4/i/d;
    //   69: aload 6
    //   71: invokevirtual 115	android/graphics/Bitmap:getWidth	()I
    //   74: aload 6
    //   76: invokevirtual 118	android/graphics/Bitmap:getHeight	()I
    //   79: aload 10
    //   81: aload_0
    //   82: getfield 26	android/support/v4/i/e:c	I
    //   85: invokestatic 121	android/support/v4/i/d:a	(Landroid/support/v4/i/d;IILandroid/graphics/RectF;I)Landroid/graphics/Matrix;
    //   88: astore 11
    //   90: aload 9
    //   92: invokevirtual 125	android/graphics/pdf/PdfDocument$Page:getCanvas	()Landroid/graphics/Canvas;
    //   95: aload 6
    //   97: aload 11
    //   99: aconst_null
    //   100: invokevirtual 131	android/graphics/Canvas:drawBitmap	(Landroid/graphics/Bitmap;Landroid/graphics/Matrix;Landroid/graphics/Paint;)V
    //   103: aload 5
    //   105: aload 9
    //   107: invokevirtual 135	android/print/pdf/PrintedPdfDocument:finishPage	(Landroid/graphics/pdf/PdfDocument$Page;)V
    //   110: aload 5
    //   112: new 137	java/io/FileOutputStream
    //   115: dup
    //   116: aload_2
    //   117: invokevirtual 143	android/os/ParcelFileDescriptor:getFileDescriptor	()Ljava/io/FileDescriptor;
    //   120: invokespecial 146	java/io/FileOutputStream:<init>	(Ljava/io/FileDescriptor;)V
    //   123: invokevirtual 150	android/print/pdf/PrintedPdfDocument:writeTo	(Ljava/io/OutputStream;)V
    //   126: iconst_1
    //   127: anewarray 152	android/print/PageRange
    //   130: astore 15
    //   132: aload 15
    //   134: iconst_0
    //   135: getstatic 156	android/print/PageRange:ALL_PAGES	Landroid/print/PageRange;
    //   138: aastore
    //   139: aload 4
    //   141: aload 15
    //   143: invokevirtual 162	android/print/PrintDocumentAdapter$WriteResultCallback:onWriteFinished	([Landroid/print/PageRange;)V
    //   146: aload 5
    //   148: ifnull +8 -> 156
    //   151: aload 5
    //   153: invokevirtual 165	android/print/pdf/PrintedPdfDocument:close	()V
    //   156: aload_2
    //   157: ifnull +7 -> 164
    //   160: aload_2
    //   161: invokevirtual 166	android/os/ParcelFileDescriptor:close	()V
    //   164: aload 6
    //   166: aload_0
    //   167: getfield 24	android/support/v4/i/e:b	Landroid/graphics/Bitmap;
    //   170: if_acmpeq +8 -> 178
    //   173: aload 6
    //   175: invokevirtual 169	android/graphics/Bitmap:recycle	()V
    //   178: return
    //   179: astore 12
    //   181: ldc 171
    //   183: ldc 173
    //   185: aload 12
    //   187: invokestatic 178	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   190: pop
    //   191: aload 4
    //   193: aconst_null
    //   194: invokevirtual 182	android/print/PrintDocumentAdapter$WriteResultCallback:onWriteFailed	(Ljava/lang/CharSequence;)V
    //   197: goto -51 -> 146
    //   200: astore 7
    //   202: aload 5
    //   204: ifnull +8 -> 212
    //   207: aload 5
    //   209: invokevirtual 165	android/print/pdf/PrintedPdfDocument:close	()V
    //   212: aload_2
    //   213: ifnull +7 -> 220
    //   216: aload_2
    //   217: invokevirtual 166	android/os/ParcelFileDescriptor:close	()V
    //   220: aload 6
    //   222: aload_0
    //   223: getfield 24	android/support/v4/i/e:b	Landroid/graphics/Bitmap;
    //   226: if_acmpeq +8 -> 234
    //   229: aload 6
    //   231: invokevirtual 169	android/graphics/Bitmap:recycle	()V
    //   234: aload 7
    //   236: athrow
    //   237: astore 14
    //   239: goto -75 -> 164
    //   242: astore 8
    //   244: goto -24 -> 220
    //
    // Exception table:
    //   from	to	target	type
    //   110	146	179	java/io/IOException
    //   40	110	200	finally
    //   110	146	200	finally
    //   181	197	200	finally
    //   160	164	237	java/io/IOException
    //   216	220	242	java/io/IOException
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.i.e
 * JD-Core Version:    0.6.2
 */