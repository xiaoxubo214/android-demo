package android.support.v4.i;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory.Options;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentAdapter.LayoutResultCallback;
import android.print.PrintDocumentInfo;
import android.print.PrintDocumentInfo.Builder;

class f extends PrintDocumentAdapter
{
  AsyncTask<Uri, Boolean, Bitmap> a;
  Bitmap b = null;
  private PrintAttributes h;

  f(d paramd, String paramString, Uri paramUri, d.a parama, int paramInt)
  {
  }

  private void a()
  {
    synchronized (d.a(this.g))
    {
      if (this.g.b != null)
      {
        this.g.b.requestCancelDecode();
        this.g.b = null;
      }
      return;
    }
  }

  public void onFinish()
  {
    super.onFinish();
    a();
    if (this.a != null)
      this.a.cancel(true);
    if (this.e != null)
      this.e.a();
    if (this.b != null)
    {
      this.b.recycle();
      this.b = null;
    }
  }

  public void onLayout(PrintAttributes paramPrintAttributes1, PrintAttributes paramPrintAttributes2, CancellationSignal paramCancellationSignal, PrintDocumentAdapter.LayoutResultCallback paramLayoutResultCallback, Bundle paramBundle)
  {
    int i = 1;
    this.h = paramPrintAttributes2;
    if (paramCancellationSignal.isCanceled())
    {
      paramLayoutResultCallback.onLayoutCancelled();
      return;
    }
    if (this.b != null)
    {
      PrintDocumentInfo localPrintDocumentInfo = new PrintDocumentInfo.Builder(this.c).setContentType(i).setPageCount(i).build();
      if (!paramPrintAttributes2.equals(paramPrintAttributes1));
      while (true)
      {
        paramLayoutResultCallback.onLayoutFinished(localPrintDocumentInfo, i);
        return;
        int j = 0;
      }
    }
    this.a = new g(this, paramCancellationSignal, paramPrintAttributes2, paramPrintAttributes1, paramLayoutResultCallback).execute(new Uri[0]);
  }

  // ERROR //
  public void onWrite(android.print.PageRange[] paramArrayOfPageRange, android.os.ParcelFileDescriptor paramParcelFileDescriptor, CancellationSignal paramCancellationSignal, android.print.PrintDocumentAdapter.WriteResultCallback paramWriteResultCallback)
  {
    // Byte code:
    //   0: new 131	android/print/pdf/PrintedPdfDocument
    //   3: dup
    //   4: aload_0
    //   5: getfield 25	android/support/v4/i/f:g	Landroid/support/v4/i/d;
    //   8: getfield 134	android/support/v4/i/d:a	Landroid/content/Context;
    //   11: aload_0
    //   12: getfield 77	android/support/v4/i/f:h	Landroid/print/PrintAttributes;
    //   15: invokespecial 137	android/print/pdf/PrintedPdfDocument:<init>	(Landroid/content/Context;Landroid/print/PrintAttributes;)V
    //   18: astore 5
    //   20: aload_0
    //   21: getfield 25	android/support/v4/i/f:g	Landroid/support/v4/i/d;
    //   24: aload_0
    //   25: getfield 38	android/support/v4/i/f:b	Landroid/graphics/Bitmap;
    //   28: aload_0
    //   29: getfield 77	android/support/v4/i/f:h	Landroid/print/PrintAttributes;
    //   32: invokevirtual 141	android/print/PrintAttributes:getColorMode	()I
    //   35: invokestatic 144	android/support/v4/i/d:a	(Landroid/support/v4/i/d;Landroid/graphics/Bitmap;I)Landroid/graphics/Bitmap;
    //   38: astore 6
    //   40: aload 5
    //   42: iconst_1
    //   43: invokevirtual 148	android/print/pdf/PrintedPdfDocument:startPage	(I)Landroid/graphics/pdf/PdfDocument$Page;
    //   46: astore 9
    //   48: new 150	android/graphics/RectF
    //   51: dup
    //   52: aload 9
    //   54: invokevirtual 156	android/graphics/pdf/PdfDocument$Page:getInfo	()Landroid/graphics/pdf/PdfDocument$PageInfo;
    //   57: invokevirtual 162	android/graphics/pdf/PdfDocument$PageInfo:getContentRect	()Landroid/graphics/Rect;
    //   60: invokespecial 165	android/graphics/RectF:<init>	(Landroid/graphics/Rect;)V
    //   63: astore 10
    //   65: aload_0
    //   66: getfield 25	android/support/v4/i/f:g	Landroid/support/v4/i/d;
    //   69: aload_0
    //   70: getfield 38	android/support/v4/i/f:b	Landroid/graphics/Bitmap;
    //   73: invokevirtual 168	android/graphics/Bitmap:getWidth	()I
    //   76: aload_0
    //   77: getfield 38	android/support/v4/i/f:b	Landroid/graphics/Bitmap;
    //   80: invokevirtual 171	android/graphics/Bitmap:getHeight	()I
    //   83: aload 10
    //   85: aload_0
    //   86: getfield 33	android/support/v4/i/f:f	I
    //   89: invokestatic 174	android/support/v4/i/d:a	(Landroid/support/v4/i/d;IILandroid/graphics/RectF;I)Landroid/graphics/Matrix;
    //   92: astore 11
    //   94: aload 9
    //   96: invokevirtual 178	android/graphics/pdf/PdfDocument$Page:getCanvas	()Landroid/graphics/Canvas;
    //   99: aload 6
    //   101: aload 11
    //   103: aconst_null
    //   104: invokevirtual 184	android/graphics/Canvas:drawBitmap	(Landroid/graphics/Bitmap;Landroid/graphics/Matrix;Landroid/graphics/Paint;)V
    //   107: aload 5
    //   109: aload 9
    //   111: invokevirtual 188	android/print/pdf/PrintedPdfDocument:finishPage	(Landroid/graphics/pdf/PdfDocument$Page;)V
    //   114: aload 5
    //   116: new 190	java/io/FileOutputStream
    //   119: dup
    //   120: aload_2
    //   121: invokevirtual 196	android/os/ParcelFileDescriptor:getFileDescriptor	()Ljava/io/FileDescriptor;
    //   124: invokespecial 199	java/io/FileOutputStream:<init>	(Ljava/io/FileDescriptor;)V
    //   127: invokevirtual 203	android/print/pdf/PrintedPdfDocument:writeTo	(Ljava/io/OutputStream;)V
    //   130: iconst_1
    //   131: anewarray 205	android/print/PageRange
    //   134: astore 15
    //   136: aload 15
    //   138: iconst_0
    //   139: getstatic 209	android/print/PageRange:ALL_PAGES	Landroid/print/PageRange;
    //   142: aastore
    //   143: aload 4
    //   145: aload 15
    //   147: invokevirtual 215	android/print/PrintDocumentAdapter$WriteResultCallback:onWriteFinished	([Landroid/print/PageRange;)V
    //   150: aload 5
    //   152: ifnull +8 -> 160
    //   155: aload 5
    //   157: invokevirtual 218	android/print/pdf/PrintedPdfDocument:close	()V
    //   160: aload_2
    //   161: ifnull +7 -> 168
    //   164: aload_2
    //   165: invokevirtual 219	android/os/ParcelFileDescriptor:close	()V
    //   168: aload 6
    //   170: aload_0
    //   171: getfield 38	android/support/v4/i/f:b	Landroid/graphics/Bitmap;
    //   174: if_acmpeq +8 -> 182
    //   177: aload 6
    //   179: invokevirtual 73	android/graphics/Bitmap:recycle	()V
    //   182: return
    //   183: astore 12
    //   185: ldc 221
    //   187: ldc 223
    //   189: aload 12
    //   191: invokestatic 228	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   194: pop
    //   195: aload 4
    //   197: aconst_null
    //   198: invokevirtual 232	android/print/PrintDocumentAdapter$WriteResultCallback:onWriteFailed	(Ljava/lang/CharSequence;)V
    //   201: goto -51 -> 150
    //   204: astore 7
    //   206: aload 5
    //   208: ifnull +8 -> 216
    //   211: aload 5
    //   213: invokevirtual 218	android/print/pdf/PrintedPdfDocument:close	()V
    //   216: aload_2
    //   217: ifnull +7 -> 224
    //   220: aload_2
    //   221: invokevirtual 219	android/os/ParcelFileDescriptor:close	()V
    //   224: aload 6
    //   226: aload_0
    //   227: getfield 38	android/support/v4/i/f:b	Landroid/graphics/Bitmap;
    //   230: if_acmpeq +8 -> 238
    //   233: aload 6
    //   235: invokevirtual 73	android/graphics/Bitmap:recycle	()V
    //   238: aload 7
    //   240: athrow
    //   241: astore 14
    //   243: goto -75 -> 168
    //   246: astore 8
    //   248: goto -24 -> 224
    //
    // Exception table:
    //   from	to	target	type
    //   114	150	183	java/io/IOException
    //   40	114	204	finally
    //   114	150	204	finally
    //   185	201	204	finally
    //   164	168	241	java/io/IOException
    //   220	224	246	java/io/IOException
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.i.f
 * JD-Core Version:    0.6.2
 */