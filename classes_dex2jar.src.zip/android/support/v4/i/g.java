package android.support.v4.i;

import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.CancellationSignal;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter.LayoutResultCallback;
import android.print.PrintDocumentInfo;
import android.print.PrintDocumentInfo.Builder;
import java.io.FileNotFoundException;

class g extends AsyncTask<Uri, Boolean, Bitmap>
{
  g(f paramf, CancellationSignal paramCancellationSignal, PrintAttributes paramPrintAttributes1, PrintAttributes paramPrintAttributes2, PrintDocumentAdapter.LayoutResultCallback paramLayoutResultCallback)
  {
  }

  protected Bitmap a(Uri[] paramArrayOfUri)
  {
    try
    {
      Bitmap localBitmap = d.a(this.e.g, this.e.d, 3500);
      return localBitmap;
    }
    catch (FileNotFoundException localFileNotFoundException)
    {
    }
    return null;
  }

  protected void a(Bitmap paramBitmap)
  {
    int i = 1;
    super.onPostExecute(paramBitmap);
    this.e.b = paramBitmap;
    if (paramBitmap != null)
    {
      PrintDocumentInfo localPrintDocumentInfo = new PrintDocumentInfo.Builder(this.e.c).setContentType(i).setPageCount(i).build();
      if (!this.b.equals(this.c))
        this.d.onLayoutFinished(localPrintDocumentInfo, i);
    }
    while (true)
    {
      this.e.a = null;
      return;
      int j = 0;
      break;
      this.d.onLayoutFailed(null);
    }
  }

  protected void b(Bitmap paramBitmap)
  {
    this.d.onLayoutCancelled();
    this.e.a = null;
  }

  protected void onPreExecute()
  {
    this.a.setOnCancelListener(new h(this));
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.i.g
 * JD-Core Version:    0.6.2
 */