package android.support.v4.i;

import android.os.CancellationSignal.OnCancelListener;

class h
  implements CancellationSignal.OnCancelListener
{
  h(g paramg)
  {
  }

  public void onCancel()
  {
    f.a(this.a.e);
    this.a.cancel(false);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.i.h
 * JD-Core Version:    0.6.2
 */