package android.support.v4.j;

import android.content.Context;
import android.net.Uri;
import android.os.Build.VERSION;
import java.io.File;

public abstract class a
{
  static final String a = "DocumentFile";
  private final a b;

  a(a parama)
  {
    this.b = parama;
  }

  public static a a(Context paramContext, Uri paramUri)
  {
    if (Build.VERSION.SDK_INT >= 19)
      return new e(null, paramContext, paramUri);
    return null;
  }

  public static a a(File paramFile)
  {
    return new d(null, paramFile);
  }

  public static a b(Context paramContext, Uri paramUri)
  {
    if (Build.VERSION.SDK_INT >= 21)
      return new f(null, paramContext, c.a(paramUri));
    return null;
  }

  public static boolean c(Context paramContext, Uri paramUri)
  {
    if (Build.VERSION.SDK_INT >= 19)
      return b.a(paramContext, paramUri);
    return false;
  }

  public abstract Uri a();

  public abstract a a(String paramString);

  public abstract a a(String paramString1, String paramString2);

  public a b(String paramString)
  {
    for (a locala : m())
      if (paramString.equals(locala.b()))
        return locala;
    return null;
  }

  public abstract String b();

  public abstract String c();

  public abstract boolean c(String paramString);

  public a d()
  {
    return this.b;
  }

  public abstract boolean e();

  public abstract boolean f();

  public abstract long g();

  public abstract long h();

  public abstract boolean i();

  public abstract boolean j();

  public abstract boolean k();

  public abstract boolean l();

  public abstract a[] m();
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.j.a
 * JD-Core Version:    0.6.2
 */