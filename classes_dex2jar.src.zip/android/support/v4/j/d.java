package android.support.v4.j;

import android.net.Uri;
import android.util.Log;
import android.webkit.MimeTypeMap;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

class d extends a
{
  private File b;

  d(a parama, File paramFile)
  {
    super(parama);
    this.b = paramFile;
  }

  private static boolean b(File paramFile)
  {
    File[] arrayOfFile = paramFile.listFiles();
    boolean bool = true;
    if (arrayOfFile != null)
    {
      int i = arrayOfFile.length;
      for (int j = 0; j < i; j++)
      {
        File localFile = arrayOfFile[j];
        if (localFile.isDirectory())
          bool &= b(localFile);
        if (!localFile.delete())
        {
          Log.w("DocumentFile", "Failed to delete " + localFile);
          bool = false;
        }
      }
    }
    return bool;
  }

  private static String d(String paramString)
  {
    int i = paramString.lastIndexOf('.');
    if (i >= 0)
    {
      String str1 = paramString.substring(i + 1).toLowerCase();
      String str2 = MimeTypeMap.getSingleton().getMimeTypeFromExtension(str1);
      if (str2 != null)
        return str2;
    }
    return "application/octet-stream";
  }

  public Uri a()
  {
    return Uri.fromFile(this.b);
  }

  public a a(String paramString)
  {
    File localFile = new File(this.b, paramString);
    if ((localFile.isDirectory()) || (localFile.mkdir()))
      return new d(this, localFile);
    return null;
  }

  public a a(String paramString1, String paramString2)
  {
    String str = MimeTypeMap.getSingleton().getExtensionFromMimeType(paramString1);
    if (str != null)
      paramString2 = paramString2 + "." + str;
    File localFile = new File(this.b, paramString2);
    try
    {
      localFile.createNewFile();
      d locald = new d(this, localFile);
      return locald;
    }
    catch (IOException localIOException)
    {
      Log.w("DocumentFile", "Failed to createFile: " + localIOException);
    }
    return null;
  }

  public String b()
  {
    return this.b.getName();
  }

  public String c()
  {
    if (this.b.isDirectory())
      return null;
    return d(this.b.getName());
  }

  public boolean c(String paramString)
  {
    File localFile = new File(this.b.getParentFile(), paramString);
    if (this.b.renameTo(localFile))
    {
      this.b = localFile;
      return true;
    }
    return false;
  }

  public boolean e()
  {
    return this.b.isDirectory();
  }

  public boolean f()
  {
    return this.b.isFile();
  }

  public long g()
  {
    return this.b.lastModified();
  }

  public long h()
  {
    return this.b.length();
  }

  public boolean i()
  {
    return this.b.canRead();
  }

  public boolean j()
  {
    return this.b.canWrite();
  }

  public boolean k()
  {
    b(this.b);
    return this.b.delete();
  }

  public boolean l()
  {
    return this.b.exists();
  }

  public a[] m()
  {
    ArrayList localArrayList = new ArrayList();
    File[] arrayOfFile = this.b.listFiles();
    if (arrayOfFile != null)
    {
      int i = arrayOfFile.length;
      for (int j = 0; j < i; j++)
        localArrayList.add(new d(this, arrayOfFile[j]));
    }
    return (a[])localArrayList.toArray(new a[localArrayList.size()]);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.j.d
 * JD-Core Version:    0.6.2
 */