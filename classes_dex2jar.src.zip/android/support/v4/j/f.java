package android.support.v4.j;

import android.content.Context;
import android.net.Uri;

class f extends a
{
  private Context b;
  private Uri c;

  f(a parama, Context paramContext, Uri paramUri)
  {
    super(parama);
    this.b = paramContext;
    this.c = paramUri;
  }

  public Uri a()
  {
    return this.c;
  }

  public a a(String paramString)
  {
    Uri localUri = c.a(this.b, this.c, paramString);
    if (localUri != null)
      return new f(this, this.b, localUri);
    return null;
  }

  public a a(String paramString1, String paramString2)
  {
    Uri localUri = c.a(this.b, this.c, paramString1, paramString2);
    if (localUri != null)
      return new f(this, this.b, localUri);
    return null;
  }

  public String b()
  {
    return b.b(this.b, this.c);
  }

  public String c()
  {
    return b.c(this.b, this.c);
  }

  public boolean c(String paramString)
  {
    Uri localUri = c.b(this.b, this.c, paramString);
    if (localUri != null)
    {
      this.c = localUri;
      return true;
    }
    return false;
  }

  public boolean e()
  {
    return b.d(this.b, this.c);
  }

  public boolean f()
  {
    return b.e(this.b, this.c);
  }

  public long g()
  {
    return b.f(this.b, this.c);
  }

  public long h()
  {
    return b.g(this.b, this.c);
  }

  public boolean i()
  {
    return b.h(this.b, this.c);
  }

  public boolean j()
  {
    return b.i(this.b, this.c);
  }

  public boolean k()
  {
    return b.j(this.b, this.c);
  }

  public boolean l()
  {
    return b.k(this.b, this.c);
  }

  public a[] m()
  {
    Uri[] arrayOfUri = c.a(this.b, this.c);
    a[] arrayOfa = new a[arrayOfUri.length];
    for (int i = 0; i < arrayOfUri.length; i++)
      arrayOfa[i] = new f(this, this.b, arrayOfUri[i]);
    return arrayOfa;
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.j.f
 * JD-Core Version:    0.6.2
 */