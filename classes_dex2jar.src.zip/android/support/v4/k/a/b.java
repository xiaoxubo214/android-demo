package android.support.v4.k.a;

import android.os.Build.VERSION;
import android.speech.tts.TextToSpeech;
import java.util.Locale;
import java.util.Set;

class b
{
  public static final String a = "embeddedTts";
  public static final String b = "networkTts";

  static Set<String> a(TextToSpeech paramTextToSpeech, Locale paramLocale)
  {
    if (Build.VERSION.SDK_INT >= 15)
      return paramTextToSpeech.getFeatures(paramLocale);
    return null;
  }

  static void a(TextToSpeech paramTextToSpeech, a parama)
  {
    if (Build.VERSION.SDK_INT >= 15)
    {
      paramTextToSpeech.setOnUtteranceProgressListener(new c(parama));
      return;
    }
    paramTextToSpeech.setOnUtteranceCompletedListener(new d(parama));
  }

  static abstract interface a
  {
    public abstract void a(String paramString);

    public abstract void b(String paramString);

    public abstract void c(String paramString);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.k.a.b
 * JD-Core Version:    0.6.2
 */