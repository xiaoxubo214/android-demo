package android.support.v4.k.a;

import android.speech.tts.UtteranceProgressListener;

final class c extends UtteranceProgressListener
{
  c(b.a parama)
  {
  }

  public void onDone(String paramString)
  {
    this.a.a(paramString);
  }

  public void onError(String paramString)
  {
    this.a.b(paramString);
  }

  public void onStart(String paramString)
  {
    this.a.c(paramString);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.k.a.c
 * JD-Core Version:    0.6.2
 */