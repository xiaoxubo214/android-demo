package android.support.v4.k.a;

import android.speech.tts.TextToSpeech.OnUtteranceCompletedListener;

final class d
  implements TextToSpeech.OnUtteranceCompletedListener
{
  d(b.a parama)
  {
  }

  public void onUtteranceCompleted(String paramString)
  {
    this.a.c(paramString);
    this.a.a(paramString);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.k.a.d
 * JD-Core Version:    0.6.2
 */