package android.support.v4.l;

import java.util.Locale;

public final class a
{
  private static e a = f.c;
  private static final char b = '‪';
  private static final char c = '‫';
  private static final char d = '‬';
  private static final char e = '‎';
  private static final char f = '‏';
  private static final String g = Character.toString('‎');
  private static final String h = Character.toString('‏');
  private static final String i = "";
  private static final int j = 2;
  private static final int k = 2;
  private static final a l = new a(false, 2, a);
  private static final a m = new a(true, 2, a);
  private static final int q = -1;
  private static final int r = 0;
  private static final int s = 1;
  private final boolean n;
  private final int o;
  private final e p;

  private a(boolean paramBoolean, int paramInt, e parame)
  {
    this.n = paramBoolean;
    this.o = paramInt;
    this.p = parame;
  }

  public static a a()
  {
    return new a().a();
  }

  public static a a(Locale paramLocale)
  {
    return new a(paramLocale).a();
  }

  public static a a(boolean paramBoolean)
  {
    return new a(paramBoolean).a();
  }

  private String b(String paramString, e parame)
  {
    boolean bool = parame.a(paramString, 0, paramString.length());
    if ((!this.n) && ((bool) || (c(paramString) == 1)))
      return g;
    if ((this.n) && ((!bool) || (c(paramString) == -1)))
      return h;
    return "";
  }

  private static int c(String paramString)
  {
    return new b(paramString, false).b();
  }

  private String c(String paramString, e parame)
  {
    boolean bool = parame.a(paramString, 0, paramString.length());
    if ((!this.n) && ((bool) || (d(paramString) == 1)))
      return g;
    if ((this.n) && ((!bool) || (d(paramString) == -1)))
      return h;
    return "";
  }

  private static boolean c(Locale paramLocale)
  {
    return g.a(paramLocale) == 1;
  }

  private static int d(String paramString)
  {
    return new b(paramString, false).a();
  }

  public String a(String paramString, e parame)
  {
    return a(paramString, parame, true);
  }

  public String a(String paramString, e parame, boolean paramBoolean)
  {
    if (paramString == null)
      return null;
    boolean bool = parame.a(paramString, 0, paramString.length());
    StringBuilder localStringBuilder = new StringBuilder();
    e locale2;
    if ((c()) && (paramBoolean))
    {
      if (bool)
      {
        locale2 = f.b;
        localStringBuilder.append(c(paramString, locale2));
      }
    }
    else
    {
      if (bool == this.n)
        break label155;
      if (!bool)
        break label147;
      int i1 = 8235;
      label82: localStringBuilder.append(i1);
      localStringBuilder.append(paramString);
      localStringBuilder.append('‬');
      label106: if (paramBoolean)
        if (!bool)
          break label165;
    }
    label147: label155: label165: for (e locale1 = f.b; ; locale1 = f.a)
    {
      localStringBuilder.append(b(paramString, locale1));
      return localStringBuilder.toString();
      locale2 = f.a;
      break;
      int i2 = 8234;
      break label82;
      localStringBuilder.append(paramString);
      break label106;
    }
  }

  public String a(String paramString, boolean paramBoolean)
  {
    return a(paramString, this.p, paramBoolean);
  }

  public boolean a(String paramString)
  {
    return this.p.a(paramString, 0, paramString.length());
  }

  public String b(String paramString)
  {
    return a(paramString, this.p, true);
  }

  public boolean b()
  {
    return this.n;
  }

  public boolean c()
  {
    return (0x2 & this.o) != 0;
  }

  public static final class a
  {
    private boolean a;
    private int b;
    private e c;

    public a()
    {
      b(a.b(Locale.getDefault()));
    }

    public a(Locale paramLocale)
    {
      b(a.b(paramLocale));
    }

    public a(boolean paramBoolean)
    {
      b(paramBoolean);
    }

    private void b(boolean paramBoolean)
    {
      this.a = paramBoolean;
      this.c = a.d();
      this.b = 2;
    }

    private static a c(boolean paramBoolean)
    {
      if (paramBoolean)
        return a.e();
      return a.f();
    }

    public a a(e parame)
    {
      this.c = parame;
      return this;
    }

    public a a(boolean paramBoolean)
    {
      if (paramBoolean)
      {
        this.b = (0x2 | this.b);
        return this;
      }
      this.b = (0xFFFFFFFD & this.b);
      return this;
    }

    public a a()
    {
      if ((this.b == 2) && (this.c == a.d()))
        return c(this.a);
      return new a(this.a, this.b, this.c, null);
    }
  }

  private static class b
  {
    private static final int a = 1792;
    private static final byte[] b = new byte[1792];
    private final String c;
    private final boolean d;
    private final int e;
    private int f;
    private char g;

    static
    {
      for (int i = 0; i < 1792; i++)
        b[i] = Character.getDirectionality(i);
    }

    b(String paramString, boolean paramBoolean)
    {
      this.c = paramString;
      this.d = paramBoolean;
      this.e = paramString.length();
    }

    private static byte a(char paramChar)
    {
      if (paramChar < '܀')
        return b[paramChar];
      return Character.getDirectionality(paramChar);
    }

    private byte e()
    {
      int i = this.f;
      label132: 
      while (this.f < this.e)
      {
        String str1 = this.c;
        int j = this.f;
        this.f = (j + 1);
        this.g = str1.charAt(j);
        if (this.g == '>')
          return 12;
        if ((this.g == '"') || (this.g == '\''))
        {
          int k = this.g;
          while (true)
          {
            if (this.f >= this.e)
              break label132;
            String str2 = this.c;
            int m = this.f;
            this.f = (m + 1);
            char c1 = str2.charAt(m);
            this.g = c1;
            if (c1 == k)
              break;
          }
        }
      }
      this.f = i;
      this.g = '<';
      return 13;
    }

    private byte f()
    {
      int i = this.f;
      label147: 
      while (true)
      {
        if (this.f > 0)
        {
          String str1 = this.c;
          int j = -1 + this.f;
          this.f = j;
          this.g = str1.charAt(j);
          if (this.g == '<')
            return 12;
          if (this.g != '>');
        }
        else
        {
          this.f = i;
          this.g = '>';
          return 13;
        }
        if ((this.g == '"') || (this.g == '\''))
        {
          int k = this.g;
          while (true)
          {
            if (this.f <= 0)
              break label147;
            String str2 = this.c;
            int m = -1 + this.f;
            this.f = m;
            char c1 = str2.charAt(m);
            this.g = c1;
            if (c1 == k)
              break;
          }
        }
      }
    }

    private byte g()
    {
      char c1;
      do
      {
        if (this.f >= this.e)
          break;
        String str = this.c;
        int i = this.f;
        this.f = (i + 1);
        c1 = str.charAt(i);
        this.g = c1;
      }
      while (c1 != ';');
      return 12;
    }

    private byte h()
    {
      int i = this.f;
      do
      {
        if (this.f <= 0)
          break;
        String str = this.c;
        int j = -1 + this.f;
        this.f = j;
        this.g = str.charAt(j);
        if (this.g == '&')
          return 12;
      }
      while (this.g != ';');
      this.f = i;
      this.g = ';';
      return 13;
    }

    int a()
    {
      this.f = 0;
      int i = 0;
      int j = 0;
      int k = 0;
      while ((this.f < this.e) && (i == 0))
        switch (c())
        {
        case 9:
        case 3:
        case 4:
        case 5:
        case 6:
        case 7:
        case 8:
        case 10:
        case 11:
        case 12:
        case 13:
        default:
          i = k;
          break;
        case 14:
        case 15:
          k++;
          j = -1;
          break;
        case 16:
        case 17:
          k++;
          j = 1;
          break;
        case 18:
          k--;
          j = 0;
          break;
        case 0:
          if (k == 0)
            return -1;
          i = k;
          break;
        case 1:
        case 2:
          if (k == 0)
            return 1;
          i = k;
        }
      if (i == 0)
        return 0;
      if (j != 0)
        return j;
      while (true)
      {
        if (this.f <= 0)
          break label261;
        switch (d())
        {
        default:
          break;
        case 14:
        case 15:
          if (i == k)
            break;
          k--;
          break;
        case 16:
        case 17:
          if (i == k)
            return 1;
          k--;
          break;
        case 18:
          k++;
        }
      }
      label261: return 0;
    }

    int b()
    {
      this.f = this.e;
      int i = 0;
      int j = 0;
      while (true)
      {
        int k = this.f;
        int m = 0;
        if (k > 0);
        switch (d())
        {
        case 9:
        case 3:
        case 4:
        case 5:
        case 6:
        case 7:
        case 8:
        case 10:
        case 11:
        case 12:
        case 13:
        default:
          if (i == 0)
            i = j;
          break;
        case 0:
          if (j == 0)
          {
            m = -1;
            return m;
          }
          if (i == 0)
            i = j;
          break;
        case 14:
        case 15:
          if (i == j)
            return -1;
          j--;
          break;
        case 1:
        case 2:
          if (j == 0)
            return 1;
          if (i == 0)
            i = j;
          break;
        case 16:
        case 17:
          if (i == j)
            return 1;
          j--;
          break;
        case 18:
          j++;
        }
      }
    }

    byte c()
    {
      this.g = this.c.charAt(this.f);
      byte b1;
      if (Character.isHighSurrogate(this.g))
      {
        int i = Character.codePointAt(this.c, this.f);
        this.f += Character.charCount(i);
        b1 = Character.getDirectionality(i);
      }
      do
      {
        do
        {
          return b1;
          this.f = (1 + this.f);
          b1 = a(this.g);
        }
        while (!this.d);
        if (this.g == '<')
          return e();
      }
      while (this.g != '&');
      return g();
    }

    byte d()
    {
      this.g = this.c.charAt(-1 + this.f);
      byte b1;
      if (Character.isLowSurrogate(this.g))
      {
        int i = Character.codePointBefore(this.c, this.f);
        this.f -= Character.charCount(i);
        b1 = Character.getDirectionality(i);
      }
      do
      {
        do
        {
          return b1;
          this.f = (-1 + this.f);
          b1 = a(this.g);
        }
        while (!this.d);
        if (this.g == '>')
          return f();
      }
      while (this.g != ';');
      return h();
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.l.a
 * JD-Core Version:    0.6.2
 */