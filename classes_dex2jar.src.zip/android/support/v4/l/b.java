package android.support.v4.l;

import android.os.Build.VERSION;
import java.util.Locale;

public final class b
{
  private static final a a = new b();

  static
  {
    int i = Build.VERSION.SDK_INT;
    if (i >= 21)
    {
      a = new d();
      return;
    }
    if (i >= 14)
    {
      a = new c();
      return;
    }
  }

  public static String a(Locale paramLocale)
  {
    return a.a(paramLocale);
  }

  static abstract interface a
  {
    public abstract String a(Locale paramLocale);
  }

  static class b
    implements b.a
  {
    public String a(Locale paramLocale)
    {
      return null;
    }
  }

  static class c
    implements b.a
  {
    public String a(Locale paramLocale)
    {
      return d.a(paramLocale);
    }
  }

  static class d
    implements b.a
  {
    public String a(Locale paramLocale)
    {
      return c.a(paramLocale);
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.l.b
 * JD-Core Version:    0.6.2
 */