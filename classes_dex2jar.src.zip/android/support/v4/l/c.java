package android.support.v4.l;

import android.util.Log;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Locale;

class c
{
  private static final String a = "ICUCompatIcs";
  private static Method b;

  static
  {
    try
    {
      b = Class.forName("libcore.icu.ICU").getMethod("addLikelySubtags", new Class[] { Locale.class });
      return;
    }
    catch (Exception localException)
    {
      throw new IllegalStateException(localException);
    }
  }

  public static String a(Locale paramLocale)
  {
    try
    {
      Object[] arrayOfObject = { paramLocale };
      String str = ((Locale)b.invoke(null, arrayOfObject)).getScript();
      return str;
    }
    catch (InvocationTargetException localInvocationTargetException)
    {
      Log.w("ICUCompatIcs", localInvocationTargetException);
      return paramLocale.getScript();
    }
    catch (IllegalAccessException localIllegalAccessException)
    {
      while (true)
        Log.w("ICUCompatIcs", localIllegalAccessException);
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.l.c
 * JD-Core Version:    0.6.2
 */