package android.support.v4.l;

import java.nio.CharBuffer;
import java.util.Locale;

public final class f
{
  public static final e a = new e(null, false, null);
  public static final e b = new e(null, true, null);
  public static final e c = new e(b.a, false, null);
  public static final e d = new e(b.a, true, null);
  public static final e e = new e(a.a, false, null);
  public static final e f = f.a;
  private static final int g = 0;
  private static final int h = 1;
  private static final int i = 2;

  private static int c(int paramInt)
  {
    switch (paramInt)
    {
    default:
      return 2;
    case 0:
      return 1;
    case 1:
    case 2:
    }
    return 0;
  }

  private static int d(int paramInt)
  {
    switch (paramInt)
    {
    default:
      return 2;
    case 0:
    case 14:
    case 15:
      return 1;
    case 1:
    case 2:
    case 16:
    case 17:
    }
    return 0;
  }

  private static class a
    implements f.c
  {
    public static final a a = new a(true);
    public static final a b = new a(false);
    private final boolean c;

    private a(boolean paramBoolean)
    {
      this.c = paramBoolean;
    }

    public int a(CharSequence paramCharSequence, int paramInt1, int paramInt2)
    {
      int i = 1;
      int j = paramInt1 + paramInt2;
      int k = 0;
      while (true)
        if (paramInt1 < j)
          switch (f.b(Character.getDirectionality(paramCharSequence.charAt(paramInt1))))
          {
          default:
            paramInt1++;
            break;
          case 0:
            if (this.c)
              i = 0;
            break;
          case 1:
          }
      do
      {
        do
        {
          return i;
          k = i;
          break;
        }
        while (!this.c);
        k = i;
        break;
        if (k == 0)
          break label106;
      }
      while (this.c);
      return 0;
      label106: return 2;
    }
  }

  private static class b
    implements f.c
  {
    public static final b a = new b();

    public int a(CharSequence paramCharSequence, int paramInt1, int paramInt2)
    {
      int i = paramInt1 + paramInt2;
      int j = 2;
      while ((paramInt1 < i) && (j == 2))
      {
        j = f.a(Character.getDirectionality(paramCharSequence.charAt(paramInt1)));
        paramInt1++;
      }
      return j;
    }
  }

  private static abstract interface c
  {
    public abstract int a(CharSequence paramCharSequence, int paramInt1, int paramInt2);
  }

  private static abstract class d
    implements e
  {
    private final f.c a;

    public d(f.c paramc)
    {
      this.a = paramc;
    }

    private boolean b(CharSequence paramCharSequence, int paramInt1, int paramInt2)
    {
      switch (this.a.a(paramCharSequence, paramInt1, paramInt2))
      {
      default:
        return a();
      case 0:
        return true;
      case 1:
      }
      return false;
    }

    protected abstract boolean a();

    public boolean a(CharSequence paramCharSequence, int paramInt1, int paramInt2)
    {
      if ((paramCharSequence == null) || (paramInt1 < 0) || (paramInt2 < 0) || (paramCharSequence.length() - paramInt2 < paramInt1))
        throw new IllegalArgumentException();
      if (this.a == null)
        return a();
      return b(paramCharSequence, paramInt1, paramInt2);
    }

    public boolean a(char[] paramArrayOfChar, int paramInt1, int paramInt2)
    {
      return a(CharBuffer.wrap(paramArrayOfChar), paramInt1, paramInt2);
    }
  }

  private static class e extends f.d
  {
    private final boolean a;

    private e(f.c paramc, boolean paramBoolean)
    {
      super();
      this.a = paramBoolean;
    }

    protected boolean a()
    {
      return this.a;
    }
  }

  private static class f extends f.d
  {
    public static final f a = new f();

    public f()
    {
      super();
    }

    protected boolean a()
    {
      return g.a(Locale.getDefault()) == 1;
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.l.f
 * JD-Core Version:    0.6.2
 */