package android.support.v4.l;

import android.os.Build.VERSION;
import android.support.annotation.x;
import android.support.annotation.y;
import java.util.Locale;

public final class g
{
  public static final Locale a;
  private static final a b;
  private static String c;
  private static String d;

  static
  {
    if (Build.VERSION.SDK_INT >= 17);
    for (b = new b(null); ; b = new a(null))
    {
      a = new Locale("", "");
      c = "Arab";
      d = "Hebr";
      return;
    }
  }

  public static int a(@y Locale paramLocale)
  {
    return b.a(paramLocale);
  }

  @x
  public static String a(@x String paramString)
  {
    return b.a(paramString);
  }

  private static class a
  {
    private static int b(@x Locale paramLocale)
    {
      switch (Character.getDirectionality(paramLocale.getDisplayName(paramLocale).charAt(0)))
      {
      default:
        return 0;
      case 1:
      case 2:
      }
      return 1;
    }

    public int a(@y Locale paramLocale)
    {
      if ((paramLocale != null) && (!paramLocale.equals(g.a)))
      {
        String str = b.a(paramLocale);
        if (str == null)
          return b(paramLocale);
        if ((str.equalsIgnoreCase(g.a())) || (str.equalsIgnoreCase(g.b())))
          return 1;
      }
      return 0;
    }

    @x
    public String a(@x String paramString)
    {
      StringBuilder localStringBuilder = new StringBuilder();
      int i = 0;
      if (i < paramString.length())
      {
        char c = paramString.charAt(i);
        switch (c)
        {
        default:
          localStringBuilder.append(c);
        case '<':
        case '>':
        case '&':
        case '\'':
        case '"':
        }
        while (true)
        {
          i++;
          break;
          localStringBuilder.append("&lt;");
          continue;
          localStringBuilder.append("&gt;");
          continue;
          localStringBuilder.append("&amp;");
          continue;
          localStringBuilder.append("&#39;");
          continue;
          localStringBuilder.append("&quot;");
        }
      }
      return localStringBuilder.toString();
    }
  }

  private static class b extends g.a
  {
    private b()
    {
      super();
    }

    public int a(@y Locale paramLocale)
    {
      return h.a(paramLocale);
    }

    @x
    public String a(@x String paramString)
    {
      return h.a(paramString);
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.l.g
 * JD-Core Version:    0.6.2
 */