package android.support.v4.l;

import android.support.annotation.x;
import android.support.annotation.y;
import android.text.TextUtils;
import java.util.Locale;

class h
{
  public static int a(@y Locale paramLocale)
  {
    return TextUtils.getLayoutDirectionFromLocale(paramLocale);
  }

  @x
  public static String a(@x String paramString)
  {
    return TextUtils.htmlEncode(paramString);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.l.h
 * JD-Core Version:    0.6.2
 */