package android.support.v4.m;

import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class a<K, V> extends n<K, V>
  implements Map<K, V>
{
  k<K, V> a;

  public a()
  {
  }

  public a(int paramInt)
  {
    super(paramInt);
  }

  public a(n paramn)
  {
    super(paramn);
  }

  private k<K, V> b()
  {
    if (this.a == null)
      this.a = new b(this);
    return this.a;
  }

  public boolean a(Collection<?> paramCollection)
  {
    return k.a(this, paramCollection);
  }

  public boolean b(Collection<?> paramCollection)
  {
    return k.b(this, paramCollection);
  }

  public boolean c(Collection<?> paramCollection)
  {
    return k.c(this, paramCollection);
  }

  public Set<Map.Entry<K, V>> entrySet()
  {
    return b().d();
  }

  public Set<K> keySet()
  {
    return b().e();
  }

  public void putAll(Map<? extends K, ? extends V> paramMap)
  {
    a(this.h + paramMap.size());
    Iterator localIterator = paramMap.entrySet().iterator();
    while (localIterator.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      put(localEntry.getKey(), localEntry.getValue());
    }
  }

  public Collection<V> values()
  {
    return b().f();
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.m.a
 * JD-Core Version:    0.6.2
 */