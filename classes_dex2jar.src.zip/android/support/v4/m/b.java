package android.support.v4.m;

import java.util.Map;

class b extends k<K, V>
{
  b(a parama)
  {
  }

  protected int a()
  {
    return this.a.h;
  }

  protected int a(Object paramObject)
  {
    return this.a.a(paramObject);
  }

  protected Object a(int paramInt1, int paramInt2)
  {
    return this.a.g[(paramInt2 + (paramInt1 << 1))];
  }

  protected V a(int paramInt, V paramV)
  {
    return this.a.a(paramInt, paramV);
  }

  protected void a(int paramInt)
  {
    this.a.d(paramInt);
  }

  protected void a(K paramK, V paramV)
  {
    this.a.put(paramK, paramV);
  }

  protected int b(Object paramObject)
  {
    return this.a.b(paramObject);
  }

  protected Map<K, V> b()
  {
    return this.a;
  }

  protected void c()
  {
    this.a.clear();
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.m.b
 * JD-Core Version:    0.6.2
 */