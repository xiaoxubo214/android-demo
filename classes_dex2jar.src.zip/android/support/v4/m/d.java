package android.support.v4.m;

public final class d<E>
{
  private E[] a;
  private int b;
  private int c;
  private int d;

  public d()
  {
    this(8);
  }

  public d(int paramInt)
  {
    if (paramInt <= 0)
      throw new IllegalArgumentException("capacity must be positive");
    if (Integer.bitCount(paramInt) != 1)
      paramInt = 1 << 1 + Integer.highestOneBit(paramInt);
    this.d = (paramInt - 1);
    this.a = ((Object[])new Object[paramInt]);
  }

  private void h()
  {
    int i = this.a.length;
    int j = i - this.b;
    int k = i << 1;
    if (k < 0)
      throw new RuntimeException("Max array capacity exceeded");
    Object[] arrayOfObject = new Object[k];
    System.arraycopy(this.a, this.b, arrayOfObject, 0, j);
    System.arraycopy(this.a, 0, arrayOfObject, j, this.b);
    this.a = ((Object[])arrayOfObject);
    this.b = 0;
    this.c = i;
    this.d = (k - 1);
  }

  public E a()
  {
    if (this.b == this.c)
      throw new ArrayIndexOutOfBoundsException();
    Object localObject = this.a[this.b];
    this.a[this.b] = null;
    this.b = (1 + this.b & this.d);
    return localObject;
  }

  public void a(int paramInt)
  {
    if (paramInt <= 0);
    int m;
    do
    {
      return;
      if (paramInt > f())
        throw new ArrayIndexOutOfBoundsException();
      int i = this.a.length;
      if (paramInt < i - this.b)
        i = paramInt + this.b;
      for (int j = this.b; j < i; j++)
        this.a[j] = null;
      int k = i - this.b;
      m = paramInt - k;
      this.b = (k + this.b & this.d);
    }
    while (m <= 0);
    for (int n = 0; n < m; n++)
      this.a[n] = null;
    this.b = m;
  }

  public void a(E paramE)
  {
    this.b = (-1 + this.b & this.d);
    this.a[this.b] = paramE;
    if (this.b == this.c)
      h();
  }

  public E b()
  {
    if (this.b == this.c)
      throw new ArrayIndexOutOfBoundsException();
    int i = -1 + this.c & this.d;
    Object localObject = this.a[i];
    this.a[i] = null;
    this.c = i;
    return localObject;
  }

  public void b(int paramInt)
  {
    if (paramInt <= 0);
    int n;
    do
    {
      return;
      if (paramInt > f())
        throw new ArrayIndexOutOfBoundsException();
      int i = this.c;
      int j = 0;
      if (paramInt < i)
        j = this.c - paramInt;
      for (int k = j; k < this.c; k++)
        this.a[k] = null;
      int m = this.c - j;
      n = paramInt - m;
      this.c -= m;
    }
    while (n <= 0);
    this.c = this.a.length;
    int i1 = this.c - n;
    for (int i2 = i1; i2 < this.c; i2++)
      this.a[i2] = null;
    this.c = i1;
  }

  public void b(E paramE)
  {
    this.a[this.c] = paramE;
    this.c = (1 + this.c & this.d);
    if (this.c == this.b)
      h();
  }

  public E c(int paramInt)
  {
    if ((paramInt < 0) || (paramInt >= f()))
      throw new ArrayIndexOutOfBoundsException();
    return this.a[(paramInt + this.b & this.d)];
  }

  public void c()
  {
    a(f());
  }

  public E d()
  {
    if (this.b == this.c)
      throw new ArrayIndexOutOfBoundsException();
    return this.a[this.b];
  }

  public E e()
  {
    if (this.b == this.c)
      throw new ArrayIndexOutOfBoundsException();
    return this.a[(-1 + this.c & this.d)];
  }

  public int f()
  {
    return this.c - this.b & this.d;
  }

  public boolean g()
  {
    return this.b == this.c;
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.m.d
 * JD-Core Version:    0.6.2
 */