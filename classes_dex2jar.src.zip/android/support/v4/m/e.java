package android.support.v4.m;

public final class e
{
  private int[] a;
  private int b;
  private int c;
  private int d;

  public e()
  {
    this(8);
  }

  public e(int paramInt)
  {
    if (paramInt <= 0)
      throw new IllegalArgumentException("capacity must be positive");
    if (Integer.bitCount(paramInt) != 1)
      paramInt = 1 << 1 + Integer.highestOneBit(paramInt);
    this.d = (paramInt - 1);
    this.a = new int[paramInt];
  }

  private void h()
  {
    int i = this.a.length;
    int j = i - this.b;
    int k = i << 1;
    if (k < 0)
      throw new RuntimeException("Max array capacity exceeded");
    int[] arrayOfInt = new int[k];
    System.arraycopy(this.a, this.b, arrayOfInt, 0, j);
    System.arraycopy(this.a, 0, arrayOfInt, j, this.b);
    this.a = arrayOfInt;
    this.b = 0;
    this.c = i;
    this.d = (k - 1);
  }

  public int a()
  {
    if (this.b == this.c)
      throw new ArrayIndexOutOfBoundsException();
    int i = this.a[this.b];
    this.b = (1 + this.b & this.d);
    return i;
  }

  public void a(int paramInt)
  {
    this.b = (-1 + this.b & this.d);
    this.a[this.b] = paramInt;
    if (this.b == this.c)
      h();
  }

  public int b()
  {
    if (this.b == this.c)
      throw new ArrayIndexOutOfBoundsException();
    int i = -1 + this.c & this.d;
    int j = this.a[i];
    this.c = i;
    return j;
  }

  public void b(int paramInt)
  {
    this.a[this.c] = paramInt;
    this.c = (1 + this.c & this.d);
    if (this.c == this.b)
      h();
  }

  public void c()
  {
    this.c = this.b;
  }

  public void c(int paramInt)
  {
    if (paramInt <= 0)
      return;
    if (paramInt > f())
      throw new ArrayIndexOutOfBoundsException();
    this.b = (paramInt + this.b & this.d);
  }

  public int d()
  {
    if (this.b == this.c)
      throw new ArrayIndexOutOfBoundsException();
    return this.a[this.b];
  }

  public void d(int paramInt)
  {
    if (paramInt <= 0)
      return;
    if (paramInt > f())
      throw new ArrayIndexOutOfBoundsException();
    this.c = (this.c - paramInt & this.d);
  }

  public int e()
  {
    if (this.b == this.c)
      throw new ArrayIndexOutOfBoundsException();
    return this.a[(-1 + this.c & this.d)];
  }

  public int e(int paramInt)
  {
    if ((paramInt < 0) || (paramInt >= f()))
      throw new ArrayIndexOutOfBoundsException();
    return this.a[(paramInt + this.b & this.d)];
  }

  public int f()
  {
    return this.c - this.b & this.d;
  }

  public boolean g()
  {
    return this.b == this.c;
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.m.e
 * JD-Core Version:    0.6.2
 */