package android.support.v4.m;

public class i<E>
  implements Cloneable
{
  private static final Object a = new Object();
  private boolean b = false;
  private long[] c;
  private Object[] d;
  private int e;

  public i()
  {
    this(10);
  }

  public i(int paramInt)
  {
    if (paramInt == 0)
      this.c = f.b;
    int i;
    for (this.d = f.c; ; this.d = new Object[i])
    {
      this.e = 0;
      return;
      i = f.b(paramInt);
      this.c = new long[i];
    }
  }

  private void d()
  {
    int i = this.e;
    long[] arrayOfLong = this.c;
    Object[] arrayOfObject = this.d;
    int j = 0;
    int k = 0;
    while (j < i)
    {
      Object localObject = arrayOfObject[j];
      if (localObject != a)
      {
        if (j != k)
        {
          arrayOfLong[k] = arrayOfLong[j];
          arrayOfObject[k] = localObject;
          arrayOfObject[j] = null;
        }
        k++;
      }
      j++;
    }
    this.b = false;
    this.e = k;
  }

  public int a(E paramE)
  {
    if (this.b)
      d();
    for (int i = 0; i < this.e; i++)
      if (this.d[i] == paramE)
        return i;
    return -1;
  }

  // ERROR //
  public i<E> a()
  {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial 54	java/lang/Object:clone	()Ljava/lang/Object;
    //   4: checkcast 2	android/support/v4/m/i
    //   7: astore_2
    //   8: aload_2
    //   9: aload_0
    //   10: getfield 35	android/support/v4/m/i:c	[J
    //   13: invokevirtual 56	[J:clone	()Ljava/lang/Object;
    //   16: checkcast 55	[J
    //   19: putfield 35	android/support/v4/m/i:c	[J
    //   22: aload_2
    //   23: aload_0
    //   24: getfield 39	android/support/v4/m/i:d	[Ljava/lang/Object;
    //   27: invokevirtual 58	[Ljava/lang/Object;:clone	()Ljava/lang/Object;
    //   30: checkcast 57	[Ljava/lang/Object;
    //   33: putfield 39	android/support/v4/m/i:d	[Ljava/lang/Object;
    //   36: aload_2
    //   37: areturn
    //   38: astore_1
    //   39: aconst_null
    //   40: areturn
    //   41: astore_3
    //   42: aload_2
    //   43: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   0	8	38	java/lang/CloneNotSupportedException
    //   8	36	41	java/lang/CloneNotSupportedException
  }

  public E a(long paramLong)
  {
    return a(paramLong, null);
  }

  public E a(long paramLong, E paramE)
  {
    int i = f.a(this.c, this.e, paramLong);
    if ((i < 0) || (this.d[i] == a))
      return paramE;
    return this.d[i];
  }

  public void a(int paramInt)
  {
    if (this.d[paramInt] != a)
    {
      this.d[paramInt] = a;
      this.b = true;
    }
  }

  public void a(int paramInt, E paramE)
  {
    if (this.b)
      d();
    this.d[paramInt] = paramE;
  }

  public int b()
  {
    if (this.b)
      d();
    return this.e;
  }

  public long b(int paramInt)
  {
    if (this.b)
      d();
    return this.c[paramInt];
  }

  public void b(long paramLong)
  {
    int i = f.a(this.c, this.e, paramLong);
    if ((i >= 0) && (this.d[i] != a))
    {
      this.d[i] = a;
      this.b = true;
    }
  }

  public void b(long paramLong, E paramE)
  {
    int i = f.a(this.c, this.e, paramLong);
    if (i >= 0)
    {
      this.d[i] = paramE;
      return;
    }
    int j = i ^ 0xFFFFFFFF;
    if ((j < this.e) && (this.d[j] == a))
    {
      this.c[j] = paramLong;
      this.d[j] = paramE;
      return;
    }
    if ((this.b) && (this.e >= this.c.length))
    {
      d();
      j = 0xFFFFFFFF ^ f.a(this.c, this.e, paramLong);
    }
    if (this.e >= this.c.length)
    {
      int k = f.b(1 + this.e);
      long[] arrayOfLong = new long[k];
      Object[] arrayOfObject = new Object[k];
      System.arraycopy(this.c, 0, arrayOfLong, 0, this.c.length);
      System.arraycopy(this.d, 0, arrayOfObject, 0, this.d.length);
      this.c = arrayOfLong;
      this.d = arrayOfObject;
    }
    if (this.e - j != 0)
    {
      System.arraycopy(this.c, j, this.c, j + 1, this.e - j);
      System.arraycopy(this.d, j, this.d, j + 1, this.e - j);
    }
    this.c[j] = paramLong;
    this.d[j] = paramE;
    this.e = (1 + this.e);
  }

  public E c(int paramInt)
  {
    if (this.b)
      d();
    return this.d[paramInt];
  }

  public void c()
  {
    int i = this.e;
    Object[] arrayOfObject = this.d;
    for (int j = 0; j < i; j++)
      arrayOfObject[j] = null;
    this.e = 0;
    this.b = false;
  }

  public void c(long paramLong)
  {
    b(paramLong);
  }

  public void c(long paramLong, E paramE)
  {
    if ((this.e != 0) && (paramLong <= this.c[(-1 + this.e)]))
    {
      b(paramLong, paramE);
      return;
    }
    if ((this.b) && (this.e >= this.c.length))
      d();
    int i = this.e;
    if (i >= this.c.length)
    {
      int j = f.b(i + 1);
      long[] arrayOfLong = new long[j];
      Object[] arrayOfObject = new Object[j];
      System.arraycopy(this.c, 0, arrayOfLong, 0, this.c.length);
      System.arraycopy(this.d, 0, arrayOfObject, 0, this.d.length);
      this.c = arrayOfLong;
      this.d = arrayOfObject;
    }
    this.c[i] = paramLong;
    this.d[i] = paramE;
    this.e = (i + 1);
  }

  public int d(long paramLong)
  {
    if (this.b)
      d();
    return f.a(this.c, this.e, paramLong);
  }

  public String toString()
  {
    if (b() <= 0)
      return "{}";
    StringBuilder localStringBuilder = new StringBuilder(28 * this.e);
    localStringBuilder.append('{');
    int i = 0;
    if (i < this.e)
    {
      if (i > 0)
        localStringBuilder.append(", ");
      localStringBuilder.append(b(i));
      localStringBuilder.append('=');
      Object localObject = c(i);
      if (localObject != this)
        localStringBuilder.append(localObject);
      while (true)
      {
        i++;
        break;
        localStringBuilder.append("(this Map)");
      }
    }
    localStringBuilder.append('}');
    return localStringBuilder.toString();
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.m.i
 * JD-Core Version:    0.6.2
 */