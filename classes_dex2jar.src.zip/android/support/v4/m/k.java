package android.support.v4.m;

import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

abstract class k<K, V>
{
  k<K, V>.b b;
  k<K, V>.c c;
  k<K, V>.e d;

  public static <K, V> boolean a(Map<K, V> paramMap, Collection<?> paramCollection)
  {
    Iterator localIterator = paramCollection.iterator();
    while (localIterator.hasNext())
      if (!paramMap.containsKey(localIterator.next()))
        return false;
    return true;
  }

  public static <T> boolean a(Set<T> paramSet, Object paramObject)
  {
    boolean bool1 = true;
    boolean bool3;
    if (paramSet == paramObject)
      bool3 = bool1;
    boolean bool2;
    do
    {
      return bool3;
      bool2 = paramObject instanceof Set;
      bool3 = false;
    }
    while (!bool2);
    Set localSet = (Set)paramObject;
    try
    {
      if (paramSet.size() == localSet.size())
      {
        boolean bool4 = paramSet.containsAll(localSet);
        if (!bool4);
      }
      while (true)
      {
        return bool1;
        bool1 = false;
      }
    }
    catch (ClassCastException localClassCastException)
    {
      return false;
    }
    catch (NullPointerException localNullPointerException)
    {
    }
    return false;
  }

  public static <K, V> boolean b(Map<K, V> paramMap, Collection<?> paramCollection)
  {
    int i = paramMap.size();
    Iterator localIterator = paramCollection.iterator();
    while (localIterator.hasNext())
      paramMap.remove(localIterator.next());
    return i != paramMap.size();
  }

  public static <K, V> boolean c(Map<K, V> paramMap, Collection<?> paramCollection)
  {
    int i = paramMap.size();
    Iterator localIterator = paramMap.keySet().iterator();
    while (localIterator.hasNext())
      if (!paramCollection.contains(localIterator.next()))
        localIterator.remove();
    return i != paramMap.size();
  }

  protected abstract int a();

  protected abstract int a(Object paramObject);

  protected abstract Object a(int paramInt1, int paramInt2);

  protected abstract V a(int paramInt, V paramV);

  protected abstract void a(int paramInt);

  protected abstract void a(K paramK, V paramV);

  public <T> T[] a(T[] paramArrayOfT, int paramInt)
  {
    int i = a();
    if (paramArrayOfT.length < i);
    for (Object localObject = (Object[])Array.newInstance(paramArrayOfT.getClass().getComponentType(), i); ; localObject = paramArrayOfT)
    {
      for (int j = 0; j < i; j++)
        localObject[j] = a(j, paramInt);
      if (localObject.length > i)
        localObject[i] = null;
      return localObject;
    }
  }

  protected abstract int b(Object paramObject);

  protected abstract Map<K, V> b();

  public Object[] b(int paramInt)
  {
    int i = a();
    Object[] arrayOfObject = new Object[i];
    for (int j = 0; j < i; j++)
      arrayOfObject[j] = a(j, paramInt);
    return arrayOfObject;
  }

  protected abstract void c();

  public Set<Map.Entry<K, V>> d()
  {
    if (this.b == null)
      this.b = new b();
    return this.b;
  }

  public Set<K> e()
  {
    if (this.c == null)
      this.c = new c();
    return this.c;
  }

  public Collection<V> f()
  {
    if (this.d == null)
      this.d = new e();
    return this.d;
  }

  final class a<T>
    implements Iterator<T>
  {
    final int a;
    int b;
    int c;
    boolean d = false;

    a(int arg2)
    {
      int i;
      this.a = i;
      this.b = k.this.a();
    }

    public boolean hasNext()
    {
      return this.c < this.b;
    }

    public T next()
    {
      Object localObject = k.this.a(this.c, this.a);
      this.c = (1 + this.c);
      this.d = true;
      return localObject;
    }

    public void remove()
    {
      if (!this.d)
        throw new IllegalStateException();
      this.c = (-1 + this.c);
      this.b = (-1 + this.b);
      this.d = false;
      k.this.a(this.c);
    }
  }

  final class b
    implements Set<Map.Entry<K, V>>
  {
    b()
    {
    }

    public boolean a(Map.Entry<K, V> paramEntry)
    {
      throw new UnsupportedOperationException();
    }

    public boolean addAll(Collection<? extends Map.Entry<K, V>> paramCollection)
    {
      int i = k.this.a();
      Iterator localIterator = paramCollection.iterator();
      while (localIterator.hasNext())
      {
        Map.Entry localEntry = (Map.Entry)localIterator.next();
        k.this.a(localEntry.getKey(), localEntry.getValue());
      }
      return i != k.this.a();
    }

    public void clear()
    {
      k.this.c();
    }

    public boolean contains(Object paramObject)
    {
      if (!(paramObject instanceof Map.Entry));
      Map.Entry localEntry;
      int i;
      do
      {
        return false;
        localEntry = (Map.Entry)paramObject;
        i = k.this.a(localEntry.getKey());
      }
      while (i < 0);
      return f.a(k.this.a(i, 1), localEntry.getValue());
    }

    public boolean containsAll(Collection<?> paramCollection)
    {
      Iterator localIterator = paramCollection.iterator();
      while (localIterator.hasNext())
        if (!contains(localIterator.next()))
          return false;
      return true;
    }

    public boolean equals(Object paramObject)
    {
      return k.a(this, paramObject);
    }

    public int hashCode()
    {
      int i = -1 + k.this.a();
      int j = 0;
      if (i >= 0)
      {
        Object localObject1 = k.this.a(i, 0);
        Object localObject2 = k.this.a(i, 1);
        int k;
        if (localObject1 == null)
        {
          k = 0;
          label44: if (localObject2 != null)
            break label79;
        }
        label79: for (int m = 0; ; m = localObject2.hashCode())
        {
          int n = j + (m ^ k);
          i--;
          j = n;
          break;
          k = localObject1.hashCode();
          break label44;
        }
      }
      return j;
    }

    public boolean isEmpty()
    {
      return k.this.a() == 0;
    }

    public Iterator<Map.Entry<K, V>> iterator()
    {
      return new k.d(k.this);
    }

    public boolean remove(Object paramObject)
    {
      throw new UnsupportedOperationException();
    }

    public boolean removeAll(Collection<?> paramCollection)
    {
      throw new UnsupportedOperationException();
    }

    public boolean retainAll(Collection<?> paramCollection)
    {
      throw new UnsupportedOperationException();
    }

    public int size()
    {
      return k.this.a();
    }

    public Object[] toArray()
    {
      throw new UnsupportedOperationException();
    }

    public <T> T[] toArray(T[] paramArrayOfT)
    {
      throw new UnsupportedOperationException();
    }
  }

  final class c
    implements Set<K>
  {
    c()
    {
    }

    public boolean add(K paramK)
    {
      throw new UnsupportedOperationException();
    }

    public boolean addAll(Collection<? extends K> paramCollection)
    {
      throw new UnsupportedOperationException();
    }

    public void clear()
    {
      k.this.c();
    }

    public boolean contains(Object paramObject)
    {
      return k.this.a(paramObject) >= 0;
    }

    public boolean containsAll(Collection<?> paramCollection)
    {
      return k.a(k.this.b(), paramCollection);
    }

    public boolean equals(Object paramObject)
    {
      return k.a(this, paramObject);
    }

    public int hashCode()
    {
      int i = -1 + k.this.a();
      int j = 0;
      if (i >= 0)
      {
        Object localObject = k.this.a(i, 0);
        if (localObject == null);
        for (int k = 0; ; k = localObject.hashCode())
        {
          j += k;
          i--;
          break;
        }
      }
      return j;
    }

    public boolean isEmpty()
    {
      return k.this.a() == 0;
    }

    public Iterator<K> iterator()
    {
      return new k.a(k.this, 0);
    }

    public boolean remove(Object paramObject)
    {
      int i = k.this.a(paramObject);
      if (i >= 0)
      {
        k.this.a(i);
        return true;
      }
      return false;
    }

    public boolean removeAll(Collection<?> paramCollection)
    {
      return k.b(k.this.b(), paramCollection);
    }

    public boolean retainAll(Collection<?> paramCollection)
    {
      return k.c(k.this.b(), paramCollection);
    }

    public int size()
    {
      return k.this.a();
    }

    public Object[] toArray()
    {
      return k.this.b(0);
    }

    public <T> T[] toArray(T[] paramArrayOfT)
    {
      return k.this.a(paramArrayOfT, 0);
    }
  }

  final class d
    implements Iterator<Map.Entry<K, V>>, Map.Entry<K, V>
  {
    int a = -1 + k.this.a();
    int b = -1;
    boolean c = false;

    d()
    {
    }

    public Map.Entry<K, V> a()
    {
      this.b = (1 + this.b);
      this.c = true;
      return this;
    }

    public final boolean equals(Object paramObject)
    {
      int i = 1;
      if (!this.c)
        throw new IllegalStateException("This container does not support retaining Map.Entry objects");
      if (!(paramObject instanceof Map.Entry))
        return false;
      Map.Entry localEntry = (Map.Entry)paramObject;
      if ((f.a(localEntry.getKey(), k.this.a(this.b, 0))) && (f.a(localEntry.getValue(), k.this.a(this.b, i))));
      while (true)
      {
        return i;
        int j = 0;
      }
    }

    public K getKey()
    {
      if (!this.c)
        throw new IllegalStateException("This container does not support retaining Map.Entry objects");
      return k.this.a(this.b, 0);
    }

    public V getValue()
    {
      if (!this.c)
        throw new IllegalStateException("This container does not support retaining Map.Entry objects");
      return k.this.a(this.b, 1);
    }

    public boolean hasNext()
    {
      return this.b < this.a;
    }

    public final int hashCode()
    {
      if (!this.c)
        throw new IllegalStateException("This container does not support retaining Map.Entry objects");
      Object localObject1 = k.this.a(this.b, 0);
      Object localObject2 = k.this.a(this.b, 1);
      int i;
      int j;
      if (localObject1 == null)
      {
        i = 0;
        j = 0;
        if (localObject2 != null)
          break label69;
      }
      while (true)
      {
        return j ^ i;
        i = localObject1.hashCode();
        break;
        label69: j = localObject2.hashCode();
      }
    }

    public void remove()
    {
      if (!this.c)
        throw new IllegalStateException();
      k.this.a(this.b);
      this.b = (-1 + this.b);
      this.a = (-1 + this.a);
      this.c = false;
    }

    public V setValue(V paramV)
    {
      if (!this.c)
        throw new IllegalStateException("This container does not support retaining Map.Entry objects");
      return k.this.a(this.b, paramV);
    }

    public final String toString()
    {
      return getKey() + "=" + getValue();
    }
  }

  final class e
    implements Collection<V>
  {
    e()
    {
    }

    public boolean add(V paramV)
    {
      throw new UnsupportedOperationException();
    }

    public boolean addAll(Collection<? extends V> paramCollection)
    {
      throw new UnsupportedOperationException();
    }

    public void clear()
    {
      k.this.c();
    }

    public boolean contains(Object paramObject)
    {
      return k.this.b(paramObject) >= 0;
    }

    public boolean containsAll(Collection<?> paramCollection)
    {
      Iterator localIterator = paramCollection.iterator();
      while (localIterator.hasNext())
        if (!contains(localIterator.next()))
          return false;
      return true;
    }

    public boolean isEmpty()
    {
      return k.this.a() == 0;
    }

    public Iterator<V> iterator()
    {
      return new k.a(k.this, 1);
    }

    public boolean remove(Object paramObject)
    {
      int i = k.this.b(paramObject);
      if (i >= 0)
      {
        k.this.a(i);
        return true;
      }
      return false;
    }

    public boolean removeAll(Collection<?> paramCollection)
    {
      int i = 0;
      int j = k.this.a();
      boolean bool = false;
      while (i < j)
      {
        if (paramCollection.contains(k.this.a(i, 1)))
        {
          k.this.a(i);
          i--;
          j--;
          bool = true;
        }
        i++;
      }
      return bool;
    }

    public boolean retainAll(Collection<?> paramCollection)
    {
      int i = 0;
      int j = k.this.a();
      boolean bool = false;
      while (i < j)
      {
        if (!paramCollection.contains(k.this.a(i, 1)))
        {
          k.this.a(i);
          i--;
          j--;
          bool = true;
        }
        i++;
      }
      return bool;
    }

    public int size()
    {
      return k.this.a();
    }

    public Object[] toArray()
    {
      return k.this.b(1);
    }

    public <T> T[] toArray(T[] paramArrayOfT)
    {
      return k.this.a(paramArrayOfT, 1);
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.m.k
 * JD-Core Version:    0.6.2
 */