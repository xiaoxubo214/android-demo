package android.support.v4.m;

public class l<F, S>
{
  public final F a;
  public final S b;

  public l(F paramF, S paramS)
  {
    this.a = paramF;
    this.b = paramS;
  }

  public static <A, B> l<A, B> a(A paramA, B paramB)
  {
    return new l(paramA, paramB);
  }

  private static boolean b(Object paramObject1, Object paramObject2)
  {
    return (paramObject1 == paramObject2) || ((paramObject1 != null) && (paramObject1.equals(paramObject2)));
  }

  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof l));
    l locall;
    do
    {
      return false;
      locall = (l)paramObject;
    }
    while ((!b(locall.a, this.a)) || (!b(locall.b, this.b)));
    return true;
  }

  public int hashCode()
  {
    int i;
    int j;
    if (this.a == null)
    {
      i = 0;
      Object localObject = this.b;
      j = 0;
      if (localObject != null)
        break label35;
    }
    while (true)
    {
      return i ^ j;
      i = this.a.hashCode();
      break;
      label35: j = this.b.hashCode();
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.m.l
 * JD-Core Version:    0.6.2
 */