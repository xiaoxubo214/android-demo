package android.support.v4.m;

import java.util.Map;

public class n<K, V>
{
  private static final boolean a = false;
  static Object[] b;
  static int c = 0;
  static Object[] d;
  static int e = 0;
  private static final String i = "ArrayMap";
  private static final int j = 4;
  private static final int k = 10;
  int[] f;
  Object[] g;
  int h;

  public n()
  {
    this.f = f.a;
    this.g = f.c;
    this.h = 0;
  }

  public n(int paramInt)
  {
    if (paramInt == 0)
    {
      this.f = f.a;
      this.g = f.c;
    }
    while (true)
    {
      this.h = 0;
      return;
      e(paramInt);
    }
  }

  public n(n paramn)
  {
    this();
    if (paramn != null)
      a(paramn);
  }

  private static void a(int[] paramArrayOfInt, Object[] paramArrayOfObject, int paramInt)
  {
    if (paramArrayOfInt.length == 8)
      try
      {
        if (e < 10)
        {
          paramArrayOfObject[0] = d;
          paramArrayOfObject[1] = paramArrayOfInt;
          for (int n = -1 + (paramInt << 1); n >= 2; n--)
            paramArrayOfObject[n] = null;
          d = paramArrayOfObject;
          e = 1 + e;
        }
        return;
      }
      finally
      {
      }
    if (paramArrayOfInt.length == 4)
      try
      {
        if (c < 10)
        {
          paramArrayOfObject[0] = b;
          paramArrayOfObject[1] = paramArrayOfInt;
          for (int m = -1 + (paramInt << 1); m >= 2; m--)
            paramArrayOfObject[m] = null;
          b = paramArrayOfObject;
          c = 1 + c;
        }
        return;
      }
      finally
      {
      }
  }

  private void e(int paramInt)
  {
    if (paramInt == 8);
    while (true)
    {
      try
      {
        if (d != null)
        {
          Object[] arrayOfObject2 = d;
          this.g = arrayOfObject2;
          d = (Object[])arrayOfObject2[0];
          this.f = ((int[])arrayOfObject2[1]);
          arrayOfObject2[1] = null;
          arrayOfObject2[0] = null;
          e = -1 + e;
          return;
        }
        this.f = new int[paramInt];
        this.g = new Object[paramInt << 1];
        return;
      }
      finally
      {
      }
      if (paramInt == 4)
        try
        {
          if (b != null)
          {
            Object[] arrayOfObject1 = b;
            this.g = arrayOfObject1;
            b = (Object[])arrayOfObject1[0];
            this.f = ((int[])arrayOfObject1[1]);
            arrayOfObject1[1] = null;
            arrayOfObject1[0] = null;
            c = -1 + c;
            return;
          }
        }
        finally
        {
        }
    }
  }

  int a()
  {
    int m = this.h;
    int n;
    if (m == 0)
      n = -1;
    do
    {
      return n;
      n = f.a(this.f, m, 0);
    }
    while ((n < 0) || (this.g[(n << 1)] == null));
    for (int i1 = n + 1; (i1 < m) && (this.f[i1] == 0); i1++)
      if (this.g[(i1 << 1)] == null)
        return i1;
    n--;
    while (true)
    {
      if ((n < 0) || (this.f[n] != 0))
        break label108;
      if (this.g[(n << 1)] == null)
        break;
      n--;
    }
    label108: return i1 ^ 0xFFFFFFFF;
  }

  public int a(Object paramObject)
  {
    if (paramObject == null)
      return a();
    return a(paramObject, paramObject.hashCode());
  }

  int a(Object paramObject, int paramInt)
  {
    int m = this.h;
    int n;
    if (m == 0)
      n = -1;
    do
    {
      return n;
      n = f.a(this.f, m, paramInt);
    }
    while ((n < 0) || (paramObject.equals(this.g[(n << 1)])));
    for (int i1 = n + 1; (i1 < m) && (this.f[i1] == paramInt); i1++)
      if (paramObject.equals(this.g[(i1 << 1)]))
        return i1;
    n--;
    while (true)
    {
      if ((n < 0) || (this.f[n] != paramInt))
        break label136;
      if (paramObject.equals(this.g[(n << 1)]))
        break;
      n--;
    }
    label136: return i1 ^ 0xFFFFFFFF;
  }

  public V a(int paramInt, V paramV)
  {
    int m = 1 + (paramInt << 1);
    Object localObject = this.g[m];
    this.g[m] = paramV;
    return localObject;
  }

  public void a(int paramInt)
  {
    if (this.f.length < paramInt)
    {
      int[] arrayOfInt = this.f;
      Object[] arrayOfObject = this.g;
      e(paramInt);
      if (this.h > 0)
      {
        System.arraycopy(arrayOfInt, 0, this.f, 0, this.h);
        System.arraycopy(arrayOfObject, 0, this.g, 0, this.h << 1);
      }
      a(arrayOfInt, arrayOfObject, this.h);
    }
  }

  public void a(n<? extends K, ? extends V> paramn)
  {
    int m = paramn.h;
    a(m + this.h);
    int n = this.h;
    int i1 = 0;
    if (n == 0)
      if (m > 0)
      {
        System.arraycopy(paramn.f, 0, this.f, 0, m);
        System.arraycopy(paramn.g, 0, this.g, 0, m << 1);
        this.h = m;
      }
    while (true)
    {
      return;
      while (i1 < m)
      {
        put(paramn.b(i1), paramn.c(i1));
        i1++;
      }
    }
  }

  int b(Object paramObject)
  {
    int m = 1;
    int n = 2 * this.h;
    Object[] arrayOfObject = this.g;
    if (paramObject == null)
      while (m < n)
      {
        if (arrayOfObject[m] == null)
          return m >> 1;
        m += 2;
      }
    do
    {
      m += 2;
      if (m >= n)
        break;
    }
    while (!paramObject.equals(arrayOfObject[m]));
    return m >> 1;
    return -1;
  }

  public K b(int paramInt)
  {
    return this.g[(paramInt << 1)];
  }

  public V c(int paramInt)
  {
    return this.g[(1 + (paramInt << 1))];
  }

  public void clear()
  {
    if (this.h != 0)
    {
      a(this.f, this.g, this.h);
      this.f = f.a;
      this.g = f.c;
      this.h = 0;
    }
  }

  public boolean containsKey(Object paramObject)
  {
    return a(paramObject) >= 0;
  }

  public boolean containsValue(Object paramObject)
  {
    return b(paramObject) >= 0;
  }

  public V d(int paramInt)
  {
    int m = 8;
    Object localObject = this.g[(1 + (paramInt << 1))];
    if (this.h <= 1)
    {
      a(this.f, this.g, this.h);
      this.f = f.a;
      this.g = f.c;
      this.h = 0;
    }
    int[] arrayOfInt;
    Object[] arrayOfObject;
    do
    {
      return localObject;
      if ((this.f.length <= m) || (this.h >= this.f.length / 3))
        break;
      if (this.h > m)
        m = this.h + (this.h >> 1);
      arrayOfInt = this.f;
      arrayOfObject = this.g;
      e(m);
      this.h = (-1 + this.h);
      if (paramInt > 0)
      {
        System.arraycopy(arrayOfInt, 0, this.f, 0, paramInt);
        System.arraycopy(arrayOfObject, 0, this.g, 0, paramInt << 1);
      }
    }
    while (paramInt >= this.h);
    System.arraycopy(arrayOfInt, paramInt + 1, this.f, paramInt, this.h - paramInt);
    System.arraycopy(arrayOfObject, paramInt + 1 << 1, this.g, paramInt << 1, this.h - paramInt << 1);
    return localObject;
    this.h = (-1 + this.h);
    if (paramInt < this.h)
    {
      System.arraycopy(this.f, paramInt + 1, this.f, paramInt, this.h - paramInt);
      System.arraycopy(this.g, paramInt + 1 << 1, this.g, paramInt << 1, this.h - paramInt << 1);
    }
    this.g[(this.h << 1)] = null;
    this.g[(1 + (this.h << 1))] = null;
    return localObject;
  }

  public boolean equals(Object paramObject)
  {
    if (this == paramObject);
    while (true)
    {
      return true;
      if ((paramObject instanceof Map))
      {
        Map localMap = (Map)paramObject;
        if (size() != localMap.size())
          return false;
        int m = 0;
        try
        {
          while (m < this.h)
          {
            Object localObject1 = b(m);
            Object localObject2 = c(m);
            Object localObject3 = localMap.get(localObject1);
            if (localObject2 == null)
            {
              if (localObject3 != null)
                break label124;
              if (!localMap.containsKey(localObject1))
                break label124;
            }
            else
            {
              boolean bool = localObject2.equals(localObject3);
              if (!bool)
                return false;
            }
            m++;
          }
        }
        catch (NullPointerException localNullPointerException)
        {
          return false;
        }
        catch (ClassCastException localClassCastException)
        {
          return false;
        }
      }
    }
    return false;
    label124: return false;
  }

  public V get(Object paramObject)
  {
    int m = a(paramObject);
    if (m >= 0)
      return this.g[(1 + (m << 1))];
    return null;
  }

  public int hashCode()
  {
    int[] arrayOfInt = this.f;
    Object[] arrayOfObject = this.g;
    int m = this.h;
    int n = 1;
    int i1 = 0;
    int i2 = 0;
    if (i1 < m)
    {
      Object localObject = arrayOfObject[n];
      int i3 = arrayOfInt[i1];
      if (localObject == null);
      for (int i4 = 0; ; i4 = localObject.hashCode())
      {
        i2 += (i4 ^ i3);
        i1++;
        n += 2;
        break;
      }
    }
    return i2;
  }

  public boolean isEmpty()
  {
    return this.h <= 0;
  }

  public V put(K paramK, V paramV)
  {
    int m = 8;
    int i1;
    int n;
    if (paramK == null)
    {
      i1 = a();
      n = 0;
    }
    while (i1 >= 0)
    {
      int i3 = 1 + (i1 << 1);
      Object localObject = this.g[i3];
      this.g[i3] = paramV;
      return localObject;
      n = paramK.hashCode();
      i1 = a(paramK, n);
    }
    int i2 = i1 ^ 0xFFFFFFFF;
    if (this.h >= this.f.length)
    {
      if (this.h < m)
        break label275;
      m = this.h + (this.h >> 1);
    }
    while (true)
    {
      int[] arrayOfInt = this.f;
      Object[] arrayOfObject = this.g;
      e(m);
      if (this.f.length > 0)
      {
        System.arraycopy(arrayOfInt, 0, this.f, 0, arrayOfInt.length);
        System.arraycopy(arrayOfObject, 0, this.g, 0, arrayOfObject.length);
      }
      a(arrayOfInt, arrayOfObject, this.h);
      if (i2 < this.h)
      {
        System.arraycopy(this.f, i2, this.f, i2 + 1, this.h - i2);
        System.arraycopy(this.g, i2 << 1, this.g, i2 + 1 << 1, this.h - i2 << 1);
      }
      this.f[i2] = n;
      this.g[(i2 << 1)] = paramK;
      this.g[(1 + (i2 << 1))] = paramV;
      this.h = (1 + this.h);
      return null;
      label275: if (this.h < 4)
        m = 4;
    }
  }

  public V remove(Object paramObject)
  {
    int m = a(paramObject);
    if (m >= 0)
      return d(m);
    return null;
  }

  public int size()
  {
    return this.h;
  }

  public String toString()
  {
    if (isEmpty())
      return "{}";
    StringBuilder localStringBuilder = new StringBuilder(28 * this.h);
    localStringBuilder.append('{');
    int m = 0;
    if (m < this.h)
    {
      if (m > 0)
        localStringBuilder.append(", ");
      Object localObject1 = b(m);
      if (localObject1 != this)
      {
        localStringBuilder.append(localObject1);
        label73: localStringBuilder.append('=');
        Object localObject2 = c(m);
        if (localObject2 == this)
          break label116;
        localStringBuilder.append(localObject2);
      }
      while (true)
      {
        m++;
        break;
        localStringBuilder.append("(this Map)");
        break label73;
        label116: localStringBuilder.append("(this Map)");
      }
    }
    localStringBuilder.append('}');
    return localStringBuilder.toString();
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.m.n
 * JD-Core Version:    0.6.2
 */