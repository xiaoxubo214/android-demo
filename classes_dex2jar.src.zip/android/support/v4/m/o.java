package android.support.v4.m;

public class o<E>
  implements Cloneable
{
  private static final Object a = new Object();
  private boolean b = false;
  private int[] c;
  private Object[] d;
  private int e;

  public o()
  {
    this(10);
  }

  public o(int paramInt)
  {
    if (paramInt == 0)
      this.c = f.a;
    int i;
    for (this.d = f.c; ; this.d = new Object[i])
    {
      this.e = 0;
      return;
      i = f.a(paramInt);
      this.c = new int[i];
    }
  }

  private void d()
  {
    int i = this.e;
    int[] arrayOfInt = this.c;
    Object[] arrayOfObject = this.d;
    int j = 0;
    int k = 0;
    while (j < i)
    {
      Object localObject = arrayOfObject[j];
      if (localObject != a)
      {
        if (j != k)
        {
          arrayOfInt[k] = arrayOfInt[j];
          arrayOfObject[k] = localObject;
          arrayOfObject[j] = null;
        }
        k++;
      }
      j++;
    }
    this.b = false;
    this.e = k;
  }

  public int a(E paramE)
  {
    if (this.b)
      d();
    for (int i = 0; i < this.e; i++)
      if (this.d[i] == paramE)
        return i;
    return -1;
  }

  // ERROR //
  public o<E> a()
  {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial 54	java/lang/Object:clone	()Ljava/lang/Object;
    //   4: checkcast 2	android/support/v4/m/o
    //   7: astore_2
    //   8: aload_2
    //   9: aload_0
    //   10: getfield 35	android/support/v4/m/o:c	[I
    //   13: invokevirtual 56	[I:clone	()Ljava/lang/Object;
    //   16: checkcast 55	[I
    //   19: putfield 35	android/support/v4/m/o:c	[I
    //   22: aload_2
    //   23: aload_0
    //   24: getfield 39	android/support/v4/m/o:d	[Ljava/lang/Object;
    //   27: invokevirtual 58	[Ljava/lang/Object;:clone	()Ljava/lang/Object;
    //   30: checkcast 57	[Ljava/lang/Object;
    //   33: putfield 39	android/support/v4/m/o:d	[Ljava/lang/Object;
    //   36: aload_2
    //   37: areturn
    //   38: astore_1
    //   39: aconst_null
    //   40: areturn
    //   41: astore_3
    //   42: aload_2
    //   43: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   0	8	38	java/lang/CloneNotSupportedException
    //   8	36	41	java/lang/CloneNotSupportedException
  }

  public E a(int paramInt)
  {
    return a(paramInt, null);
  }

  public E a(int paramInt, E paramE)
  {
    int i = f.a(this.c, this.e, paramInt);
    if ((i < 0) || (this.d[i] == a))
      return paramE;
    return this.d[i];
  }

  public void a(int paramInt1, int paramInt2)
  {
    int i = Math.min(this.e, paramInt1 + paramInt2);
    while (paramInt1 < i)
    {
      d(paramInt1);
      paramInt1++;
    }
  }

  public int b()
  {
    if (this.b)
      d();
    return this.e;
  }

  public void b(int paramInt)
  {
    int i = f.a(this.c, this.e, paramInt);
    if ((i >= 0) && (this.d[i] != a))
    {
      this.d[i] = a;
      this.b = true;
    }
  }

  public void b(int paramInt, E paramE)
  {
    int i = f.a(this.c, this.e, paramInt);
    if (i >= 0)
    {
      this.d[i] = paramE;
      return;
    }
    int j = i ^ 0xFFFFFFFF;
    if ((j < this.e) && (this.d[j] == a))
    {
      this.c[j] = paramInt;
      this.d[j] = paramE;
      return;
    }
    if ((this.b) && (this.e >= this.c.length))
    {
      d();
      j = 0xFFFFFFFF ^ f.a(this.c, this.e, paramInt);
    }
    if (this.e >= this.c.length)
    {
      int k = f.a(1 + this.e);
      int[] arrayOfInt = new int[k];
      Object[] arrayOfObject = new Object[k];
      System.arraycopy(this.c, 0, arrayOfInt, 0, this.c.length);
      System.arraycopy(this.d, 0, arrayOfObject, 0, this.d.length);
      this.c = arrayOfInt;
      this.d = arrayOfObject;
    }
    if (this.e - j != 0)
    {
      System.arraycopy(this.c, j, this.c, j + 1, this.e - j);
      System.arraycopy(this.d, j, this.d, j + 1, this.e - j);
    }
    this.c[j] = paramInt;
    this.d[j] = paramE;
    this.e = (1 + this.e);
  }

  public void c()
  {
    int i = this.e;
    Object[] arrayOfObject = this.d;
    for (int j = 0; j < i; j++)
      arrayOfObject[j] = null;
    this.e = 0;
    this.b = false;
  }

  public void c(int paramInt)
  {
    b(paramInt);
  }

  public void c(int paramInt, E paramE)
  {
    if (this.b)
      d();
    this.d[paramInt] = paramE;
  }

  public void d(int paramInt)
  {
    if (this.d[paramInt] != a)
    {
      this.d[paramInt] = a;
      this.b = true;
    }
  }

  public void d(int paramInt, E paramE)
  {
    if ((this.e != 0) && (paramInt <= this.c[(-1 + this.e)]))
    {
      b(paramInt, paramE);
      return;
    }
    if ((this.b) && (this.e >= this.c.length))
      d();
    int i = this.e;
    if (i >= this.c.length)
    {
      int j = f.a(i + 1);
      int[] arrayOfInt = new int[j];
      Object[] arrayOfObject = new Object[j];
      System.arraycopy(this.c, 0, arrayOfInt, 0, this.c.length);
      System.arraycopy(this.d, 0, arrayOfObject, 0, this.d.length);
      this.c = arrayOfInt;
      this.d = arrayOfObject;
    }
    this.c[i] = paramInt;
    this.d[i] = paramE;
    this.e = (i + 1);
  }

  public int e(int paramInt)
  {
    if (this.b)
      d();
    return this.c[paramInt];
  }

  public E f(int paramInt)
  {
    if (this.b)
      d();
    return this.d[paramInt];
  }

  public int g(int paramInt)
  {
    if (this.b)
      d();
    return f.a(this.c, this.e, paramInt);
  }

  public String toString()
  {
    if (b() <= 0)
      return "{}";
    StringBuilder localStringBuilder = new StringBuilder(28 * this.e);
    localStringBuilder.append('{');
    int i = 0;
    if (i < this.e)
    {
      if (i > 0)
        localStringBuilder.append(", ");
      localStringBuilder.append(e(i));
      localStringBuilder.append('=');
      Object localObject = f(i);
      if (localObject != this)
        localStringBuilder.append(localObject);
      while (true)
      {
        i++;
        break;
        localStringBuilder.append("(this Map)");
      }
    }
    localStringBuilder.append('}');
    return localStringBuilder.toString();
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.m.o
 * JD-Core Version:    0.6.2
 */