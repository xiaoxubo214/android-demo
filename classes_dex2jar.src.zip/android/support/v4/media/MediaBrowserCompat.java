package android.support.v4.media;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.Messenger;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.os.RemoteException;
import android.support.annotation.x;
import android.support.v4.m.a;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.media.session.MediaSessionCompat.Token;
import android.support.v4.os.ResultReceiver;
import android.text.TextUtils;
import android.util.Log;
import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;

public final class MediaBrowserCompat
{
  public static final String a = "android.media.browse.extra.PAGE";
  public static final String b = "android.media.browse.extra.PAGE_SIZE";
  private static final String c = "MediaBrowserCompat";
  private final d d;

  public MediaBrowserCompat(Context paramContext, ComponentName paramComponentName, b paramb, Bundle paramBundle)
  {
    if (Build.VERSION.SDK_INT >= 23)
    {
      this.d = new f(paramContext, paramComponentName, paramb, paramBundle);
      return;
    }
    if (Build.VERSION.SDK_INT >= 21)
    {
      this.d = new e(paramContext, paramComponentName, paramb, paramBundle);
      return;
    }
    this.d = new h(paramContext, paramComponentName, paramb, paramBundle);
  }

  public void a()
  {
    this.d.d();
  }

  public void a(@x String paramString)
  {
    this.d.a(paramString, null);
  }

  public void a(@x String paramString, @x Bundle paramBundle)
  {
    if (paramBundle == null)
      throw new IllegalArgumentException("options are null");
    this.d.a(paramString, paramBundle);
  }

  public void a(@x String paramString, @x Bundle paramBundle, @x k paramk)
  {
    if (paramBundle == null)
      throw new IllegalArgumentException("options are null");
    this.d.a(paramString, paramBundle, paramk);
  }

  public void a(@x String paramString, @x c paramc)
  {
    this.d.a(paramString, paramc);
  }

  public void a(@x String paramString, @x k paramk)
  {
    this.d.a(paramString, null, paramk);
  }

  public void b()
  {
    this.d.e();
  }

  public boolean c()
  {
    return this.d.f();
  }

  @x
  public ComponentName d()
  {
    return this.d.g();
  }

  @x
  public String e()
  {
    return this.d.h();
  }

  @android.support.annotation.y
  public Bundle f()
  {
    return this.d.i();
  }

  @x
  public MediaSessionCompat.Token g()
  {
    return this.d.j();
  }

  private static class ItemReceiver extends ResultReceiver
  {
    private final String a;
    private final MediaBrowserCompat.c b;

    ItemReceiver(String paramString, MediaBrowserCompat.c paramc, Handler paramHandler)
    {
      super();
      this.a = paramString;
      this.b = paramc;
    }

    protected void a(int paramInt, Bundle paramBundle)
    {
      paramBundle.setClassLoader(MediaBrowserCompat.class.getClassLoader());
      if ((paramInt != 0) || (paramBundle == null) || (!paramBundle.containsKey("media_item")))
      {
        this.b.a(this.a);
        return;
      }
      Parcelable localParcelable = paramBundle.getParcelable("media_item");
      if ((localParcelable instanceof MediaBrowserCompat.MediaItem))
      {
        this.b.a((MediaBrowserCompat.MediaItem)localParcelable);
        return;
      }
      this.b.a(this.a);
    }
  }

  public static class MediaItem
    implements Parcelable
  {
    public static final Parcelable.Creator<MediaItem> CREATOR = new k();
    public static final int a = 1;
    public static final int b = 2;
    private final int c;
    private final MediaDescriptionCompat d;

    private MediaItem(Parcel paramParcel)
    {
      this.c = paramParcel.readInt();
      this.d = ((MediaDescriptionCompat)MediaDescriptionCompat.CREATOR.createFromParcel(paramParcel));
    }

    public MediaItem(@x MediaDescriptionCompat paramMediaDescriptionCompat, int paramInt)
    {
      if (paramMediaDescriptionCompat == null)
        throw new IllegalArgumentException("description cannot be null");
      if (TextUtils.isEmpty(paramMediaDescriptionCompat.a()))
        throw new IllegalArgumentException("description must have a non-empty media id");
      this.c = paramInt;
      this.d = paramMediaDescriptionCompat;
    }

    public int a()
    {
      return this.c;
    }

    public boolean b()
    {
      return (0x1 & this.c) != 0;
    }

    public boolean c()
    {
      return (0x2 & this.c) != 0;
    }

    @x
    public MediaDescriptionCompat d()
    {
      return this.d;
    }

    public int describeContents()
    {
      return 0;
    }

    @x
    public String e()
    {
      return this.d.a();
    }

    public String toString()
    {
      StringBuilder localStringBuilder = new StringBuilder("MediaItem{");
      localStringBuilder.append("mFlags=").append(this.c);
      localStringBuilder.append(", mDescription=").append(this.d);
      localStringBuilder.append('}');
      return localStringBuilder.toString();
    }

    public void writeToParcel(Parcel paramParcel, int paramInt)
    {
      paramParcel.writeInt(this.c);
      this.d.writeToParcel(paramParcel, paramInt);
    }

    @Retention(RetentionPolicy.SOURCE)
    public static @interface a
    {
    }
  }

  private static class a extends Handler
  {
    private final MediaBrowserCompat.g a;
    private WeakReference<Messenger> b;

    a(MediaBrowserCompat.g paramg)
    {
      this.a = paramg;
    }

    void a(Messenger paramMessenger)
    {
      this.b = new WeakReference(paramMessenger);
    }

    public void handleMessage(Message paramMessage)
    {
      if (this.b == null)
        return;
      Bundle localBundle = paramMessage.getData();
      localBundle.setClassLoader(MediaSessionCompat.class.getClassLoader());
      switch (paramMessage.what)
      {
      default:
        Log.w("MediaBrowserCompat", "Unhandled message: " + paramMessage + "\n  Client version: " + 1 + "\n  Service version: " + paramMessage.arg1);
        return;
      case 1:
        this.a.a((Messenger)this.b.get(), localBundle.getString("data_media_item_id"), (MediaSessionCompat.Token)localBundle.getParcelable("data_media_session_token"), localBundle.getBundle("data_root_hints"));
        return;
      case 2:
        this.a.a((Messenger)this.b.get());
        return;
      case 3:
      }
      this.a.a((Messenger)this.b.get(), localBundle.getString("data_media_item_id"), localBundle.getParcelableArrayList("data_media_item_list"), localBundle.getBundle("data_options"));
    }
  }

  public static class b
  {
    final Object a;
    private a b;

    public b()
    {
      if (Build.VERSION.SDK_INT >= 21)
      {
        this.a = l.a(new b(null));
        return;
      }
      this.a = null;
    }

    public void a()
    {
    }

    void a(a parama)
    {
      this.b = parama;
    }

    public void b()
    {
    }

    public void c()
    {
    }

    static abstract interface a
    {
      public abstract void a();

      public abstract void b();

      public abstract void c();
    }

    private class b
      implements l.a
    {
      private b()
      {
      }

      public void a()
      {
        if (MediaBrowserCompat.b.a(MediaBrowserCompat.b.this) != null)
          MediaBrowserCompat.b.a(MediaBrowserCompat.b.this).a();
        MediaBrowserCompat.b.this.a();
      }

      public void b()
      {
        if (MediaBrowserCompat.b.a(MediaBrowserCompat.b.this) != null)
          MediaBrowserCompat.b.a(MediaBrowserCompat.b.this).b();
        MediaBrowserCompat.b.this.b();
      }

      public void c()
      {
        if (MediaBrowserCompat.b.a(MediaBrowserCompat.b.this) != null)
          MediaBrowserCompat.b.a(MediaBrowserCompat.b.this).c();
        MediaBrowserCompat.b.this.c();
      }
    }
  }

  public static abstract class c
  {
    final Object a;

    public c()
    {
      if (Build.VERSION.SDK_INT >= 23)
      {
        this.a = m.a(new a(null));
        return;
      }
      this.a = null;
    }

    public void a(MediaBrowserCompat.MediaItem paramMediaItem)
    {
    }

    public void a(@x String paramString)
    {
    }

    private class a
      implements m.a
    {
      private a()
      {
      }

      public void a(Parcel paramParcel)
      {
        paramParcel.setDataPosition(0);
        MediaBrowserCompat.MediaItem localMediaItem = (MediaBrowserCompat.MediaItem)MediaBrowserCompat.MediaItem.CREATOR.createFromParcel(paramParcel);
        paramParcel.recycle();
        MediaBrowserCompat.c.this.a(localMediaItem);
      }

      public void a(@x String paramString)
      {
        MediaBrowserCompat.c.this.a(paramString);
      }
    }
  }

  static abstract interface d
  {
    public abstract void a(@x String paramString, Bundle paramBundle);

    public abstract void a(@x String paramString, Bundle paramBundle, @x MediaBrowserCompat.k paramk);

    public abstract void a(@x String paramString, @x MediaBrowserCompat.c paramc);

    public abstract void d();

    public abstract void e();

    public abstract boolean f();

    public abstract ComponentName g();

    @x
    public abstract String h();

    @android.support.annotation.y
    public abstract Bundle i();

    @x
    public abstract MediaSessionCompat.Token j();
  }

  static class e
    implements MediaBrowserCompat.b.a, MediaBrowserCompat.d, MediaBrowserCompat.g
  {
    private static final boolean b;
    protected Object a;
    private final ComponentName c;
    private final MediaBrowserCompat.a d = new MediaBrowserCompat.a(this);
    private final a<String, MediaBrowserCompat.j> e = new a();
    private MediaBrowserCompat.i f;
    private Messenger g;

    public e(Context paramContext, ComponentName paramComponentName, MediaBrowserCompat.b paramb, Bundle paramBundle)
    {
      this.c = paramComponentName;
      paramb.a(this);
      this.a = l.a(paramContext, paramComponentName, paramb.a, paramBundle);
    }

    public void a()
    {
      Bundle localBundle = l.f(this.a);
      if (localBundle == null);
      IBinder localIBinder;
      do
      {
        return;
        localIBinder = android.support.v4.app.y.a(localBundle, "extra_messenger");
      }
      while (localIBinder == null);
      this.f = new MediaBrowserCompat.i(localIBinder);
      this.g = new Messenger(this.d);
      this.d.a(this.g);
      try
      {
        this.f.b(this.g);
        a(this.g, null, null, null);
        return;
      }
      catch (RemoteException localRemoteException)
      {
        while (true)
          Log.i("MediaBrowserCompat", "Remote error registering client messenger.");
      }
    }

    public void a(Messenger paramMessenger)
    {
    }

    public void a(Messenger paramMessenger, String paramString, MediaSessionCompat.Token paramToken, Bundle paramBundle)
    {
      Iterator localIterator = this.e.entrySet().iterator();
      if (localIterator.hasNext())
      {
        Map.Entry localEntry = (Map.Entry)localIterator.next();
        String str = (String)localEntry.getKey();
        MediaBrowserCompat.j localj = (MediaBrowserCompat.j)localEntry.getValue();
        List localList1 = localj.b();
        List localList2 = localj.c();
        int i = 0;
        label77: if (i < localList1.size())
        {
          if (localList1.get(i) != null)
            break label131;
          l.a(this.a, str, MediaBrowserCompat.l.b((MediaBrowserCompat.l)localList2.get(i)));
        }
        while (true)
        {
          i++;
          break label77;
          break;
          try
          {
            label131: this.f.a(str, (Bundle)localList1.get(i), this.g);
          }
          catch (RemoteException localRemoteException)
          {
            Log.d("MediaBrowserCompat", "addSubscription failed with RemoteException parentId=" + str);
          }
        }
      }
    }

    public void a(Messenger paramMessenger, String paramString, List paramList, @x Bundle paramBundle)
    {
      if (this.g != paramMessenger);
      MediaBrowserCompat.j localj;
      do
      {
        return;
        localj = (MediaBrowserCompat.j)this.e.get(paramString);
      }
      while (localj == null);
      localj.b(paramBundle).a(paramString, paramList, paramBundle);
    }

    public void a(@x String paramString, Bundle paramBundle)
    {
      if (TextUtils.isEmpty(paramString))
        throw new IllegalArgumentException("parentId is empty.");
      MediaBrowserCompat.j localj = (MediaBrowserCompat.j)this.e.get(paramString);
      if ((localj != null) && (localj.a(paramBundle)))
      {
        if ((paramBundle != null) && (this.f != null))
          break label95;
        if ((this.f != null) || (localj.a()))
          l.a(this.a, paramString);
      }
      while (true)
      {
        if ((localj != null) && (localj.a()))
          this.e.remove(paramString);
        return;
        label95: if (this.f == null)
          try
          {
            this.f.b(paramString, paramBundle, this.g);
          }
          catch (RemoteException localRemoteException)
          {
            Log.d("MediaBrowserCompat", "removeSubscription failed with RemoteException parentId=" + paramString);
          }
      }
    }

    public void a(@x String paramString, Bundle paramBundle, @x MediaBrowserCompat.k paramk)
    {
      MediaBrowserCompat.l locall = new MediaBrowserCompat.l(paramk, paramBundle);
      MediaBrowserCompat.j localj = (MediaBrowserCompat.j)this.e.get(paramString);
      if (localj == null)
      {
        localj = new MediaBrowserCompat.j();
        this.e.put(paramString, localj);
      }
      localj.a(locall, paramBundle);
      if (l.c(this.a))
      {
        if ((paramBundle == null) || (this.f == null))
          l.a(this.a, paramString, MediaBrowserCompat.l.b(locall));
      }
      else
        return;
      try
      {
        this.f.a(paramString, paramBundle, this.g);
        return;
      }
      catch (RemoteException localRemoteException)
      {
        Log.i("MediaBrowserCompat", "Remote error subscribing media item: " + paramString);
      }
    }

    public void a(@x String paramString, @x MediaBrowserCompat.c paramc)
    {
      if (TextUtils.isEmpty(paramString))
        throw new IllegalArgumentException("mediaId is empty.");
      if (paramc == null)
        throw new IllegalArgumentException("cb is null.");
      if (!l.c(this.a))
      {
        Log.i("MediaBrowserCompat", "Not connected, unable to retrieve the MediaItem.");
        this.d.post(new c(this, paramc, paramString));
        return;
      }
      if (this.f == null)
      {
        this.d.post(new d(this, paramc));
        return;
      }
      MediaBrowserCompat.ItemReceiver localItemReceiver = new MediaBrowserCompat.ItemReceiver(paramString, paramc, this.d);
      try
      {
        this.f.a(paramString, localItemReceiver);
        return;
      }
      catch (RemoteException localRemoteException)
      {
        Log.i("MediaBrowserCompat", "Remote error getting media item: " + paramString);
        this.d.post(new e(this, paramc, paramString));
      }
    }

    public void b()
    {
      this.f = null;
      this.g = null;
    }

    public void c()
    {
    }

    public void d()
    {
      l.a(this.a);
    }

    public void e()
    {
      l.b(this.a);
    }

    public boolean f()
    {
      return l.c(this.a);
    }

    public ComponentName g()
    {
      return l.d(this.a);
    }

    @x
    public String h()
    {
      return l.e(this.a);
    }

    @android.support.annotation.y
    public Bundle i()
    {
      return l.f(this.a);
    }

    @x
    public MediaSessionCompat.Token j()
    {
      return MediaSessionCompat.Token.a(l.g(this.a));
    }
  }

  static class f extends MediaBrowserCompat.e
  {
    public f(Context paramContext, ComponentName paramComponentName, MediaBrowserCompat.b paramb, Bundle paramBundle)
    {
      super(paramComponentName, paramb, paramBundle);
    }

    public void a(@x String paramString, @x MediaBrowserCompat.c paramc)
    {
      m.a(this.a, paramString, paramc.a);
    }
  }

  static abstract interface g
  {
    public abstract void a(Messenger paramMessenger);

    public abstract void a(Messenger paramMessenger, String paramString, MediaSessionCompat.Token paramToken, Bundle paramBundle);

    public abstract void a(Messenger paramMessenger, String paramString, List paramList, Bundle paramBundle);
  }

  static class h
    implements MediaBrowserCompat.d, MediaBrowserCompat.g
  {
    private static final boolean a = false;
    private static final int b = 0;
    private static final int c = 1;
    private static final int d = 2;
    private static final int e = 3;
    private final Context f;
    private final ComponentName g;
    private final MediaBrowserCompat.b h;
    private final Bundle i;
    private final MediaBrowserCompat.a j = new MediaBrowserCompat.a(this);
    private final a<String, MediaBrowserCompat.j> k = new a();
    private int l = 0;
    private a m;
    private MediaBrowserCompat.i n;
    private Messenger o;
    private String p;
    private MediaSessionCompat.Token q;
    private Bundle r;

    public h(Context paramContext, ComponentName paramComponentName, MediaBrowserCompat.b paramb, Bundle paramBundle)
    {
      if (paramContext == null)
        throw new IllegalArgumentException("context must not be null");
      if (paramComponentName == null)
        throw new IllegalArgumentException("service component must not be null");
      if (paramb == null)
        throw new IllegalArgumentException("connection callback must not be null");
      this.f = paramContext;
      this.g = paramComponentName;
      this.h = paramb;
      this.i = paramBundle;
    }

    private static String a(int paramInt)
    {
      switch (paramInt)
      {
      default:
        return "UNKNOWN/" + paramInt;
      case 0:
        return "CONNECT_STATE_DISCONNECTED";
      case 1:
        return "CONNECT_STATE_CONNECTING";
      case 2:
        return "CONNECT_STATE_CONNECTED";
      case 3:
      }
      return "CONNECT_STATE_SUSPENDED";
    }

    private boolean a(Messenger paramMessenger, String paramString)
    {
      if (this.o != paramMessenger)
      {
        if (this.l != 0)
          Log.i("MediaBrowserCompat", paramString + " for " + this.g + " with mCallbacksMessenger=" + this.o + " this=" + this);
        return false;
      }
      return true;
    }

    private void b()
    {
      if (this.m != null)
        this.f.unbindService(this.m);
      this.l = 0;
      this.m = null;
      this.n = null;
      this.o = null;
      this.p = null;
      this.q = null;
    }

    void a()
    {
      Log.d("MediaBrowserCompat", "MediaBrowserCompat...");
      Log.d("MediaBrowserCompat", "  mServiceComponent=" + this.g);
      Log.d("MediaBrowserCompat", "  mCallback=" + this.h);
      Log.d("MediaBrowserCompat", "  mRootHints=" + this.i);
      Log.d("MediaBrowserCompat", "  mState=" + a(this.l));
      Log.d("MediaBrowserCompat", "  mServiceConnection=" + this.m);
      Log.d("MediaBrowserCompat", "  mServiceBinderWrapper=" + this.n);
      Log.d("MediaBrowserCompat", "  mCallbacksMessenger=" + this.o);
      Log.d("MediaBrowserCompat", "  mRootId=" + this.p);
      Log.d("MediaBrowserCompat", "  mMediaSessionToken=" + this.q);
    }

    public void a(Messenger paramMessenger)
    {
      Log.e("MediaBrowserCompat", "onConnectFailed for " + this.g);
      if (!a(paramMessenger, "onConnectFailed"))
        return;
      if (this.l != 1)
      {
        Log.w("MediaBrowserCompat", "onConnect from service while mState=" + a(this.l) + "... ignoring");
        return;
      }
      b();
      this.h.c();
    }

    public void a(Messenger paramMessenger, String paramString, MediaSessionCompat.Token paramToken, Bundle paramBundle)
    {
      if (!a(paramMessenger, "onConnect"));
      while (true)
      {
        return;
        if (this.l != 1)
        {
          Log.w("MediaBrowserCompat", "onConnect from service while mState=" + a(this.l) + "... ignoring");
          return;
        }
        this.p = paramString;
        this.q = paramToken;
        this.r = paramBundle;
        this.l = 2;
        this.h.a();
        try
        {
          Iterator localIterator1 = this.k.entrySet().iterator();
          while (localIterator1.hasNext())
          {
            Map.Entry localEntry = (Map.Entry)localIterator1.next();
            String str = (String)localEntry.getKey();
            Iterator localIterator2 = ((MediaBrowserCompat.j)localEntry.getValue()).b().iterator();
            while (localIterator2.hasNext())
            {
              Bundle localBundle = (Bundle)localIterator2.next();
              this.n.a(str, localBundle, this.o);
            }
          }
        }
        catch (RemoteException localRemoteException)
        {
          Log.d("MediaBrowserCompat", "addSubscription failed with RemoteException.");
        }
      }
    }

    public void a(Messenger paramMessenger, String paramString, List paramList, Bundle paramBundle)
    {
      if (!a(paramMessenger, "onLoadChildren"));
      MediaBrowserCompat.k localk;
      do
      {
        MediaBrowserCompat.j localj;
        do
        {
          return;
          localj = (MediaBrowserCompat.j)this.k.get(paramString);
        }
        while (localj == null);
        localk = localj.b(paramBundle);
      }
      while (localk == null);
      if (paramBundle == null)
      {
        localk.a(paramString, paramList);
        return;
      }
      localk.a(paramString, paramList, paramBundle);
    }

    public void a(@x String paramString, Bundle paramBundle)
    {
      if (TextUtils.isEmpty(paramString))
        throw new IllegalArgumentException("parentId is empty.");
      MediaBrowserCompat.j localj = (MediaBrowserCompat.j)this.k.get(paramString);
      if ((localj != null) && (localj.a(paramBundle)) && (this.l == 2));
      try
      {
        this.n.b(paramString, paramBundle, this.o);
        if ((localj != null) && (localj.a()))
          this.k.remove(paramString);
        return;
      }
      catch (RemoteException localRemoteException)
      {
        while (true)
          Log.d("MediaBrowserCompat", "removeSubscription failed with RemoteException parentId=" + paramString);
      }
    }

    public void a(@x String paramString, Bundle paramBundle, @x MediaBrowserCompat.k paramk)
    {
      if (TextUtils.isEmpty(paramString))
        throw new IllegalArgumentException("parentId is empty.");
      if (paramk == null)
        throw new IllegalArgumentException("callback is null");
      MediaBrowserCompat.j localj = (MediaBrowserCompat.j)this.k.get(paramString);
      if (localj == null)
      {
        localj = new MediaBrowserCompat.j();
        this.k.put(paramString, localj);
      }
      localj.a(paramk, paramBundle);
      if (this.l == 2);
      try
      {
        this.n.a(paramString, paramBundle, this.o);
        return;
      }
      catch (RemoteException localRemoteException)
      {
        Log.d("MediaBrowserCompat", "addSubscription failed with RemoteException parentId=" + paramString);
      }
    }

    public void a(@x String paramString, @x MediaBrowserCompat.c paramc)
    {
      if (TextUtils.isEmpty(paramString))
        throw new IllegalArgumentException("mediaId is empty.");
      if (paramc == null)
        throw new IllegalArgumentException("cb is null.");
      if (this.l != 2)
      {
        Log.i("MediaBrowserCompat", "Not connected, unable to retrieve the MediaItem.");
        this.j.post(new g(this, paramc, paramString));
        return;
      }
      MediaBrowserCompat.ItemReceiver localItemReceiver = new MediaBrowserCompat.ItemReceiver(paramString, paramc, this.j);
      try
      {
        this.n.a(paramString, localItemReceiver);
        return;
      }
      catch (RemoteException localRemoteException)
      {
        Log.i("MediaBrowserCompat", "Remote error getting media item.");
        this.j.post(new h(this, paramc, paramString));
      }
    }

    public void d()
    {
      if (this.l != 0)
        throw new IllegalStateException("connect() called while not disconnected (state=" + a(this.l) + ")");
      if (this.n != null)
        throw new RuntimeException("mServiceBinderWrapper should be null. Instead it is " + this.n);
      if (this.o != null)
        throw new RuntimeException("mCallbacksMessenger should be null. Instead it is " + this.o);
      this.l = 1;
      Intent localIntent = new Intent("android.media.browse.MediaBrowserService");
      localIntent.setComponent(this.g);
      a locala = new a(null);
      this.m = locala;
      try
      {
        boolean bool2 = this.f.bindService(localIntent, this.m, 1);
        bool1 = bool2;
        if (!bool1)
          this.j.post(new f(this, locala));
        return;
      }
      catch (Exception localException)
      {
        while (true)
        {
          Log.e("MediaBrowserCompat", "Failed binding to service " + this.g);
          boolean bool1 = false;
        }
      }
    }

    public void e()
    {
      if (this.o != null);
      try
      {
        this.n.a(this.o);
        b();
        return;
      }
      catch (RemoteException localRemoteException)
      {
        while (true)
          Log.w("MediaBrowserCompat", "RemoteException during connect for " + this.g);
      }
    }

    public boolean f()
    {
      return this.l == 2;
    }

    @x
    public ComponentName g()
    {
      if (!f())
        throw new IllegalStateException("getServiceComponent() called while not connected (state=" + this.l + ")");
      return this.g;
    }

    @x
    public String h()
    {
      if (!f())
        throw new IllegalStateException("getRoot() called while not connected(state=" + a(this.l) + ")");
      return this.p;
    }

    @android.support.annotation.y
    public Bundle i()
    {
      if (!f())
        throw new IllegalStateException("getExtras() called while not connected (state=" + a(this.l) + ")");
      return this.r;
    }

    @x
    public MediaSessionCompat.Token j()
    {
      if (!f())
        throw new IllegalStateException("getSessionToken() called while not connected(state=" + this.l + ")");
      return this.q;
    }

    private class a
      implements ServiceConnection
    {
      private a()
      {
      }

      private void a(Runnable paramRunnable)
      {
        if (Thread.currentThread() == MediaBrowserCompat.h.d(MediaBrowserCompat.h.this).getLooper().getThread())
        {
          paramRunnable.run();
          return;
        }
        MediaBrowserCompat.h.d(MediaBrowserCompat.h.this).post(paramRunnable);
      }

      private boolean a(String paramString)
      {
        if (MediaBrowserCompat.h.a(MediaBrowserCompat.h.this) != this)
        {
          if (MediaBrowserCompat.h.j(MediaBrowserCompat.h.this) != 0)
            Log.i("MediaBrowserCompat", paramString + " for " + MediaBrowserCompat.h.i(MediaBrowserCompat.h.this) + " with mServiceConnection=" + MediaBrowserCompat.h.a(MediaBrowserCompat.h.this) + " this=" + this);
          return false;
        }
        return true;
      }

      public void onServiceConnected(ComponentName paramComponentName, IBinder paramIBinder)
      {
        a(new i(this, paramComponentName, paramIBinder));
      }

      public void onServiceDisconnected(ComponentName paramComponentName)
      {
        a(new j(this, paramComponentName));
      }
    }
  }

  private static class i
  {
    private Messenger a;

    public i(IBinder paramIBinder)
    {
      this.a = new Messenger(paramIBinder);
    }

    private void a(int paramInt, Bundle paramBundle, Messenger paramMessenger)
      throws RemoteException
    {
      Message localMessage = Message.obtain();
      localMessage.what = paramInt;
      localMessage.arg1 = 1;
      localMessage.setData(paramBundle);
      localMessage.replyTo = paramMessenger;
      this.a.send(localMessage);
    }

    void a(Context paramContext, Bundle paramBundle, Messenger paramMessenger)
      throws RemoteException
    {
      Bundle localBundle = new Bundle();
      localBundle.putString("data_package_name", paramContext.getPackageName());
      localBundle.putBundle("data_root_hints", paramBundle);
      a(1, localBundle, paramMessenger);
    }

    void a(Messenger paramMessenger)
      throws RemoteException
    {
      a(2, null, paramMessenger);
    }

    void a(String paramString, Bundle paramBundle, Messenger paramMessenger)
      throws RemoteException
    {
      Bundle localBundle = new Bundle();
      localBundle.putString("data_media_item_id", paramString);
      localBundle.putBundle("data_options", paramBundle);
      a(3, localBundle, paramMessenger);
    }

    void a(String paramString, ResultReceiver paramResultReceiver)
      throws RemoteException
    {
      Bundle localBundle = new Bundle();
      localBundle.putString("data_media_item_id", paramString);
      localBundle.putParcelable("data_result_receiver", paramResultReceiver);
      a(5, localBundle, null);
    }

    void b(Messenger paramMessenger)
      throws RemoteException
    {
      a(6, null, paramMessenger);
    }

    void b(String paramString, Bundle paramBundle, Messenger paramMessenger)
      throws RemoteException
    {
      Bundle localBundle = new Bundle();
      localBundle.putString("data_media_item_id", paramString);
      localBundle.putBundle("data_options", paramBundle);
      a(4, localBundle, paramMessenger);
    }
  }

  private static class j
  {
    private final List<MediaBrowserCompat.k> a = new ArrayList();
    private final List<Bundle> b = new ArrayList();

    public void a(MediaBrowserCompat.k paramk, Bundle paramBundle)
    {
      for (int i = 0; i < this.b.size(); i++)
        if (n.a((Bundle)this.b.get(i), paramBundle))
        {
          this.a.set(i, paramk);
          return;
        }
      this.a.add(paramk);
      this.b.add(paramBundle);
    }

    public boolean a()
    {
      return this.a.isEmpty();
    }

    public boolean a(Bundle paramBundle)
    {
      for (int i = 0; ; i++)
      {
        int j = this.b.size();
        boolean bool = false;
        if (i < j)
        {
          if (n.a((Bundle)this.b.get(i), paramBundle))
          {
            this.a.remove(i);
            this.b.remove(i);
            bool = true;
          }
        }
        else
          return bool;
      }
    }

    public MediaBrowserCompat.k b(Bundle paramBundle)
    {
      for (int i = 0; i < this.b.size(); i++)
        if (n.a((Bundle)this.b.get(i), paramBundle))
          return (MediaBrowserCompat.k)this.a.get(i);
      return null;
    }

    public List<Bundle> b()
    {
      return this.b;
    }

    public List<MediaBrowserCompat.k> c()
    {
      return this.a;
    }
  }

  public static abstract class k
  {
    public void a(@x String paramString)
    {
    }

    public void a(@x String paramString, @x Bundle paramBundle)
    {
    }

    public void a(@x String paramString, List<MediaBrowserCompat.MediaItem> paramList)
    {
    }

    public void a(@x String paramString, List<MediaBrowserCompat.MediaItem> paramList, @x Bundle paramBundle)
    {
    }
  }

  static class l extends MediaBrowserCompat.k
  {
    MediaBrowserCompat.k a;
    private final Object b;
    private Bundle c;

    public l(MediaBrowserCompat.k paramk, Bundle paramBundle)
    {
      this.a = paramk;
      this.c = paramBundle;
      this.b = l.a(new a(null));
    }

    public void a(@x String paramString)
    {
      this.a.a(paramString);
    }

    public void a(@x String paramString, @x Bundle paramBundle)
    {
      this.a.a(paramString, paramBundle);
    }

    public void a(@x String paramString, List<MediaBrowserCompat.MediaItem> paramList)
    {
      this.a.a(paramString, paramList);
    }

    public void a(@x String paramString, List<MediaBrowserCompat.MediaItem> paramList, @x Bundle paramBundle)
    {
      this.a.a(paramString, paramList, paramBundle);
    }

    private class a
      implements l.c
    {
      private a()
      {
      }

      public void a(@x String paramString)
      {
        if (MediaBrowserCompat.l.a(MediaBrowserCompat.l.this) != null)
        {
          MediaBrowserCompat.l.this.a(paramString, MediaBrowserCompat.l.a(MediaBrowserCompat.l.this));
          return;
        }
        MediaBrowserCompat.l.this.a(paramString);
      }

      public void a(@x String paramString, List<Parcel> paramList)
      {
        Object localObject = null;
        if (paramList != null)
        {
          ArrayList localArrayList = new ArrayList();
          Iterator localIterator = paramList.iterator();
          while (localIterator.hasNext())
          {
            Parcel localParcel = (Parcel)localIterator.next();
            localParcel.setDataPosition(0);
            localArrayList.add(MediaBrowserCompat.MediaItem.CREATOR.createFromParcel(localParcel));
            localParcel.recycle();
          }
          localObject = localArrayList;
        }
        if (MediaBrowserCompat.l.a(MediaBrowserCompat.l.this) != null)
        {
          MediaBrowserCompat.l.this.a(paramString, n.a(localObject, MediaBrowserCompat.l.a(MediaBrowserCompat.l.this)), MediaBrowserCompat.l.a(MediaBrowserCompat.l.this));
          return;
        }
        MediaBrowserCompat.l.this.a(paramString, localObject);
      }
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.media.MediaBrowserCompat
 * JD-Core Version:    0.6.2
 */