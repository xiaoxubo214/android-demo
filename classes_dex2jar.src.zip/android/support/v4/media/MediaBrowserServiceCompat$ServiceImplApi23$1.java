package android.support.v4.media;

import android.os.Bundle;
import android.os.Handler;
import android.os.Parcel;
import android.support.v4.os.ResultReceiver;

class MediaBrowserServiceCompat$ServiceImplApi23$1 extends ResultReceiver
{
  MediaBrowserServiceCompat$ServiceImplApi23$1(p.n paramn, Handler paramHandler, ab.a parama)
  {
    super(paramHandler);
  }

  protected void a(int paramInt, Bundle paramBundle)
  {
    MediaBrowserCompat.MediaItem localMediaItem = (MediaBrowserCompat.MediaItem)paramBundle.getParcelable("media_item");
    Parcel localParcel2;
    if (localMediaItem != null)
    {
      localParcel2 = Parcel.obtain();
      localMediaItem.writeToParcel(localParcel2, 0);
    }
    for (Parcel localParcel1 = localParcel2; ; localParcel1 = null)
    {
      this.a.a(paramInt, paramBundle, localParcel1);
      return;
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.media.MediaBrowserServiceCompat.ServiceImplApi23.1
 * JD-Core Version:    0.6.2
 */