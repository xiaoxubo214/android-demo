package android.support.v4.media;

import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.annotation.y;
import android.text.TextUtils;

public final class MediaDescriptionCompat
  implements Parcelable
{
  public static final Parcelable.Creator<MediaDescriptionCompat> CREATOR = new ad();
  public static final String a = "android.support.v4.media.description.MEDIA_URI";
  public static final String b = "android.support.v4.media.description.NULL_BUNDLE_FLAG";
  private final String c;
  private final CharSequence d;
  private final CharSequence e;
  private final CharSequence f;
  private final Bitmap g;
  private final Uri h;
  private final Bundle i;
  private final Uri j;
  private Object k;

  private MediaDescriptionCompat(Parcel paramParcel)
  {
    this.c = paramParcel.readString();
    this.d = ((CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(paramParcel));
    this.e = ((CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(paramParcel));
    this.f = ((CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(paramParcel));
    this.g = ((Bitmap)paramParcel.readParcelable(null));
    this.h = ((Uri)paramParcel.readParcelable(null));
    this.i = paramParcel.readBundle();
    this.j = ((Uri)paramParcel.readParcelable(null));
  }

  private MediaDescriptionCompat(String paramString, CharSequence paramCharSequence1, CharSequence paramCharSequence2, CharSequence paramCharSequence3, Bitmap paramBitmap, Uri paramUri1, Bundle paramBundle, Uri paramUri2)
  {
    this.c = paramString;
    this.d = paramCharSequence1;
    this.e = paramCharSequence2;
    this.f = paramCharSequence3;
    this.g = paramBitmap;
    this.h = paramUri1;
    this.i = paramBundle;
    this.j = paramUri2;
  }

  public static MediaDescriptionCompat a(Object paramObject)
  {
    if ((paramObject == null) || (Build.VERSION.SDK_INT < 21))
      return null;
    a locala = new a();
    locala.a(ae.a(paramObject));
    locala.a(ae.b(paramObject));
    locala.b(ae.c(paramObject));
    locala.c(ae.d(paramObject));
    locala.a(ae.e(paramObject));
    locala.a(ae.f(paramObject));
    Bundle localBundle1 = ae.g(paramObject);
    Uri localUri;
    Bundle localBundle2;
    if (localBundle1 == null)
    {
      localUri = null;
      if (localUri == null)
        break label180;
      if ((!localBundle1.containsKey("android.support.v4.media.description.NULL_BUNDLE_FLAG")) || (localBundle1.size() != 2))
        break label166;
      localBundle2 = null;
      label117: locala.a(localBundle2);
      if (localUri == null)
        break label187;
      locala.b(localUri);
    }
    while (true)
    {
      MediaDescriptionCompat localMediaDescriptionCompat = locala.a();
      localMediaDescriptionCompat.k = paramObject;
      return localMediaDescriptionCompat;
      localUri = (Uri)localBundle1.getParcelable("android.support.v4.media.description.MEDIA_URI");
      break;
      label166: localBundle1.remove("android.support.v4.media.description.MEDIA_URI");
      localBundle1.remove("android.support.v4.media.description.NULL_BUNDLE_FLAG");
      label180: localBundle2 = localBundle1;
      break label117;
      label187: if (Build.VERSION.SDK_INT >= 23)
        locala.b(af.h(paramObject));
    }
  }

  @y
  public String a()
  {
    return this.c;
  }

  @y
  public CharSequence b()
  {
    return this.d;
  }

  @y
  public CharSequence c()
  {
    return this.e;
  }

  @y
  public CharSequence d()
  {
    return this.f;
  }

  public int describeContents()
  {
    return 0;
  }

  @y
  public Bitmap e()
  {
    return this.g;
  }

  @y
  public Uri f()
  {
    return this.h;
  }

  @y
  public Bundle g()
  {
    return this.i;
  }

  @y
  public Uri h()
  {
    return this.j;
  }

  public Object i()
  {
    if ((this.k != null) || (Build.VERSION.SDK_INT < 21))
      return this.k;
    Object localObject = ae.a.a();
    ae.a.a(localObject, this.c);
    ae.a.a(localObject, this.d);
    ae.a.b(localObject, this.e);
    ae.a.c(localObject, this.f);
    ae.a.a(localObject, this.g);
    ae.a.a(localObject, this.h);
    Bundle localBundle = this.i;
    if ((Build.VERSION.SDK_INT < 23) && (this.j != null))
    {
      if (localBundle == null)
      {
        localBundle = new Bundle();
        localBundle.putBoolean("android.support.v4.media.description.NULL_BUNDLE_FLAG", true);
      }
      localBundle.putParcelable("android.support.v4.media.description.MEDIA_URI", this.j);
    }
    ae.a.a(localObject, localBundle);
    if (Build.VERSION.SDK_INT >= 23)
      af.a.b(localObject, this.j);
    this.k = ae.a.a(localObject);
    return this.k;
  }

  public String toString()
  {
    return this.d + ", " + this.e + ", " + this.f;
  }

  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    if (Build.VERSION.SDK_INT < 21)
    {
      paramParcel.writeString(this.c);
      TextUtils.writeToParcel(this.d, paramParcel, paramInt);
      TextUtils.writeToParcel(this.e, paramParcel, paramInt);
      TextUtils.writeToParcel(this.f, paramParcel, paramInt);
      paramParcel.writeParcelable(this.g, paramInt);
      paramParcel.writeParcelable(this.h, paramInt);
      paramParcel.writeBundle(this.i);
      paramParcel.writeParcelable(this.j, paramInt);
      return;
    }
    ae.a(i(), paramParcel, paramInt);
  }

  public static final class a
  {
    private String a;
    private CharSequence b;
    private CharSequence c;
    private CharSequence d;
    private Bitmap e;
    private Uri f;
    private Bundle g;
    private Uri h;

    public a a(@y Bitmap paramBitmap)
    {
      this.e = paramBitmap;
      return this;
    }

    public a a(@y Uri paramUri)
    {
      this.f = paramUri;
      return this;
    }

    public a a(@y Bundle paramBundle)
    {
      this.g = paramBundle;
      return this;
    }

    public a a(@y CharSequence paramCharSequence)
    {
      this.b = paramCharSequence;
      return this;
    }

    public a a(@y String paramString)
    {
      this.a = paramString;
      return this;
    }

    public MediaDescriptionCompat a()
    {
      return new MediaDescriptionCompat(this.a, this.b, this.c, this.d, this.e, this.f, this.g, this.h, null);
    }

    public a b(@y Uri paramUri)
    {
      this.h = paramUri;
      return this;
    }

    public a b(@y CharSequence paramCharSequence)
    {
      this.c = paramCharSequence;
      return this;
    }

    public a c(@y CharSequence paramCharSequence)
    {
      this.d = paramCharSequence;
      return this;
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.media.MediaDescriptionCompat
 * JD-Core Version:    0.6.2
 */