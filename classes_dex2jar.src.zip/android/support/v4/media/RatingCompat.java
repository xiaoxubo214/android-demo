package android.support.v4.media;

import android.os.Build.VERSION;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.util.Log;
import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

public final class RatingCompat
  implements Parcelable
{
  public static final Parcelable.Creator<RatingCompat> CREATOR = new aj();
  public static final int a = 0;
  public static final int b = 1;
  public static final int c = 2;
  public static final int d = 3;
  public static final int e = 4;
  public static final int f = 5;
  public static final int g = 6;
  private static final String h = "Rating";
  private static final float i = -1.0F;
  private final int j;
  private final float k;
  private Object l;

  private RatingCompat(int paramInt, float paramFloat)
  {
    this.j = paramInt;
    this.k = paramFloat;
  }

  public static RatingCompat a(float paramFloat)
  {
    if ((paramFloat < 0.0F) || (paramFloat > 100.0F))
    {
      Log.e("Rating", "Invalid percentage-based rating value");
      return null;
    }
    return new RatingCompat(6, paramFloat);
  }

  public static RatingCompat a(int paramInt)
  {
    switch (paramInt)
    {
    default:
      return null;
    case 1:
    case 2:
    case 3:
    case 4:
    case 5:
    case 6:
    }
    return new RatingCompat(paramInt, -1.0F);
  }

  public static RatingCompat a(int paramInt, float paramFloat)
  {
    float f1;
    switch (paramInt)
    {
    default:
      Log.e("Rating", "Invalid rating style (" + paramInt + ") for a star rating");
      return null;
    case 3:
      f1 = 3.0F;
    case 4:
    case 5:
    }
    while ((paramFloat < 0.0F) || (paramFloat > f1))
    {
      Log.e("Rating", "Trying to set out of range star-based rating");
      return null;
      f1 = 4.0F;
      continue;
      f1 = 5.0F;
    }
    return new RatingCompat(paramInt, paramFloat);
  }

  public static RatingCompat a(Object paramObject)
  {
    if ((paramObject == null) || (Build.VERSION.SDK_INT < 21))
      return null;
    int m = ak.b(paramObject);
    RatingCompat localRatingCompat;
    if (ak.a(paramObject))
      switch (m)
      {
      default:
        return null;
      case 1:
        localRatingCompat = a(ak.c(paramObject));
      case 2:
      case 3:
      case 4:
      case 5:
      case 6:
      }
    while (true)
    {
      localRatingCompat.l = paramObject;
      return localRatingCompat;
      localRatingCompat = b(ak.d(paramObject));
      continue;
      localRatingCompat = a(m, ak.e(paramObject));
      continue;
      localRatingCompat = a(ak.f(paramObject));
      continue;
      localRatingCompat = a(m);
    }
  }

  public static RatingCompat a(boolean paramBoolean)
  {
    if (paramBoolean);
    for (float f1 = 1.0F; ; f1 = 0.0F)
      return new RatingCompat(1, f1);
  }

  public static RatingCompat b(boolean paramBoolean)
  {
    if (paramBoolean);
    for (float f1 = 1.0F; ; f1 = 0.0F)
      return new RatingCompat(2, f1);
  }

  public boolean a()
  {
    return this.k >= 0.0F;
  }

  public int b()
  {
    return this.j;
  }

  public boolean c()
  {
    int m = 1;
    if (this.j != m)
      return false;
    if (this.k == 1.0F);
    while (true)
    {
      return m;
      int n = 0;
    }
  }

  public boolean d()
  {
    if (this.j != 2);
    while (this.k != 1.0F)
      return false;
    return true;
  }

  public int describeContents()
  {
    return this.j;
  }

  public float e()
  {
    switch (this.j)
    {
    default:
    case 3:
    case 4:
    case 5:
    }
    do
      return -1.0F;
    while (!a());
    return this.k;
  }

  public float f()
  {
    if ((this.j != 6) || (!a()))
      return -1.0F;
    return this.k;
  }

  public Object g()
  {
    if ((this.l != null) || (Build.VERSION.SDK_INT < 21))
      return this.l;
    if (a())
      switch (this.j)
      {
      default:
        return null;
      case 1:
        this.l = ak.a(c());
      case 2:
      case 3:
      case 4:
      case 5:
      case 6:
      }
    while (true)
    {
      return this.l;
      this.l = ak.b(d());
      continue;
      this.l = ak.a(this.j, e());
      continue;
      this.l = ak.a(f());
      break;
      this.l = ak.a(this.j);
    }
  }

  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder().append("Rating:style=").append(this.j).append(" rating=");
    if (this.k < 0.0F);
    for (String str = "unrated"; ; str = String.valueOf(this.k))
      return str;
  }

  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    paramParcel.writeInt(this.j);
    paramParcel.writeFloat(this.k);
  }

  @Retention(RetentionPolicy.SOURCE)
  public static @interface a
  {
  }

  @Retention(RetentionPolicy.SOURCE)
  public static @interface b
  {
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.media.RatingCompat
 * JD-Core Version:    0.6.2
 */