package android.support.v4.media;

import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.os.RemoteException;
import android.os.ResultReceiver;

class a
{
  static abstract class a extends Binder
    implements IInterface
  {
    private static final String a = "android.service.media.IMediaBrowserService";
    private static final int b = 1;
    private static final int c = 2;
    private static final int d = 3;
    private static final int e = 4;
    private static final int f = 5;

    public a()
    {
      attachInterface(this, "android.service.media.IMediaBrowserService");
    }

    public abstract void a(Object paramObject);

    public abstract void a(String paramString, Bundle paramBundle, Object paramObject);

    public abstract void a(String paramString, ResultReceiver paramResultReceiver);

    public abstract void a(String paramString, Object paramObject);

    public IBinder asBinder()
    {
      return this;
    }

    public abstract void b(String paramString, Object paramObject);

    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      switch (paramInt1)
      {
      default:
        return super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902:
        paramParcel2.writeString("android.service.media.IMediaBrowserService");
        return true;
      case 1:
        paramParcel1.enforceInterface("android.service.media.IMediaBrowserService");
        String str2 = paramParcel1.readString();
        int j = paramParcel1.readInt();
        Bundle localBundle = null;
        if (j != 0)
          localBundle = (Bundle)Bundle.CREATOR.createFromParcel(paramParcel1);
        a(str2, localBundle, b.a.a(paramParcel1.readStrongBinder()));
        return true;
      case 2:
        paramParcel1.enforceInterface("android.service.media.IMediaBrowserService");
        a(b.a.a(paramParcel1.readStrongBinder()));
        return true;
      case 3:
        paramParcel1.enforceInterface("android.service.media.IMediaBrowserService");
        a(paramParcel1.readString(), b.a.a(paramParcel1.readStrongBinder()));
        return true;
      case 4:
        paramParcel1.enforceInterface("android.service.media.IMediaBrowserService");
        b(paramParcel1.readString(), b.a.a(paramParcel1.readStrongBinder()));
        return true;
      case 5:
      }
      paramParcel1.enforceInterface("android.service.media.IMediaBrowserService");
      String str1 = paramParcel1.readString();
      int i = paramParcel1.readInt();
      ResultReceiver localResultReceiver = null;
      if (i != 0)
        localResultReceiver = (ResultReceiver)ResultReceiver.CREATOR.createFromParcel(paramParcel1);
      a(str1, localResultReceiver);
      return true;
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.media.a
 * JD-Core Version:    0.6.2
 */