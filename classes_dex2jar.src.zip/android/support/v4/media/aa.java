package android.support.v4.media;

import android.content.Intent;
import android.media.MediaDescription.Builder;
import android.media.browse.MediaBrowser.MediaItem;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.os.RemoteException;
import android.os.ResultReceiver;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

class aa
{
  public static IBinder a(Object paramObject, Intent paramIntent)
  {
    return ((a)paramObject).a(paramIntent);
  }

  public static Object a()
  {
    return new a();
  }

  public static void a(Object paramObject, d paramd)
  {
    ((a)paramObject).a(paramd);
  }

  static class a
  {
    a a;

    public IBinder a(Intent paramIntent)
    {
      if ("android.media.browse.MediaBrowserService".equals(paramIntent.getAction()))
        return this.a;
      return null;
    }

    public void a(aa.d paramd)
    {
      this.a = new a(paramd);
    }

    static class a extends a.a
    {
      final aa.d a;

      a(aa.d paramd)
      {
        this.a = paramd;
      }

      public void a(Object paramObject)
      {
        this.a.a(new aa.c(paramObject));
      }

      public void a(String paramString, Bundle paramBundle, Object paramObject)
      {
        this.a.a(paramString, paramBundle, new aa.c(paramObject));
      }

      public void a(String paramString, ResultReceiver paramResultReceiver)
      {
      }

      public void a(String paramString, Object paramObject)
      {
        this.a.a(paramString, new aa.c(paramObject));
      }

      public void b(String paramString, Object paramObject)
      {
        this.a.b(paramString, new aa.c(paramObject));
      }
    }
  }

  public static abstract interface b
  {
    public abstract IBinder a();

    public abstract void a(String paramString, Object paramObject, Bundle paramBundle)
      throws RemoteException;

    public abstract void a(String paramString, List<Parcel> paramList)
      throws RemoteException;

    public abstract void b()
      throws RemoteException;
  }

  public static class c
    implements aa.b
  {
    private static Object a = ai.a(localArrayList);
    private final b b;

    static
    {
      MediaBrowser.MediaItem localMediaItem = new MediaBrowser.MediaItem(new MediaDescription.Builder().setMediaId("android.support.v4.media.MediaBrowserCompat.NULL_MEDIA_ITEM").build(), 0);
      ArrayList localArrayList = new ArrayList();
      localArrayList.add(localMediaItem);
    }

    c(Object paramObject)
    {
      this.b = new b(paramObject);
    }

    public IBinder a()
    {
      return this.b.a();
    }

    public void a(String paramString, Object paramObject, Bundle paramBundle)
      throws RemoteException
    {
      this.b.a(paramString, paramObject, paramBundle);
    }

    public void a(String paramString, List<Parcel> paramList)
      throws RemoteException
    {
      ArrayList localArrayList1;
      if (paramList != null)
      {
        localArrayList1 = new ArrayList();
        Iterator localIterator = paramList.iterator();
        while (localIterator.hasNext())
        {
          Parcel localParcel = (Parcel)localIterator.next();
          localParcel.setDataPosition(0);
          localArrayList1.add(MediaBrowser.MediaItem.CREATOR.createFromParcel(localParcel));
          localParcel.recycle();
        }
      }
      for (ArrayList localArrayList2 = localArrayList1; ; localArrayList2 = null)
      {
        Object localObject1;
        if (Build.VERSION.SDK_INT > 23)
        {
          localObject1 = null;
          if (localArrayList2 == null);
          while (true)
          {
            this.b.a(paramString, localObject1);
            return;
            localObject1 = ai.a(localArrayList2);
          }
        }
        if (localArrayList2 == null);
        for (Object localObject2 = a; ; localObject2 = ai.a(localArrayList2))
        {
          localObject1 = localObject2;
          break;
        }
      }
    }

    public void b()
      throws RemoteException
    {
      this.b.b();
    }
  }

  public static abstract interface d
  {
    public abstract void a(aa.b paramb);

    public abstract void a(String paramString, Bundle paramBundle, aa.b paramb);

    public abstract void a(String paramString, aa.b paramb);

    public abstract void b(String paramString, aa.b paramb);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.media.aa
 * JD-Core Version:    0.6.2
 */