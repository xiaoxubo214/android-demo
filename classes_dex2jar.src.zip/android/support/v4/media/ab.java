package android.support.v4.media;

import android.os.Bundle;
import android.os.Parcel;
import android.os.ResultReceiver;
import android.service.media.MediaBrowserService;
import android.util.Log;
import java.lang.reflect.Field;

class ab extends aa
{
  private static final String a = "MediaBrowserServiceCompatApi21";

  public static void a(Object paramObject, c paramc)
  {
    ((b)paramObject).a(paramc);
  }

  public static Object b()
  {
    return new b();
  }

  public static abstract interface a
  {
    public abstract void a(int paramInt, Bundle paramBundle, Parcel paramParcel);
  }

  static class b extends aa.a
  {
    public void a(ab.c paramc)
    {
      this.a = new a(paramc);
    }

    private static class a extends aa.a.a
    {
      ab.c b;

      a(ab.c paramc)
      {
        super();
        this.b = paramc;
      }

      public void a(String paramString, ResultReceiver paramResultReceiver)
      {
        try
        {
          String str = (String)MediaBrowserService.class.getDeclaredField("KEY_MEDIA_ITEM").get(null);
          this.b.a(paramString, new ac(this, str, paramResultReceiver));
          return;
        }
        catch (NoSuchFieldException localNoSuchFieldException)
        {
          Log.i("MediaBrowserServiceCompatApi21", "Failed to get KEY_MEDIA_ITEM via reflection", localNoSuchFieldException);
          return;
        }
        catch (IllegalAccessException localIllegalAccessException)
        {
          label39: break label39;
        }
      }
    }
  }

  public static abstract interface c extends aa.d
  {
    public abstract void a(String paramString, ab.a parama);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.media.ab
 * JD-Core Version:    0.6.2
 */