package android.support.v4.media;

import android.media.browse.MediaBrowser.MediaItem;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.os.ResultReceiver;

class ac
  implements ab.a
{
  ac(ab.b.a parama, String paramString, ResultReceiver paramResultReceiver)
  {
  }

  public void a(int paramInt, Bundle paramBundle, Parcel paramParcel)
  {
    if (paramParcel != null)
    {
      paramParcel.setDataPosition(0);
      MediaBrowser.MediaItem localMediaItem = (MediaBrowser.MediaItem)MediaBrowser.MediaItem.CREATOR.createFromParcel(paramParcel);
      paramBundle.putParcelable(this.a, localMediaItem);
      paramParcel.recycle();
    }
    this.b.send(paramInt, paramBundle);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.media.ac
 * JD-Core Version:    0.6.2
 */