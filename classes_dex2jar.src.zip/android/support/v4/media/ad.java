package android.support.v4.media;

import android.os.Build.VERSION;
import android.os.Parcel;
import android.os.Parcelable.Creator;

final class ad
  implements Parcelable.Creator<MediaDescriptionCompat>
{
  public MediaDescriptionCompat a(Parcel paramParcel)
  {
    if (Build.VERSION.SDK_INT < 21)
      return new MediaDescriptionCompat(paramParcel, null);
    return MediaDescriptionCompat.a(ae.a(paramParcel));
  }

  public MediaDescriptionCompat[] a(int paramInt)
  {
    return new MediaDescriptionCompat[paramInt];
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.media.ad
 * JD-Core Version:    0.6.2
 */