package android.support.v4.media;

import android.media.MediaDescription;
import android.media.MediaDescription.Builder;
import android.net.Uri;

class af extends ae
{
  public static Uri h(Object paramObject)
  {
    return ((MediaDescription)paramObject).getMediaUri();
  }

  static class a extends ae.a
  {
    public static void b(Object paramObject, Uri paramUri)
    {
      ((MediaDescription.Builder)paramObject).setMediaUri(paramUri);
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.media.af
 * JD-Core Version:    0.6.2
 */