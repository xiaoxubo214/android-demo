package android.support.v4.media;

import android.os.Parcel;
import android.os.Parcelable.Creator;

final class ag
  implements Parcelable.Creator<MediaMetadataCompat>
{
  public MediaMetadataCompat a(Parcel paramParcel)
  {
    return new MediaMetadataCompat(paramParcel, null);
  }

  public MediaMetadataCompat[] a(int paramInt)
  {
    return new MediaMetadataCompat[paramInt];
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.media.ag
 * JD-Core Version:    0.6.2
 */