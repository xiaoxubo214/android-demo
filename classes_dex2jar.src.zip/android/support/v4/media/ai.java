package android.support.v4.media;

import android.media.browse.MediaBrowser.MediaItem;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.List;

class ai
{
  private static Constructor a;

  static
  {
    try
    {
      a = Class.forName("android.content.pm.ParceledListSlice").getConstructor(new Class[] { List.class });
      return;
    }
    catch (ClassNotFoundException localClassNotFoundException)
    {
      localClassNotFoundException.printStackTrace();
      return;
    }
    catch (NoSuchMethodException localNoSuchMethodException)
    {
      label22: break label22;
    }
  }

  static Object a(List<MediaBrowser.MediaItem> paramList)
  {
    try
    {
      Object localObject = a.newInstance(new Object[] { paramList });
      return localObject;
    }
    catch (InstantiationException localInstantiationException)
    {
      localInstantiationException.printStackTrace();
      return null;
    }
    catch (IllegalAccessException localIllegalAccessException)
    {
      break label18;
    }
    catch (InvocationTargetException localInvocationTargetException)
    {
      label18: break label18;
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.media.ai
 * JD-Core Version:    0.6.2
 */