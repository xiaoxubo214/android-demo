package android.support.v4.media;

import android.os.Parcel;
import android.os.Parcelable.Creator;

final class aj
  implements Parcelable.Creator<RatingCompat>
{
  public RatingCompat a(Parcel paramParcel)
  {
    return new RatingCompat(paramParcel.readInt(), paramParcel.readFloat(), null);
  }

  public RatingCompat[] a(int paramInt)
  {
    return new RatingCompat[paramInt];
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.media.aj
 * JD-Core Version:    0.6.2
 */