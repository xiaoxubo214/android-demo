package android.support.v4.media;

public abstract class al
{
  public abstract void a();

  public abstract void a(long paramLong);

  public abstract void a(ay paramay);

  public abstract void b();

  public abstract void b(ay paramay);

  public abstract void c();

  public abstract long d();

  public abstract long e();

  public abstract boolean f();

  public abstract int g();

  public abstract int h();
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.media.al
 * JD-Core Version:    0.6.2
 */