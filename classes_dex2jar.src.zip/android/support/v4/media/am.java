package android.support.v4.media;

import android.app.Activity;
import android.content.Context;
import android.media.AudioManager;
import android.os.Build.VERSION;
import android.support.v4.view.m;
import android.view.KeyEvent;
import android.view.KeyEvent.Callback;
import android.view.View;
import android.view.Window;
import java.util.ArrayList;

public class am extends al
{
  public static final int i = 126;
  public static final int j = 127;
  public static final int k = 130;
  public static final int l = 1;
  public static final int m = 2;
  public static final int n = 4;
  public static final int o = 8;
  public static final int p = 16;
  public static final int q = 32;
  public static final int r = 64;
  public static final int s = 128;
  final Context a;
  final ax b;
  final AudioManager c;
  final View d;
  final Object e;
  final aq f;
  final ArrayList<ay> g = new ArrayList();
  final ap h = new an(this);
  final KeyEvent.Callback t = new ao(this);

  public am(Activity paramActivity, ax paramax)
  {
    this(paramActivity, null, paramax);
  }

  private am(Activity paramActivity, View paramView, ax paramax)
  {
    if (paramActivity != null);
    for (Object localObject = paramActivity; ; localObject = paramView.getContext())
    {
      this.a = ((Context)localObject);
      this.b = paramax;
      this.c = ((AudioManager)this.a.getSystemService("audio"));
      if (paramActivity != null)
        paramView = paramActivity.getWindow().getDecorView();
      this.d = paramView;
      this.e = m.a(this.d);
      if (Build.VERSION.SDK_INT < 18)
        break;
      this.f = new aq(this.a, this.c, this.d, this.h);
      return;
    }
    this.f = null;
  }

  public am(View paramView, ax paramax)
  {
    this(null, paramView, paramax);
  }

  static boolean a(int paramInt)
  {
    switch (paramInt)
    {
    default:
      return false;
    case 79:
    case 85:
    case 86:
    case 87:
    case 88:
    case 89:
    case 90:
    case 91:
    case 126:
    case 127:
    case 130:
    }
    return true;
  }

  private ay[] l()
  {
    if (this.g.size() <= 0)
      return null;
    ay[] arrayOfay = new ay[this.g.size()];
    this.g.toArray(arrayOfay);
    return arrayOfay;
  }

  private void m()
  {
    ay[] arrayOfay = l();
    if (arrayOfay != null)
    {
      int i1 = arrayOfay.length;
      for (int i2 = 0; i2 < i1; i2++)
        arrayOfay[i2].a(this);
    }
  }

  private void n()
  {
    ay[] arrayOfay = l();
    if (arrayOfay != null)
    {
      int i1 = arrayOfay.length;
      for (int i2 = 0; i2 < i1; i2++)
        arrayOfay[i2].b(this);
    }
  }

  private void o()
  {
    if (this.f != null)
      this.f.a(this.b.f(), this.b.e(), this.b.h());
  }

  public void a()
  {
    if (this.f != null)
      this.f.f();
    this.b.a();
    o();
    m();
  }

  public void a(long paramLong)
  {
    this.b.a(paramLong);
  }

  public void a(ay paramay)
  {
    this.g.add(paramay);
  }

  public boolean a(KeyEvent paramKeyEvent)
  {
    return m.a(paramKeyEvent, this.t, this.e, this);
  }

  public void b()
  {
    if (this.f != null)
      this.f.g();
    this.b.b();
    o();
    m();
  }

  public void b(ay paramay)
  {
    this.g.remove(paramay);
  }

  public void c()
  {
    if (this.f != null)
      this.f.h();
    this.b.c();
    o();
    m();
  }

  public long d()
  {
    return this.b.d();
  }

  public long e()
  {
    return this.b.e();
  }

  public boolean f()
  {
    return this.b.f();
  }

  public int g()
  {
    return this.b.g();
  }

  public int h()
  {
    return this.b.h();
  }

  public Object i()
  {
    if (this.f != null)
      return this.f.a();
    return null;
  }

  public void j()
  {
    o();
    m();
    n();
  }

  public void k()
  {
    this.f.b();
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.media.am
 * JD-Core Version:    0.6.2
 */