package android.support.v4.media;

import android.view.KeyEvent;

class an
  implements ap
{
  an(am paramam)
  {
  }

  public long a()
  {
    return this.a.b.e();
  }

  public void a(int paramInt)
  {
    this.a.b.a(paramInt);
  }

  public void a(long paramLong)
  {
    this.a.b.a(paramLong);
  }

  public void a(KeyEvent paramKeyEvent)
  {
    paramKeyEvent.dispatch(this.a.t);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.media.an
 * JD-Core Version:    0.6.2
 */