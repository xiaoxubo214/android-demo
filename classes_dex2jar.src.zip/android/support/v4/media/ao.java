package android.support.v4.media;

import android.view.KeyEvent;
import android.view.KeyEvent.Callback;

class ao
  implements KeyEvent.Callback
{
  ao(am paramam)
  {
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (am.a(paramInt))
      return this.a.b.a(paramInt, paramKeyEvent);
    return false;
  }

  public boolean onKeyLongPress(int paramInt, KeyEvent paramKeyEvent)
  {
    return false;
  }

  public boolean onKeyMultiple(int paramInt1, int paramInt2, KeyEvent paramKeyEvent)
  {
    return false;
  }

  public boolean onKeyUp(int paramInt, KeyEvent paramKeyEvent)
  {
    if (am.a(paramInt))
      return this.a.b.b(paramInt, paramKeyEvent);
    return false;
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.media.ao
 * JD-Core Version:    0.6.2
 */