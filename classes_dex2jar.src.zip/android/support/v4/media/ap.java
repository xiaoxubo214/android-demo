package android.support.v4.media;

import android.view.KeyEvent;

abstract interface ap
{
  public abstract long a();

  public abstract void a(int paramInt);

  public abstract void a(long paramLong);

  public abstract void a(KeyEvent paramKeyEvent);
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.media.ap
 * JD-Core Version:    0.6.2
 */