package android.support.v4.media;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.AudioManager;
import android.media.AudioManager.OnAudioFocusChangeListener;
import android.media.RemoteControlClient;
import android.media.RemoteControlClient.OnGetPlaybackPositionListener;
import android.media.RemoteControlClient.OnPlaybackPositionUpdateListener;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.ViewTreeObserver.OnWindowAttachListener;
import android.view.ViewTreeObserver.OnWindowFocusChangeListener;

class aq
{
  final Context a;
  final AudioManager b;
  final View c;
  final ap d;
  final String e;
  final IntentFilter f;
  final Intent g;
  final ViewTreeObserver.OnWindowAttachListener h = new ar(this);
  final ViewTreeObserver.OnWindowFocusChangeListener i = new as(this);
  final BroadcastReceiver j = new at(this);
  AudioManager.OnAudioFocusChangeListener k = new au(this);
  final RemoteControlClient.OnGetPlaybackPositionListener l = new av(this);
  final RemoteControlClient.OnPlaybackPositionUpdateListener m = new aw(this);
  PendingIntent n;
  RemoteControlClient o;
  boolean p;
  int q = 0;
  boolean r;

  public aq(Context paramContext, AudioManager paramAudioManager, View paramView, ap paramap)
  {
    this.a = paramContext;
    this.b = paramAudioManager;
    this.c = paramView;
    this.d = paramap;
    this.e = (paramContext.getPackageName() + ":transport:" + System.identityHashCode(this));
    this.g = new Intent(this.e);
    this.g.setPackage(paramContext.getPackageName());
    this.f = new IntentFilter();
    this.f.addAction(this.e);
    this.c.getViewTreeObserver().addOnWindowAttachListener(this.h);
    this.c.getViewTreeObserver().addOnWindowFocusChangeListener(this.i);
  }

  public Object a()
  {
    return this.o;
  }

  public void a(boolean paramBoolean, long paramLong, int paramInt)
  {
    RemoteControlClient localRemoteControlClient;
    int i1;
    if (this.o != null)
    {
      localRemoteControlClient = this.o;
      if (!paramBoolean)
        break label47;
      i1 = 3;
      if (!paramBoolean)
        break label53;
    }
    label47: label53: for (float f1 = 1.0F; ; f1 = 0.0F)
    {
      localRemoteControlClient.setPlaybackState(i1, paramLong, f1);
      this.o.setTransportControlFlags(paramInt);
      return;
      i1 = 1;
      break;
    }
  }

  public void b()
  {
    k();
    this.c.getViewTreeObserver().removeOnWindowAttachListener(this.h);
    this.c.getViewTreeObserver().removeOnWindowFocusChangeListener(this.i);
  }

  void c()
  {
    this.a.registerReceiver(this.j, this.f);
    this.n = PendingIntent.getBroadcast(this.a, 0, this.g, 268435456);
    this.o = new RemoteControlClient(this.n);
    this.o.setOnGetPlaybackPositionListener(this.l);
    this.o.setPlaybackPositionUpdateListener(this.m);
  }

  void d()
  {
    if (!this.p)
    {
      this.p = true;
      this.b.registerMediaButtonEventReceiver(this.n);
      this.b.registerRemoteControlClient(this.o);
      if (this.q == 3)
        e();
    }
  }

  void e()
  {
    if (!this.r)
    {
      this.r = true;
      this.b.requestAudioFocus(this.k, 3, 1);
    }
  }

  public void f()
  {
    if (this.q != 3)
    {
      this.q = 3;
      this.o.setPlaybackState(3);
    }
    if (this.p)
      e();
  }

  public void g()
  {
    if (this.q == 3)
    {
      this.q = 2;
      this.o.setPlaybackState(2);
    }
    i();
  }

  public void h()
  {
    if (this.q != 1)
    {
      this.q = 1;
      this.o.setPlaybackState(1);
    }
    i();
  }

  void i()
  {
    if (this.r)
    {
      this.r = false;
      this.b.abandonAudioFocus(this.k);
    }
  }

  void j()
  {
    i();
    if (this.p)
    {
      this.p = false;
      this.b.unregisterRemoteControlClient(this.o);
      this.b.unregisterMediaButtonEventReceiver(this.n);
    }
  }

  void k()
  {
    j();
    if (this.n != null)
    {
      this.a.unregisterReceiver(this.j);
      this.n.cancel();
      this.n = null;
      this.o = null;
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.media.aq
 * JD-Core Version:    0.6.2
 */