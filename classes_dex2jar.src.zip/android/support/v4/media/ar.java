package android.support.v4.media;

import android.view.ViewTreeObserver.OnWindowAttachListener;

class ar
  implements ViewTreeObserver.OnWindowAttachListener
{
  ar(aq paramaq)
  {
  }

  public void onWindowAttached()
  {
    this.a.c();
  }

  public void onWindowDetached()
  {
    this.a.k();
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.media.ar
 * JD-Core Version:    0.6.2
 */