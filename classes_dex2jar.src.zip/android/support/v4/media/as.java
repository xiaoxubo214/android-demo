package android.support.v4.media;

import android.view.ViewTreeObserver.OnWindowFocusChangeListener;

class as
  implements ViewTreeObserver.OnWindowFocusChangeListener
{
  as(aq paramaq)
  {
  }

  public void onWindowFocusChanged(boolean paramBoolean)
  {
    if (paramBoolean)
    {
      this.a.d();
      return;
    }
    this.a.j();
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.media.as
 * JD-Core Version:    0.6.2
 */