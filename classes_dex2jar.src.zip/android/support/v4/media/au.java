package android.support.v4.media;

import android.media.AudioManager.OnAudioFocusChangeListener;

class au
  implements AudioManager.OnAudioFocusChangeListener
{
  au(aq paramaq)
  {
  }

  public void onAudioFocusChange(int paramInt)
  {
    this.a.d.a(paramInt);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.media.au
 * JD-Core Version:    0.6.2
 */