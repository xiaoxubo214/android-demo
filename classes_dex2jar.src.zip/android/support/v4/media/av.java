package android.support.v4.media;

import android.media.RemoteControlClient.OnGetPlaybackPositionListener;

class av
  implements RemoteControlClient.OnGetPlaybackPositionListener
{
  av(aq paramaq)
  {
  }

  public long onGetPlaybackPosition()
  {
    return this.a.d.a();
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.media.av
 * JD-Core Version:    0.6.2
 */