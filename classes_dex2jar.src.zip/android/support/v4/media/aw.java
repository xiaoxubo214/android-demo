package android.support.v4.media;

import android.media.RemoteControlClient.OnPlaybackPositionUpdateListener;

class aw
  implements RemoteControlClient.OnPlaybackPositionUpdateListener
{
  aw(aq paramaq)
  {
  }

  public void onPlaybackPositionUpdate(long paramLong)
  {
    this.a.d.a(paramLong);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.media.aw
 * JD-Core Version:    0.6.2
 */