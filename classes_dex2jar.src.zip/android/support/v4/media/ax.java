package android.support.v4.media;

import android.os.SystemClock;
import android.view.KeyEvent;

public abstract class ax
{
  static final int a = 1;
  static final int b = 2;
  static final int c = 3;
  static final int d = -1;
  static final int e = -2;
  static final int f = -3;

  public abstract void a();

  public void a(int paramInt)
  {
    int i = 0;
    switch (paramInt)
    {
    default:
    case -1:
    }
    while (true)
    {
      if (i != 0)
      {
        long l = SystemClock.uptimeMillis();
        a(i, new KeyEvent(l, l, 0, i, 0));
        b(i, new KeyEvent(l, l, 1, i, 0));
      }
      return;
      i = 127;
    }
  }

  public abstract void a(long paramLong);

  public boolean a(int paramInt, KeyEvent paramKeyEvent)
  {
    switch (paramInt)
    {
    default:
      return true;
    case 126:
      a();
      return true;
    case 127:
      b();
      return true;
    case 86:
      c();
      return true;
    case 79:
    case 85:
    }
    if (f())
    {
      b();
      return true;
    }
    a();
    return true;
  }

  public abstract void b();

  public boolean b(int paramInt, KeyEvent paramKeyEvent)
  {
    return true;
  }

  public abstract void c();

  public abstract long d();

  public abstract long e();

  public abstract boolean f();

  public int g()
  {
    return 100;
  }

  public int h()
  {
    return 60;
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.media.ax
 * JD-Core Version:    0.6.2
 */