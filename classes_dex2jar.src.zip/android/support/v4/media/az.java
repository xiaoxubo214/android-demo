package android.support.v4.media;

import android.os.Build.VERSION;
import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

public abstract class az
{
  public static final int a = 0;
  public static final int b = 1;
  public static final int c = 2;
  private final int d;
  private final int e;
  private int f;
  private a g;
  private Object h;

  public az(int paramInt1, int paramInt2, int paramInt3)
  {
    this.d = paramInt1;
    this.e = paramInt2;
    this.f = paramInt3;
  }

  public final int a()
  {
    return this.f;
  }

  public final void a(int paramInt)
  {
    this.f = paramInt;
    Object localObject = d();
    if (localObject != null)
      bb.a(localObject, paramInt);
    if (this.g != null)
      this.g.a(this);
  }

  public void a(a parama)
  {
    this.g = parama;
  }

  public final int b()
  {
    return this.d;
  }

  public void b(int paramInt)
  {
  }

  public final int c()
  {
    return this.e;
  }

  public void c(int paramInt)
  {
  }

  public Object d()
  {
    if ((this.h != null) || (Build.VERSION.SDK_INT < 21))
      return this.h;
    this.h = bb.a(this.d, this.e, this.f, new ba(this));
    return this.h;
  }

  public static abstract class a
  {
    public abstract void a(az paramaz);
  }

  @Retention(RetentionPolicy.SOURCE)
  public static @interface b
  {
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.media.az
 * JD-Core Version:    0.6.2
 */