package android.support.v4.media;

import android.media.session.MediaSession.Token;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

class b
{
  Object a;
  private Method b;
  private Method c;
  private Method d;
  private Method e;

  b(Object paramObject)
  {
    this.a = paramObject;
    try
    {
      Class localClass1 = Class.forName("android.service.media.IMediaBrowserServiceCallbacks");
      Class localClass2 = Class.forName("android.content.pm.ParceledListSlice");
      this.b = localClass1.getMethod("asBinder", new Class[0]);
      this.c = localClass1.getMethod("onConnect", new Class[] { String.class, MediaSession.Token.class, Bundle.class });
      this.d = localClass1.getMethod("onConnectFailed", new Class[0]);
      this.e = localClass1.getMethod("onLoadChildren", new Class[] { String.class, localClass2 });
      return;
    }
    catch (ClassNotFoundException localClassNotFoundException)
    {
      localClassNotFoundException.printStackTrace();
      return;
    }
    catch (NoSuchMethodException localNoSuchMethodException)
    {
      label105: break label105;
    }
  }

  IBinder a()
  {
    try
    {
      IBinder localIBinder = (IBinder)this.b.invoke(this.a, new Object[0]);
      return localIBinder;
    }
    catch (IllegalAccessException localIllegalAccessException)
    {
      localIllegalAccessException.printStackTrace();
      return null;
    }
    catch (InvocationTargetException localInvocationTargetException)
    {
      label22: break label22;
    }
  }

  void a(String paramString, Object paramObject)
    throws RemoteException
  {
    try
    {
      this.e.invoke(this.a, new Object[] { paramString, paramObject });
      return;
    }
    catch (IllegalAccessException localIllegalAccessException)
    {
      localIllegalAccessException.printStackTrace();
      return;
    }
    catch (InvocationTargetException localInvocationTargetException)
    {
      label26: break label26;
    }
  }

  void a(String paramString, Object paramObject, Bundle paramBundle)
    throws RemoteException
  {
    try
    {
      this.c.invoke(this.a, new Object[] { paramString, paramObject, paramBundle });
      return;
    }
    catch (IllegalAccessException localIllegalAccessException)
    {
      localIllegalAccessException.printStackTrace();
      return;
    }
    catch (InvocationTargetException localInvocationTargetException)
    {
      label31: break label31;
    }
  }

  void b()
    throws RemoteException
  {
    try
    {
      this.d.invoke(this.a, new Object[0]);
      return;
    }
    catch (IllegalAccessException localIllegalAccessException)
    {
      localIllegalAccessException.printStackTrace();
      return;
    }
    catch (InvocationTargetException localInvocationTargetException)
    {
      label18: break label18;
    }
  }

  static class a
  {
    static Method a;

    static
    {
      try
      {
        a = Class.forName("android.service.media.IMediaBrowserServiceCallbacks$Stub").getMethod("asInterface", new Class[] { IBinder.class });
        return;
      }
      catch (ClassNotFoundException localClassNotFoundException)
      {
        localClassNotFoundException.printStackTrace();
        return;
      }
      catch (NoSuchMethodException localNoSuchMethodException)
      {
        label24: break label24;
      }
    }

    static Object a(IBinder paramIBinder)
    {
      try
      {
        Object localObject = a.invoke(null, new Object[] { paramIBinder });
        return localObject;
      }
      catch (IllegalAccessException localIllegalAccessException)
      {
        localIllegalAccessException.printStackTrace();
        return null;
      }
      catch (InvocationTargetException localInvocationTargetException)
      {
        label19: break label19;
      }
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.media.b
 * JD-Core Version:    0.6.2
 */