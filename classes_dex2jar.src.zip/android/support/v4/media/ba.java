package android.support.v4.media;

class ba
  implements bb.a
{
  ba(az paramaz)
  {
  }

  public void a(int paramInt)
  {
    this.a.b(paramInt);
  }

  public void b(int paramInt)
  {
    this.a.c(paramInt);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.media.ba
 * JD-Core Version:    0.6.2
 */