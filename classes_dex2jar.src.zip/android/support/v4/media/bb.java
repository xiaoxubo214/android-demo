package android.support.v4.media;

import android.media.VolumeProvider;

class bb
{
  public static Object a(int paramInt1, int paramInt2, int paramInt3, a parama)
  {
    return new bc(paramInt1, paramInt2, paramInt3, parama);
  }

  public static void a(Object paramObject, int paramInt)
  {
    ((VolumeProvider)paramObject).setCurrentVolume(paramInt);
  }

  public static abstract interface a
  {
    public abstract void a(int paramInt);

    public abstract void b(int paramInt);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.media.bb
 * JD-Core Version:    0.6.2
 */