package android.support.v4.media;

import android.media.VolumeProvider;

final class bc extends VolumeProvider
{
  bc(int paramInt1, int paramInt2, int paramInt3, bb.a parama)
  {
    super(paramInt1, paramInt2, paramInt3);
  }

  public void onAdjustVolume(int paramInt)
  {
    this.a.b(paramInt);
  }

  public void onSetVolumeTo(int paramInt)
  {
    this.a.a(paramInt);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.media.bc
 * JD-Core Version:    0.6.2
 */