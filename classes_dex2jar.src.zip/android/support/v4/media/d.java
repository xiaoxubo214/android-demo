package android.support.v4.media;

class d
  implements Runnable
{
  d(MediaBrowserCompat.e parame, MediaBrowserCompat.c paramc)
  {
  }

  public void run()
  {
    this.a.a(null);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.media.d
 * JD-Core Version:    0.6.2
 */