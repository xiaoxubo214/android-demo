package android.support.v4.media;

import android.content.ServiceConnection;

class f
  implements Runnable
{
  f(MediaBrowserCompat.h paramh, ServiceConnection paramServiceConnection)
  {
  }

  public void run()
  {
    if (this.a == MediaBrowserCompat.h.a(this.b))
    {
      MediaBrowserCompat.h.b(this.b);
      MediaBrowserCompat.h.c(this.b).c();
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.media.f
 * JD-Core Version:    0.6.2
 */