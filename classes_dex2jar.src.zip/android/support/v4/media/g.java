package android.support.v4.media;

class g
  implements Runnable
{
  g(MediaBrowserCompat.h paramh, MediaBrowserCompat.c paramc, String paramString)
  {
  }

  public void run()
  {
    this.a.a(this.b);
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.media.g
 * JD-Core Version:    0.6.2
 */