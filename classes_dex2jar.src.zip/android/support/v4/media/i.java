package android.support.v4.media;

import android.content.ComponentName;
import android.os.IBinder;
import android.os.Messenger;
import android.os.RemoteException;
import android.util.Log;

class i
  implements Runnable
{
  i(MediaBrowserCompat.h.a parama, ComponentName paramComponentName, IBinder paramIBinder)
  {
  }

  public void run()
  {
    if (!MediaBrowserCompat.h.a.a(this.c, "onServiceConnected"))
      return;
    MediaBrowserCompat.h.a(this.c.a, new MediaBrowserCompat.i(this.b));
    MediaBrowserCompat.h.a(this.c.a, new Messenger(MediaBrowserCompat.h.d(this.c.a)));
    MediaBrowserCompat.h.d(this.c.a).a(MediaBrowserCompat.h.e(this.c.a));
    MediaBrowserCompat.h.a(this.c.a, 1);
    try
    {
      MediaBrowserCompat.h.h(this.c.a).a(MediaBrowserCompat.h.f(this.c.a), MediaBrowserCompat.h.g(this.c.a), MediaBrowserCompat.h.e(this.c.a));
      return;
    }
    catch (RemoteException localRemoteException)
    {
      Log.w("MediaBrowserCompat", "RemoteException during connect for " + MediaBrowserCompat.h.i(this.c.a));
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.media.i
 * JD-Core Version:    0.6.2
 */