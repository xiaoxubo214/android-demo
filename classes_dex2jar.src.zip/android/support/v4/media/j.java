package android.support.v4.media;

import android.content.ComponentName;

class j
  implements Runnable
{
  j(MediaBrowserCompat.h.a parama, ComponentName paramComponentName)
  {
  }

  public void run()
  {
    if (!MediaBrowserCompat.h.a.a(this.b, "onServiceDisconnected"))
      return;
    MediaBrowserCompat.h.a(this.b.a, null);
    MediaBrowserCompat.h.a(this.b.a, null);
    MediaBrowserCompat.h.d(this.b.a).a(null);
    MediaBrowserCompat.h.a(this.b.a, 3);
    MediaBrowserCompat.h.c(this.b.a).b();
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.media.j
 * JD-Core Version:    0.6.2
 */