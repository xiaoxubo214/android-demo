package android.support.v4.media;

import android.os.Parcel;
import android.os.Parcelable.Creator;

final class k
  implements Parcelable.Creator<MediaBrowserCompat.MediaItem>
{
  public MediaBrowserCompat.MediaItem a(Parcel paramParcel)
  {
    return new MediaBrowserCompat.MediaItem(paramParcel, null);
  }

  public MediaBrowserCompat.MediaItem[] a(int paramInt)
  {
    return new MediaBrowserCompat.MediaItem[paramInt];
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.media.k
 * JD-Core Version:    0.6.2
 */