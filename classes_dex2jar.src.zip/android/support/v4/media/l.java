package android.support.v4.media;

import android.content.ComponentName;
import android.content.Context;
import android.media.browse.MediaBrowser;
import android.media.browse.MediaBrowser.ConnectionCallback;
import android.media.browse.MediaBrowser.MediaItem;
import android.media.browse.MediaBrowser.SubscriptionCallback;
import android.os.Bundle;
import android.os.Parcel;
import android.support.annotation.x;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

class l
{
  static final String a = "android.support.v4.media.MediaBrowserCompat.NULL_MEDIA_ITEM";

  public static Object a(Context paramContext, ComponentName paramComponentName, Object paramObject, Bundle paramBundle)
  {
    return new MediaBrowser(paramContext, paramComponentName, (MediaBrowser.ConnectionCallback)paramObject, paramBundle);
  }

  public static Object a(a parama)
  {
    return new b(parama);
  }

  public static Object a(c paramc)
  {
    return new d(paramc);
  }

  public static void a(Object paramObject)
  {
    ((MediaBrowser)paramObject).connect();
  }

  public static void a(Object paramObject, String paramString)
  {
    ((MediaBrowser)paramObject).unsubscribe(paramString);
  }

  public static void a(Object paramObject1, String paramString, Object paramObject2)
  {
    ((MediaBrowser)paramObject1).subscribe(paramString, (MediaBrowser.SubscriptionCallback)paramObject2);
  }

  public static void b(Object paramObject)
  {
    ((MediaBrowser)paramObject).disconnect();
  }

  public static boolean c(Object paramObject)
  {
    return ((MediaBrowser)paramObject).isConnected();
  }

  public static ComponentName d(Object paramObject)
  {
    return ((MediaBrowser)paramObject).getServiceComponent();
  }

  public static String e(Object paramObject)
  {
    return ((MediaBrowser)paramObject).getRoot();
  }

  public static Bundle f(Object paramObject)
  {
    return ((MediaBrowser)paramObject).getExtras();
  }

  public static Object g(Object paramObject)
  {
    return ((MediaBrowser)paramObject).getSessionToken();
  }

  static abstract interface a
  {
    public abstract void a();

    public abstract void b();

    public abstract void c();
  }

  static class b<T extends l.a> extends MediaBrowser.ConnectionCallback
  {
    protected final T a;

    public b(T paramT)
    {
      this.a = paramT;
    }

    public void onConnected()
    {
      this.a.a();
    }

    public void onConnectionFailed()
    {
      this.a.c();
    }

    public void onConnectionSuspended()
    {
      this.a.b();
    }
  }

  static abstract interface c
  {
    public abstract void a(@x String paramString);

    public abstract void a(@x String paramString, List<Parcel> paramList);
  }

  static class d<T extends l.c> extends MediaBrowser.SubscriptionCallback
  {
    protected final T a;

    public d(T paramT)
    {
      this.a = paramT;
    }

    public void onChildrenLoaded(@x String paramString, List<MediaBrowser.MediaItem> paramList)
    {
      if ((paramList != null) && (paramList.size() == 1) && (((MediaBrowser.MediaItem)paramList.get(0)).getMediaId().equals("android.support.v4.media.MediaBrowserCompat.NULL_MEDIA_ITEM")))
        paramList = null;
      ArrayList localArrayList1;
      if (paramList != null)
      {
        localArrayList1 = new ArrayList();
        Iterator localIterator = paramList.iterator();
        while (localIterator.hasNext())
        {
          MediaBrowser.MediaItem localMediaItem = (MediaBrowser.MediaItem)localIterator.next();
          Parcel localParcel = Parcel.obtain();
          localMediaItem.writeToParcel(localParcel, 0);
          localArrayList1.add(localParcel);
        }
      }
      for (ArrayList localArrayList2 = localArrayList1; ; localArrayList2 = null)
      {
        this.a.a(paramString, localArrayList2);
        return;
      }
    }

    public void onError(@x String paramString)
    {
      this.a.a(paramString);
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.media.l
 * JD-Core Version:    0.6.2
 */