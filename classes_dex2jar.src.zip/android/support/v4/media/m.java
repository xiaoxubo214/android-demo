package android.support.v4.media;

import android.media.browse.MediaBrowser;
import android.media.browse.MediaBrowser.ItemCallback;
import android.media.browse.MediaBrowser.MediaItem;
import android.os.Parcel;
import android.support.annotation.x;

class m
{
  public static Object a(a parama)
  {
    return new b(parama);
  }

  public static void a(Object paramObject1, String paramString, Object paramObject2)
  {
    ((MediaBrowser)paramObject1).getItem(paramString, (MediaBrowser.ItemCallback)paramObject2);
  }

  static abstract interface a
  {
    public abstract void a(Parcel paramParcel);

    public abstract void a(@x String paramString);
  }

  static class b<T extends m.a> extends MediaBrowser.ItemCallback
  {
    protected final T a;

    public b(T paramT)
    {
      this.a = paramT;
    }

    public void onError(@x String paramString)
    {
      this.a.a(paramString);
    }

    public void onItemLoaded(MediaBrowser.MediaItem paramMediaItem)
    {
      Parcel localParcel = Parcel.obtain();
      paramMediaItem.writeToParcel(localParcel, 0);
      this.a.a(localParcel);
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.media.m
 * JD-Core Version:    0.6.2
 */