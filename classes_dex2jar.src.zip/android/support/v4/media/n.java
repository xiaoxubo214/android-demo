package android.support.v4.media;

import android.os.Bundle;
import java.util.List;

public class n
{
  public static List<MediaBrowserCompat.MediaItem> a(List<MediaBrowserCompat.MediaItem> paramList, Bundle paramBundle)
  {
    int i = paramBundle.getInt("android.media.browse.extra.PAGE", -1);
    int j = paramBundle.getInt("android.media.browse.extra.PAGE_SIZE", -1);
    if ((i == -1) && (j == -1))
      return paramList;
    int k = j * (i - 1);
    int m = k + j;
    if ((i < 1) || (j < 1) || (k >= paramList.size()))
      return null;
    if (m > paramList.size())
      m = paramList.size();
    return paramList.subList(k, m);
  }

  public static boolean a(Bundle paramBundle1, Bundle paramBundle2)
  {
    if (paramBundle1 == paramBundle2);
    do
    {
      do
      {
        do
        {
          return true;
          if (paramBundle1 != null)
            break;
        }
        while ((paramBundle2.getInt("android.media.browse.extra.PAGE", -1) == -1) && (paramBundle2.getInt("android.media.browse.extra.PAGE_SIZE", -1) == -1));
        return false;
        if (paramBundle2 != null)
          break;
      }
      while ((paramBundle1.getInt("android.media.browse.extra.PAGE", -1) == -1) && (paramBundle1.getInt("android.media.browse.extra.PAGE_SIZE", -1) == -1));
      return false;
    }
    while ((paramBundle1.getInt("android.media.browse.extra.PAGE", -1) == paramBundle2.getInt("android.media.browse.extra.PAGE", -1)) && (paramBundle1.getInt("android.media.browse.extra.PAGE_SIZE", -1) == paramBundle2.getInt("android.media.browse.extra.PAGE_SIZE", -1)));
    return false;
  }

  public static boolean b(Bundle paramBundle1, Bundle paramBundle2)
  {
    int i = 2147483647;
    int j;
    int k;
    label16: int m;
    label23: int n;
    label30: int i1;
    int i2;
    label47: int i3;
    if (paramBundle1 == null)
    {
      j = -1;
      if (paramBundle2 != null)
        break label89;
      k = -1;
      if (paramBundle1 != null)
        break label101;
      m = -1;
      if (paramBundle2 != null)
        break label113;
      n = -1;
      if ((j != -1) && (m != -1))
        break label125;
      i1 = i;
      i2 = 0;
      if ((k != -1) && (n != -1))
        break label153;
      i3 = 0;
      label62: if ((i2 > i3) || (i3 > i1))
        break label173;
    }
    label89: label101: label113: label125: 
    while ((i2 <= i) && (i <= i1))
    {
      return true;
      j = paramBundle1.getInt("android.media.browse.extra.PAGE", -1);
      break;
      k = paramBundle2.getInt("android.media.browse.extra.PAGE", -1);
      break label16;
      m = paramBundle1.getInt("android.media.browse.extra.PAGE_SIZE", -1);
      break label23;
      n = paramBundle2.getInt("android.media.browse.extra.PAGE_SIZE", -1);
      break label30;
      int i4 = m * (j - 1);
      int i5 = -1 + (i4 + m);
      i2 = i4;
      i1 = i5;
      break label47;
      i3 = n * (k - 1);
      i = -1 + (i3 + n);
      break label62;
    }
    label153: label173: return false;
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.media.n
 * JD-Core Version:    0.6.2
 */