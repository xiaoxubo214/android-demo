package android.support.v4.media;

class o
{
  public static final String a = "data_calling_uid";
  public static final String b = "data_media_item_id";
  public static final String c = "data_media_item_list";
  public static final String d = "data_media_session_token";
  public static final String e = "data_options";
  public static final String f = "data_package_name";
  public static final String g = "data_result_receiver";
  public static final String h = "data_root_hints";
  public static final String i = "extra_service_version";
  public static final String j = "extra_messenger";
  public static final int k = 1;
  public static final int l = 1;
  public static final int m = 1;
  public static final int n = 2;
  public static final int o = 3;
  public static final int p = 1;
  public static final int q = 1;
  public static final int r = 1;
  public static final int s = 2;
  public static final int t = 3;
  public static final int u = 4;
  public static final int v = 5;
  public static final int w = 6;
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.media.o
 * JD-Core Version:    0.6.2
 */