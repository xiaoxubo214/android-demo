package android.support.v4.media;

import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Binder;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.Messenger;
import android.os.Parcel;
import android.os.RemoteException;
import android.support.v4.m.a;
import android.support.v4.media.session.MediaSessionCompat.Token;
import android.support.v4.os.ResultReceiver;
import android.text.TextUtils;
import android.util.Log;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

public abstract class p extends Service
{
  public static final String a = "android.media.browse.MediaBrowserService";
  public static final String b = "media_item";
  private static final String d = "MediaBrowserServiceCompat";
  private static final boolean e = false;
  private static final int g = 1;
  MediaSessionCompat.Token c;
  private c f;
  private final a<IBinder, b> h = new a();
  private final k i = new k(null);

  private List<MediaBrowserCompat.MediaItem> a(List<MediaBrowserCompat.MediaItem> paramList, Bundle paramBundle)
  {
    int j = paramBundle.getInt("android.media.browse.extra.PAGE", -1);
    int k = paramBundle.getInt("android.media.browse.extra.PAGE_SIZE", -1);
    if ((j == -1) && (k == -1))
      return paramList;
    int m = k * (j - 1);
    int n = m + k;
    if ((j < 1) || (k < 1) || (m >= paramList.size()))
      return Collections.emptyList();
    if (n > paramList.size())
      n = paramList.size();
    return paramList.subList(m, n);
  }

  private void a(String paramString, b paramb, Bundle paramBundle)
  {
    List localList = (List)paramb.e.get(paramString);
    if (localList == null);
    for (Object localObject = new ArrayList(); ; localObject = localList)
    {
      Iterator localIterator = ((List)localObject).iterator();
      while (localIterator.hasNext())
        if (n.a(paramBundle, (Bundle)localIterator.next()))
          return;
      ((List)localObject).add(paramBundle);
      paramb.e.put(paramString, localObject);
      c(paramString, paramb, paramBundle);
      return;
    }
  }

  private void a(String paramString, ResultReceiver paramResultReceiver)
  {
    t localt = new t(this, paramString, paramResultReceiver);
    b(paramString, localt);
    if (!localt.b())
      throw new IllegalStateException("onLoadItem must call detach() or sendResult() before returning for id=" + paramString);
  }

  private boolean a(String paramString, int paramInt)
  {
    if (paramString == null);
    while (true)
    {
      return false;
      String[] arrayOfString = getPackageManager().getPackagesForUid(paramInt);
      int j = arrayOfString.length;
      for (int k = 0; k < j; k++)
        if (arrayOfString[k].equals(paramString))
          return true;
    }
  }

  private void b(String paramString, Bundle paramBundle)
  {
    if (paramString == null)
      throw new IllegalArgumentException("parentId cannot be null in notifyChildrenChanged");
    this.i.post(new r(this, paramString, paramBundle));
  }

  private boolean b(String paramString, b paramb, Bundle paramBundle)
  {
    List localList = (List)paramb.e.get(paramString);
    if (localList != null)
    {
      Iterator localIterator = localList.iterator();
      while (localIterator.hasNext())
      {
        Bundle localBundle = (Bundle)localIterator.next();
        if (n.a(paramBundle, localBundle))
          localList.remove(localBundle);
      }
      for (boolean bool = true; ; bool = false)
      {
        if (localList.size() == 0)
          paramb.e.remove(paramString);
        return bool;
      }
    }
    return false;
  }

  private void c(String paramString, b paramb, Bundle paramBundle)
  {
    s locals = new s(this, paramString, paramb, paramString, paramBundle);
    if (paramBundle == null)
      a(paramString, locals);
    while (!locals.b())
    {
      throw new IllegalStateException("onLoadChildren must call detach() or sendResult() before returning for package=" + paramb.a + " id=" + paramString);
      a(paramString, locals, paramBundle);
    }
  }

  @android.support.annotation.y
  public abstract a a(@android.support.annotation.x String paramString, int paramInt, @android.support.annotation.y Bundle paramBundle);

  @android.support.annotation.y
  public MediaSessionCompat.Token a()
  {
    return this.c;
  }

  public void a(MediaSessionCompat.Token paramToken)
  {
    if (paramToken == null)
      throw new IllegalArgumentException("Session token may not be null.");
    if (this.c != null)
      throw new IllegalStateException("The session token has already been set.");
    this.c = paramToken;
    this.i.post(new q(this, paramToken));
  }

  public void a(@android.support.annotation.x String paramString)
  {
    b(paramString, null);
  }

  public void a(@android.support.annotation.x String paramString, @android.support.annotation.x Bundle paramBundle)
  {
    if (paramBundle == null)
      throw new IllegalArgumentException("options cannot be null in notifyChildrenChanged");
    b(paramString, paramBundle);
  }

  public abstract void a(@android.support.annotation.x String paramString, @android.support.annotation.x g<List<MediaBrowserCompat.MediaItem>> paramg);

  public void a(@android.support.annotation.x String paramString, @android.support.annotation.x g<List<MediaBrowserCompat.MediaItem>> paramg, @android.support.annotation.x Bundle paramBundle)
  {
    paramg.a(1);
    a(paramString, paramg);
  }

  public void b(String paramString, g<MediaBrowserCompat.MediaItem> paramg)
  {
    paramg.a(null);
  }

  public void dump(FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString)
  {
  }

  public IBinder onBind(Intent paramIntent)
  {
    return this.f.a(paramIntent);
  }

  public void onCreate()
  {
    super.onCreate();
    if (Build.VERSION.SDK_INT >= 23)
      this.f = new e();
    while (true)
    {
      this.f.a();
      return;
      if (Build.VERSION.SDK_INT >= 21)
        this.f = new d();
      else
        this.f = new f();
    }
  }

  public static final class a
  {
    public static final String a = "android.service.media.extra.RECENT";
    public static final String b = "android.service.media.extra.OFFLINE";
    public static final String c = "android.service.media.extra.SUGGESTED";
    private final String d;
    private final Bundle e;

    public a(@android.support.annotation.x String paramString, @android.support.annotation.y Bundle paramBundle)
    {
      if (paramString == null)
        throw new IllegalArgumentException("The root id in BrowserRoot cannot be null. Use null for BrowserRoot instead.");
      this.d = paramString;
      this.e = paramBundle;
    }

    public String a()
    {
      return this.d;
    }

    public Bundle b()
    {
      return this.e;
    }
  }

  private class b
  {
    String a;
    Bundle b;
    p.h c;
    p.a d;
    HashMap<String, List<Bundle>> e = new HashMap();

    private b()
    {
    }
  }

  static abstract interface c
  {
    public abstract IBinder a(Intent paramIntent);

    public abstract void a();
  }

  class d
    implements p.c
  {
    private Object b;

    d()
    {
    }

    public IBinder a(Intent paramIntent)
    {
      return aa.a(this.b, paramIntent);
    }

    public void a()
    {
      this.b = aa.a();
      aa.a(this.b, new p.m(p.this));
    }
  }

  class e
    implements p.c
  {
    private Object b;

    e()
    {
    }

    public IBinder a(Intent paramIntent)
    {
      return ab.a(this.b, paramIntent);
    }

    public void a()
    {
      this.b = ab.b();
      ab.a(this.b, new p.n(p.this, null));
    }
  }

  class f
    implements p.c
  {
    private Messenger b;

    f()
    {
    }

    public IBinder a(Intent paramIntent)
    {
      if ("android.media.browse.MediaBrowserService".equals(paramIntent.getAction()))
        return this.b.getBinder();
      return null;
    }

    public void a()
    {
      this.b = new Messenger(p.a(p.this));
    }
  }

  public static class g<T>
  {
    private Object a;
    private boolean b;
    private boolean c;
    private int d;

    g(Object paramObject)
    {
      this.a = paramObject;
    }

    public void a()
    {
      if (this.b)
        throw new IllegalStateException("detach() called when detach() had already been called for: " + this.a);
      if (this.c)
        throw new IllegalStateException("detach() called when sendResult() had already been called for: " + this.a);
      this.b = true;
    }

    void a(int paramInt)
    {
      this.d = paramInt;
    }

    public void a(T paramT)
    {
      if (this.c)
        throw new IllegalStateException("sendResult() called twice for: " + this.a);
      this.c = true;
      a(paramT, this.d);
    }

    void a(T paramT, int paramInt)
    {
    }

    boolean b()
    {
      return (this.b) || (this.c);
    }
  }

  private static abstract interface h
  {
    public abstract IBinder a();

    public abstract void a(String paramString, MediaSessionCompat.Token paramToken, Bundle paramBundle)
      throws RemoteException;

    public abstract void a(String paramString, List<MediaBrowserCompat.MediaItem> paramList, Bundle paramBundle)
      throws RemoteException;

    public abstract void b()
      throws RemoteException;
  }

  private class i
    implements p.h
  {
    final aa.b a;
    Messenger b;

    i(aa.b arg2)
    {
      Object localObject;
      this.a = localObject;
    }

    public IBinder a()
    {
      return this.a.a();
    }

    public void a(String paramString, MediaSessionCompat.Token paramToken, Bundle paramBundle)
      throws RemoteException
    {
      if (paramBundle == null)
        paramBundle = new Bundle();
      this.b = new Messenger(p.a(p.this));
      android.support.v4.app.y.a(paramBundle, "extra_messenger", this.b.getBinder());
      paramBundle.putInt("extra_service_version", 1);
      this.a.a(paramString, paramToken.a(), paramBundle);
    }

    public void a(String paramString, List<MediaBrowserCompat.MediaItem> paramList, Bundle paramBundle)
      throws RemoteException
    {
      Object localObject = null;
      if (paramList != null)
      {
        ArrayList localArrayList = new ArrayList();
        Iterator localIterator = paramList.iterator();
        while (localIterator.hasNext())
        {
          MediaBrowserCompat.MediaItem localMediaItem = (MediaBrowserCompat.MediaItem)localIterator.next();
          Parcel localParcel = Parcel.obtain();
          localMediaItem.writeToParcel(localParcel, 0);
          localArrayList.add(localParcel);
        }
        localObject = localArrayList;
      }
      this.a.a(paramString, localObject);
    }

    public void b()
      throws RemoteException
    {
      this.a.b();
    }
  }

  private class j
    implements p.h
  {
    final Messenger a;

    j(Messenger arg2)
    {
      Object localObject;
      this.a = localObject;
    }

    private void a(int paramInt, Bundle paramBundle)
      throws RemoteException
    {
      Message localMessage = Message.obtain();
      localMessage.what = paramInt;
      localMessage.arg1 = 1;
      localMessage.setData(paramBundle);
      this.a.send(localMessage);
    }

    public IBinder a()
    {
      return this.a.getBinder();
    }

    public void a(String paramString, MediaSessionCompat.Token paramToken, Bundle paramBundle)
      throws RemoteException
    {
      if (paramBundle == null)
        paramBundle = new Bundle();
      paramBundle.putInt("extra_service_version", 1);
      Bundle localBundle = new Bundle();
      localBundle.putString("data_media_item_id", paramString);
      localBundle.putParcelable("data_media_session_token", paramToken);
      localBundle.putBundle("data_root_hints", paramBundle);
      a(1, localBundle);
    }

    public void a(String paramString, List<MediaBrowserCompat.MediaItem> paramList, Bundle paramBundle)
      throws RemoteException
    {
      Bundle localBundle = new Bundle();
      localBundle.putString("data_media_item_id", paramString);
      localBundle.putBundle("data_options", paramBundle);
      if (paramList != null)
        if (!(paramList instanceof ArrayList))
          break label59;
      label59: for (ArrayList localArrayList = (ArrayList)paramList; ; localArrayList = new ArrayList(paramList))
      {
        localBundle.putParcelableArrayList("data_media_item_list", localArrayList);
        a(3, localBundle);
        return;
      }
    }

    public void b()
      throws RemoteException
    {
      a(2, null);
    }
  }

  private final class k extends Handler
  {
    private final p.l b = new p.l(p.this, null);

    private k()
    {
    }

    public p.l a()
    {
      return this.b;
    }

    public void a(Runnable paramRunnable)
    {
      if (Thread.currentThread() == getLooper().getThread())
      {
        paramRunnable.run();
        return;
      }
      post(paramRunnable);
    }

    public void handleMessage(Message paramMessage)
    {
      Bundle localBundle = paramMessage.getData();
      switch (paramMessage.what)
      {
      default:
        Log.w("MediaBrowserServiceCompat", "Unhandled message: " + paramMessage + "\n  Service version: " + 1 + "\n  Client version: " + paramMessage.arg1);
        return;
      case 1:
        this.b.a(localBundle.getString("data_package_name"), localBundle.getInt("data_calling_uid"), localBundle.getBundle("data_root_hints"), new p.j(p.this, paramMessage.replyTo));
        return;
      case 2:
        this.b.a(new p.j(p.this, paramMessage.replyTo));
        return;
      case 3:
        this.b.a(localBundle.getString("data_media_item_id"), localBundle.getBundle("data_options"), new p.j(p.this, paramMessage.replyTo));
        return;
      case 4:
        this.b.b(localBundle.getString("data_media_item_id"), localBundle.getBundle("data_options"), new p.j(p.this, paramMessage.replyTo));
        return;
      case 5:
        this.b.a(localBundle.getString("data_media_item_id"), (ResultReceiver)localBundle.getParcelable("data_result_receiver"));
        return;
      case 6:
      }
      this.b.b(new p.j(p.this, paramMessage.replyTo));
    }

    public boolean sendMessageAtTime(Message paramMessage, long paramLong)
    {
      Bundle localBundle = paramMessage.getData();
      localBundle.setClassLoader(MediaBrowserCompat.class.getClassLoader());
      localBundle.putInt("data_calling_uid", Binder.getCallingUid());
      return super.sendMessageAtTime(paramMessage, paramLong);
    }
  }

  private class l
  {
    private l()
    {
    }

    public void a(p.h paramh)
    {
      p.a(p.this).a(new v(this, paramh));
    }

    public void a(String paramString, int paramInt, Bundle paramBundle, p.h paramh)
    {
      if (!p.a(p.this, paramString, paramInt))
        throw new IllegalArgumentException("Package/uid mismatch: uid=" + paramInt + " package=" + paramString);
      p.a(p.this).a(new u(this, paramh, paramString, paramBundle, paramInt));
    }

    public void a(String paramString, Bundle paramBundle, p.h paramh)
    {
      p.a(p.this).a(new w(this, paramh, paramString, paramBundle));
    }

    public void a(String paramString, ResultReceiver paramResultReceiver)
    {
      if ((TextUtils.isEmpty(paramString)) || (paramResultReceiver == null))
        return;
      p.a(p.this).a(new y(this, paramString, paramResultReceiver));
    }

    public void b(p.h paramh)
    {
      p.a(p.this).a(new z(this, paramh));
    }

    public void b(String paramString, Bundle paramBundle, p.h paramh)
    {
      p.a(p.this).a(new x(this, paramh, paramString, paramBundle));
    }
  }

  private class m
    implements aa.d
  {
    final p.l a = p.a(p.this).a();

    m()
    {
    }

    public void a(aa.b paramb)
    {
      this.a.a(new p.i(p.this, paramb));
    }

    public void a(String paramString, Bundle paramBundle, aa.b paramb)
    {
      this.a.a(paramString, Binder.getCallingUid(), paramBundle, new p.i(p.this, paramb));
    }

    public void a(String paramString, aa.b paramb)
    {
      this.a.a(paramString, null, new p.i(p.this, paramb));
    }

    public void b(String paramString, aa.b paramb)
    {
      this.a.b(paramString, null, new p.i(p.this, paramb));
    }
  }

  private class n extends p.m
    implements ab.c
  {
    private n()
    {
      super();
    }

    public void a(String paramString, ab.a parama)
    {
      MediaBrowserServiceCompat.ServiceImplApi23.1 local1 = new MediaBrowserServiceCompat.ServiceImplApi23.1(this, p.a(p.this), parama);
      this.a.a(paramString, local1);
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.media.p
 * JD-Core Version:    0.6.2
 */