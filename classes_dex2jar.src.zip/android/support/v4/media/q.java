package android.support.v4.media;

import android.os.IBinder;
import android.os.RemoteException;
import android.support.v4.m.a;
import android.support.v4.media.session.MediaSessionCompat.Token;
import android.util.Log;
import java.util.Iterator;
import java.util.Set;

class q
  implements Runnable
{
  q(p paramp, MediaSessionCompat.Token paramToken)
  {
  }

  public void run()
  {
    Iterator localIterator = p.b(this.b).keySet().iterator();
    while (localIterator.hasNext())
    {
      IBinder localIBinder = (IBinder)localIterator.next();
      p.b localb = (p.b)p.b(this.b).get(localIBinder);
      try
      {
        localb.c.a(localb.d.a(), this.a, localb.d.b());
      }
      catch (RemoteException localRemoteException)
      {
        Log.w("MediaBrowserServiceCompat", "Connection for " + localb.a + " is no longer valid.");
        p.b(this.b).remove(localIBinder);
      }
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.media.q
 * JD-Core Version:    0.6.2
 */