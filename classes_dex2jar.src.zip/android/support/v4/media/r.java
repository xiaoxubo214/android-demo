package android.support.v4.media;

import android.os.Bundle;
import android.os.IBinder;
import android.support.v4.m.a;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

class r
  implements Runnable
{
  r(p paramp, String paramString, Bundle paramBundle)
  {
  }

  public void run()
  {
    Iterator localIterator1 = p.b(this.c).keySet().iterator();
    while (true)
    {
      if (!localIterator1.hasNext())
        return;
      IBinder localIBinder = (IBinder)localIterator1.next();
      p.b localb = (p.b)p.b(this.c).get(localIBinder);
      List localList = (List)localb.e.get(this.a);
      if (localList != null)
      {
        Iterator localIterator2 = localList.iterator();
        if (localIterator2.hasNext())
        {
          Bundle localBundle = (Bundle)localIterator2.next();
          if (!n.b(this.b, localBundle))
            break;
          p.c(this.c, this.a, localb, localBundle);
        }
      }
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.media.r
 * JD-Core Version:    0.6.2
 */