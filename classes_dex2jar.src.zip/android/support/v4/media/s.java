package android.support.v4.media;

import android.os.Bundle;
import android.os.RemoteException;
import android.support.v4.m.a;
import android.util.Log;
import java.util.List;

class s extends p.g<List<MediaBrowserCompat.MediaItem>>
{
  s(p paramp, Object paramObject, p.b paramb, String paramString, Bundle paramBundle)
  {
    super(paramObject);
  }

  void a(List<MediaBrowserCompat.MediaItem> paramList, int paramInt)
  {
    if (p.b(this.d).get(this.a.c.a()) != this.a)
      return;
    if ((paramInt & 0x1) != 0)
      paramList = n.a(paramList, this.c);
    try
    {
      this.a.c.a(this.b, paramList, this.c);
      return;
    }
    catch (RemoteException localRemoteException)
    {
      Log.w("MediaBrowserServiceCompat", "Calling onLoadChildren() failed for id=" + this.b + " package=" + this.a.a);
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.media.s
 * JD-Core Version:    0.6.2
 */