package android.support.v4.media.session;

import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.os.RemoteCallbackList;
import android.os.RemoteException;
import android.os.ResultReceiver;
import android.os.SystemClock;
import android.support.v4.media.MediaDescriptionCompat;
import android.support.v4.media.MediaMetadataCompat;
import android.support.v4.media.MediaMetadataCompat.b;
import android.support.v4.media.RatingCompat;
import android.support.v4.media.az;
import android.support.v4.media.az.a;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class MediaSessionCompat
{
  public static final int a = 1;
  public static final int b = 2;
  public static final String c = "android.support.v4.media.session.action.PLAY_FROM_URI";
  public static final String d = "android.support.v4.media.session.action.ARGUMENT_URI";
  public static final String e = "android.support.v4.media.session.action.ARGUMENT_EXTRAS";
  private static final String f = "MediaSessionCompat";
  private final b g;
  private final d h;
  private final ArrayList<e> i = new ArrayList();

  private MediaSessionCompat(Context paramContext, b paramb)
  {
    this.g = paramb;
    this.h = new d(paramContext, this);
  }

  public MediaSessionCompat(Context paramContext, String paramString)
  {
    this(paramContext, paramString, null, null);
  }

  public MediaSessionCompat(Context paramContext, String paramString, ComponentName paramComponentName, PendingIntent paramPendingIntent)
  {
    if (paramContext == null)
      throw new IllegalArgumentException("context must not be null");
    if (TextUtils.isEmpty(paramString))
      throw new IllegalArgumentException("tag must not be null or empty");
    List localList;
    if (paramComponentName == null)
    {
      Intent localIntent1 = new Intent("android.intent.action.MEDIA_BUTTON");
      localIntent1.setPackage(paramContext.getPackageName());
      localList = paramContext.getPackageManager().queryBroadcastReceivers(localIntent1, 0);
      if (localList.size() == 1)
      {
        ResolveInfo localResolveInfo = (ResolveInfo)localList.get(0);
        paramComponentName = new ComponentName(localResolveInfo.activityInfo.packageName, localResolveInfo.activityInfo.name);
      }
    }
    else
    {
      if ((paramComponentName != null) && (paramPendingIntent == null))
      {
        Intent localIntent2 = new Intent("android.intent.action.MEDIA_BUTTON");
        localIntent2.setComponent(paramComponentName);
        paramPendingIntent = PendingIntent.getBroadcast(paramContext, 0, localIntent2, 0);
      }
      if (Build.VERSION.SDK_INT < 21)
        break label236;
      this.g = new c(paramContext, paramString);
      this.g.b(paramPendingIntent);
    }
    while (true)
    {
      this.h = new d(paramContext, this);
      return;
      if (localList.size() <= 1)
        break;
      Log.w("MediaSessionCompat", "More than one BroadcastReceiver that handles android.intent.action.MEDIA_BUTTON was found, using null. Provide a specific ComponentName to use as this session's media button receiver");
      break;
      label236: this.g = new d(paramContext, paramString, paramComponentName, paramPendingIntent);
    }
  }

  public static MediaSessionCompat a(Context paramContext, Object paramObject)
  {
    return new MediaSessionCompat(paramContext, new c(paramObject));
  }

  public void a(int paramInt)
  {
    this.g.a(paramInt);
  }

  public void a(PendingIntent paramPendingIntent)
  {
    this.g.a(paramPendingIntent);
  }

  public void a(Bundle paramBundle)
  {
    this.g.a(paramBundle);
  }

  public void a(MediaMetadataCompat paramMediaMetadataCompat)
  {
    this.g.a(paramMediaMetadataCompat);
  }

  public void a(az paramaz)
  {
    if (paramaz == null)
      throw new IllegalArgumentException("volumeProvider may not be null!");
    this.g.a(paramaz);
  }

  public void a(a parama)
  {
    a(parama, null);
  }

  public void a(a parama, Handler paramHandler)
  {
    b localb = this.g;
    if (paramHandler != null);
    while (true)
    {
      localb.a(parama, paramHandler);
      return;
      paramHandler = new Handler();
    }
  }

  public void a(e parame)
  {
    if (parame == null)
      throw new IllegalArgumentException("Listener may not be null");
    this.i.add(parame);
  }

  public void a(PlaybackStateCompat paramPlaybackStateCompat)
  {
    this.g.a(paramPlaybackStateCompat);
  }

  public void a(CharSequence paramCharSequence)
  {
    this.g.a(paramCharSequence);
  }

  public void a(String paramString, Bundle paramBundle)
  {
    if (TextUtils.isEmpty(paramString))
      throw new IllegalArgumentException("event cannot be null or empty");
    this.g.a(paramString, paramBundle);
  }

  public void a(List<QueueItem> paramList)
  {
    this.g.a(paramList);
  }

  public void a(boolean paramBoolean)
  {
    this.g.a(paramBoolean);
    Iterator localIterator = this.i.iterator();
    while (localIterator.hasNext())
      ((e)localIterator.next()).a();
  }

  public boolean a()
  {
    return this.g.a();
  }

  public void b()
  {
    this.g.b();
  }

  public void b(int paramInt)
  {
    this.g.b(paramInt);
  }

  public void b(PendingIntent paramPendingIntent)
  {
    this.g.b(paramPendingIntent);
  }

  public void b(e parame)
  {
    if (parame == null)
      throw new IllegalArgumentException("Listener may not be null");
    this.i.remove(parame);
  }

  public Token c()
  {
    return this.g.c();
  }

  public void c(int paramInt)
  {
    this.g.c(paramInt);
  }

  public d d()
  {
    return this.h;
  }

  public Object e()
  {
    return this.g.d();
  }

  public Object f()
  {
    return this.g.e();
  }

  public static final class QueueItem
    implements Parcelable
  {
    public static final Parcelable.Creator<QueueItem> CREATOR = new i();
    public static final int a = -1;
    private final MediaDescriptionCompat b;
    private final long c;
    private Object d;

    private QueueItem(Parcel paramParcel)
    {
      this.b = ((MediaDescriptionCompat)MediaDescriptionCompat.CREATOR.createFromParcel(paramParcel));
      this.c = paramParcel.readLong();
    }

    public QueueItem(MediaDescriptionCompat paramMediaDescriptionCompat, long paramLong)
    {
      this(null, paramMediaDescriptionCompat, paramLong);
    }

    private QueueItem(Object paramObject, MediaDescriptionCompat paramMediaDescriptionCompat, long paramLong)
    {
      if (paramMediaDescriptionCompat == null)
        throw new IllegalArgumentException("Description cannot be null.");
      if (paramLong == -1L)
        throw new IllegalArgumentException("Id cannot be QueueItem.UNKNOWN_ID");
      this.b = paramMediaDescriptionCompat;
      this.c = paramLong;
      this.d = paramObject;
    }

    public static QueueItem a(Object paramObject)
    {
      return new QueueItem(paramObject, MediaDescriptionCompat.a(o.c.a(paramObject)), o.c.b(paramObject));
    }

    public MediaDescriptionCompat a()
    {
      return this.b;
    }

    public long b()
    {
      return this.c;
    }

    public Object c()
    {
      if ((this.d != null) || (Build.VERSION.SDK_INT < 21))
        return this.d;
      this.d = o.c.a(this.b.i(), this.c);
      return this.d;
    }

    public int describeContents()
    {
      return 0;
    }

    public String toString()
    {
      return "MediaSession.QueueItem {Description=" + this.b + ", Id=" + this.c + " }";
    }

    public void writeToParcel(Parcel paramParcel, int paramInt)
    {
      this.b.writeToParcel(paramParcel, paramInt);
      paramParcel.writeLong(this.c);
    }
  }

  static final class ResultReceiverWrapper
    implements Parcelable
  {
    public static final Parcelable.Creator<ResultReceiverWrapper> CREATOR = new j();
    private ResultReceiver a;

    ResultReceiverWrapper(Parcel paramParcel)
    {
      this.a = ((ResultReceiver)ResultReceiver.CREATOR.createFromParcel(paramParcel));
    }

    public ResultReceiverWrapper(ResultReceiver paramResultReceiver)
    {
      this.a = paramResultReceiver;
    }

    public int describeContents()
    {
      return 0;
    }

    public void writeToParcel(Parcel paramParcel, int paramInt)
    {
      this.a.writeToParcel(paramParcel, paramInt);
    }
  }

  public static final class Token
    implements Parcelable
  {
    public static final Parcelable.Creator<Token> CREATOR = new k();
    private final Object a;

    Token(Object paramObject)
    {
      this.a = paramObject;
    }

    public static Token a(Object paramObject)
    {
      if ((paramObject == null) || (Build.VERSION.SDK_INT < 21))
        return null;
      return new Token(o.b(paramObject));
    }

    public Object a()
    {
      return this.a;
    }

    public int describeContents()
    {
      return 0;
    }

    public void writeToParcel(Parcel paramParcel, int paramInt)
    {
      if (Build.VERSION.SDK_INT >= 21)
      {
        paramParcel.writeParcelable((Parcelable)this.a, paramInt);
        return;
      }
      paramParcel.writeStrongBinder((IBinder)this.a);
    }
  }

  public static abstract class a
  {
    final Object a;

    public a()
    {
      if (Build.VERSION.SDK_INT >= 23)
      {
        this.a = q.a(new b(null));
        return;
      }
      if (Build.VERSION.SDK_INT >= 21)
      {
        this.a = o.a(new a(null));
        return;
      }
      this.a = null;
    }

    public void a()
    {
    }

    public void a(long paramLong)
    {
    }

    public void a(Uri paramUri, Bundle paramBundle)
    {
    }

    public void a(RatingCompat paramRatingCompat)
    {
    }

    public void a(String paramString, Bundle paramBundle)
    {
    }

    public void a(String paramString, Bundle paramBundle, ResultReceiver paramResultReceiver)
    {
    }

    public boolean a(Intent paramIntent)
    {
      return false;
    }

    public void b()
    {
    }

    public void b(long paramLong)
    {
    }

    public void b(String paramString, Bundle paramBundle)
    {
    }

    public void c()
    {
    }

    public void c(String paramString, Bundle paramBundle)
    {
    }

    public void d()
    {
    }

    public void e()
    {
    }

    public void f()
    {
    }

    public void g()
    {
    }

    private class a
      implements o.a
    {
      private a()
      {
      }

      public void a()
      {
        MediaSessionCompat.a.this.a();
      }

      public void a(long paramLong)
      {
        MediaSessionCompat.a.this.a(paramLong);
      }

      public void a(Object paramObject)
      {
        MediaSessionCompat.a.this.a(RatingCompat.a(paramObject));
      }

      public void a(String paramString, Bundle paramBundle)
      {
        MediaSessionCompat.a.this.a(paramString, paramBundle);
      }

      public void a(String paramString, Bundle paramBundle, ResultReceiver paramResultReceiver)
      {
        MediaSessionCompat.a.this.a(paramString, paramBundle, paramResultReceiver);
      }

      public boolean a(Intent paramIntent)
      {
        return MediaSessionCompat.a.this.a(paramIntent);
      }

      public void b()
      {
        MediaSessionCompat.a.this.b();
      }

      public void b(long paramLong)
      {
        MediaSessionCompat.a.this.b(paramLong);
      }

      public void b(String paramString, Bundle paramBundle)
      {
        MediaSessionCompat.a.this.b(paramString, paramBundle);
      }

      public void c()
      {
        MediaSessionCompat.a.this.c();
      }

      public void c(String paramString, Bundle paramBundle)
      {
        if (paramString.equals("android.support.v4.media.session.action.PLAY_FROM_URI"))
        {
          Uri localUri = (Uri)paramBundle.getParcelable("android.support.v4.media.session.action.ARGUMENT_URI");
          Bundle localBundle = (Bundle)paramBundle.getParcelable("android.support.v4.media.session.action.ARGUMENT_EXTRAS");
          MediaSessionCompat.a.this.a(localUri, localBundle);
          return;
        }
        MediaSessionCompat.a.this.c(paramString, paramBundle);
      }

      public void d()
      {
        MediaSessionCompat.a.this.d();
      }

      public void e()
      {
        MediaSessionCompat.a.this.e();
      }

      public void f()
      {
        MediaSessionCompat.a.this.f();
      }

      public void g()
      {
        MediaSessionCompat.a.this.g();
      }
    }

    private class b extends MediaSessionCompat.a.a
      implements q.a
    {
      private b()
      {
        super(null);
      }

      public void a(Uri paramUri, Bundle paramBundle)
      {
        MediaSessionCompat.a.this.a(paramUri, paramBundle);
      }
    }
  }

  static abstract interface b
  {
    public abstract void a(int paramInt);

    public abstract void a(PendingIntent paramPendingIntent);

    public abstract void a(Bundle paramBundle);

    public abstract void a(MediaMetadataCompat paramMediaMetadataCompat);

    public abstract void a(az paramaz);

    public abstract void a(MediaSessionCompat.a parama, Handler paramHandler);

    public abstract void a(PlaybackStateCompat paramPlaybackStateCompat);

    public abstract void a(CharSequence paramCharSequence);

    public abstract void a(String paramString, Bundle paramBundle);

    public abstract void a(List<MediaSessionCompat.QueueItem> paramList);

    public abstract void a(boolean paramBoolean);

    public abstract boolean a();

    public abstract void b();

    public abstract void b(int paramInt);

    public abstract void b(PendingIntent paramPendingIntent);

    public abstract MediaSessionCompat.Token c();

    public abstract void c(int paramInt);

    public abstract Object d();

    public abstract Object e();
  }

  static class c
    implements MediaSessionCompat.b
  {
    private final Object a;
    private final MediaSessionCompat.Token b;
    private PendingIntent c;

    public c(Context paramContext, String paramString)
    {
      this.a = o.a(paramContext, paramString);
      this.b = new MediaSessionCompat.Token(o.e(this.a));
    }

    public c(Object paramObject)
    {
      this.a = o.a(paramObject);
      this.b = new MediaSessionCompat.Token(o.e(this.a));
    }

    public void a(int paramInt)
    {
      o.a(this.a, paramInt);
    }

    public void a(PendingIntent paramPendingIntent)
    {
      o.a(this.a, paramPendingIntent);
    }

    public void a(Bundle paramBundle)
    {
      o.a(this.a, paramBundle);
    }

    public void a(MediaMetadataCompat paramMediaMetadataCompat)
    {
      Object localObject1 = this.a;
      if (paramMediaMetadataCompat == null);
      for (Object localObject2 = null; ; localObject2 = paramMediaMetadataCompat.e())
      {
        o.c(localObject1, localObject2);
        return;
      }
    }

    public void a(az paramaz)
    {
      o.a(this.a, paramaz.d());
    }

    public void a(MediaSessionCompat.a parama, Handler paramHandler)
    {
      Object localObject1 = this.a;
      if (parama == null);
      for (Object localObject2 = null; ; localObject2 = parama.a)
      {
        o.a(localObject1, localObject2, paramHandler);
        return;
      }
    }

    public void a(PlaybackStateCompat paramPlaybackStateCompat)
    {
      Object localObject1 = this.a;
      if (paramPlaybackStateCompat == null);
      for (Object localObject2 = null; ; localObject2 = paramPlaybackStateCompat.k())
      {
        o.b(localObject1, localObject2);
        return;
      }
    }

    public void a(CharSequence paramCharSequence)
    {
      o.a(this.a, paramCharSequence);
    }

    public void a(String paramString, Bundle paramBundle)
    {
      o.a(this.a, paramString, paramBundle);
    }

    public void a(List<MediaSessionCompat.QueueItem> paramList)
    {
      Object localObject = null;
      if (paramList != null)
      {
        ArrayList localArrayList = new ArrayList();
        Iterator localIterator = paramList.iterator();
        while (localIterator.hasNext())
          localArrayList.add(((MediaSessionCompat.QueueItem)localIterator.next()).c());
        localObject = localArrayList;
      }
      o.a(this.a, localObject);
    }

    public void a(boolean paramBoolean)
    {
      o.a(this.a, paramBoolean);
    }

    public boolean a()
    {
      return o.c(this.a);
    }

    public void b()
    {
      o.d(this.a);
    }

    public void b(int paramInt)
    {
      o.b(this.a, paramInt);
    }

    public void b(PendingIntent paramPendingIntent)
    {
      this.c = paramPendingIntent;
      o.b(this.a, paramPendingIntent);
    }

    public MediaSessionCompat.Token c()
    {
      return this.b;
    }

    public void c(int paramInt)
    {
      if (Build.VERSION.SDK_INT < 22)
        return;
      p.a(this.a, paramInt);
    }

    public Object d()
    {
      return this.a;
    }

    public Object e()
    {
      return null;
    }
  }

  static class d
    implements MediaSessionCompat.b
  {
    private int A;
    private az B;
    private az.a C = new g(this);
    private final Context a;
    private final ComponentName b;
    private final PendingIntent c;
    private final Object d;
    private final b e;
    private final MediaSessionCompat.Token f;
    private final String g;
    private final String h;
    private final AudioManager i;
    private final Object j = new Object();
    private final RemoteCallbackList<a> k = new RemoteCallbackList();
    private c l;
    private boolean m = false;
    private boolean n = false;
    private boolean o = false;
    private boolean p = false;
    private volatile MediaSessionCompat.a q;
    private int r;
    private MediaMetadataCompat s;
    private PlaybackStateCompat t;
    private PendingIntent u;
    private List<MediaSessionCompat.QueueItem> v;
    private CharSequence w;
    private int x;
    private Bundle y;
    private int z;

    public d(Context paramContext, String paramString, ComponentName paramComponentName, PendingIntent paramPendingIntent)
    {
      if (paramComponentName == null)
        throw new IllegalArgumentException("MediaButtonReceiver component may not be null.");
      this.a = paramContext;
      this.g = paramContext.getPackageName();
      this.i = ((AudioManager)paramContext.getSystemService("audio"));
      this.h = paramString;
      this.b = paramComponentName;
      this.c = paramPendingIntent;
      this.e = new b();
      this.f = new MediaSessionCompat.Token(this.e);
      this.x = 0;
      this.z = 1;
      this.A = 3;
      if (Build.VERSION.SDK_INT >= 14)
      {
        this.d = l.a(paramPendingIntent);
        return;
      }
      this.d = null;
    }

    private void a(int paramInt1, int paramInt2)
    {
      if (this.z == 2)
      {
        if (this.B != null)
          this.B.c(paramInt1);
        return;
      }
      this.i.adjustStreamVolume(this.A, paramInt1, paramInt2);
    }

    private void a(int paramInt, Object paramObject)
    {
      a(paramInt, paramObject, null);
    }

    private void a(int paramInt, Object paramObject, Bundle paramBundle)
    {
      synchronized (this.j)
      {
        if (this.l != null)
          this.l.a(paramInt, paramObject, paramBundle);
        return;
      }
    }

    private void a(ParcelableVolumeInfo paramParcelableVolumeInfo)
    {
      int i1 = -1 + this.k.beginBroadcast();
      while (true)
      {
        a locala;
        if (i1 >= 0)
          locala = (a)this.k.getBroadcastItem(i1);
        try
        {
          locala.a(paramParcelableVolumeInfo);
          label33: i1--;
          continue;
          this.k.finishBroadcast();
          return;
        }
        catch (RemoteException localRemoteException)
        {
          break label33;
        }
      }
    }

    private MediaMetadataCompat b(MediaMetadataCompat paramMediaMetadataCompat)
    {
      if (paramMediaMetadataCompat == null)
        paramMediaMetadataCompat = null;
      while ((!paramMediaMetadataCompat.a("android.media.metadata.ART")) && (!paramMediaMetadataCompat.a("android.media.metadata.ALBUM_ART")))
        return paramMediaMetadataCompat;
      MediaMetadataCompat.b localb = new MediaMetadataCompat.b(paramMediaMetadataCompat);
      Bitmap localBitmap1 = paramMediaMetadataCompat.f("android.media.metadata.ART");
      if (localBitmap1 != null)
        localb.a("android.media.metadata.ART", localBitmap1.copy(localBitmap1.getConfig(), false));
      Bitmap localBitmap2 = paramMediaMetadataCompat.f("android.media.metadata.ALBUM_ART");
      if (localBitmap2 != null)
        localb.a("android.media.metadata.ALBUM_ART", localBitmap2.copy(localBitmap2.getConfig(), false));
      return localb.a();
    }

    private void b(int paramInt1, int paramInt2)
    {
      if (this.z == 2)
      {
        if (this.B != null)
          this.B.b(paramInt1);
        return;
      }
      this.i.setStreamVolume(this.A, paramInt1, paramInt2);
    }

    private void b(PlaybackStateCompat paramPlaybackStateCompat)
    {
      int i1 = -1 + this.k.beginBroadcast();
      while (true)
      {
        a locala;
        if (i1 >= 0)
          locala = (a)this.k.getBroadcastItem(i1);
        try
        {
          locala.a(paramPlaybackStateCompat);
          label33: i1--;
          continue;
          this.k.finishBroadcast();
          return;
        }
        catch (RemoteException localRemoteException)
        {
          break label33;
        }
      }
    }

    private void b(CharSequence paramCharSequence)
    {
      int i1 = -1 + this.k.beginBroadcast();
      while (true)
      {
        a locala;
        if (i1 >= 0)
          locala = (a)this.k.getBroadcastItem(i1);
        try
        {
          locala.a(paramCharSequence);
          label33: i1--;
          continue;
          this.k.finishBroadcast();
          return;
        }
        catch (RemoteException localRemoteException)
        {
          break label33;
        }
      }
    }

    private void b(String paramString, Bundle paramBundle)
    {
      int i1 = -1 + this.k.beginBroadcast();
      while (true)
      {
        a locala;
        if (i1 >= 0)
          locala = (a)this.k.getBroadcastItem(i1);
        try
        {
          locala.a(paramString, paramBundle);
          label36: i1--;
          continue;
          this.k.finishBroadcast();
          return;
        }
        catch (RemoteException localRemoteException)
        {
          break label36;
        }
      }
    }

    private void b(List<MediaSessionCompat.QueueItem> paramList)
    {
      int i1 = -1 + this.k.beginBroadcast();
      while (true)
      {
        a locala;
        if (i1 >= 0)
          locala = (a)this.k.getBroadcastItem(i1);
        try
        {
          locala.a(paramList);
          label33: i1--;
          continue;
          this.k.finishBroadcast();
          return;
        }
        catch (RemoteException localRemoteException)
        {
          break label33;
        }
      }
    }

    private void c(MediaMetadataCompat paramMediaMetadataCompat)
    {
      int i1 = -1 + this.k.beginBroadcast();
      while (true)
      {
        a locala;
        if (i1 >= 0)
          locala = (a)this.k.getBroadcastItem(i1);
        try
        {
          locala.a(paramMediaMetadataCompat);
          label33: i1--;
          continue;
          this.k.finishBroadcast();
          return;
        }
        catch (RemoteException localRemoteException)
        {
          break label33;
        }
      }
    }

    private void d(int paramInt)
    {
      a(paramInt, null);
    }

    private boolean f()
    {
      if (this.n)
      {
        if (Build.VERSION.SDK_INT >= 8)
        {
          if ((this.p) || ((0x1 & this.r) == 0))
            break label115;
          if (Build.VERSION.SDK_INT < 18)
            break label101;
          m.a(this.a, this.c, this.b);
          this.p = true;
        }
        label101: label115: 
        while ((!this.p) || ((0x1 & this.r) != 0))
          while (true)
          {
            if (Build.VERSION.SDK_INT < 14)
              break label284;
            if ((this.o) || ((0x2 & this.r) == 0))
              break;
            l.a(this.a, this.d);
            this.o = true;
            return true;
            r.a(this.a, this.b);
          }
        if (Build.VERSION.SDK_INT >= 18)
          m.b(this.a, this.c, this.b);
        while (true)
        {
          this.p = false;
          break;
          r.b(this.a, this.b);
        }
        if ((this.o) && ((0x2 & this.r) == 0))
        {
          l.a(this.d, 0);
          l.b(this.a, this.d);
          this.o = false;
          return false;
        }
      }
      else if (this.p)
      {
        if (Build.VERSION.SDK_INT < 18)
          break label286;
        m.b(this.a, this.c, this.b);
      }
      while (true)
      {
        this.p = false;
        if (this.o)
        {
          l.a(this.d, 0);
          l.b(this.a, this.d);
          this.o = false;
        }
        label284: return false;
        label286: r.b(this.a, this.b);
      }
    }

    private PlaybackStateCompat g()
    {
      long l1 = -1L;
      while (true)
      {
        long l4;
        PlaybackStateCompat localPlaybackStateCompat2;
        synchronized (this.j)
        {
          PlaybackStateCompat localPlaybackStateCompat1 = this.t;
          if ((this.s != null) && (this.s.a("android.media.metadata.DURATION")))
            l1 = this.s.d("android.media.metadata.DURATION");
          if ((localPlaybackStateCompat1 == null) || ((localPlaybackStateCompat1.a() != 3) && (localPlaybackStateCompat1.a() != 4) && (localPlaybackStateCompat1.a() != 5)))
            break label209;
          long l2 = localPlaybackStateCompat1.h();
          long l3 = SystemClock.elapsedRealtime();
          if (l2 <= 0L)
            break label209;
          l4 = ()(localPlaybackStateCompat1.d() * (float)(l3 - l2)) + localPlaybackStateCompat1.b();
          if ((l1 >= 0L) && (l4 > l1))
          {
            PlaybackStateCompat.b localb = new PlaybackStateCompat.b(localPlaybackStateCompat1);
            localb.a(localPlaybackStateCompat1.a(), l1, localPlaybackStateCompat1.d(), l3);
            localPlaybackStateCompat2 = localb.a();
            if (localPlaybackStateCompat2 == null)
              localPlaybackStateCompat2 = localPlaybackStateCompat1;
            return localPlaybackStateCompat2;
          }
        }
        if (l4 < 0L)
        {
          l1 = 0L;
        }
        else
        {
          l1 = l4;
          continue;
          label209: localPlaybackStateCompat2 = null;
        }
      }
    }

    private void h()
    {
      int i1 = -1 + this.k.beginBroadcast();
      while (true)
      {
        a locala;
        if (i1 >= 0)
          locala = (a)this.k.getBroadcastItem(i1);
        try
        {
          locala.a();
          label32: i1--;
          continue;
          this.k.finishBroadcast();
          this.k.kill();
          return;
        }
        catch (RemoteException localRemoteException)
        {
          break label32;
        }
      }
    }

    public void a(int paramInt)
    {
      synchronized (this.j)
      {
        this.r = paramInt;
        f();
        return;
      }
    }

    public void a(PendingIntent paramPendingIntent)
    {
      synchronized (this.j)
      {
        this.u = paramPendingIntent;
        return;
      }
    }

    public void a(Bundle paramBundle)
    {
      this.y = paramBundle;
    }

    public void a(MediaMetadataCompat paramMediaMetadataCompat)
    {
      if ((Build.VERSION.SDK_INT >= 14) && (paramMediaMetadataCompat != null))
        paramMediaMetadataCompat = b(paramMediaMetadataCompat);
      label100: 
      do
      {
        synchronized (this.j)
        {
          this.s = paramMediaMetadataCompat;
          c(paramMediaMetadataCompat);
          if (!this.n)
            return;
        }
        if (Build.VERSION.SDK_INT >= 19)
        {
          Object localObject4 = this.d;
          Bundle localBundle2 = null;
          if (paramMediaMetadataCompat == null)
            if (this.t != null)
              break label100;
          for (long l1 = 0L; ; l1 = this.t.e())
          {
            n.a(localObject4, localBundle2, l1);
            return;
            localBundle2 = paramMediaMetadataCompat.d();
            break;
          }
        }
      }
      while (Build.VERSION.SDK_INT < 14);
      Object localObject3 = this.d;
      Bundle localBundle1 = null;
      if (paramMediaMetadataCompat == null);
      while (true)
      {
        l.a(localObject3, localBundle1);
        return;
        localBundle1 = paramMediaMetadataCompat.d();
      }
    }

    public void a(az paramaz)
    {
      if (paramaz == null)
        throw new IllegalArgumentException("volumeProvider may not be null");
      if (this.B != null)
        this.B.a(null);
      this.z = 2;
      this.B = paramaz;
      a(new ParcelableVolumeInfo(this.z, this.A, this.B.b(), this.B.c(), this.B.a()));
      paramaz.a(this.C);
    }

    public void a(MediaSessionCompat.a parama, Handler paramHandler)
    {
      this.q = parama;
      if (parama == null)
      {
        if (Build.VERSION.SDK_INT >= 18)
          m.a(this.d, null);
        if (Build.VERSION.SDK_INT >= 19)
          n.a(this.d, null);
      }
      while (true)
      {
        return;
        if (paramHandler == null)
          paramHandler = new Handler();
        synchronized (this.j)
        {
          this.l = new c(paramHandler.getLooper());
          h localh = new h(this);
          if (Build.VERSION.SDK_INT >= 18)
          {
            Object localObject4 = m.a(localh);
            m.a(this.d, localObject4);
          }
          if (Build.VERSION.SDK_INT < 19)
            continue;
          Object localObject3 = n.a(localh);
          n.a(this.d, localObject3);
          return;
        }
      }
    }

    public void a(PlaybackStateCompat paramPlaybackStateCompat)
    {
      do
      {
        do
        {
          synchronized (this.j)
          {
            this.t = paramPlaybackStateCompat;
            b(paramPlaybackStateCompat);
            if (!this.n)
              return;
          }
          if (paramPlaybackStateCompat != null)
            break;
        }
        while (Build.VERSION.SDK_INT < 14);
        l.a(this.d, 0);
        l.a(this.d, 0L);
        return;
        if (Build.VERSION.SDK_INT >= 18)
          m.a(this.d, paramPlaybackStateCompat.a(), paramPlaybackStateCompat.b(), paramPlaybackStateCompat.d(), paramPlaybackStateCompat.h());
        while (Build.VERSION.SDK_INT >= 19)
        {
          n.a(this.d, paramPlaybackStateCompat.e());
          return;
          if (Build.VERSION.SDK_INT >= 14)
            l.a(this.d, paramPlaybackStateCompat.a());
        }
        if (Build.VERSION.SDK_INT >= 18)
        {
          m.a(this.d, paramPlaybackStateCompat.e());
          return;
        }
      }
      while (Build.VERSION.SDK_INT < 14);
      l.a(this.d, paramPlaybackStateCompat.e());
    }

    public void a(CharSequence paramCharSequence)
    {
      this.w = paramCharSequence;
      b(paramCharSequence);
    }

    public void a(String paramString, Bundle paramBundle)
    {
      b(paramString, paramBundle);
    }

    public void a(List<MediaSessionCompat.QueueItem> paramList)
    {
      this.v = paramList;
      b(paramList);
    }

    public void a(boolean paramBoolean)
    {
      if (paramBoolean == this.n);
      do
      {
        return;
        this.n = paramBoolean;
      }
      while (!f());
      a(this.s);
      a(this.t);
    }

    public boolean a()
    {
      return this.n;
    }

    public void b()
    {
      this.n = false;
      this.m = true;
      f();
      h();
    }

    public void b(int paramInt)
    {
      if (this.B != null)
        this.B.a(null);
      this.z = 1;
      a(new ParcelableVolumeInfo(this.z, this.A, 2, this.i.getStreamMaxVolume(this.A), this.i.getStreamVolume(this.A)));
    }

    public void b(PendingIntent paramPendingIntent)
    {
    }

    public MediaSessionCompat.Token c()
    {
      return this.f;
    }

    public void c(int paramInt)
    {
      this.x = paramInt;
    }

    public Object d()
    {
      return null;
    }

    public Object e()
    {
      return this.d;
    }

    private static final class a
    {
      public final String a;
      public final Bundle b;
      public final ResultReceiver c;

      public a(String paramString, Bundle paramBundle, ResultReceiver paramResultReceiver)
      {
        this.a = paramString;
        this.b = paramBundle;
        this.c = paramResultReceiver;
      }
    }

    class b extends b.a
    {
      b()
      {
      }

      public void a(int paramInt1, int paramInt2, String paramString)
      {
        MediaSessionCompat.d.a(MediaSessionCompat.d.this, paramInt1, paramInt2);
      }

      public void a(long paramLong)
      {
        MediaSessionCompat.d.a(MediaSessionCompat.d.this, 4, Long.valueOf(paramLong));
      }

      public void a(Uri paramUri, Bundle paramBundle)
        throws RemoteException
      {
        MediaSessionCompat.d.a(MediaSessionCompat.d.this, 18, paramUri, paramBundle);
      }

      public void a(RatingCompat paramRatingCompat)
        throws RemoteException
      {
        MediaSessionCompat.d.a(MediaSessionCompat.d.this, 12, paramRatingCompat);
      }

      public void a(a parama)
      {
        if (MediaSessionCompat.d.e(MediaSessionCompat.d.this));
        try
        {
          parama.a();
          return;
          MediaSessionCompat.d.f(MediaSessionCompat.d.this).register(parama);
          return;
        }
        catch (Exception localException)
        {
        }
      }

      public void a(String paramString, Bundle paramBundle)
        throws RemoteException
      {
        MediaSessionCompat.d.a(MediaSessionCompat.d.this, 2, paramString, paramBundle);
      }

      public void a(String paramString, Bundle paramBundle, MediaSessionCompat.ResultReceiverWrapper paramResultReceiverWrapper)
      {
        MediaSessionCompat.d.a(MediaSessionCompat.d.this, 15, new MediaSessionCompat.d.a(paramString, paramBundle, MediaSessionCompat.ResultReceiverWrapper.a(paramResultReceiverWrapper)));
      }

      public boolean a()
      {
        return (0x2 & MediaSessionCompat.d.d(MediaSessionCompat.d.this)) != 0;
      }

      public boolean a(KeyEvent paramKeyEvent)
      {
        if ((0x1 & MediaSessionCompat.d.d(MediaSessionCompat.d.this)) != 0);
        for (boolean bool = true; ; bool = false)
        {
          if (bool)
            MediaSessionCompat.d.a(MediaSessionCompat.d.this, 14, paramKeyEvent);
          return bool;
        }
      }

      public String b()
      {
        return MediaSessionCompat.d.g(MediaSessionCompat.d.this);
      }

      public void b(int paramInt1, int paramInt2, String paramString)
      {
        MediaSessionCompat.d.b(MediaSessionCompat.d.this, paramInt1, paramInt2);
      }

      public void b(long paramLong)
        throws RemoteException
      {
        MediaSessionCompat.d.a(MediaSessionCompat.d.this, 11, Long.valueOf(paramLong));
      }

      public void b(a parama)
      {
        MediaSessionCompat.d.f(MediaSessionCompat.d.this).unregister(parama);
      }

      public void b(String paramString, Bundle paramBundle)
        throws RemoteException
      {
        MediaSessionCompat.d.a(MediaSessionCompat.d.this, 3, paramString, paramBundle);
      }

      public String c()
      {
        return MediaSessionCompat.d.h(MediaSessionCompat.d.this);
      }

      public void c(String paramString, Bundle paramBundle)
        throws RemoteException
      {
        MediaSessionCompat.d.a(MediaSessionCompat.d.this, 13, paramString, paramBundle);
      }

      public PendingIntent d()
      {
        synchronized (MediaSessionCompat.d.i(MediaSessionCompat.d.this))
        {
          PendingIntent localPendingIntent = MediaSessionCompat.d.j(MediaSessionCompat.d.this);
          return localPendingIntent;
        }
      }

      public long e()
      {
        synchronized (MediaSessionCompat.d.i(MediaSessionCompat.d.this))
        {
          long l = MediaSessionCompat.d.d(MediaSessionCompat.d.this);
          return l;
        }
      }

      public ParcelableVolumeInfo f()
      {
        int i = 2;
        synchronized (MediaSessionCompat.d.i(MediaSessionCompat.d.this))
        {
          int j = MediaSessionCompat.d.b(MediaSessionCompat.d.this);
          int k = MediaSessionCompat.d.c(MediaSessionCompat.d.this);
          az localaz = MediaSessionCompat.d.a(MediaSessionCompat.d.this);
          if (j == i)
          {
            i = localaz.b();
            m = localaz.c();
            n = localaz.a();
            return new ParcelableVolumeInfo(j, k, i, m, n);
          }
          int m = MediaSessionCompat.d.k(MediaSessionCompat.d.this).getStreamMaxVolume(k);
          int n = MediaSessionCompat.d.k(MediaSessionCompat.d.this).getStreamVolume(k);
        }
      }

      public void g()
        throws RemoteException
      {
        MediaSessionCompat.d.a(MediaSessionCompat.d.this, 1);
      }

      public void h()
        throws RemoteException
      {
        MediaSessionCompat.d.a(MediaSessionCompat.d.this, 5);
      }

      public void i()
        throws RemoteException
      {
        MediaSessionCompat.d.a(MediaSessionCompat.d.this, 6);
      }

      public void j()
        throws RemoteException
      {
        MediaSessionCompat.d.a(MediaSessionCompat.d.this, 7);
      }

      public void k()
        throws RemoteException
      {
        MediaSessionCompat.d.a(MediaSessionCompat.d.this, 8);
      }

      public void l()
        throws RemoteException
      {
        MediaSessionCompat.d.a(MediaSessionCompat.d.this, 9);
      }

      public void m()
        throws RemoteException
      {
        MediaSessionCompat.d.a(MediaSessionCompat.d.this, 10);
      }

      public MediaMetadataCompat n()
      {
        return MediaSessionCompat.d.l(MediaSessionCompat.d.this);
      }

      public PlaybackStateCompat o()
      {
        return MediaSessionCompat.d.m(MediaSessionCompat.d.this);
      }

      public List<MediaSessionCompat.QueueItem> p()
      {
        synchronized (MediaSessionCompat.d.i(MediaSessionCompat.d.this))
        {
          List localList = MediaSessionCompat.d.n(MediaSessionCompat.d.this);
          return localList;
        }
      }

      public CharSequence q()
      {
        return MediaSessionCompat.d.o(MediaSessionCompat.d.this);
      }

      public Bundle r()
      {
        synchronized (MediaSessionCompat.d.i(MediaSessionCompat.d.this))
        {
          Bundle localBundle = MediaSessionCompat.d.p(MediaSessionCompat.d.this);
          return localBundle;
        }
      }

      public int s()
      {
        return MediaSessionCompat.d.q(MediaSessionCompat.d.this);
      }
    }

    private class c extends Handler
    {
      private static final int b = 1;
      private static final int c = 2;
      private static final int d = 3;
      private static final int e = 4;
      private static final int f = 5;
      private static final int g = 6;
      private static final int h = 7;
      private static final int i = 8;
      private static final int j = 9;
      private static final int k = 10;
      private static final int l = 11;
      private static final int m = 12;
      private static final int n = 13;
      private static final int o = 14;
      private static final int p = 15;
      private static final int q = 16;
      private static final int r = 17;
      private static final int s = 18;
      private static final int t = 127;
      private static final int u = 126;

      public c(Looper arg2)
      {
        super();
      }

      private void a(KeyEvent paramKeyEvent, MediaSessionCompat.a parama)
      {
        if ((paramKeyEvent == null) || (paramKeyEvent.getAction() != 0));
        label24: int i1;
        label140: int i2;
        label153: label304: label310: label316: 
        do
        {
          return;
          long l1;
          if (MediaSessionCompat.d.s(MediaSessionCompat.d.this) == null)
          {
            l1 = 0L;
            switch (paramKeyEvent.getKeyCode())
            {
            default:
              return;
            case 79:
            case 85:
              if ((MediaSessionCompat.d.s(MediaSessionCompat.d.this) != null) && (MediaSessionCompat.d.s(MediaSessionCompat.d.this).a() == 3))
              {
                i1 = 1;
                if ((0x204 & l1) == 0L)
                  break label304;
                i2 = 1;
                if ((l1 & 0x202) == 0L)
                  break label310;
              }
              break;
            case 126:
            case 127:
            case 87:
            case 88:
            case 86:
            case 90:
            case 89:
            }
          }
          for (int i3 = 1; ; i3 = 0)
          {
            if ((i1 == 0) || (i3 == 0))
              break label316;
            parama.b();
            return;
            l1 = MediaSessionCompat.d.s(MediaSessionCompat.d.this).e();
            break label24;
            if ((l1 & 0x4) == 0L)
              break;
            parama.a();
            return;
            if ((l1 & 0x2) == 0L)
              break;
            parama.b();
            return;
            if ((l1 & 0x20) == 0L)
              break;
            parama.c();
            return;
            if ((l1 & 0x10) == 0L)
              break;
            parama.d();
            return;
            if ((l1 & 1L) == 0L)
              break;
            parama.g();
            return;
            if ((l1 & 0x40) == 0L)
              break;
            parama.e();
            return;
            if ((l1 & 0x8) == 0L)
              break;
            parama.f();
            return;
            i1 = 0;
            break label140;
            i2 = 0;
            break label153;
          }
        }
        while ((i1 != 0) || (i2 == 0));
        parama.a();
      }

      public void a(int paramInt)
      {
        a(paramInt, null);
      }

      public void a(int paramInt, Object paramObject)
      {
        obtainMessage(paramInt, paramObject).sendToTarget();
      }

      public void a(int paramInt1, Object paramObject, int paramInt2)
      {
        obtainMessage(paramInt1, paramInt2, 0, paramObject).sendToTarget();
      }

      public void a(int paramInt, Object paramObject, Bundle paramBundle)
      {
        Message localMessage = obtainMessage(paramInt, paramObject);
        localMessage.setData(paramBundle);
        localMessage.sendToTarget();
      }

      public void handleMessage(Message paramMessage)
      {
        MediaSessionCompat.a locala = MediaSessionCompat.d.r(MediaSessionCompat.d.this);
        if (locala == null);
        KeyEvent localKeyEvent;
        Intent localIntent;
        do
        {
          return;
          switch (paramMessage.what)
          {
          default:
            return;
          case 1:
            locala.a();
            return;
          case 2:
            locala.a((String)paramMessage.obj, paramMessage.getData());
            return;
          case 3:
            locala.b((String)paramMessage.obj, paramMessage.getData());
            return;
          case 18:
            locala.a((Uri)paramMessage.obj, paramMessage.getData());
            return;
          case 4:
            locala.a(((Long)paramMessage.obj).longValue());
            return;
          case 5:
            locala.b();
            return;
          case 6:
            locala.g();
            return;
          case 7:
            locala.c();
            return;
          case 8:
            locala.d();
            return;
          case 9:
            locala.e();
            return;
          case 10:
            locala.f();
            return;
          case 11:
            locala.b(((Long)paramMessage.obj).longValue());
            return;
          case 12:
            locala.a((RatingCompat)paramMessage.obj);
            return;
          case 13:
            locala.c((String)paramMessage.obj, paramMessage.getData());
            return;
          case 14:
            localKeyEvent = (KeyEvent)paramMessage.obj;
            localIntent = new Intent("android.intent.action.MEDIA_BUTTON");
            localIntent.putExtra("android.intent.extra.KEY_EVENT", localKeyEvent);
          case 15:
          case 16:
          case 17:
          }
        }
        while (locala.a(localIntent));
        a(localKeyEvent, locala);
        return;
        MediaSessionCompat.d.a locala1 = (MediaSessionCompat.d.a)paramMessage.obj;
        locala.a(locala1.a, locala1.b, locala1.c);
        return;
        MediaSessionCompat.d.a(MediaSessionCompat.d.this, ((Integer)paramMessage.obj).intValue(), 0);
        return;
        MediaSessionCompat.d.b(MediaSessionCompat.d.this, ((Integer)paramMessage.obj).intValue(), 0);
      }
    }
  }

  public static abstract interface e
  {
    public abstract void a();
  }

  @Retention(RetentionPolicy.SOURCE)
  public static @interface f
  {
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.media.session.MediaSessionCompat
 * JD-Core Version:    0.6.2
 */