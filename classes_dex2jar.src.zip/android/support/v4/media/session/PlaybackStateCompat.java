package android.support.v4.media.session;

import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.os.SystemClock;
import android.support.annotation.y;
import android.text.TextUtils;
import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public final class PlaybackStateCompat
  implements Parcelable
{
  public static final long A = -1L;
  public static final Parcelable.Creator<PlaybackStateCompat> CREATOR = new t();
  public static final long a = 1L;
  public static final long b = 2L;
  public static final long c = 4L;
  public static final long d = 8L;
  public static final long e = 16L;
  public static final long f = 32L;
  public static final long g = 64L;
  public static final long h = 128L;
  public static final long i = 256L;
  public static final long j = 512L;
  public static final long k = 1024L;
  public static final long l = 2048L;
  public static final long m = 4096L;
  public static final long n = 8192L;
  public static final int o = 0;
  public static final int p = 1;
  public static final int q = 2;
  public static final int r = 3;
  public static final int s = 4;
  public static final int t = 5;
  public static final int u = 6;
  public static final int v = 7;
  public static final int w = 8;
  public static final int x = 9;
  public static final int y = 10;
  public static final int z = 11;
  private final int B;
  private final long C;
  private final long D;
  private final float E;
  private final long F;
  private final CharSequence G;
  private final long H;
  private List<CustomAction> I;
  private final long J;
  private final Bundle K;
  private Object L;

  private PlaybackStateCompat(int paramInt, long paramLong1, long paramLong2, float paramFloat, long paramLong3, CharSequence paramCharSequence, long paramLong4, List<CustomAction> paramList, long paramLong5, Bundle paramBundle)
  {
    this.B = paramInt;
    this.C = paramLong1;
    this.D = paramLong2;
    this.E = paramFloat;
    this.F = paramLong3;
    this.G = paramCharSequence;
    this.H = paramLong4;
    this.I = new ArrayList(paramList);
    this.J = paramLong5;
    this.K = paramBundle;
  }

  private PlaybackStateCompat(Parcel paramParcel)
  {
    this.B = paramParcel.readInt();
    this.C = paramParcel.readLong();
    this.E = paramParcel.readFloat();
    this.H = paramParcel.readLong();
    this.D = paramParcel.readLong();
    this.F = paramParcel.readLong();
    this.G = ((CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(paramParcel));
    this.I = paramParcel.createTypedArrayList(CustomAction.CREATOR);
    this.J = paramParcel.readLong();
    this.K = paramParcel.readBundle();
  }

  public static PlaybackStateCompat a(Object paramObject)
  {
    if ((paramObject == null) || (Build.VERSION.SDK_INT < 21))
      return null;
    List localList = v.h(paramObject);
    ArrayList localArrayList = null;
    if (localList != null)
    {
      localArrayList = new ArrayList(localList.size());
      Iterator localIterator = localList.iterator();
      while (localIterator.hasNext())
        localArrayList.add(CustomAction.a(localIterator.next()));
    }
    if (Build.VERSION.SDK_INT >= 22);
    for (Bundle localBundle = w.a(paramObject); ; localBundle = null)
    {
      PlaybackStateCompat localPlaybackStateCompat = new PlaybackStateCompat(v.a(paramObject), v.b(paramObject), v.c(paramObject), v.d(paramObject), v.e(paramObject), v.f(paramObject), v.g(paramObject), localArrayList, v.i(paramObject), localBundle);
      localPlaybackStateCompat.L = paramObject;
      return localPlaybackStateCompat;
    }
  }

  public int a()
  {
    return this.B;
  }

  public long b()
  {
    return this.C;
  }

  public long c()
  {
    return this.D;
  }

  public float d()
  {
    return this.E;
  }

  public int describeContents()
  {
    return 0;
  }

  public long e()
  {
    return this.F;
  }

  public List<CustomAction> f()
  {
    return this.I;
  }

  public CharSequence g()
  {
    return this.G;
  }

  public long h()
  {
    return this.H;
  }

  public long i()
  {
    return this.J;
  }

  @y
  public Bundle j()
  {
    return this.K;
  }

  public Object k()
  {
    if ((this.L != null) || (Build.VERSION.SDK_INT < 21))
      return this.L;
    List localList = this.I;
    ArrayList localArrayList = null;
    if (localList != null)
    {
      localArrayList = new ArrayList(this.I.size());
      Iterator localIterator = this.I.iterator();
      while (localIterator.hasNext())
        localArrayList.add(((CustomAction)localIterator.next()).a());
    }
    if (Build.VERSION.SDK_INT >= 22);
    for (this.L = w.a(this.B, this.C, this.D, this.E, this.F, this.G, this.H, localArrayList, this.J, this.K); ; this.L = v.a(this.B, this.C, this.D, this.E, this.F, this.G, this.H, localArrayList, this.J))
      return this.L;
  }

  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder("PlaybackState {");
    localStringBuilder.append("state=").append(this.B);
    localStringBuilder.append(", position=").append(this.C);
    localStringBuilder.append(", buffered position=").append(this.D);
    localStringBuilder.append(", speed=").append(this.E);
    localStringBuilder.append(", updated=").append(this.H);
    localStringBuilder.append(", actions=").append(this.F);
    localStringBuilder.append(", error=").append(this.G);
    localStringBuilder.append(", custom actions=").append(this.I);
    localStringBuilder.append(", active item id=").append(this.J);
    localStringBuilder.append("}");
    return localStringBuilder.toString();
  }

  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    paramParcel.writeInt(this.B);
    paramParcel.writeLong(this.C);
    paramParcel.writeFloat(this.E);
    paramParcel.writeLong(this.H);
    paramParcel.writeLong(this.D);
    paramParcel.writeLong(this.F);
    TextUtils.writeToParcel(this.G, paramParcel, paramInt);
    paramParcel.writeTypedList(this.I);
    paramParcel.writeLong(this.J);
    paramParcel.writeBundle(this.K);
  }

  public static final class CustomAction
    implements Parcelable
  {
    public static final Parcelable.Creator<CustomAction> CREATOR = new u();
    private final String a;
    private final CharSequence b;
    private final int c;
    private final Bundle d;
    private Object e;

    private CustomAction(Parcel paramParcel)
    {
      this.a = paramParcel.readString();
      this.b = ((CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(paramParcel));
      this.c = paramParcel.readInt();
      this.d = paramParcel.readBundle();
    }

    private CustomAction(String paramString, CharSequence paramCharSequence, int paramInt, Bundle paramBundle)
    {
      this.a = paramString;
      this.b = paramCharSequence;
      this.c = paramInt;
      this.d = paramBundle;
    }

    public static CustomAction a(Object paramObject)
    {
      if ((paramObject == null) || (Build.VERSION.SDK_INT < 21))
        return null;
      CustomAction localCustomAction = new CustomAction(v.a.a(paramObject), v.a.b(paramObject), v.a.c(paramObject), v.a.d(paramObject));
      localCustomAction.e = paramObject;
      return localCustomAction;
    }

    public Object a()
    {
      if ((this.e != null) || (Build.VERSION.SDK_INT < 21))
        return this.e;
      this.e = v.a.a(this.a, this.b, this.c, this.d);
      return this.e;
    }

    public String b()
    {
      return this.a;
    }

    public CharSequence c()
    {
      return this.b;
    }

    public int d()
    {
      return this.c;
    }

    public int describeContents()
    {
      return 0;
    }

    public Bundle e()
    {
      return this.d;
    }

    public String toString()
    {
      return "Action:mName='" + this.b + ", mIcon=" + this.c + ", mExtras=" + this.d;
    }

    public void writeToParcel(Parcel paramParcel, int paramInt)
    {
      paramParcel.writeString(this.a);
      TextUtils.writeToParcel(this.b, paramParcel, paramInt);
      paramParcel.writeInt(this.c);
      paramParcel.writeBundle(this.d);
    }

    public static final class a
    {
      private final String a;
      private final CharSequence b;
      private final int c;
      private Bundle d;

      public a(String paramString, CharSequence paramCharSequence, int paramInt)
      {
        if (TextUtils.isEmpty(paramString))
          throw new IllegalArgumentException("You must specify an action to build a CustomAction.");
        if (TextUtils.isEmpty(paramCharSequence))
          throw new IllegalArgumentException("You must specify a name to build a CustomAction.");
        if (paramInt == 0)
          throw new IllegalArgumentException("You must specify an icon resource id to build a CustomAction.");
        this.a = paramString;
        this.b = paramCharSequence;
        this.c = paramInt;
      }

      public a a(Bundle paramBundle)
      {
        this.d = paramBundle;
        return this;
      }

      public PlaybackStateCompat.CustomAction a()
      {
        return new PlaybackStateCompat.CustomAction(this.a, this.b, this.c, this.d, null);
      }
    }
  }

  @Retention(RetentionPolicy.SOURCE)
  public static @interface a
  {
  }

  public static final class b
  {
    private final List<PlaybackStateCompat.CustomAction> a = new ArrayList();
    private int b;
    private long c;
    private long d;
    private float e;
    private long f;
    private CharSequence g;
    private long h;
    private long i = -1L;
    private Bundle j;

    public b()
    {
    }

    public b(PlaybackStateCompat paramPlaybackStateCompat)
    {
      this.b = PlaybackStateCompat.a(paramPlaybackStateCompat);
      this.c = PlaybackStateCompat.b(paramPlaybackStateCompat);
      this.e = PlaybackStateCompat.c(paramPlaybackStateCompat);
      this.h = PlaybackStateCompat.d(paramPlaybackStateCompat);
      this.d = PlaybackStateCompat.e(paramPlaybackStateCompat);
      this.f = PlaybackStateCompat.f(paramPlaybackStateCompat);
      this.g = PlaybackStateCompat.g(paramPlaybackStateCompat);
      if (PlaybackStateCompat.h(paramPlaybackStateCompat) != null)
        this.a.addAll(PlaybackStateCompat.h(paramPlaybackStateCompat));
      this.i = PlaybackStateCompat.i(paramPlaybackStateCompat);
      this.j = PlaybackStateCompat.j(paramPlaybackStateCompat);
    }

    public b a(int paramInt, long paramLong, float paramFloat)
    {
      return a(paramInt, paramLong, paramFloat, SystemClock.elapsedRealtime());
    }

    public b a(int paramInt, long paramLong1, float paramFloat, long paramLong2)
    {
      this.b = paramInt;
      this.c = paramLong1;
      this.h = paramLong2;
      this.e = paramFloat;
      return this;
    }

    public b a(long paramLong)
    {
      this.d = paramLong;
      return this;
    }

    public b a(Bundle paramBundle)
    {
      this.j = paramBundle;
      return this;
    }

    public b a(PlaybackStateCompat.CustomAction paramCustomAction)
    {
      if (paramCustomAction == null)
        throw new IllegalArgumentException("You may not add a null CustomAction to PlaybackStateCompat.");
      this.a.add(paramCustomAction);
      return this;
    }

    public b a(CharSequence paramCharSequence)
    {
      this.g = paramCharSequence;
      return this;
    }

    public b a(String paramString1, String paramString2, int paramInt)
    {
      return a(new PlaybackStateCompat.CustomAction(paramString1, paramString2, paramInt, null, null));
    }

    public PlaybackStateCompat a()
    {
      return new PlaybackStateCompat(this.b, this.c, this.d, this.e, this.f, this.g, this.h, this.a, this.i, this.j, null);
    }

    public b b(long paramLong)
    {
      this.f = paramLong;
      return this;
    }

    public b c(long paramLong)
    {
      this.i = paramLong;
      return this;
    }
  }

  @Retention(RetentionPolicy.SOURCE)
  public static @interface c
  {
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.media.session.PlaybackStateCompat
 * JD-Core Version:    0.6.2
 */