package android.support.v4.os;

import android.os.Bundle;
import android.os.Handler;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.os.RemoteException;

public class ResultReceiver
  implements Parcelable
{
  public static final Parcelable.Creator<ResultReceiver> CREATOR = new m();
  final boolean c;
  final Handler d;
  g e;

  public ResultReceiver(Handler paramHandler)
  {
    this.c = true;
    this.d = paramHandler;
  }

  ResultReceiver(Parcel paramParcel)
  {
    this.c = false;
    this.d = null;
    this.e = g.a.a(paramParcel.readStrongBinder());
  }

  protected void a(int paramInt, Bundle paramBundle)
  {
  }

  public void b(int paramInt, Bundle paramBundle)
  {
    if (this.c)
      if (this.d != null)
        this.d.post(new b(paramInt, paramBundle));
    while (this.e == null)
    {
      return;
      a(paramInt, paramBundle);
      return;
    }
    try
    {
      this.e.a(paramInt, paramBundle);
      return;
    }
    catch (RemoteException localRemoteException)
    {
    }
  }

  public int describeContents()
  {
    return 0;
  }

  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    try
    {
      if (this.e == null)
        this.e = new a();
      paramParcel.writeStrongBinder(this.e.asBinder());
      return;
    }
    finally
    {
    }
  }

  class a extends g.a
  {
    a()
    {
    }

    public void a(int paramInt, Bundle paramBundle)
    {
      if (ResultReceiver.this.d != null)
      {
        ResultReceiver.this.d.post(new ResultReceiver.b(ResultReceiver.this, paramInt, paramBundle));
        return;
      }
      ResultReceiver.this.a(paramInt, paramBundle);
    }
  }

  class b
    implements Runnable
  {
    final int a;
    final Bundle b;

    b(int paramBundle, Bundle arg3)
    {
      this.a = paramBundle;
      Object localObject;
      this.b = localObject;
    }

    public void run()
    {
      ResultReceiver.this.a(this.a, this.b);
    }
  }
}

/* Location:           D:\fanbianyi\fanbianyi\dex2jar-0.0.9.15\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.os.ResultReceiver
 * JD-Core Version:    0.6.2
 */